# MAS Education POC — GCSE Maths Socratic Tutor

A working proof-of-concept for a **Multi-Agent System (MAS)** that tutors GCSE Maths students using Socratic questioning, RAG-grounded content, Bayesian Knowledge Tracing (BKT), and a Neo4j Knowledge Graph (KG) to track curriculum structure and mastery.

**Last updated:** 5 March 2026 — Math verification safety net added (Phases A/B/C): sympy cross-checks on Assessment scoring, Tutor assertive claims verified pre-delivery, all 41 curriculum files audited (0 errors found). See [DEVELOPMENT_LOG.md](DEVELOPMENT_LOG.md) for full history.

---

## What It Demonstrates

| Capability | Implementation |
|---|---|
| Multi-agent coordination | 5 specialised agents via LangGraph 7-node session graph |
| RAG-grounded tutoring | ChromaDB (146 chunks, 41 topics, all 4 quals) + qwen3-embedding:8b, HyDE + multi-query retrieval |
| LLM cross-encoder reranking | Claude Haiku scores all retrieved chunks 0–10 in a single batch call; relevance threshold filter |
| KG-guided retrieval | Neo4j [:HAS_RESOURCE] edges → preferred chunks surfaced before semantic re-ranking |
| Learning dashboard | `/dashboard` — Cytoscape.js knowledge map, mastery progress bars, "What's Next" LO cards |
| Mastery tracking | Bayesian Knowledge Tracing (BKT), parameters per LO in Neo4j |
| Knowledge Graph | 4 qualifications, 19 topics, 75 subtopics, 191 LOs, spiral chains via [:DEEPENS] edges |
| Multi-qualification scope | IGCSE 0580, IGCSE 0606, AS-Level 9709, A-Level 9231 — prerequisite chains across quals |
| Dialogue management | 5-state engagement machine (EXPLORING → STUCK → BREAKTHROUGH → CONSOLIDATING → MASTERED) |
| Constitutional AI | C4 fallback — no RAG results → teacher escalation, never hallucination |
| Math verification | sympy cross-checks on Assessment scoring and Tutor assertive claims; curriculum audit (0 errors in 41 files) |
| A2A protocol | BeeAI AgentStack server (port 8000) for agent-to-agent communication |
| Browser UI | FastAPI chat page (port 8080) — zero new dependencies |

---

## Architecture

```
Student input
      │
      ▼
┌─────────────────────────────────────────────────────────────────┐
│                    LangGraph Orchestrator                        │
│                                                                  │
│  session_init ──► route_intent ──┬──► tutoring_node             │
│       │                           └──► assessment_node          │
│  [Neo4j: get_next_lo()]                      │                   │
│                                         reflect_node             │
│                                              │                   │
│                                         deliver_node             │
│                                              │                   │
│                                         log_update_node          │
└─────────────────────────────────────────────────────────────────┘
      │
      ▼
┌────────────────┐  ┌──────────────┐  ┌───────────────────────────┐
│  TutorAgent    │  │ AssessAgent  │  │ PlanningAgent             │
│  RAG + C4      │  │ BKT scoring  │  │ Neo4j Cypher routing      │
│  KG-guided     │  │ → Neo4j      │  │ get_next_lo() / advance() │
└────────────────┘  └──────────────┘  └───────────────────────────┘
      │                    │
      ▼                    ▼
┌─────────────────────────────────────────────────────────────────┐
│  ChromaDB poc_curriculum       │  Neo4j Knowledge Graph         │
│  146 chunks, 41 topics         │  4 quals, 191 LOs              │
│  qwen3-embedding:8b            │  77 Concepts, DEEPENS chains   │
│  HAS_RESOURCE edges → KG boost │  HAS_MASTERY edges per learner │
├────────────────────────────────┴────────────────────────────────┤
│  SQLite poc_learner.db                                           │
│  session_log, audit_events (structural data stays in Neo4j)     │
└─────────────────────────────────────────────────────────────────┘
      │
      ▼
┌──────────────────────┐  ┌──────────────┐
│ DialogueTracker      │  │ MonitorAgent │
│ 5-state machine      │  │ cost/audit   │
└──────────────────────┘  └──────────────┘
```

### Agent Responsibilities

| Agent | File | Role |
|---|---|---|
| **Tutor** | `agents/tutor_agent.py` | RAG-grounded Socratic responses; KG-guided retrieval via `lo_id`; C4 constitutional fallback; sympy assertive-claim check with one correction regeneration |
| **Assessment** | `agents/assessment_agent.py` | BKT mastery scoring; writes [:HAS_MASTERY] edges to Neo4j; sympy cross-check (LLM/sympy disagreement → PARTIAL) |
| **Planning** | `agents/planning_agent.py` | Neo4j Cypher pathway routing; advancement check (mastery ≥ 0.85 + 5 evidence) |
| **Dialogue** | `agents/dialogue_agent.py` | 5-state engagement tracker; stuck detection (3 × < 5 words) |
| **Monitor** | `agents/monitor_agent.py` | API cost tracking; session audit log; never blocks response path |

---

## Neo4j Knowledge Graph

The KG is the structural backbone of the curriculum. It was built across 5 phases.

### Graph Statistics (as of 4 Mar 2026)

| Node Type | Count | Description |
|---|---|---|
| Qualification | 4 | 0580 (IGCSE), 0606 (Add. Maths), 9709 (AS), 9231 (A-Level) |
| Topic | 19 | e.g., Algebra and Graphs, Geometry and Trigonometry |
| Subtopic | 75 | e.g., Equations and Inequalities, Trigonometry |
| LearningObjective | 191 | Granular, BKT-parameterised LOs (difficulty-scaled) |
| Concept | 77 | Abstract mathematical concepts (e.g., QuadraticFactoring) |
| ConceptInstance | 114 | Qual-level manifestations of concepts |
| Resource | 71 | ChromaDB chunk references (Phase 5) |

| Relationship | Count | Description |
|---|---|---|
| [:HAS_MASTERY] | Runtime | Per-learner mastery state (p_mastery, evidence_count, mastered) |
| [:HAS_RESOURCE] | 200 | LO → ChromaDB chunk ID (KG-guided RAG) |
| [:DEEPENS] | 20 | Cross-qualification concept spiral chains |
| [:PREREQUISITE_OF] | Runtime | Hard/soft prerequisites between LOs |

### Spiral Chains (DEEPENS edges)

5 cross-qualification spirals connect IGCSE → AS → A-Level concepts:
- Differentiation, Integration, Quadratic Equations, Sequences And Series, Trigonometric Identities

### Accessing Neo4j

```bash
cd ~/projects/mas_education_poc
docker compose -f docker-compose.neo4j.yml up -d   # start Neo4j
# Browser UI: http://localhost:7474  (credentials: neo4j / mas_education_poc_dev)
# Bolt port: 7687
```

---

## RAG Pipeline

### Current Coverage

| Qualification | Topics | Chunks |
|---|---|---|
| 0580 IGCSE Maths | 26 (geometry, algebra, number, statistics — all areas) | 79 |
| 0606 Additional Maths | 5 (functions, polynomial algebra, logs/exponentials, trigonometry, calculus) | 21 |
| 9709 AS/A Level Maths | 6 (algebra, functions/coord geometry, sequences/series, trigonometry, calculus, vectors) | 28 |
| 9231 Further Maths | 4 (complex numbers, further matrices, further calculus, further DEs) | 18 |
| **Total** | **41 topics** | **146 chunks** |

### KG-Guided Retrieval

When the tutor has a current LO ID, it follows `[:HAS_RESOURCE]` edges in Neo4j to get chunk IDs pre-matched to that LO. These are floated to the top before re-ranking — ensuring curriculum-relevant content for the student's current LO. KG-preferred chunks also bypass the relevance threshold filter.

### Pipeline Stages

1. **Query Enhancement** — Claude generates HyDE excerpt + 2 reformulations (4 variants total)
2. **Multi-query retrieval** — Each variant queries ChromaDB; results deduplicated
3. **KG boost** — HAS_RESOURCE-linked chunks promoted to front (if lo_id provided)
4. **LLM cross-encoder reranking** — Claude Haiku scores all chunks 0–10 in a single batch call; normalised to [0, 1]; falls back to term-overlap on API failure
5. **Relevance threshold filter** — Chunks below `RELEVANCE_THRESHOLD` (default 0.15) dropped; if all filtered, hard C4 fallback triggers

---

## File Structure

```
mas_education_poc/
├── DEVELOPMENT_LOG.md       ← Full iterative development history (all phases + sessions)
├── BUILD_PLAN.md            ← Original build plan
├── KG_PLANNING_DOCUMENT.md  ← Full Neo4j KG design document
├── AGENT_ARCHITECTURE_REPORT.md  ← Agent design reference
├── USER_GUIDE.md            ← End-user guide for the chat UI
│
├── main.py                  # BeeAI AgentStack server — A2A protocol on port 8000
├── demo.py                  # CLI interactive demo — no server needed
├── chat_ui.py               # FastAPI browser chat UI on port 8080
├── dashboard.py             # Learning progress dashboard — /dashboard route
├── start.sh / stop.sh / status.sh  # Chat UI management scripts
├── pyproject.toml           # uv project (Python 3.11)
├── .env                     # ANTHROPIC_API_KEY + Neo4j credentials
│
├── agents/
│   ├── tutor_agent.py       # Socratic tutor: RAG + C4 + KG-guided retrieval (lo_id)
│   ├── assessment_agent.py  # BKT scoring → writes [:HAS_MASTERY] to Neo4j
│   ├── planning_agent.py    # Neo4j Cypher routing: get_next_lo(), check_advancement()
│   ├── dialogue_agent.py    # Engagement state machine (5 states)
│   └── monitor_agent.py     # Cost tracking and session audit
│
├── orchestrator/
│   └── poc_orchestrator.py  # LangGraph 7-node session graph
│
├── rag/
│   ├── ingest.py            # Chunk → embed (qwen3-embedding:8b) → upsert to ChromaDB
│   ├── retrieve.py          # HyDE + multi-query + KG boost → top-4 with citations
│   └── math_verify.py       # sympy verification: ComputationResult, verify_response(), verify_tutor_claims()
│
├── db/
│   ├── kg.py                # Neo4j driver: kg_session(), BKT helpers, HAS_MASTERY
│   ├── schema.cypher        # Neo4j constraints + indexes (incl. Resource)
│   ├── poc_schema.sql       # SQLite: session_log, audit_events
│   ├── init_db.py           # SQLite seed (idempotent)
│   └── db.py                # SQLite session/audit logging
│
├── scripts/
│   ├── ingest_curriculum.py # YAML syllabus → Neo4j graph (Phases 1-3)
│   ├── extract_concepts.py  # LLM concept extraction per qualification (Phase 2)
│   ├── derive_deepens.py    # DEEPENS edge derivation from ConceptInstance chains (Phase 3)
│   ├── link_resources.py    # Phase 5: LO → ChromaDB chunk via HAS_RESOURCE edges
│   └── audit_curriculum.py  # Phase C: sympy audit of all curriculum files (run standalone)
│
├── curriculum_data/         # 41 Markdown files — all 4 qualifications
│   ├── geometry_*.md        # 0580: Angle properties, trig, mensuration, transformations, etc.
│   ├── algebra_*.md         # 0580: Expressions, sequences, graphs, functions, etc.
│   ├── number_*.md          # 0580: Powers, ratio, interest, fractions, estimation, etc.
│   ├── statistics_*.md      # 0580: Probability, measures, representation
│   ├── 0606_*.md            # IGCSE Additional Maths (5 topics)
│   ├── 9709_*.md            # AS/A Level Maths (6 topics)
│   └── 9231_*.md            # Further Maths (4 topics)
│
├── data/qualifications/     # YAML curriculum files (source for Neo4j ingestion)
│   ├── igcse_0580.yaml
│   ├── igcse_0606.yaml
│   ├── alevel_9709.yaml
│   └── alevel_9231.yaml
│
├── syllabuses/              # Source PDFs for each qualification
└── neo4j/                   # Neo4j data directory (mounted by docker-compose.neo4j.yml)
```

---

## How to Run

### Prerequisites

1. `.env` must have `ANTHROPIC_API_KEY` and Neo4j credentials
2. Ollama running locally with `qwen3-embedding:8b`
3. Neo4j container running: `docker compose -f docker-compose.neo4j.yml up -d`

### Option 1: CLI Demo (fastest)

```bash
cd ~/projects/mas_education_poc
uv run python demo.py
```

Type your question. `summary` for cost/turn report. `quit` or Ctrl+C to exit.

> **Note:** `demo.py` uses the SQLite-backed legacy routing for the CLI demo.
> The Neo4j-backed routing is active in the full orchestrator (`chat_ui.py`).

### Option 2: Browser Chat UI (recommended for demos)

```bash
cd ~/projects/mas_education_poc
./start.sh        # start in background (logs to chat_ui.log)
./status.sh       # check if running
./stop.sh         # stop
# Open http://localhost:8080 in browser
```

Features:
- Chat bubbles: white (you) / blue (tutor)
- Engagement state badge (EXPLORING / STUCK / BREAKTHROUGH)
- Mastery progress bar per LO
- Citations shown below tutor responses
- Type `summary` for session stats

### Option 3: BeeAI A2A Server

```bash
cd ~/projects/mas_education_poc
uv run python main.py
# A2A endpoint on port 8000
```

### Re-ingesting Curriculum (if files change)

```bash
uv run python rag/ingest.py curriculum_data   # idempotent
```

### Re-linking KG Resources (if curriculum changes)

```bash
uv run python scripts/link_resources.py --qual 0580   # re-links HAS_RESOURCE edges
uv run python scripts/link_resources.py --all          # all qualifications
```

---

## Key Technical Decisions

### C4 Constitutional Principle
The Tutor Agent will **never hallucinate**. If RAG retrieval returns no relevant chunks, the response escalates to "please ask your teacher" and logs a `c4_fallback` audit event. This is a hard constraint — no amount of prompt pressure can override it.

### BKT on Neo4j (Phase 4+)
BKT parameters (`p_learn`, `p_slip`, `p_guess`, `p_init`) are stored on each `LearningObjective` node, difficulty-scaled during curriculum ingestion. Mastery state lives in `[:HAS_MASTERY]` edges. A student advances when mastery ≥ **0.85** AND evidence ≥ **5**. This is checked via Cypher after every Assessment Agent update.

### Neo4j Planning vs SQLite Planning
The legacy `poc_learner.db` SQLite schema (8 topics) is still used by `demo.py`. The Neo4j KG (191 LOs, 4 qualifications) backs the full orchestrator via `chat_ui.py`. Both coexist without conflict — SQLite only stores session logs and audit events in the Neo4j-backed path.

### KG-Guided RAG
`retrieve()` accepts an optional `lo_id`. When present, it queries Neo4j for `[:HAS_RESOURCE]`-linked chunk IDs and floats them to the top of the result list before re-ranking. This is an additive boost — semantic search still runs, ensuring fallback if KG links are suboptimal.

### Single BeeAI Agent Constraint
BeeAI AgentStack `Server()` raises `ValueError` if `@server.agent()` is called more than once. The full MAS runs internally via LangGraph; `main.py` exposes a single `MAS Tutor` agent to the A2A network.

---

## Build Summary

### POC Stages (23 Feb 2026 — all on one day)

| Stage | What Was Built |
|---|---|
| 1 | Environment: uv, Python 3.11, agentstack-sdk, langgraph, anthropic, chromadb |
| 2 | RAG pipeline: curriculum ingestion, HyDE retrieval, ChromaDB `poc_curriculum` collection |
| 3 | SQLite schema: 5 tables, BKT parameters, 8 topic seed data |
| 4 | Tutor + Assessment agents: RAG-grounded Socratic tutor, BKT scoring |
| 5 | Planning + Dialogue + Monitor agents: topic ladder, engagement machine, cost tracking |
| 6 | LangGraph orchestrator: 7-node session graph, conditional intent routing |
| 7 | BeeAI integration: A2A server on port 8000, end-to-end DB writes confirmed |

### Neo4j KG Phases (23–24 Feb 2026)

| Phase | What Was Built |
|---|---|
| 0 | Docker Neo4j 5.x, `db/kg.py` driver, `db/schema.cypher` constraints and indexes |
| 1 | YAML curriculum → `scripts/ingest_curriculum.py` → Qualification/Topic/Subtopic/LO nodes for all 4 quals |
| 2 | `scripts/extract_concepts.py` (LLM extraction) → 77 Concepts, 114 ConceptInstances, TEACHES/INSTANCE_OF edges |
| 3 | `scripts/derive_deepens.py` → 20 DEEPENS edges, 5 spiral chains, cross-qual prerequisite edges |
| 4 | `agents/planning_agent.py` and `agents/assessment_agent.py` migrated to Neo4j; BKT reads from LO node properties; [:HAS_MASTERY] edges written at runtime |
| 5 | 22 new curriculum markdown files (all 0580 topic areas); 79 ChromaDB chunks; `scripts/link_resources.py`; 200 [:HAS_RESOURCE] edges; KG-guided retrieval in `retrieve()` |

### Session: 4 March 2026

| Improvement | What Changed |
|---|---|
| Dashboard | `dashboard.py` — `/dashboard` route with Cytoscape.js knowledge map, mastery bars, "What's Next" LOs |
| Topic stability | `session_init()` now preserves `current_topic` across turns; only queries Neo4j on first turn |
| RAG coverage | 15 new curriculum files for 0606/9709/9231; ChromaDB 79 → 146 chunks; all 191 LOs now covered |
| Relevance threshold | `RELEVANCE_THRESHOLD=0.15` in `retrieve()` — filters low-score chunks; triggers hard C4 fallback |
| LLM cross-encoder | `_llm_rerank()` — Claude Haiku scores chunks 0–10 in single batch call; replaces term-overlap Stage 3 |

### Session: 5 March 2026 — Math Verification Safety Net

| Phase | What Changed |
|---|---|
| **Phase A — Assessment** | `rag/math_verify.py` (new): sympy `verify_response()`. Assessment Agent cross-checks LLM verdict — disagreement yields PARTIAL score |
| **Phase B — Tutor** | `verify_tutor_claims()` added to `math_verify.py`. Tutor's assertive solution claims verified pre-delivery. Provably wrong → one correction regeneration. Exploratory Socratic language excluded |
| **Phase C — Curriculum audit** | `scripts/audit_curriculum.py` (new): sympy audit of all 41 curriculum files. Result: **78 PASS, 0 FAIL, 44 SKIP** — all content confirmed mathematically correct. `AUDIT_REPORT.md` written to project root |

---

## Knowledge Graph Scope

This POC is built around **4 Cambridge Mathematics qualifications** (IGCSE 0580, IGCSE 0606,
AS-Level 9709, A-Level 9231). The underlying Neo4j graph has been expanded by the
[syllabus-pipeline](https://github.com/tgs21/syllabus-pipeline) batch ingestion to include
**102 qualifications** and **8,222 LOs** across IGCSE and A-Level subjects, but the agents
and RAG system in this POC are tuned for the 4-mathematics-qual scope.

The product-agnostic ontology (12 Domains → 39 Branches → 123 Areas → 483 Concepts) is
fully seeded — see the [knowledge-graph](https://github.com/tgs21/knowledge-graph) repo.

---

## Current Limitations

**By design (POC scope):**
- Single learner `demo-student-001` — no multi-user session management
- In-memory session state — restarting the server resets conversation history
- Intent classification is rule-based (not LLM-based)
- BeeAI `/ui` requires the Platform binary — use `chat_ui.py` instead

**Technical debt to address for MVP:**
- `demo.py` still uses the legacy 8-topic SQLite knowledge graph, not Neo4j
- No streaming responses in `chat_ui.py`
- No authentication for real student use
- Assessment Agent self-reflection loop (scaffold in place, 10% divergence trigger wired, but self-reflection call not yet implemented)
- HAS_RESOURCE links auto-generated by vector similarity — would benefit from human review
- DeBERTa NLI faithfulness check (deferred from RAG pipeline — currently only LLM cross-encoder + threshold)
- math_verify Phase B only fires on assertive equation-solution claims — numeric arithmetic in Tutor responses (e.g. "4 × 8 = 32") not yet checked

---

## Environment

```
Project:          ~/projects/mas_education_poc/
Neo4j browser:    http://localhost:7474  (neo4j / mas_education_poc_dev)
Neo4j bolt:       bolt://localhost:7687
Chat UI:          http://localhost:8080
BeeAI server:     http://localhost:8000
ChromaDB:         ~/.pai/rag/chromadb  (collection: poc_curriculum)
SQLite:           ~/projects/mas_education_poc/poc_learner.db (session/audit logs)
Embedding model:  qwen3-embedding:8b (Ollama)
LLM primary:      claude-sonnet-4-6 (Anthropic API)
LLM for KG:       claude-haiku-4-5-20251001 (avoids 529 errors on the same key)
```
