# MAS Education POC — User Guide

> A proof-of-concept GCSE Maths Socratic Tutor built on a 5-agent Multi-Agent System (MAS). This guide covers everything you need to use, run, demo, and understand the system.

**Last updated:** 13 June 2026
**Status:** Live at https://mas-tutor.com ✅ | Local development ✅

---

## Contents

1. [What This Is](#1-what-this-is)
2. [Live Service (mas-tutor.com)](#2-live-service-mas-tutorcom)
3. [Running Locally](#3-running-locally)
4. [Browser UI Walkthrough](#4-browser-ui-walkthrough)
5. [Key Concepts](#5-key-concepts)
6. [Example Conversation](#6-example-conversation)
7. [Known Limitations](#7-known-limitations)
8. [Troubleshooting](#8-troubleshooting)
9. [Appendix: Environment Variables](#appendix-environment-variables)

---

## 1. What This Is

The MAS Education POC is a working demonstration of a multi-agent AI tutoring system for GCSE Maths. Rather than a single AI answering questions, five specialised agents collaborate behind the scenes:

- A **Tutor Agent** that asks Socratic questions instead of giving direct answers
- An **Assessment Agent** that tracks what the student actually understands (not just what they say)
- A **Planning Agent** that decides which topic to work on next
- A **Dialogue Agent** that detects when a student is stuck and intervenes
- A **Monitor Agent** that tracks API cost and logs everything for audit

The agents are coordinated by a **LangGraph orchestrator** and grounded in real GCSE curriculum content via a **RAG pipeline**. Mastery is tracked using **Bayesian Knowledge Tracing (BKT)** — a probabilistic model used in real educational software.

**What it demonstrates for Cambridge colleagues:**
- How multi-agent coordination differs from a single-agent chatbot
- How AI can be constrained to never give ungrounded answers (the C4 constitutional principle)
- How mastery tracking can be mathematically principled, not just conversational
- How a Socratic teaching approach can be operationalised in an LLM
- How pedagogical adaptation works in practice: distress triage, resistance detection, ability-paced progression

---

## 2. Live Service (mas-tutor.com)

The tutor is live and accessible at **https://mas-tutor.com** — no setup required.

### 2.1 Accessing the Tutor

Open **https://mas-tutor.com** in any browser. You'll see a chat interface. Type a GCSE Maths question to begin.

Each browser session is automatically assigned a unique learner ID. Your mastery progress and conversation history persist across page refreshes within the same session.

### 2.2 LLM Provider

The live service uses **OpenRouter** as the LLM gateway, with `claude-sonnet-4-6` as the primary model. This allows resilient fallback routing without direct Anthropic API dependency.

### 2.3 Rate Limits (Production)

The live service enforces the following rate limits per IP:

| Endpoint | Limit |
|---|---|
| `/chat` | 20 requests / minute |
| `/chat` | 200 requests / hour |
| `/chat` | 1,000 requests / day |

These limits apply per-IP. Normal tester usage (5–15 messages per session) will not approach any limit.

### 2.4 Admin Access (Tailscale Only)

Admin endpoints are restricted to the Tailscale network:

| Endpoint | Purpose |
|---|---|
| `/admin` | Session overview dashboard |
| `/admin/metrics` | Aggregate usage metrics |
| `/admin/session/{id}` | Detailed session audit log |

---

## 3. Running Locally

Use the local setup when developing, testing new features, or demoing without a live internet connection.

### 3.1 Prerequisites

**OpenRouter API Key**

The system uses [OpenRouter](https://openrouter.io) as the LLM provider. Set `OPENROUTER_API_KEY` in your `.env` file.

```bash
cd ~/projects/mas_education_poc
cp .env.template .env
# Edit .env: set OPENROUTER_API_KEY=sk-or-v1-...
```

> **Note:** A direct `ANTHROPIC_API_KEY` can also be used for local development by setting `LLM_PRIMARY=claude-sonnet-4-6` and providing the key. OpenRouter is preferred — it handles model routing and fallback automatically.

**Ollama (for local RAG embeddings)**

The RAG pipeline uses a local embedding model. You need Ollama running with `nomic-embed-text` installed.

```bash
# Check Ollama is running
curl http://localhost:11434/api/tags

# Install embedding model if needed
ollama pull nomic-embed-text
```

### 3.2 Quick Start

```bash
cd ~/projects/mas_education_poc
uv run python chat_ui.py
# Open http://localhost:8080 in your browser
```

### 3.3 All Run Modes

**Option 1: Browser Chat UI** *(recommended for demos)*

```bash
cd ~/projects/mas_education_poc
uv run python chat_ui.py
# Open http://localhost:8080
# Stop: fuser -k 8080/tcp
```

**Option 2: CLI Demo** *(no browser needed)*

```bash
cd ~/projects/mas_education_poc
uv run python demo.py
```

During the session:
- Type a GCSE Maths question and press Enter
- Type `summary` to see session cost and turn count
- Type `quit` or Ctrl+C to exit

**Option 3: BeeAI A2A Server** *(agent-to-agent integration)*

```bash
cd ~/projects/mas_education_poc
uv run python main.py
# Agent card: http://localhost:8000/.well-known/agent-card.json
```

> **Note:** The BeeAI Platform `/ui` requires the BeeAI binary, which is not included. Use `chat_ui.py` for browser access.

---

## 4. Browser UI Walkthrough

### Chat Window

- **White bubbles (right)** — your messages
- **Blue bubbles (left)** — tutor responses
- A typing indicator appears while the agents are processing

### Engagement State Badge

Shows the **Dialogue Agent's** 5-state engagement machine:

| State | Meaning |
|---|---|
| `EXPLORING` | Student is actively engaging |
| `STUCK` | 3+ consecutive very short responses (< 5 words) |
| `BREAKTHROUGH` | Shift detected from stuck to understanding |
| `CONSOLIDATING` | Student is reinforcing understanding |
| `MASTERED` | BKT mastery ≥ 0.85 with ≥ 5 correct evidence events |

When `STUCK` is detected, the tutor automatically receives an intervention prompt on the next turn, switching to a more open-ended approach.

### Mastery Progress Bar

Shows the BKT mastery probability (0–100%) for the current topic. Updates after each exchange where the Assessment Agent scores the student's response.

### Citations

Below each tutor response, citation labels show which curriculum chunks the response was grounded in (e.g., `quadratic-equations-chunk-2`). If no citations appear, the response used the LLM's general knowledge (RAG fallback mode, fully logged).

### FAQ Responses

Certain meta-questions receive instant static responses without hitting the LLM — eliminating hallucination risk for common questions:

| What you type | What triggers it |
|---|---|
| Topic list | "what topics", "what can you teach", "what subjects" |
| How it works | "how does it work", "what is this", "how does the tutor work" |
| How to use | "how do I use", "how to use", "how do I start" |
| Help | "help", "help me" |

These are served directly by the chat server and do not consume API quota.

---

## 5. Key Concepts

### Socratic Tutoring

The Tutor Agent never simply gives the answer. It asks guiding questions that help the student reason towards the answer themselves.

**Example:** If a student asks "what is x² + 5x + 6 = 0?", the tutor might respond: "What two numbers multiply to give 6 and add to give 5?"

### Bayesian Knowledge Tracing (BKT)

BKT is a probabilistic model that estimates the probability that a student has truly learned a concept, accounting for:
- A student who answers correctly might have guessed
- A student who answers incorrectly might have slipped

The model parameters per topic:

| Parameter | Value | Meaning |
|---|---|---|
| P(L₀) | 0.10 | Prior probability of knowing the topic |
| P(T) | 0.20 | Probability of learning on each correct step |
| P(S) | 0.10 | Probability of slipping (knows but answers wrong) |
| P(G) | 0.25 | Probability of guessing (doesn't know but answers right) |

A student advances when mastery ≥ **0.85**.

### Topic Routing

The system detects which GCSE topic a student is asking about from their message — even if the curriculum knowledge graph assigns a different starting topic. Keywords in the student's message override the KG assignment for the LLM context.

For example, if a student types "I want to understand quadratic equations", the tutor immediately centres on quadratic equations regardless of where they are in the curriculum ladder.

Detected topics include: quadratic equations, graph transformations, trigonometry, probability, statistics, vectors, functions, mensuration, fractions/percentages/ratio, algebra, geometry, sequences, simultaneous equations, and inequalities.

### Assessment Signal Detection

The Assessment Agent is triggered when the orchestrator detects that the student is submitting an answer (not just asking a question). The detection now covers a wide range of natural-language answer patterns:

> "I think…", "the answer is…", "I got…", "so x = …", "would be…", "I calculated…", "therefore…", "which gives…", "my working shows…"

This means students don't need to use formal phrasing to get their answers scored.

### Distress Triage

If a student expresses general confusion without identifying a specific topic ("I'm completely lost", "I don't know where to start", "I can't do maths"), the system intercepts the message before it reaches the orchestrator and returns a topic menu:

```
That's okay — let's figure out where to start together! 😊

Which area of maths is giving you trouble? Pick the one that feels most urgent:
1. Algebra — equations, expressions, factorising
2. Number — fractions, percentages, decimals, ratios
3. Geometry — angles, shapes, circles, area and volume
...
```

This prevents the LLM from generating a generic reassurance and grounds the next turn in a specific topic.

### Resistance Adaptation

If a student repeatedly asks for direct answers ("just tell me", "give me the answer", "stop asking me questions"), the system tracks a resistance count. After two such requests, the tutor receives an internal instruction to:
- Acknowledge the student's frustration warmly
- Offer to verify the student's own guess by substitution, rather than confirming directly
- Provide a partial scaffold (e.g. the first step) to unstick them

The Socratic approach is maintained — the tutor never simply gives the answer — but the pedagogical strategy adapts.

### Ability-Paced Progression

When a student answers correctly multiple times in a row, the system tracks an ability signal. After two correct answers, the tutor receives a hint to match the student's pace: offer extension problems or harder variants rather than re-explaining basics.

### Meta-Commentary Filter

LLMs can sometimes generate internal diagnostic commentary in their responses (e.g., "The student appears to be confused about the topic" or "Let me reconsider"). The system filters these lines from all responses before they reach the student. Students only ever see language that would naturally come from a tutor speaking directly to them.

### Sympy Mathematical Verification

When the tutor makes an assertive mathematical claim in its response (e.g. "so x = 3"), the system verifies this using SymPy before delivering it. If SymPy finds a computation error, the tutor regenerates its response. This is a conservative check — exploratory Socratic suggestions ("try x = 3") are deliberately excluded.

### C4 Constitutional Principle

The Tutor Agent is designed to **never give ungrounded answers**. If the RAG pipeline cannot find relevant curriculum content:
1. The system falls back to the LLM's general knowledge and logs a `rag_fallback_llm` audit event
2. The tutor continues the Socratic approach using its training knowledge
3. Responses that cannot be grounded are never delivered with false confidence

In production, curriculum content will be loaded for all topics, eliminating fallback reliance.

### GCSE Topic Ladder

The 8 topics in the knowledge graph, in prerequisite order:

1. Number basics
2. Algebra basics
3. Linear equations
4. Linear graphs
5. Simultaneous equations
6. Quadratic factoring
7. Quadratic equations
8. Quadratic graphs

---

## 6. Example Conversation

This example shows the system handling a student who is initially vague, then submits an answer:

```
You: I want to understand quadratic equations. Can you help me?

Tutor [EXPLORING]: Great choice — quadratic equations are really useful
  and I think you'll find them satisfying to master!

  Let's start by building from what you already know. Can you tell me
  what you think makes an equation "quadratic"? What do you notice
  about the word itself, or any examples you've seen before?

You: idk something about x squared

Tutor [EXPLORING]: Exactly right — "quadratic" comes from the Latin for
  "square", which is why x² always appears. Good instinct.

  Now, if I gave you x² + 5x + 6 = 0, what would be your first
  instinct for how to approach it?
  ↳ quadratic-equations-chunk-2

You: I think x = -2 and x = -3

Tutor [EXPLORING]: That's correct! Well done for spotting both solutions.
  Now — can you show me how you'd verify that x = -2 actually satisfies
  the equation? What do you get when you substitute it in?
  ↳ quadratic-equations-chunk-1

[Mastery bar updates to 42%]
```

Notice:
- The topic routing detected "quadratic equations" from the first message and centred on it immediately
- The assessment fired when the student said "I think x = -2 and x = -3" (natural-language answer signal)
- The tutor verified the answer and immediately pushed to the next Socratic step rather than just confirming

---

## 7. Known Limitations

These limitations are **by design** for a proof-of-concept:

| Limitation | Detail |
|---|---|
| **In-memory session state** | Restarting the local `chat_ui.py` process starts a fresh session. Conversation history is lost; BKT mastery in the DB persists. The live service at mas-tutor.com maintains session state across page refreshes but not across browser sessions. |
| **RAG coverage** | The RAG pipeline covers 3 of 8 GCSE topics locally (quadratic equations, linear equations, number/algebra basics). On the live VPS, the ChromaDB ingest has not yet been run — the tutor uses LLM general knowledge in fallback mode for all topics. Accuracy is good; grounding citations will not appear until the ingest is run. |
| **No authentication** | Anyone who can reach port 8080 (local) or https://mas-tutor.com (live) can use the chat UI. Access control is not part of the POC scope. |
| **Curriculum accuracy not audited** | The mathematical content of tutor responses has not been systematically reviewed by a domain expert. The sympy verification catches arithmetic errors in stated values; wider pedagogical accuracy is not guaranteed for all topics. |
| **BeeAI `/ui` not available** | The BeeAI Platform UI requires the BeeAI binary. Use `chat_ui.py` for browser access. |
| **Single curriculum language** | The tutor only operates in English. Multi-language support is not part of this POC. |

---

## 8. Troubleshooting

### The chat UI returns an error on every message

**Likely cause (local):** `OPENROUTER_API_KEY` in `.env` is not set or is invalid.

```bash
cat .env | grep OPENROUTER_API_KEY
```

If it shows the placeholder value, edit `.env` and add your key.

**Likely cause (live service):** Check the VPS service status:
```bash
ssh root@51.15.38.155 "systemctl status mas-tutor"
```

---

### The tutor always says "I'm having trouble with that one"

This is the fallback message when the LLM call fails entirely. Possible causes:
- OpenRouter API key exhausted or invalid
- The model ID is not available via OpenRouter
- Network timeout

Check VPS logs:
```bash
ssh root@51.15.38.155 "journalctl -u mas-tutor -f"
```

---

### The tutor always responds with general knowledge (no citations)

**Likely cause:** ChromaDB collection is empty — the curriculum ingest pipeline has not been run on this machine.

**Fix (local):**
```bash
cd ~/projects/mas_education_poc
uv run python -m rag.ingest  # Run curriculum ingest
uv run python chat_ui.py
```

---

### Port 8080 is already in use (local)

```bash
fuser -k 8080/tcp
uv run python chat_ui.py
```

---

### The mastery bar doesn't update

The mastery bar updates only when the Assessment Agent scores a response. This happens when the orchestrator detects an answer pattern in your message (after turn 1).

To trigger it, include a stated answer: "I think x = -2 and x = -3" or "the answer is 42" or "I got 0.5".

---

### Database errors on startup (local)

The database auto-initialises on first run. If `mas_poc.db` is corrupted:

```bash
cd ~/projects/mas_education_poc
rm mas_poc.db
uv run python chat_ui.py
```

---

## Appendix: Environment Variables

| Variable | Default | Description |
|---|---|---|
| `OPENROUTER_API_KEY` | *(required)* | OpenRouter API key (primary LLM provider) |
| `ANTHROPIC_API_KEY` | *(optional)* | Direct Anthropic key (alternative to OpenRouter for local dev) |
| `LLM_PRIMARY` | `claude-sonnet-4-6` | Primary LLM model name |
| `LLM_SECONDARY` | *(unset)* | Secondary model for short messages (e.g. haiku). Only activates if explicitly set and different from `LLM_PRIMARY`. |
| `CHROMA_PATH` | `~/.pai/rag/chromadb` | ChromaDB data directory |
| `CHROMA_COLLECTION` | `poc_curriculum` | ChromaDB collection name |
| `DB_PATH` | `./mas_poc.db` | SQLite database path |
| `MASTERY_THRESHOLD` | `0.85` | BKT threshold for topic advancement |
| `ENGAGEMENT_STUCK_THRESHOLD` | `3` | Consecutive short responses before stuck detection |
| `DIALOGUE_MIN_WORDS` | `5` | Word count below which a response is "short" |
