# MAS Education POC — Build Plan
# Self-Contained Cross-Session Build Tracker

**Project:** MAS Education Platform — Proof of Concept
**Architecture:** v2.1 POC (see `~/projects/mas_education_architecture_blueprint_v2_1_poc.md`)
**Full MVP reference:** `~/projects/mas_education_architecture_blueprint_v2.md`
**Created:** 23 February 2026
**Rate limit window:** ~5 hours per session

---

## ═══ SESSION STATE ═══ (UPDATE THIS EACH SESSION)

```
CURRENT STAGE:    Neo4j KG Phase 5 COMPLETE — ALL PHASES DONE
LAST STEP DONE:   Phase 5 — RAG Integration with HAS_RESOURCE edges and KG-guided retrieval
NEXT ACTION:      Optional: Phase 6 — Production hardening / A-Level content / UI polish
STATUS:           ✅ POC Stages 1-7 COMPLETE | ✅ KG Phases 0-5 COMPLETE
SESSIONS DONE:    5
RATE LIMIT NOTE:  N/A

PHASE 5 SUMMARY (24 Feb 2026):
  ✅ 22 new curriculum markdown files written (geometry, statistics, algebra, number)
  ✅ ChromaDB poc_curriculum: 12 → 79 chunks (26 topics covering all 4 IGCSE 0580 topic areas)
  ✅ Neo4j Resource nodes: 71 nodes, 200 HAS_RESOURCE edges (100 0580 LOs each linked to 2 chunks)
  ✅ scripts/link_resources.py: idempotent, MERGE-based, --qual and --all flags
  ✅ rag/retrieve.py: lo_id parameter added, KG-guided chunk prioritisation before re-ranking
  ✅ agents/tutor_agent.py: passes lo_id to retrieve()
  ✅ orchestrator/poc_orchestrator.py: passes current_topic (LO ID) as lo_id to tutor
  ✅ db/schema.cypher: Resource constraint added
  ✅ End-to-end demo runs without errors

TO RUN THE CHAT UI:
  cd ~/projects/mas_education_poc
  ./start.sh              # start in background (logs to chat_ui.log)
  ./status.sh             # check if running
  ./stop.sh               # stop
  Open http://localhost:8080 in browser

TO RUN THE CLI DEMO:
  cd ~/projects/mas_education_poc && uv run python demo.py

KNOWN LIMITATION (Phase 5 gap):
  The Neo4j KG has 191 LOs but the Tutor Agent's RAG (ChromaDB) only covers 4 topics:
  linear-equations, number-basics, number-and-algebra-basics, quadratic-equations.
  Any question outside those 4 topics triggers a "check with your teacher" fallback.
  Fix: Phase 5 — add curriculum markdown files for all remaining topics.

STAGE 7 SUMMARY (23 Feb 2026):
  ✅ main.py: full BeeAI server wrapping LangGraph orchestrator
  ✅ Server starts: uvicorn port 8000, agent card HTTP 200 at /.well-known/agent-card.json
  ✅ Agent: name='MAS Tutor', description='GCSE Maths Socratic Tutor — multi-agent system'
  ✅ End-to-end turn: session_log +1 row, audit_events +2 rows per turn confirmed
  ✅ RAG: direct retrieve() returns 4 chunks from poc_curriculum (9 docs)
  ✅ C4 fallback: no RAG → teacher escalation logged to audit_events
  ✅ Single @server.agent() — BeeAI SDK one-agent constraint honoured
  ✅ No hardcoded absolute paths

STAGE 6 SUMMARY (23 Feb 2026):
  ✅ orchestrator/__init__.py: created
  ✅ orchestrator/poc_orchestrator.py: LangGraph 6-state machine, all 7 nodes
  ✅ Graph compiles: 7 named nodes (session_init, route_intent, tutoring, assessment, reflect, deliver, log_update)
  ✅ Full invoke test: agent_response populated, intent=tutor, EXPLORING state, history=2 messages
  ✅ C4 constitutional fallback verified: no RAG results → teacher escalation (not hallucination)
  ✅ No hardcoded absolute paths in orchestrator/ code

STAGE 5 SUMMARY (23 Feb 2026):
  ✅ agents/planning_agent.py: get_learner_plan, check_advancement (mastery >= 0.85 AND evidence >= 5)
  ✅ agents/dialogue_agent.py: DialogueTracker — 5-state machine, stuck threshold=3, short=5 words
  ✅ agents/monitor_agent.py: cost tracking, session summary, never blocks response path
  ✅ All 5 agents import in single test without conflicts
  ✅ Planning smoke: current_topic=number-basics (correct for fresh learner)
  ✅ Dialogue smoke: EXPLORING state, no intervention on first turn
  ✅ Monitor smoke: turns=1, cost_gbp=£0.001 (from Stage 4 test session)
  ✅ No hardcoded absolute paths in Stage 5 code

STAGE 4 SUMMARY (23 Feb 2026):
  ✅ agents/__init__.py: created
  ✅ agents/tutor_agent.py: Socratic tutor, RAG-grounded (C4), 500 token limit
  ✅ agents/assessment_agent.py: BKT scoring, self-reflection trigger at 10% divergence
  ✅ Integration test: Tutor grounded=True, citations present, Assessment scored CORRECT
  ✅ BKT update: first CORRECT on quadratic-equations → mastery 0.384 (matches expected range)
  ✅ No hardcoded absolute paths in agents/ code

STAGE 3 SUMMARY (23 Feb 2026):
  ✅ db/poc_schema.sql: 5 tables (learner_state, knowledge_graph, session_log, audit_events, bkt_parameters)
  ✅ db/init_db.py: seeds 8 GCSE Maths topics + BKT params, idempotent
  ✅ db/db.py: update_mastery (BKT), get_mastery, get_next_topic, log_session, log_audit
  ✅ BKT formula validated: first correct on quadratic-equations → 0.3838 (matches manual calc)
  ✅ Idempotency: re-run init_db, existing learner data preserved
  ✅ get_next_topic('demo-student-001') → number-basics (correct entry point for fresh learner)
  ✅ No hardcoded absolute paths in db/ code

STAGE 2 SUMMARY (23 Feb 2026):
  ✅ 3 curriculum markdown files: quadratic_equations, linear_equations, number_and_algebra_basics
  ✅ rag/ingest.py — chunks (200 words/chunk), embeds with qwen3-embedding:8b, upserts to ChromaDB
  ✅ rag/retrieve.py — HyDE + multi-query enhancement → top-10 → term-overlap rerank → top-4 with citations
  ✅ poc_curriculum collection: 9 chunks
  ✅ documents collection unchanged: 4492 chunks
  ✅ Retrieval test: query 'solve x² + 5x + 6' → top result is quadratic-equations topic ✅
  ✅ No hardcoded absolute paths in rag/ code

STAGE 1 SUMMARY (23 Feb 2026):
  ✅ uv project init (Python 3.11)
  ✅ agentstack-sdk 0.6.1 + langgraph 1.0.9 + anthropic 0.83.0 + chromadb 1.5.1 installed
  ✅ python-dotenv added
  ✅ Directory structure created: agents/ orchestrator/ rag/ db/ curriculum_data/
  ✅ .env.template created (fill in ANTHROPIC_API_KEY before Stage 2)
  ✅ BeeAI smoke test passes (Server + @server.agent() decorator works)
  ⚠️  ANTHROPIC_API_KEY: not yet set — needed before Stage 4

API PATTERN CONFIRMED (use this in all agent code):
  from agentstack_sdk.server import Server
  from agentstack_sdk.server.context import RunContext
  from a2a.types import Message
  server = Server()
  @server.agent(name="AgentName", description="...")
  async def my_agent(message: Message, context: RunContext):   # async generator
      text = "".join(p.root.text for p in message.parts if hasattr(p.root, 'text'))
      yield "response string"   # or yield str for streaming
  if __name__ == "__main__":
      server.run(host="127.0.0.1", port=PORT, self_registration=False)

  KEY RULES:
  - ONE server = ONE agent (Server() raises ValueError if @agent() called twice)
  - Stage 7 main.py uses a SINGLE server wrapping the full orchestrator
  - 'session_summary' is a special keyword inside the main agent, not a separate agent
  - Extract message text: "".join(p.root.text for p in msg.parts if hasattr(p.root,'text'))
```

### How to resume in a new session:
1. Read the SESSION STATE box above
2. Find the CURRENT STAGE section
3. Find LAST STEP DONE — start from the NEXT step
4. Run the verify command for the last step first to confirm state
5. Update SESSION STATE when you stop

---

## Overview: 7 Stages

| # | Stage | Est. Time | Depends On | Status |
|---|-------|-----------|-----------|--------|
| 1 | Environment Setup | 45 min | — | ✅ Complete (23 Feb 2026) |
| 2 | RAG + ChromaDB | 60 min | Stage 1 | ✅ Complete (23 Feb 2026) |
| 3 | SQLite Schema | 30 min | Stage 1 | ✅ Complete (23 Feb 2026) |
| 4 | Tutor + Assessment Agents | 90 min | Stages 2+3 | ✅ Complete (23 Feb 2026) |
| 5 | Planning + Dialogue + Monitor Agents | 60 min | Stage 3 | ✅ Complete (23 Feb 2026) |
| 6 | LangGraph Orchestrator | 60 min | Stages 4+5 | ✅ Complete (23 Feb 2026) |
| 7 | BeeAI Integration + End-to-End Demo | 45 min | Stage 6 | ✅ Complete (23 Feb 2026) |

**Suggested session groupings:**
- **Session 1 (today, ≤17:00 GMT):** Stage 1
- **Session 2:** Stage 2 + Stage 3
- **Session 3:** Stage 4 (hardest — do alone)
- **Session 4:** Stage 5 + Stage 6
- **Session 5:** Stage 7 (demo day)

---

## Key Constants (Reference These Throughout)

```
PROJECT DIR:        ~/projects/mas_education_poc/
BLUEPRINT v2.1:     ~/projects/mas_education_architecture_blueprint_v2_1_poc.md
CHROMADB PATH:      /home/tonyts/.pai/rag/chromadb/
CHROMADB COLLECTION: poc_curriculum   (separate from existing 'documents' collection)
SQLITE DB:          ~/projects/mas_education_poc/poc_learner.db
BEEAI PORT:         8000
BEEAI WEB UI:       http://localhost:8000/ui
LLM PRIMARY:        claude-sonnet-4-6 (Anthropic API key in .env)
LLM FALLBACK:       mistral:latest (local — qwen3:8b NOT installed, mistral confirmed ✅)
EMBEDDING MODEL:    qwen3-embedding:8b (via Ollama — already installed)
MASTERY THRESHOLD:  0.85 (BKT — advance to next topic)
MASTERY DIVERGENCE: 0.10 (10 percentile points — triggers Assessment self-reflection)
SELF-REFLECTION WINDOW: 3 sessions
MAX AGENT CHAIN:    5 hops
AGENT TIMEOUT:      10 seconds
STUCK THRESHOLD:    3 consecutive responses < 5 words
```

---

## Project File Structure

```
~/projects/mas_education_poc/
├── BUILD_PLAN.md               ← THIS FILE (update SESSION STATE each session)
├── .env                        ← API keys
├── pyproject.toml              ← uv project config
├── main.py                     ← BeeAI AgentStack entry point (Stage 7)
│
├── agents/
│   ├── __init__.py
│   ├── tutor_agent.py          ← Stage 4
│   ├── assessment_agent.py     ← Stage 4
│   ├── planning_agent.py       ← Stage 5
│   ├── dialogue_agent.py       ← Stage 5
│   └── monitor_agent.py        ← Stage 5
│
├── orchestrator/
│   ├── __init__.py
│   └── poc_orchestrator.py     ← Stage 6 (LangGraph state machine)
│
├── rag/
│   ├── __init__.py
│   ├── ingest.py               ← Stage 2
│   └── retrieve.py             ← Stage 2
│
├── db/
│   ├── poc_schema.sql          ← Stage 3
│   └── init_db.py              ← Stage 3
│
└── curriculum_data/            ← Stage 2 (raw text files for ingestion)
    ├── quadratic_equations.txt
    ├── linear_equations.txt
    ├── number_basics.txt
    └── ...
```

---

## Agent Roles Quick Reference

| Agent | BeeAI Service ID | Core Responsibility | Key Constraints |
|-------|-----------------|---------------------|-----------------|
| Tutor | `tutor-agent` | Socratic tutoring, RAG-grounded responses | C4: Never respond without RAG retrieval |
| Assessment | `assessment-agent` | Mastery tracking (BKT), response scoring | Self-reflect if divergence > 10% over 3 sessions |
| Planning | `planning-agent` | Next topic selection, DAG traversal | Advance only when mastery ≥ 0.85 |
| Dialogue | `dialogue-agent` | Engagement state machine, quality monitoring | Intervene after 3 consecutive short responses |
| Monitor | `monitor-agent` | Audit logging, cost tracking, session summary | Log every decision; never block response path |

### Dialogue Agent Engagement States:
```
EXPLORING → STUCK (3x short response) → EXPLORING (open-ended prompt)
EXPLORING → BREAKTHROUGH (conceptual connection) → CONSOLIDATING → MASTERED (BKT ≥ 0.85)
```

### Intervention Triggers (Dialogue Agent):
- Response length < 5 words for 3 consecutive turns → STUCK
- "idk" / "I don't know" / one-word response → Disengagement signal
- Question repetition → Closed-question pattern
- Confident but incorrect → Productive misconception (different intervention)

---

## ═══════════════════════════════════
## STAGE 1: Environment Setup
## Est: 45 min | Session: 1 (today)
## ═══════════════════════════════════

**Goal:** Clean project directory with all dependencies installed and verified.

### Step 1.1 — Install BeeAI AgentStack
```bash
sh -c "$(curl -LsSf https://raw.githubusercontent.com/i-am-bee/agentstack/install/install.sh)"
```
**Verify:** `beeai --version` or check install completed without errors

### Step 1.2 — Create project with uv
```bash
mkdir -p ~/projects/mas_education_poc
cd ~/projects/mas_education_poc
uv init --python 3.11
```
**Verify:** `ls ~/projects/mas_education_poc/` shows `pyproject.toml`

### Step 1.3 — Install Python dependencies
```bash
cd ~/projects/mas_education_poc
uv add agentstack-sdk langgraph anthropic chromadb
```
**Verify:** `uv run python -c "import agentstack; import langgraph; import anthropic; import chromadb; print('ALL OK')`

### Step 1.4 — Create project directory structure
```bash
cd ~/projects/mas_education_poc
mkdir -p agents orchestrator rag db curriculum_data
touch agents/__init__.py orchestrator/__init__.py rag/__init__.py
```
**Verify:** `ls -la ~/projects/mas_education_poc/` shows all directories

### Step 1.5 — Create .env file
```bash
cat > ~/projects/mas_education_poc/.env << 'EOF'
ANTHROPIC_API_KEY=your_key_here
CHROMA_PATH=/home/tonyts/.pai/rag/chromadb
CHROMA_COLLECTION=poc_curriculum
SQLITE_DB=poc_learner.db
OLLAMA_BASE_URL=http://localhost:11434
LLM_PRIMARY=claude-sonnet-4-6
LLM_FALLBACK=qwen3:8b
EOF
```
Then edit to add real ANTHROPIC_API_KEY:
```bash
nano ~/projects/mas_education_poc/.env
```
**Verify:** `grep ANTHROPIC ~/projects/mas_education_poc/.env` returns a non-empty key

### Step 1.6 — Check Ollama is available
```bash
ollama list
```
**Verify:** Output includes `qwen3:8b` and `qwen3-embedding:8b` (both should already be present from RAG work)
If `qwen3:8b` missing: `ollama pull qwen3:8b` (note: ~5GB download)

### Step 1.7 — Create pyproject.toml entry point config
Edit `pyproject.toml` to add:
```toml
[tool.uv]
python = "3.11"

[project.scripts]
mas-poc = "main:main"
```
**Verify:** `cat pyproject.toml` shows scripts section

### ✅ Stage 1 Complete When:
```bash
cd ~/projects/mas_education_poc
uv run python -c "
import agentstack, langgraph, anthropic, chromadb
import os
from dotenv import load_dotenv
load_dotenv()
print('Dependencies: OK')
print(f'Anthropic key: {\"SET\" if os.getenv(\"ANTHROPIC_API_KEY\") else \"MISSING\"}')
print(f'ChromaDB path: {os.getenv(\"CHROMA_PATH\")}')
"
```
Expected: `Dependencies: OK`, `Anthropic key: SET`, `ChromaDB path: /home/tonyts/.pai/rag/chromadb`

**Update SESSION STATE when done:**
```
CURRENT STAGE:    2 — RAG + ChromaDB
LAST STEP DONE:   1.7 — pyproject.toml configured
NEXT ACTION:      Stage 2 Step 2.1 — prepare curriculum data
STATUS:           🟡 STAGE 1 COMPLETE
```

---

## ═══════════════════════════════════
## STAGE 2: RAG + ChromaDB
## Est: 60 min | Session: 2
## ═══════════════════════════════════

**Goal:** `poc_curriculum` ChromaDB collection with ~100 GCSE Maths chunks, queryable via Advanced RAG pipeline.

### Step 2.1 — Create curriculum text files

Create `curriculum_data/quadratic_equations.txt`:
```
A quadratic equation is a polynomial equation of degree 2, written in the standard form ax² + bx + c = 0, where a ≠ 0.

SOLVING BY FACTORING:
To solve x² + 5x + 6 = 0, find two numbers that multiply to 6 (the constant) and add to 5 (the coefficient of x).
Those numbers are 2 and 3, because 2 × 3 = 6 and 2 + 3 = 5.
So x² + 5x + 6 = (x + 2)(x + 3) = 0
Therefore x = -2 or x = -3.

THE QUADRATIC FORMULA:
For any quadratic ax² + bx + c = 0:
x = (-b ± √(b² - 4ac)) / 2a
The discriminant b² - 4ac tells us:
- If b² - 4ac > 0: two distinct real solutions
- If b² - 4ac = 0: one repeated real solution
- If b² - 4ac < 0: no real solutions (complex roots)

COMPLETING THE SQUARE:
x² + 6x + 5 = 0
→ x² + 6x = -5
→ x² + 6x + 9 = -5 + 9 = 4
→ (x + 3)² = 4
→ x + 3 = ±2
→ x = -1 or x = -5
```

Create `curriculum_data/linear_equations.txt`:
```
A linear equation is an equation where the highest power of the variable is 1.

SOLVING ONE-STEP EQUATIONS:
x + 5 = 12 → x = 12 - 5 = 7
3x = 15 → x = 15/3 = 5

SOLVING TWO-STEP EQUATIONS:
2x + 3 = 11
→ 2x = 11 - 3 = 8
→ x = 8/2 = 4
Always: undo addition/subtraction first, then multiplication/division.

SOLVING WITH VARIABLES ON BOTH SIDES:
5x + 3 = 3x + 11
→ 5x - 3x = 11 - 3
→ 2x = 8
→ x = 4

WORD PROBLEM EXAMPLE:
"I think of a number, double it and add 7. The answer is 19. What is the number?"
Let the number be x.
2x + 7 = 19
2x = 12
x = 6
```

Create `curriculum_data/number_basics.txt`:
```
INTEGERS AND OPERATIONS:
Integers are whole numbers: ..., -3, -2, -1, 0, 1, 2, 3, ...

RULES FOR NEGATIVE NUMBERS:
Multiplying/dividing:
- positive × positive = positive (3 × 4 = 12)
- negative × negative = positive (-3 × -4 = 12)
- positive × negative = negative (3 × -4 = -12)
Adding and subtracting negatives:
- 5 + (-3) = 5 - 3 = 2
- 5 - (-3) = 5 + 3 = 8

FRACTIONS:
Adding fractions: need a common denominator
1/3 + 1/4 = 4/12 + 3/12 = 7/12

Multiplying fractions: multiply numerators, multiply denominators
2/3 × 3/4 = 6/12 = 1/2

PERCENTAGES:
To find 30% of 80: 0.30 × 80 = 24
To find what % 15 is of 60: (15/60) × 100 = 25%
Percentage increase: ((new - old) / old) × 100
```

**Verify:** `ls ~/projects/mas_education_poc/curriculum_data/` shows 3 text files

### Step 2.2 — Implement rag/ingest.py

Create `~/projects/mas_education_poc/rag/ingest.py`:
```python
"""
RAG Ingestion Pipeline — MAS Education POC
Ingests curriculum text files into ChromaDB poc_curriculum collection.
Uses qwen3-embedding:8b (Ollama) for embeddings — already installed.
"""
import os
import sys
import chromadb
from chromadb.utils import embedding_functions
from pathlib import Path

CHROMA_PATH = os.getenv("CHROMA_PATH", "/home/tonyts/.pai/rag/chromadb")
COLLECTION_NAME = os.getenv("CHROMA_COLLECTION", "poc_curriculum")
OLLAMA_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
EMBEDDING_MODEL = "qwen3-embedding:8b"
CHUNK_SIZE = 300  # words per chunk (smaller than production 512 tokens — sufficient for POC)
CHUNK_OVERLAP = 30  # words overlap


def chunk_text(text: str, chunk_size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP) -> list[str]:
    """Split text into overlapping word-based chunks."""
    words = text.split()
    chunks = []
    i = 0
    while i < len(words):
        chunk = " ".join(words[i:i + chunk_size])
        chunks.append(chunk)
        i += chunk_size - overlap
    return chunks


def get_topic_from_filename(filename: str) -> str:
    """Derive topic name from filename."""
    return filename.replace(".txt", "").replace("_", "-")


def ingest_file(collection, filepath: Path, topic: str) -> int:
    """Ingest a single curriculum file into ChromaDB."""
    text = filepath.read_text()
    chunks = chunk_text(text)

    ids = [f"{topic}-chunk-{i:03d}" for i in range(len(chunks))]
    metadatas = [
        {
            "topic": topic,
            "difficulty": "GCSE",
            "source": filepath.name,
            "chunk_index": i,
            "subject": "mathematics"
        }
        for i in range(len(chunks))
    ]

    # Check for existing IDs to avoid duplicates
    existing = collection.get(ids=ids)
    existing_ids = set(existing["ids"])

    new_ids = [id_ for id_ in ids if id_ not in existing_ids]
    new_docs = [chunks[ids.index(id_)] for id_ in new_ids]
    new_meta = [metadatas[ids.index(id_)] for id_ in new_ids]

    if new_ids:
        collection.add(ids=new_ids, documents=new_docs, metadatas=new_meta)
        print(f"  Ingested {len(new_ids)} new chunks (skipped {len(existing_ids)} existing)")
    else:
        print(f"  All {len(ids)} chunks already exist — skipped")

    return len(new_ids)


def main():
    curriculum_dir = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("curriculum_data")

    if not curriculum_dir.exists():
        print(f"ERROR: curriculum_data directory not found at {curriculum_dir}")
        sys.exit(1)

    print(f"Connecting to ChromaDB at {CHROMA_PATH}...")
    client = chromadb.PersistentClient(path=CHROMA_PATH)

    embedding_fn = embedding_functions.OllamaEmbeddingFunction(
        url=f"{OLLAMA_URL}/api/embeddings",
        model_name=EMBEDDING_MODEL
    )

    collection = client.get_or_create_collection(
        name=COLLECTION_NAME,
        embedding_function=embedding_fn,
        metadata={"hnsw:space": "cosine"}
    )

    print(f"Collection '{COLLECTION_NAME}': {collection.count()} existing chunks")

    total_new = 0
    for filepath in sorted(curriculum_dir.glob("*.txt")):
        topic = get_topic_from_filename(filepath.name)
        print(f"\nIngesting: {filepath.name} (topic: {topic})")
        count = ingest_file(collection, filepath, topic)
        total_new += count

    final_count = collection.count()
    print(f"\n✅ Ingestion complete. New chunks: {total_new}. Total in collection: {final_count}")


if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()
    main()
```

**Verify:** File exists: `ls ~/projects/mas_education_poc/rag/ingest.py`

### Step 2.3 — Test ingestion
```bash
cd ~/projects/mas_education_poc
uv add python-dotenv  # add dotenv if not already there
uv run python rag/ingest.py curriculum_data/
```
**Verify:** Output ends with "✅ Ingestion complete. Total in collection: [N]" where N > 0

### Step 2.4 — Implement rag/retrieve.py

Create `~/projects/mas_education_poc/rag/retrieve.py`:
```python
"""
Advanced RAG Retrieval Pipeline — MAS Education POC

Three-stage pipeline (simplified from v2.0 production):
  Stage 1: Query Enhancement (HyDE + 2 reformulations)
  Stage 2: ChromaDB vector retrieval (top-10 candidates)
  Stage 3: Basic re-ranking by chunk relevance score (returns top-4)

Production equivalents (deferred):
  - BGE-Reranker-v2-m3 cross-encoder (replaces basic overlap reranking)
  - DeBERTa NLI faithfulness check (threshold ≥ 0.85)
"""
import os
import re
import chromadb
from chromadb.utils import embedding_functions
from anthropic import Anthropic

CHROMA_PATH = os.getenv("CHROMA_PATH", "/home/tonyts/.pai/rag/chromadb")
COLLECTION_NAME = os.getenv("CHROMA_COLLECTION", "poc_curriculum")
OLLAMA_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
EMBEDDING_MODEL = "qwen3-embedding:8b"
TOP_K_CANDIDATES = 10
TOP_K_RERANKED = 4


def _get_collection():
    client = chromadb.PersistentClient(path=CHROMA_PATH)
    embedding_fn = embedding_functions.OllamaEmbeddingFunction(
        url=f"{OLLAMA_URL}/api/embeddings",
        model_name=EMBEDDING_MODEL
    )
    return client.get_collection(name=COLLECTION_NAME, embedding_function=embedding_fn)


def _enhance_query(query: str, client: Anthropic, topic_hint: str = None) -> list[str]:
    """
    Stage 1 — Query Enhancement.
    Generates: original query + HyDE document + 2 reformulations.
    Returns list of 4 query variants to search.
    """
    system = """You are helping improve a search query for a GCSE Mathematics curriculum database.
Given a student question, generate:
1. A hypothetical ideal answer excerpt (1-2 sentences) that the database might contain
2. A broader reformulation of the question
3. A narrower, more specific reformulation

Respond in this exact format:
HYDE: [hypothetical answer excerpt]
BROAD: [broader question]
NARROW: [narrower question]"""

    response = client.messages.create(
        model=os.getenv("LLM_PRIMARY", "claude-sonnet-4-6"),
        max_tokens=200,
        system=system,
        messages=[{"role": "user", "content": f"Student question: {query}"}]
    )

    text = response.content[0].text
    variants = [query]  # always include original

    for line in text.strip().split("\n"):
        if line.startswith("HYDE:"):
            variants.append(line[5:].strip())
        elif line.startswith("BROAD:"):
            variants.append(line[6:].strip())
        elif line.startswith("NARROW:"):
            variants.append(line[7:].strip())

    return variants[:4]  # cap at 4 variants


def _basic_rerank(query: str, results: list[dict]) -> list[dict]:
    """
    Stage 3 — Basic re-ranking.
    Scores each chunk by term overlap with query.
    Production: replace with BGE-Reranker-v2-m3 cross-encoder.
    """
    query_terms = set(re.findall(r'\b\w{3,}\b', query.lower()))

    for result in results:
        doc_terms = set(re.findall(r'\b\w{3,}\b', result["document"].lower()))
        overlap = len(query_terms & doc_terms)
        result["rerank_score"] = overlap / max(len(query_terms), 1)

    return sorted(results, key=lambda x: x["rerank_score"], reverse=True)


def retrieve(
    query: str,
    subject: str = "mathematics",
    topic: str = None,
    n_results: int = TOP_K_RERANKED,
    anthropic_client: Anthropic = None
) -> list[dict]:
    """
    Main retrieval function. Returns list of dicts:
    [{id, document, metadata, distance, rerank_score, citation_label}]

    Called by Tutor Agent, Assessment Agent.
    """
    collection = _get_collection()

    if anthropic_client is None:
        anthropic_client = Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))

    # Stage 1: Query Enhancement
    query_variants = _enhance_query(query, anthropic_client, topic_hint=topic)

    # Stage 2: Multi-query retrieval (deduplicated)
    where_filter = {"subject": subject}
    if topic:
        where_filter["topic"] = topic

    seen_ids = set()
    all_results = []

    for variant in query_variants:
        try:
            results = collection.query(
                query_texts=[variant],
                n_results=min(TOP_K_CANDIDATES, collection.count()),
                where=where_filter if collection.count() > 0 else None
            )
            for i, doc_id in enumerate(results["ids"][0]):
                if doc_id not in seen_ids:
                    seen_ids.add(doc_id)
                    all_results.append({
                        "id": doc_id,
                        "document": results["documents"][0][i],
                        "metadata": results["metadatas"][0][i],
                        "distance": results["distances"][0][i]
                    })
        except Exception as e:
            print(f"Warning: query variant failed: {e}")
            continue

    # Stage 3: Re-rank and select top-N
    reranked = _basic_rerank(query, all_results)[:n_results]

    # Add citation labels
    for i, result in enumerate(reranked):
        topic_name = result["metadata"].get("topic", "unknown")
        result["citation_label"] = f"[{i+1}] {topic_name} — {result['metadata'].get('source', 'curriculum')}"

    return reranked


def format_context(retrieved: list[dict]) -> str:
    """Format retrieved chunks into a context string for LLM prompts."""
    if not retrieved:
        return "No relevant curriculum content found."

    sections = []
    for r in retrieved:
        sections.append(f"{r['citation_label']}\n{r['document']}")

    return "\n\n---\n\n".join(sections)


if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()

    test_query = "How do I solve x squared plus 5x plus 6 equals 0?"
    print(f"Testing retrieval for: '{test_query}'")
    results = retrieve(test_query)
    print(f"\nRetrieved {len(results)} chunks:")
    for r in results:
        print(f"  {r['citation_label']} (score: {r.get('rerank_score', 0):.3f})")
        print(f"  Preview: {r['document'][:100]}...")
```

**Verify:** Run test:
```bash
cd ~/projects/mas_education_poc
uv run python rag/retrieve.py
```
Expected: "Retrieved N chunks" with citation labels showing `quadratic-equations` topic.

### ✅ Stage 2 Complete When:
Retrieval returns ≥ 2 relevant chunks for the test quadratic query with correct citation labels.

**Update SESSION STATE:**
```
CURRENT STAGE:    3 — SQLite Schema
LAST STEP DONE:   2.4 — retrieve.py tested
STATUS:           🟡 STAGE 2 COMPLETE
```

---

## ═══════════════════════════════════
## STAGE 3: SQLite Schema
## Est: 30 min | Session: 2 (cont.)
## ═══════════════════════════════════

**Goal:** `poc_learner.db` with all tables created and 8 GCSE Maths topics seeded into knowledge graph.

### Step 3.1 — Create db/poc_schema.sql

Create `~/projects/mas_education_poc/db/poc_schema.sql`:
```sql
-- MAS Education POC — SQLite Schema
-- Replaces PostgreSQL (learner state) + Neo4j (knowledge graph) from v2.0 production

-- Learner state (one row per learner per knowledge component)
CREATE TABLE IF NOT EXISTS learner_state (
    learner_id TEXT NOT NULL,
    topic_id TEXT NOT NULL,
    p_mastery REAL DEFAULT 0.1,         -- BKT mastery probability (0.0–1.0)
    evidence_count INTEGER DEFAULT 0,    -- Number of assessed interactions
    last_assessed TEXT,                  -- ISO-8601 datetime
    next_review TEXT,                    -- ISO-8601 datetime (spaced repetition)
    PRIMARY KEY (learner_id, topic_id)
);

-- Knowledge graph (adjacency list — replaces Neo4j for POC)
-- Prerequisite: you must master 'from_topic' before attempting 'to_topic'
CREATE TABLE IF NOT EXISTS knowledge_graph (
    topic_id TEXT PRIMARY KEY,
    topic_name TEXT NOT NULL,
    description TEXT,
    difficulty_level INTEGER DEFAULT 1,  -- 1=Foundation, 2=Higher
    prerequisite_ids TEXT DEFAULT '[]'   -- JSON array of prerequisite topic_ids
);

-- Session log (each agent interaction in a tutoring session)
CREATE TABLE IF NOT EXISTS session_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL,
    learner_id TEXT NOT NULL,
    timestamp TEXT NOT NULL,             -- ISO-8601
    agent TEXT NOT NULL,                 -- tutor-agent | assessment-agent | etc.
    event_type TEXT NOT NULL,            -- interaction | mastery_update | state_change | etc.
    input_text TEXT,
    output_text TEXT,
    metadata TEXT DEFAULT '{}'           -- JSON: BKT params, RAG chunks used, etc.
);

-- Audit events (C6 — transparent and auditable — every agent decision)
CREATE TABLE IF NOT EXISTS audit_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL,
    session_id TEXT NOT NULL,
    learner_id TEXT NOT NULL,
    agent TEXT NOT NULL,
    decision TEXT NOT NULL,              -- e.g. 'advance_topic', 'trigger_stuck', 'mastery_update'
    reasoning TEXT,                      -- Human-readable explanation
    technical TEXT DEFAULT '{}',         -- JSON: parameters, thresholds, values used
    human_override_available INTEGER DEFAULT 1
);

-- BKT parameters per topic (calibrated values)
CREATE TABLE IF NOT EXISTS bkt_parameters (
    topic_id TEXT PRIMARY KEY,
    p_learn REAL DEFAULT 0.3,            -- Probability of learning per interaction
    p_slip REAL DEFAULT 0.1,             -- Probability of incorrect response despite mastery
    p_guess REAL DEFAULT 0.2,            -- Probability of correct response without mastery
    p_init REAL DEFAULT 0.1             -- Prior mastery probability
);
```

**Verify:** `wc -l ~/projects/mas_education_poc/db/poc_schema.sql` > 40 lines

### Step 3.2 — Create db/init_db.py

Create `~/projects/mas_education_poc/db/init_db.py`:
```python
"""
Database initialisation — creates SQLite schema and seeds knowledge graph.
Run once before starting the POC server.
"""
import sqlite3
import json
import os
from pathlib import Path
from datetime import datetime


DB_PATH = os.getenv("SQLITE_DB", "poc_learner.db")
SCHEMA_PATH = Path(__file__).parent / "poc_schema.sql"

# GCSE Mathematics knowledge graph — 8 core topics
# Prerequisite structure: must master prerequisites before attempting topic
GCSE_MATHS_TOPICS = [
    {
        "topic_id": "number-basics",
        "topic_name": "Number and Operations",
        "description": "Integers, fractions, decimals, percentages, negative numbers",
        "difficulty_level": 1,
        "prerequisite_ids": []
    },
    {
        "topic_id": "algebra-basics",
        "topic_name": "Algebraic Expressions",
        "description": "Simplifying expressions, expanding brackets, factorising",
        "difficulty_level": 1,
        "prerequisite_ids": ["number-basics"]
    },
    {
        "topic_id": "linear-equations",
        "topic_name": "Linear Equations",
        "description": "Solving one- and two-step equations, equations with variables on both sides",
        "difficulty_level": 1,
        "prerequisite_ids": ["algebra-basics"]
    },
    {
        "topic_id": "linear-graphs",
        "topic_name": "Linear Graphs (y = mx + c)",
        "description": "Gradient, y-intercept, plotting straight lines, parallel and perpendicular",
        "difficulty_level": 2,
        "prerequisite_ids": ["linear-equations"]
    },
    {
        "topic_id": "simultaneous-equations",
        "topic_name": "Simultaneous Equations",
        "description": "Solving systems of two linear equations by substitution and elimination",
        "difficulty_level": 2,
        "prerequisite_ids": ["linear-equations"]
    },
    {
        "topic_id": "quadratic-factoring",
        "topic_name": "Quadratic Factoring",
        "description": "Factorising quadratics, difference of two squares",
        "difficulty_level": 2,
        "prerequisite_ids": ["algebra-basics", "linear-equations"]
    },
    {
        "topic_id": "quadratic-equations",
        "topic_name": "Quadratic Equations",
        "description": "Solving quadratics by factoring, quadratic formula, completing the square",
        "difficulty_level": 2,
        "prerequisite_ids": ["quadratic-factoring"]
    },
    {
        "topic_id": "quadratic-graphs",
        "topic_name": "Quadratic Graphs and Turning Points",
        "description": "Parabolas, axis of symmetry, vertex, discriminant and roots",
        "difficulty_level": 2,
        "prerequisite_ids": ["quadratic-equations", "linear-graphs"]
    }
]

# BKT parameters per topic (research-calibrated defaults)
BKT_PARAMETERS = {
    "number-basics":         {"p_learn": 0.35, "p_slip": 0.08, "p_guess": 0.25, "p_init": 0.20},
    "algebra-basics":        {"p_learn": 0.30, "p_slip": 0.10, "p_guess": 0.20, "p_init": 0.10},
    "linear-equations":      {"p_learn": 0.30, "p_slip": 0.10, "p_guess": 0.20, "p_init": 0.10},
    "linear-graphs":         {"p_learn": 0.25, "p_slip": 0.12, "p_guess": 0.18, "p_init": 0.10},
    "simultaneous-equations":{"p_learn": 0.25, "p_slip": 0.12, "p_guess": 0.15, "p_init": 0.08},
    "quadratic-factoring":   {"p_learn": 0.25, "p_slip": 0.12, "p_guess": 0.15, "p_init": 0.08},
    "quadratic-equations":   {"p_learn": 0.20, "p_slip": 0.15, "p_guess": 0.15, "p_init": 0.05},
    "quadratic-graphs":      {"p_learn": 0.20, "p_slip": 0.15, "p_guess": 0.12, "p_init": 0.05},
}


def init_database(db_path: str = DB_PATH):
    """Create all tables and seed reference data."""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # Create schema
    schema = SCHEMA_PATH.read_text()
    cursor.executescript(schema)

    # Seed knowledge graph
    for topic in GCSE_MATHS_TOPICS:
        cursor.execute("""
            INSERT OR IGNORE INTO knowledge_graph
            (topic_id, topic_name, description, difficulty_level, prerequisite_ids)
            VALUES (?, ?, ?, ?, ?)
        """, (
            topic["topic_id"],
            topic["topic_name"],
            topic["description"],
            topic["difficulty_level"],
            json.dumps(topic["prerequisite_ids"])
        ))

    # Seed BKT parameters
    for topic_id, params in BKT_PARAMETERS.items():
        cursor.execute("""
            INSERT OR IGNORE INTO bkt_parameters
            (topic_id, p_learn, p_slip, p_guess, p_init)
            VALUES (?, ?, ?, ?, ?)
        """, (topic_id, params["p_learn"], params["p_slip"], params["p_guess"], params["p_init"]))

    conn.commit()

    # Verify
    count = cursor.execute("SELECT COUNT(*) FROM knowledge_graph").fetchone()[0]
    print(f"✅ Database initialised: {count} topics in knowledge graph")
    print(f"   DB path: {db_path}")

    # Print topic tree
    print("\nKnowledge Graph:")
    for row in cursor.execute("SELECT topic_id, topic_name, prerequisite_ids FROM knowledge_graph ORDER BY difficulty_level, topic_id"):
        prereqs = json.loads(row[2])
        prereq_str = f" (requires: {', '.join(prereqs)})" if prereqs else " (entry point)"
        print(f"  {row[0]}: {row[1]}{prereq_str}")

    conn.close()


if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()
    init_database()
```

### Step 3.3 — Run init_db.py
```bash
cd ~/projects/mas_education_poc
uv run python db/init_db.py
```
**Verify:** Output shows "✅ Database initialised: 8 topics in knowledge graph"

### Step 3.4 — Create shared db/db.py helper

Create `~/projects/mas_education_poc/db/db.py`:
```python
"""Shared database connection helper — all agents import from here."""
import sqlite3
import json
import os
from datetime import datetime

DB_PATH = os.getenv("SQLITE_DB", "poc_learner.db")


def get_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def update_mastery(learner_id: str, topic_id: str, correct: bool) -> float:
    """
    Bayesian Knowledge Tracing (BKT) update.
    Returns new p_mastery estimate.

    BKT formula:
    P(Ln | correct) = P(Ln-1) * (1 - P(slip)) / [P(Ln-1)*(1-P(slip)) + (1-P(Ln-1))*P(guess)]
    P(Ln | incorrect) = P(Ln-1) * P(slip) / [P(Ln-1)*P(slip) + (1-P(Ln-1))*(1-P(guess))]
    P(Ln+1) = P(Ln | evidence) + (1 - P(Ln | evidence)) * P(learn)
    """
    conn = get_conn()

    # Get BKT parameters for this topic
    params = conn.execute(
        "SELECT p_learn, p_slip, p_guess, p_init FROM bkt_parameters WHERE topic_id = ?",
        (topic_id,)
    ).fetchone()

    if not params:
        p_learn, p_slip, p_guess, p_init = 0.30, 0.10, 0.20, 0.10
    else:
        p_learn = params["p_learn"]
        p_slip = params["p_slip"]
        p_guess = params["p_guess"]
        p_init = params["p_init"]

    # Get current mastery
    row = conn.execute(
        "SELECT p_mastery, evidence_count FROM learner_state WHERE learner_id=? AND topic_id=?",
        (learner_id, topic_id)
    ).fetchone()

    p_mastery = row["p_mastery"] if row else p_init
    evidence_count = row["evidence_count"] if row else 0

    # BKT update step 1: posterior given evidence
    if correct:
        numerator = p_mastery * (1 - p_slip)
        denominator = numerator + (1 - p_mastery) * p_guess
    else:
        numerator = p_mastery * p_slip
        denominator = numerator + (1 - p_mastery) * (1 - p_guess)

    p_posterior = numerator / denominator if denominator > 0 else p_mastery

    # BKT update step 2: learning transition
    p_new = p_posterior + (1 - p_posterior) * p_learn

    # Clamp to [0, 1]
    p_new = max(0.0, min(1.0, p_new))
    evidence_count += 1

    # Upsert learner state
    conn.execute("""
        INSERT INTO learner_state (learner_id, topic_id, p_mastery, evidence_count, last_assessed)
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(learner_id, topic_id) DO UPDATE SET
            p_mastery = excluded.p_mastery,
            evidence_count = excluded.evidence_count,
            last_assessed = excluded.last_assessed
    """, (learner_id, topic_id, p_new, evidence_count, datetime.utcnow().isoformat()))

    conn.commit()
    conn.close()

    return p_new


def get_next_topic(learner_id: str) -> dict | None:
    """
    Planning Agent: select next topic for learner.
    Returns topic dict or None if all topics mastered.
    Prerequisite check: only suggest topics where all prerequisites are mastered (≥ 0.85).
    """
    MASTERY_THRESHOLD = 0.85
    conn = get_conn()

    topics = conn.execute("SELECT * FROM knowledge_graph ORDER BY difficulty_level, topic_id").fetchall()

    for topic in topics:
        topic_id = topic["topic_id"]
        prerequisites = json.loads(topic["prerequisite_ids"])

        # Check current mastery for this topic
        state = conn.execute(
            "SELECT p_mastery FROM learner_state WHERE learner_id=? AND topic_id=?",
            (learner_id, topic_id)
        ).fetchone()

        current_mastery = state["p_mastery"] if state else 0.0

        # Skip if already mastered
        if current_mastery >= MASTERY_THRESHOLD:
            continue

        # Check all prerequisites are mastered
        prereqs_met = True
        for prereq_id in prerequisites:
            prereq_state = conn.execute(
                "SELECT p_mastery FROM learner_state WHERE learner_id=? AND topic_id=?",
                (learner_id, prereq_id)
            ).fetchone()
            prereq_mastery = prereq_state["p_mastery"] if prereq_state else 0.0
            if prereq_mastery < MASTERY_THRESHOLD:
                prereqs_met = False
                break

        if prereqs_met:
            conn.close()
            return {
                "topic_id": topic_id,
                "topic_name": topic["topic_name"],
                "current_mastery": current_mastery,
                "prerequisites": prerequisites
            }

    conn.close()
    return None  # All topics mastered


def log_audit(session_id: str, learner_id: str, agent: str,
              decision: str, reasoning: str, technical: dict = None):
    """C6 — Log every agent decision to audit_events table."""
    conn = get_conn()
    conn.execute("""
        INSERT INTO audit_events (timestamp, session_id, learner_id, agent, decision, reasoning, technical)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (
        datetime.utcnow().isoformat(),
        session_id, learner_id, agent, decision, reasoning,
        json.dumps(technical or {})
    ))
    conn.commit()
    conn.close()
```

**Verify:**
```bash
cd ~/projects/mas_education_poc
uv run python -c "
from db.db import get_next_topic
topic = get_next_topic('demo-student-001')
print(f'Next topic: {topic}')
"
```
Expected: `Next topic: {'topic_id': 'number-basics', 'topic_name': 'Number and Operations', ...}`

### ✅ Stage 3 Complete When:
- `poc_learner.db` exists with 8 topics
- `get_next_topic('demo-student-001')` returns `number-basics`
- `update_mastery('demo-student-001', 'number-basics', True)` returns a float between 0.1 and 0.5

**Update SESSION STATE:**
```
CURRENT STAGE:    4 — Tutor + Assessment Agents
LAST STEP DONE:   3.4 — db.py tested
STATUS:           🟡 STAGES 1-3 COMPLETE
```

---

## ═══════════════════════════════════
## STAGE 4: Tutor Agent + Assessment Agent
## Est: 90 min | Session: 3 (alone)
## ═══════════════════════════════════

**Goal:** Both critical agents implemented, unit tested, and integration tested as a pair.
**Note:** This is the hardest stage. Do it in a fresh session with full context.

### Step 4.1 — Implement agents/tutor_agent.py

Create `~/projects/mas_education_poc/agents/tutor_agent.py`:
```python
"""
Tutor Agent — MAS Education POC
Constitutional Principle C4: EVERY response must be RAG-grounded.
Uses Socratic method — asks questions, doesn't give answers directly.
"""
import os
import json
from datetime import datetime
from anthropic import Anthropic
from rag.retrieve import retrieve, format_context
from db.db import log_audit, get_conn

LLM_MODEL = os.getenv("LLM_PRIMARY", "claude-sonnet-4-6")
MAX_TOKENS = 500  # v2.0 §6.3: 500 token limit for tutoring responses

TUTOR_SYSTEM_PROMPT = """You are a Socratic mathematics tutor for GCSE students (ages 14-16).

ABSOLUTE RULES:
1. You MUST only use information from the CURRICULUM CONTEXT provided below to answer.
2. If the context does not contain enough information, say: "Let me check that with your teacher."
3. Never give the answer directly — guide the student to discover it through questions.
4. Ask ONE question at a time. Never ask multiple questions in one response.
5. Use encouraging language. Celebrate effort, not just correct answers.
6. Keep responses concise (under 150 words).

TEACHING APPROACH:
- Start with what the student already knows
- Break complex problems into small steps
- Use worked examples from the curriculum context
- When a student is stuck, ask "What do you know about...?" before explaining

CITATION REQUIREMENT:
End every factual response with: "Source: [citation label from context]"
"""


def get_tutor_response(
    student_input: str,
    conversation_history: list[dict],
    session_id: str,
    learner_id: str,
    current_topic: str = None,
    anthropic_client: Anthropic = None
) -> dict:
    """
    Generate a RAG-grounded Socratic tutor response.

    Returns:
    {
        "response": str,
        "rag_chunks_used": list[dict],
        "citations": list[str],
        "grounded": bool
    }
    """
    if anthropic_client is None:
        anthropic_client = Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))

    # C4: Retrieve grounded context FIRST — mandatory
    rag_results = retrieve(
        query=student_input,
        subject="mathematics",
        topic=current_topic,
        anthropic_client=anthropic_client
    )

    rag_context = format_context(rag_results)
    citations = [r["citation_label"] for r in rag_results]
    grounded = len(rag_results) > 0

    if not grounded:
        # C4 violation prevention — escalate rather than hallucinate
        response_text = "I couldn't find that in our curriculum materials. Let me check that with your teacher."
        log_audit(session_id, learner_id, "tutor-agent",
                  "rag_fallback", "No RAG results — escalating to teacher",
                  {"query": student_input, "topic": current_topic})
        return {
            "response": response_text,
            "rag_chunks_used": [],
            "citations": [],
            "grounded": False
        }

    # Build messages with RAG context injected
    messages = list(conversation_history[-6:])  # last 3 turns (6 messages)
    messages.append({
        "role": "user",
        "content": f"""CURRICULUM CONTEXT (use ONLY this information):
---
{rag_context}
---

STUDENT: {student_input}

Remember: Ask ONE guiding question. Don't give the answer directly. Cite your source."""
    })

    response = anthropic_client.messages.create(
        model=LLM_MODEL,
        max_tokens=MAX_TOKENS,
        system=TUTOR_SYSTEM_PROMPT,
        messages=messages
    )

    response_text = response.content[0].text

    # Audit log (C6)
    log_audit(
        session_id=session_id,
        learner_id=learner_id,
        agent="tutor-agent",
        decision="generate_response",
        reasoning=f"RAG-grounded response for: {student_input[:80]}",
        technical={
            "model": LLM_MODEL,
            "rag_chunks": len(rag_results),
            "citations": citations,
            "topic": current_topic,
            "tokens_used": response.usage.output_tokens
        }
    )

    return {
        "response": response_text,
        "rag_chunks_used": rag_results,
        "citations": citations,
        "grounded": True
    }
```

**Verify:** File exists and imports cleanly:
```bash
cd ~/projects/mas_education_poc
uv run python -c "from agents.tutor_agent import get_tutor_response; print('Tutor Agent: OK')"
```

### Step 4.2 — Implement agents/assessment_agent.py

Create `~/projects/mas_education_poc/agents/assessment_agent.py`:
```python
"""
Assessment Agent — MAS Education POC
Tracks mastery via BKT, scores responses, implements self-reflection loop.
Self-reflection triggers when predicted vs actual mastery diverges > 10% over 3 sessions.
"""
import os
import json
import sqlite3
from datetime import datetime
from anthropic import Anthropic
from db.db import update_mastery, log_audit, get_conn

LLM_MODEL = os.getenv("LLM_PRIMARY", "claude-sonnet-4-6")
MASTERY_THRESHOLD = 0.85           # Advance to next topic
DIVERGENCE_THRESHOLD = 0.10        # 10 percentile points — triggers self-reflection
REFLECTION_WINDOW = 3              # Sessions to check divergence over

SCORING_SYSTEM_PROMPT = """You are assessing a GCSE Mathematics student's response.

Score the student's response as:
- CORRECT: The reasoning and answer are mathematically correct
- PARTIAL: Some correct reasoning but incomplete or minor errors
- INCORRECT: Fundamentally wrong approach or answer

Also identify:
- MISCONCEPTION: If the student has a specific wrong belief (describe it briefly)
- CONFIDENCE: HIGH / MEDIUM / LOW (based on how confidently they expressed themselves)

Respond in this exact format:
SCORE: [CORRECT|PARTIAL|INCORRECT]
MISCONCEPTION: [description or "none"]
CONFIDENCE: [HIGH|MEDIUM|LOW]
FEEDBACK: [one sentence of constructive feedback, no more]"""


def score_response(
    student_response: str,
    topic_id: str,
    expected_concept: str,
    session_id: str,
    learner_id: str,
    anthropic_client: Anthropic = None
) -> dict:
    """
    Score a student response and update BKT mastery.
    Returns scoring result and updated mastery estimate.
    """
    if anthropic_client is None:
        anthropic_client = Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))

    # Use LLM to score the response
    scoring_response = anthropic_client.messages.create(
        model=LLM_MODEL,
        max_tokens=150,
        system=SCORING_SYSTEM_PROMPT,
        messages=[{
            "role": "user",
            "content": f"Topic: {topic_id}\nExpected concept: {expected_concept}\n\nStudent response: {student_response}"
        }]
    )

    scoring_text = scoring_response.content[0].text

    # Parse scoring
    score = "INCORRECT"
    misconception = "none"
    confidence = "LOW"
    feedback = ""

    for line in scoring_text.strip().split("\n"):
        if line.startswith("SCORE:"):
            score = line[6:].strip()
        elif line.startswith("MISCONCEPTION:"):
            misconception = line[14:].strip()
        elif line.startswith("CONFIDENCE:"):
            confidence = line[11:].strip()
        elif line.startswith("FEEDBACK:"):
            feedback = line[9:].strip()

    # BKT update
    is_correct = score == "CORRECT"
    new_mastery = update_mastery(learner_id, topic_id, is_correct)
    mastered = new_mastery >= MASTERY_THRESHOLD

    # Log to session
    conn = get_conn()
    conn.execute("""
        INSERT INTO session_log (session_id, learner_id, timestamp, agent, event_type, input_text, output_text, metadata)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        session_id, learner_id, datetime.utcnow().isoformat(),
        "assessment-agent", "mastery_update",
        student_response, feedback,
        json.dumps({"score": score, "new_mastery": new_mastery, "topic_id": topic_id,
                    "misconception": misconception, "mastered": mastered})
    ))
    conn.commit()
    conn.close()

    # Check for self-reflection trigger
    should_reflect = _check_reflection_trigger(learner_id, topic_id)

    # Audit log
    log_audit(
        session_id=session_id,
        learner_id=learner_id,
        agent="assessment-agent",
        decision="mastery_update",
        reasoning=f"Response scored {score}. Mastery: {new_mastery:.2f}. Mastered: {mastered}",
        technical={
            "score": score, "new_mastery": new_mastery, "topic_id": topic_id,
            "misconception": misconception, "should_reflect": should_reflect
        }
    )

    return {
        "score": score,
        "misconception": misconception,
        "confidence": confidence,
        "feedback": feedback,
        "new_mastery": new_mastery,
        "mastered": mastered,
        "should_reflect": should_reflect
    }


def _check_reflection_trigger(learner_id: str, topic_id: str) -> bool:
    """
    Self-reflection loop check.
    Triggers if: recent mastery trajectory diverges > 10% from prediction over 3 sessions.
    Simplified for POC: checks if mastery has stalled (< 5% improvement in last 3 assessments).
    Production: compare predicted trajectory vs actual via stored predictions.
    """
    conn = get_conn()
    recent = conn.execute("""
        SELECT metadata FROM session_log
        WHERE learner_id=? AND agent='assessment-agent'
        AND json_extract(metadata, '$.topic_id') = ?
        ORDER BY timestamp DESC LIMIT ?
    """, (learner_id, topic_id, REFLECTION_WINDOW)).fetchall()
    conn.close()

    if len(recent) < REFLECTION_WINDOW:
        return False

    # Extract mastery values from recent sessions
    mastery_values = []
    for row in recent:
        try:
            meta = json.loads(row["metadata"])
            mastery_values.append(meta.get("new_mastery", 0))
        except Exception:
            pass

    if len(mastery_values) < REFLECTION_WINDOW:
        return False

    # Check for stall: if mastery hasn't improved by > DIVERGENCE_THRESHOLD
    oldest = mastery_values[-1]
    newest = mastery_values[0]
    improvement = newest - oldest

    return improvement < DIVERGENCE_THRESHOLD  # Stalled — trigger reflection


def get_policy_adjustment(learner_id: str, topic_id: str) -> dict:
    """
    When self-reflection triggers: suggest policy adjustments.
    Returns recommended changes to hint threshold, difficulty, approach.
    """
    return {
        "recommendation": "mastery_stall_detected",
        "suggested_actions": [
            "Reduce difficulty: serve easier sub-topic first",
            "Increase scaffolding: offer more structured hints",
            "Check for misconception: re-assess foundational concept"
        ],
        "hint_threshold_adjustment": -1,  # Offer hints sooner
        "notify_teacher": True
    }
```

**Verify:**
```bash
cd ~/projects/mas_education_poc
uv run python -c "from agents.assessment_agent import score_response; print('Assessment Agent: OK')"
```

### Step 4.3 — Integration test: Tutor + Assessment pair
```bash
cd ~/projects/mas_education_poc
uv run python -c "
import os
from dotenv import load_dotenv
load_dotenv()

from agents.tutor_agent import get_tutor_response
from agents.assessment_agent import score_response

# Simulate a student interaction
session_id = 'test-session-001'
learner_id = 'demo-student-001'

print('=== TUTOR AGENT TEST ===')
result = get_tutor_response(
    student_input='How do I solve x squared plus 5x plus 6?',
    conversation_history=[],
    session_id=session_id,
    learner_id=learner_id,
    current_topic='quadratic-equations'
)
print(f'Grounded: {result[\"grounded\"]}')
print(f'Citations: {result[\"citations\"]}')
print(f'Response preview: {result[\"response\"][:100]}...')

print()
print('=== ASSESSMENT AGENT TEST ===')
score = score_response(
    student_response='I think x could be -2 and -3 because those multiply to 6 and add to 5',
    topic_id='quadratic-equations',
    expected_concept='factoring quadratic equations',
    session_id=session_id,
    learner_id=learner_id
)
print(f'Score: {score[\"score\"]}')
print(f'New mastery: {score[\"new_mastery\"]:.3f}')
print(f'Mastered: {score[\"mastered\"]}')
"
```
**Verify:** Grounded=True, citations present, score=CORRECT or PARTIAL, mastery value between 0 and 1.

### ✅ Stage 4 Complete When:
- Tutor Agent returns RAG-grounded response with citations
- Assessment Agent returns score + updated BKT mastery
- No import errors or exceptions in the integration test

**Update SESSION STATE:**
```
CURRENT STAGE:    5 — Planning + Dialogue + Monitor Agents
LAST STEP DONE:   4.3 — Integration test passed
STATUS:           🟡 STAGES 1-4 COMPLETE
```

---

## ═══════════════════════════════════
## STAGE 5: Planning + Dialogue + Monitor Agents
## Est: 60 min | Session: 4
## ═══════════════════════════════════

### Step 5.1 — Implement agents/planning_agent.py

Create `~/projects/mas_education_poc/agents/planning_agent.py`:
```python
"""
Planning Agent — MAS Education POC
Manages learning pathway via SQLite knowledge graph.
Advances learner to next topic when mastery >= 0.85.
"""
import os
import json
from datetime import datetime
from db.db import get_next_topic, log_audit, get_conn

MASTERY_THRESHOLD = 0.85


def get_learner_plan(learner_id: str, session_id: str) -> dict:
    """
    Returns current position, completed topics, and recommended next step.
    Called at session start and after each mastery update.
    """
    conn = get_conn()

    # Get all mastery states
    states = conn.execute(
        "SELECT topic_id, p_mastery, evidence_count FROM learner_state WHERE learner_id=?",
        (learner_id,)
    ).fetchall()

    mastery_map = {row["topic_id"]: row["p_mastery"] for row in states}

    mastered = [tid for tid, pm in mastery_map.items() if pm >= MASTERY_THRESHOLD]
    in_progress = [tid for tid, pm in mastery_map.items() if 0.2 <= pm < MASTERY_THRESHOLD]

    conn.close()

    # Get recommended next topic
    next_topic = get_next_topic(learner_id)

    plan = {
        "learner_id": learner_id,
        "mastered_topics": mastered,
        "in_progress_topics": in_progress,
        "current_topic": next_topic,
        "total_topics": 8,
        "completion_pct": round(len(mastered) / 8 * 100, 1)
    }

    log_audit(
        session_id=session_id,
        learner_id=learner_id,
        agent="planning-agent",
        decision="pathway_update",
        reasoning=f"Learner has mastered {len(mastered)}/8 topics. Next: {next_topic['topic_id'] if next_topic else 'all complete'}",
        technical=plan
    )

    return plan


def check_advancement(learner_id: str, topic_id: str, session_id: str) -> dict:
    """
    Called by orchestrator after Assessment Agent update.
    Returns whether to advance to next topic.
    """
    conn = get_conn()
    state = conn.execute(
        "SELECT p_mastery, evidence_count FROM learner_state WHERE learner_id=? AND topic_id=?",
        (learner_id, topic_id)
    ).fetchone()
    conn.close()

    if not state:
        return {"advance": False, "reason": "no_data"}

    p_mastery = state["p_mastery"]
    evidence_count = state["evidence_count"]

    # Must have both high mastery AND sufficient evidence (≥5 interactions)
    can_advance = p_mastery >= MASTERY_THRESHOLD and evidence_count >= 5

    if can_advance:
        next_topic = get_next_topic(learner_id)
        log_audit(session_id, learner_id, "planning-agent",
                  "advance_topic",
                  f"Mastery {p_mastery:.2f} >= {MASTERY_THRESHOLD} with {evidence_count} evidence items",
                  {"from_topic": topic_id, "to_topic": next_topic["topic_id"] if next_topic else None})
        return {"advance": True, "next_topic": next_topic, "mastery_achieved": p_mastery}

    return {
        "advance": False,
        "current_mastery": p_mastery,
        "evidence_count": evidence_count,
        "needed_mastery": MASTERY_THRESHOLD,
        "needed_evidence": max(0, 5 - evidence_count)
    }
```

### Step 5.2 — Implement agents/dialogue_agent.py

Create `~/projects/mas_education_poc/agents/dialogue_agent.py`:
```python
"""
Dialogue Agent — MAS Education POC
Manages engagement state machine and dialogic quality monitoring.
States: EXPLORING → STUCK → BREAKTHROUGH → CONSOLIDATING → MASTERED
"""
import os
import re
import json
from datetime import datetime
from db.db import log_audit

# Engagement states (from v2.1 architecture)
EXPLORING = "EXPLORING"
STUCK = "STUCK"
BREAKTHROUGH = "BREAKTHROUGH"
CONSOLIDATING = "CONSOLIDATING"
MASTERED = "MASTERED"

STUCK_THRESHOLD = 3        # Consecutive short responses before STUCK
SHORT_RESPONSE_WORDS = 5   # Responses below this count as "short"

IDK_PATTERNS = [
    r"\bidk\b", r"\bi don'?t know\b", r"\bno idea\b",
    r"\bnot sure\b", r"\bi'?m lost\b", r"\bdon'?t understand\b"
]


class DialogueTracker:
    """
    Tracks engagement state for a single learner session.
    One instance per session — managed by orchestrator.
    """

    def __init__(self, learner_id: str, session_id: str):
        self.learner_id = learner_id
        self.session_id = session_id
        self.state = EXPLORING
        self.consecutive_short_responses = 0
        self.turn_count = 0
        self.open_question_count = 0
        self.total_question_count = 0
        self.student_elaboration_count = 0  # responses > 20 words
        self.breakthroughs = 0

    def update(self, student_input: str, agent_response: str, mastery: float) -> dict:
        """
        Update engagement state based on latest exchange.
        Returns: {state, intervention_needed, intervention_type, quality_metrics}
        """
        self.turn_count += 1

        # Analyse student input
        word_count = len(student_input.split())
        is_short = word_count < SHORT_RESPONSE_WORDS
        is_idk = any(re.search(p, student_input.lower()) for p in IDK_PATTERNS)

        if word_count > 20:
            self.student_elaboration_count += 1

        # Analyse agent response for question types
        if "?" in agent_response:
            self.total_question_count += 1
            # Simple heuristic: open questions start with What/How/Why/Tell me
            if re.search(r'\b(what|how|why|tell me|can you|could you)\b', agent_response.lower()):
                self.open_question_count += 1

        # State machine transitions
        old_state = self.state
        intervention_needed = False
        intervention_type = None

        if mastery >= 0.85:
            self.state = MASTERED
        elif self.state == CONSOLIDATING and mastery >= 0.6:
            pass  # Stay in CONSOLIDATING until mastery threshold
        elif self.state in (EXPLORING, STUCK):
            if is_short or is_idk:
                self.consecutive_short_responses += 1
            else:
                self.consecutive_short_responses = 0

            if self.consecutive_short_responses >= STUCK_THRESHOLD:
                if self.state != STUCK:
                    self.state = STUCK
                intervention_needed = True
                intervention_type = "stuck_intervention"
            elif is_idk and not is_short:
                # IDK but expressed in words — productive struggle
                intervention_type = "productive_struggle"

        elif self.state == STUCK:
            if not is_short and not is_idk:
                # Recovery from STUCK
                self.state = EXPLORING
                self.consecutive_short_responses = 0

        # Check for breakthrough (significant elaboration after stuck)
        if (old_state in (STUCK, EXPLORING) and
                word_count > 30 and not is_idk):
            self.state = BREAKTHROUGH
            self.breakthroughs += 1
            if mastery >= 0.4:
                self.state = CONSOLIDATING

        # Quality metrics
        open_ratio = self.open_question_count / max(self.total_question_count, 1)
        elaboration_rate = self.student_elaboration_count / max(self.turn_count, 1)

        result = {
            "state": self.state,
            "previous_state": old_state,
            "state_changed": self.state != old_state,
            "intervention_needed": intervention_needed,
            "intervention_type": intervention_type,
            "quality_metrics": {
                "open_question_ratio": round(open_ratio, 2),
                "student_elaboration_rate": round(elaboration_rate, 2),
                "breakthroughs": self.breakthroughs,
                "consecutive_short": self.consecutive_short_responses
            }
        }

        if self.state != old_state:
            log_audit(
                self.session_id, self.learner_id, "dialogue-agent",
                f"state_transition_{old_state}_to_{self.state}",
                f"Engagement state: {old_state} → {self.state}",
                result
            )

        return result

    def get_intervention_prompt(self) -> str:
        """Returns a prompt addition for the Tutor Agent when intervention is needed."""
        if self.state == STUCK:
            return (
                "\n[DIALOGUE AGENT: Student is STUCK. Switch from closed to open-ended questions. "
                "Ask 'What do you already know about this topic?' "
                "Do NOT provide the answer or a worked example.]"
            )
        elif self.state == BREAKTHROUGH:
            return (
                "\n[DIALOGUE AGENT: BREAKTHROUGH detected. Acknowledge the student's insight. "
                "Reinforce the reasoning process. Build confidence.]"
            )
        return ""

    def get_summary(self) -> dict:
        return {
            "final_state": self.state,
            "turns": self.turn_count,
            "breakthroughs": self.breakthroughs,
            "quality_metrics": {
                "open_question_ratio": round(self.open_question_count / max(self.total_question_count, 1), 2),
                "student_elaboration_rate": round(self.student_elaboration_count / max(self.turn_count, 1), 2)
            }
        }
```

### Step 5.3 — Implement agents/monitor_agent.py

Create `~/projects/mas_education_poc/agents/monitor_agent.py`:
```python
"""
Monitor Agent — MAS Education POC
Aggregates audit logs, estimates session cost, generates session summaries.
Runs asynchronously — never blocks the response path.
"""
import os
import json
from datetime import datetime
from db.db import get_conn

# Approximate cost per token (USD) — for cost tracking
COST_PER_TOKEN = {
    "claude-sonnet-4-6": {"input": 0.000003, "output": 0.000015},
    "qwen3:8b": {"input": 0.0, "output": 0.0}  # Local, free
}


def log_session_event(session_id: str, learner_id: str, event_type: str,
                       agent: str, data: dict):
    """Log a session event to session_log table."""
    conn = get_conn()
    conn.execute("""
        INSERT INTO session_log (session_id, learner_id, timestamp, agent, event_type, metadata)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (
        session_id, learner_id,
        datetime.utcnow().isoformat(),
        agent, event_type,
        json.dumps(data)
    ))
    conn.commit()
    conn.close()


def get_session_summary(session_id: str) -> dict:
    """
    Generate end-of-session summary.
    Includes: turn count, mastery progress, cost estimate, engagement metrics.
    """
    conn = get_conn()

    # Count turns
    turns = conn.execute(
        "SELECT COUNT(*) FROM session_log WHERE session_id=?", (session_id,)
    ).fetchone()[0]

    # Get audit events for this session
    events = conn.execute(
        "SELECT agent, decision, technical FROM audit_events WHERE session_id=?",
        (session_id,)
    ).fetchall()

    # Aggregate cost
    total_tokens = 0
    total_cost_usd = 0.0
    mastery_updates = []

    for event in events:
        try:
            tech = json.loads(event["technical"])
            if "tokens_used" in tech:
                model = tech.get("model", "claude-sonnet-4-6")
                tokens = tech["tokens_used"]
                total_tokens += tokens
                cost = COST_PER_TOKEN.get(model, {}).get("output", 0) * tokens
                total_cost_usd += cost
            if "new_mastery" in tech:
                mastery_updates.append({
                    "topic": tech.get("topic_id"),
                    "mastery": tech["new_mastery"]
                })
        except Exception:
            pass

    conn.close()

    return {
        "session_id": session_id,
        "total_turns": turns,
        "api_calls": len([e for e in events if e["agent"] == "tutor-agent"]),
        "estimated_cost_usd": round(total_cost_usd, 4),
        "estimated_cost_gbp": round(total_cost_usd * 0.79, 4),
        "mastery_updates": mastery_updates,
        "timestamp": datetime.utcnow().isoformat()
    }


def print_session_report(session_id: str):
    """Print a formatted session report to console."""
    summary = get_session_summary(session_id)
    print("\n" + "="*50)
    print(f"SESSION REPORT: {session_id}")
    print("="*50)
    print(f"Turns: {summary['total_turns']}")
    print(f"API calls: {summary['api_calls']}")
    print(f"Estimated cost: £{summary['estimated_cost_gbp']:.4f}")
    if summary["mastery_updates"]:
        print("Mastery updates:")
        for mu in summary["mastery_updates"]:
            print(f"  {mu['topic']}: {mu['mastery']:.3f}")
    print("="*50)
```

**Verify all 3 agents:**
```bash
cd ~/projects/mas_education_poc
uv run python -c "
from agents.planning_agent import get_learner_plan, check_advancement
from agents.dialogue_agent import DialogueTracker
from agents.monitor_agent import log_session_event
print('Planning Agent: OK')
print('Dialogue Agent: OK')
print('Monitor Agent: OK')
"
```

### ✅ Stage 5 Complete When:
All 5 agents import without errors. Planning agent returns next topic. Dialogue tracker initialises.

---

## ═══════════════════════════════════
## STAGE 6: LangGraph Orchestrator
## Est: 60 min | Session: 4 (cont.)
## ═══════════════════════════════════

### Step 6.1 — Implement orchestrator/poc_orchestrator.py

Create `~/projects/mas_education_poc/orchestrator/poc_orchestrator.py`:
```python
"""
LangGraph Orchestrator — MAS Education POC
Implements the 6-state session machine from v2.0 §4.2:
SESSION_INIT → ROUTE_INTENT → [TUTORING|ASSESSMENT|PLANNING] → REFLECT → DELIVER → LOG_UPDATE
"""
import os
import uuid
import json
from typing import TypedDict, Annotated, Literal
from langgraph.graph import StateGraph, END
from anthropic import Anthropic

from agents.tutor_agent import get_tutor_response
from agents.assessment_agent import score_response
from agents.planning_agent import get_learner_plan, check_advancement
from agents.dialogue_agent import DialogueTracker
from agents.monitor_agent import log_session_event, print_session_report
from db.db import log_audit


class SessionState(TypedDict):
    """State passed through all LangGraph nodes."""
    session_id: str
    learner_id: str
    student_input: str
    conversation_history: list[dict]
    current_topic: str
    current_topic_name: str
    intent: str                      # "tutor" | "assess" | "plan" | "unknown"
    agent_response: str
    rag_chunks: list[dict]
    citations: list[str]
    mastery: float
    engagement_state: str            # EXPLORING | STUCK | BREAKTHROUGH | CONSOLIDATING | MASTERED
    intervention_prompt: str
    should_assess: bool
    advancement_check: dict
    turn_count: int


def create_orchestrator(anthropic_client: Anthropic, dialogue_tracker: DialogueTracker):
    """Build and compile the LangGraph session graph."""

    def session_init(state: SessionState) -> SessionState:
        """Load learner plan, set current topic."""
        plan = get_learner_plan(state["learner_id"], state["session_id"])
        current = plan.get("current_topic")

        return {
            **state,
            "current_topic": current["topic_id"] if current else "quadratic-equations",
            "current_topic_name": current["topic_name"] if current else "Quadratic Equations",
            "engagement_state": dialogue_tracker.state,
            "turn_count": state.get("turn_count", 0) + 1
        }

    def route_intent(state: SessionState) -> SessionState:
        """Classify student intent — tutor, assess, or plan."""
        text = state["student_input"].lower()

        # Simple rule-based intent classification (sufficient for POC)
        assessment_signals = ["answer is", "i think", "the solution", "= ", "equals", "my answer"]
        if any(s in text for s in assessment_signals) and state["turn_count"] > 1:
            intent = "assess"
        else:
            intent = "tutor"

        return {**state, "intent": intent}

    def tutoring_node(state: SessionState) -> SessionState:
        """Tutor Agent generates RAG-grounded Socratic response."""
        # Add dialogue intervention if needed
        intervention = dialogue_tracker.get_intervention_prompt()

        result = get_tutor_response(
            student_input=state["student_input"] + intervention,
            conversation_history=state["conversation_history"],
            session_id=state["session_id"],
            learner_id=state["learner_id"],
            current_topic=state["current_topic"],
            anthropic_client=anthropic_client
        )

        return {
            **state,
            "agent_response": result["response"],
            "rag_chunks": result["rag_chunks_used"],
            "citations": result["citations"],
            "should_assess": False
        }

    def assessment_node(state: SessionState) -> SessionState:
        """Assessment Agent scores response and updates BKT mastery."""
        result = score_response(
            student_response=state["student_input"],
            topic_id=state["current_topic"],
            expected_concept=state["current_topic_name"],
            session_id=state["session_id"],
            learner_id=state["learner_id"],
            anthropic_client=anthropic_client
        )

        advancement = check_advancement(
            state["learner_id"], state["current_topic"], state["session_id"]
        )

        # Build response for student
        if result["mastered"]:
            response = f"Excellent! You've mastered {state['current_topic_name']}! 🎉\n{result['feedback']}"
            if advancement.get("next_topic"):
                response += f"\nNext up: {advancement['next_topic']['topic_name']}"
        else:
            response = result["feedback"]
            if result["misconception"] != "none":
                response += f"\n\nLet's look at this differently — {result['misconception']}"

        return {
            **state,
            "agent_response": response,
            "mastery": result["new_mastery"],
            "advancement_check": advancement,
            "should_assess": True
        }

    def reflect_node(state: SessionState) -> SessionState:
        """Update dialogue tracker with latest exchange."""
        dialogue_result = dialogue_tracker.update(
            student_input=state["student_input"],
            agent_response=state["agent_response"],
            mastery=state.get("mastery", 0.0)
        )

        # Update topic if advancement triggered
        new_topic = state["current_topic"]
        new_topic_name = state["current_topic_name"]

        advancement = state.get("advancement_check", {})
        if advancement.get("advance") and advancement.get("next_topic"):
            new_topic = advancement["next_topic"]["topic_id"]
            new_topic_name = advancement["next_topic"]["topic_name"]

        return {
            **state,
            "engagement_state": dialogue_result["state"],
            "current_topic": new_topic,
            "current_topic_name": new_topic_name
        }

    def deliver_node(state: SessionState) -> SessionState:
        """Format final response for delivery."""
        return state  # Response already formatted; add source display here if needed

    def log_update_node(state: SessionState) -> SessionState:
        """Update conversation history, log session event."""
        history = list(state.get("conversation_history", []))
        history.append({"role": "user", "content": state["student_input"]})
        history.append({"role": "assistant", "content": state["agent_response"]})

        log_session_event(
            session_id=state["session_id"],
            learner_id=state["learner_id"],
            event_type="turn_complete",
            agent="orchestrator",
            data={
                "turn": state["turn_count"],
                "intent": state["intent"],
                "engagement_state": state["engagement_state"],
                "citations": state.get("citations", [])
            }
        )

        return {**state, "conversation_history": history[-12:]}  # Keep last 6 turns

    def route_after_intent(state: SessionState) -> Literal["tutoring", "assessment"]:
        return "assessment" if state["intent"] == "assess" else "tutoring"

    # Build graph
    graph = StateGraph(SessionState)
    graph.add_node("session_init", session_init)
    graph.add_node("route_intent", route_intent)
    graph.add_node("tutoring", tutoring_node)
    graph.add_node("assessment", assessment_node)
    graph.add_node("reflect", reflect_node)
    graph.add_node("deliver", deliver_node)
    graph.add_node("log_update", log_update_node)

    graph.set_entry_point("session_init")
    graph.add_edge("session_init", "route_intent")
    graph.add_conditional_edges("route_intent", route_after_intent,
                                 {"tutoring": "tutoring", "assessment": "assessment"})
    graph.add_edge("tutoring", "reflect")
    graph.add_edge("assessment", "reflect")
    graph.add_edge("reflect", "deliver")
    graph.add_edge("deliver", "log_update")
    graph.add_edge("log_update", END)

    return graph.compile()
```

**Verify:**
```bash
cd ~/projects/mas_education_poc
uv run python -c "
from dotenv import load_dotenv; load_dotenv()
from anthropic import Anthropic
from agents.dialogue_agent import DialogueTracker
from orchestrator.poc_orchestrator import create_orchestrator, SessionState
import uuid

client = Anthropic()
tracker = DialogueTracker('demo-student-001', 'test-session')
graph = create_orchestrator(client, tracker)
print('LangGraph orchestrator compiled: OK')
print(f'Nodes: {list(graph.get_graph().nodes.keys())}')
"
```
Expected: `LangGraph orchestrator compiled: OK` with 7 nodes listed.

### ✅ Stage 6 Complete When:
- Orchestrator compiles with 7 nodes
- Test full turn: `graph.invoke(initial_state)` returns state with `agent_response` populated

---

## ═══════════════════════════════════
## STAGE 7: BeeAI Integration + Demo
## Est: 45 min | Session: 5
## ═══════════════════════════════════

### Step 7.1 — Implement main.py

Create `~/projects/mas_education_poc/main.py`:
```python
"""
MAS Education POC — BeeAI AgentStack Entry Point
Single BeeAI server wrapping the full LangGraph orchestrator.
Open http://localhost:8000/ui for the demo interface.

NOTE: BeeAI SDK allows ONLY ONE @server.agent() per Server instance.
The full orchestrator (tutor + assess + plan + dialogue + monitor logic)
runs internally via LangGraph. 'summary' keyword triggers session report.
"""
import os
import uuid
from dotenv import load_dotenv
load_dotenv()

from anthropic import Anthropic
from agentstack_sdk.server import Server
from agentstack_sdk.server.context import RunContext
from a2a.types import Message

from agents.dialogue_agent import DialogueTracker
from orchestrator.poc_orchestrator import create_orchestrator, SessionState
from agents.monitor_agent import print_session_report
from db.init_db import init_database

# Initialise database on startup
init_database()

anthropic_client = Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))
server = Server()

# Session store (in-memory — sufficient for POC single-user demo)
active_sessions: dict[str, dict] = {}


def get_or_create_session(learner_id: str) -> dict:
    if learner_id not in active_sessions:
        session_id = str(uuid.uuid4())[:8]
        tracker = DialogueTracker(learner_id, session_id)
        orchestrator = create_orchestrator(anthropic_client, tracker)
        active_sessions[learner_id] = {
            "session_id": session_id,
            "tracker": tracker,
            "orchestrator": orchestrator,
            "history": [],
            "current_topic": None,
            "turn_count": 0
        }
    return active_sessions[learner_id]


def _extract_text(message: Message) -> str:
    """Extract plain text from A2A Message parts."""
    return "".join(
        part.root.text for part in message.parts
        if hasattr(part.root, "text")
    ).strip()


@server.agent(name="MAS Tutor", description="GCSE Maths Socratic Tutor — multi-agent system")
async def tutor_agent(message: Message, context: RunContext):
    """
    Main entry point — Socratic GCSE Maths Tutor.
    RAG-grounded responses. Multi-agent MAS collaboration behind the scenes.
    Say 'summary' to get a session report.
    """
    learner_id = "demo-student-001"  # Single demo learner for POC
    student_input = _extract_text(message)

    # Special keyword: session summary
    if student_input.lower().strip() == "summary":
        if learner_id in active_sessions:
            session_id = active_sessions[learner_id]["session_id"]
            print_session_report(session_id)
            yield f"Session {session_id} summary printed to terminal."
        else:
            yield "No active session found."
        return

    session = get_or_create_session(learner_id)

    initial_state = SessionState(
        session_id=session["session_id"],
        learner_id=learner_id,
        student_input=student_input,
        conversation_history=session["history"],
        current_topic=session.get("current_topic") or "quadratic-equations",
        current_topic_name="Quadratic Equations",
        intent="unknown",
        agent_response="",
        rag_chunks=[],
        citations=[],
        mastery=0.0,
        engagement_state=session["tracker"].state,
        intervention_prompt="",
        should_assess=False,
        advancement_check={},
        turn_count=session["turn_count"]
    )

    # Run through LangGraph orchestrator
    result = session["orchestrator"].invoke(initial_state)

    # Update session state
    session["history"] = result["conversation_history"]
    session["current_topic"] = result["current_topic"]
    session["turn_count"] = result["turn_count"]

    # Format response with citations
    response = result["agent_response"]
    if result.get("citations"):
        response += f"\n\n*Sources: {', '.join(result['citations'][:2])}*"

    # Print engagement state to console
    print(f"[Dialogue: {result['engagement_state']}] [Topic: {result['current_topic']}] [Mastery: {result.get('mastery', 0):.2f}]")

    yield response


def main():
    print("="*60)
    print("MAS Education POC — Starting BeeAI Server...")
    print(f"Agent: MAS Tutor (tutor + assess + plan + dialogue + monitor)")
    print(f"Web UI: http://localhost:8000/ui")
    print(f"ChromaDB: {os.getenv('CHROMA_PATH')}")
    print(f"SQLite: {os.getenv('SQLITE_DB', 'poc_learner.db')}")
    print("="*60)
    server.run(host="127.0.0.1", port=8000, self_registration=False)


if __name__ == "__main__":
    main()
```

### Step 7.2 — Start and test the server
```bash
cd ~/projects/mas_education_poc
uv run python main.py
```
Expected: Server starts on `localhost:8000`. No import errors.

### Step 7.3 — Open demo UI
Open browser: `http://localhost:8000/ui`
Select: `tutor-agent`
Type: `"I don't understand how to solve x squared plus 5x plus 6 = 0"`

### Step 7.4 — Verify demo session
In the browser UI, verify:
- [ ] Response is coherent and pedagogically appropriate
- [ ] Response includes "Source: [citation label]" — RAG grounding confirmed
- [ ] Console shows `[Dialogue: EXPLORING] [Topic: quadratic-equations]`
- [ ] `poc_learner.db` has new rows in `session_log` and `audit_events`

```bash
sqlite3 ~/projects/mas_education_poc/poc_learner.db "
SELECT agent, decision, reasoning FROM audit_events ORDER BY id DESC LIMIT 5;"
```

### Step 7.5 — Final validation
```bash
sqlite3 ~/projects/mas_education_poc/poc_learner.db "
SELECT COUNT(*) as turns FROM session_log;
SELECT topic_id, p_mastery, evidence_count FROM learner_state;"
```
Expected: turns > 0, mastery rows populated.

### ✅ Stage 7 (POC COMPLETE) When:
- Server runs without errors
- Browser UI loads and accepts student input
- Response is RAG-grounded (citation present)
- All 5 MAS agents participated (visible in audit_events table)
- Session cost estimated and printed

**Final SESSION STATE update:**
```
CURRENT STAGE:    COMPLETE 🟢
LAST STEP DONE:   7.5 — Final validation passed
STATUS:           🟢 POC COMPLETE — Demo ready
SESSIONS DONE:    5
```

---

## Troubleshooting Quick Reference

| Problem | Likely Cause | Fix |
|---------|-------------|-----|
| `ModuleNotFoundError: agentstack` | BeeAI not installed | Re-run step 1.1 |
| `chromadb.errors.NotFoundError` | poc_curriculum collection missing | Re-run stage 2 ingest |
| `sqlite3.OperationalError: no such table` | DB not initialised | Run `uv run python db/init_db.py` |
| `anthropic.AuthenticationError` | API key missing/wrong | Check .env ANTHROPIC_API_KEY |
| Ollama embedding fails | Ollama not running | `ollama serve` in background |
| BeeAI port 8000 in use | Another process | `lsof -i :8000` then kill |
| LangGraph `TypeError` in nodes | State TypedDict mismatch | Check SessionState has all required keys |
| RAG returns 0 chunks | Curriculum not ingested | Check poc_curriculum collection: `uv run python -c "import chromadb; c = chromadb.PersistentClient('/home/tonyts/.pai/rag/chromadb'); print(c.get_collection('poc_curriculum').count())"` |

---

## Session Log

| Session | Date | Stages Completed | Notes |
|---------|------|-----------------|-------|
| 1 | 23 Feb 2026 | — | Plan created. Stage 1 pending. Rate limit at 17:00 GMT |
| 2 | 23 Feb 2026 | POC Stages 1–7 | Full POC built: BeeAI server, LangGraph orchestrator, RAG, SQLite BKT, all 5 agents |
| 3 | 24 Feb 2026 | KG Phases 0–3 | Neo4j KG built: 4 quals, 191 LOs, 77 Concepts, spiral chains, DEEPENS edges |
| 4 | 24 Feb 2026 | KG Phase 4 | Planning Agent migrated to Neo4j; BKT writes to HAS_MASTERY; service scripts added |

---

## ═══ NEO4J KNOWLEDGE GRAPH STATUS ═══

Reference: `KG_PLANNING_DOCUMENT.md` for full design and phase definitions.

### Graph State (as of 24 Feb 2026)

```
Nodes
  Qualification:       4  (0580, 0606, 9709, 9231)
  Topic:              19
  Subtopic:           75
  LearningObjective: 191  (0580: 100 | 0606: 35 | 9709: 36 | 9231: 20)
  Concept:            77
  ConceptInstance:   114
  MathDomain:          6
  Learner:             1  (test learner from Phase 4 validation)

Relationships
  HAS_TOPIC:         19
  HAS_SUBTOPIC:      75
  HAS_LO:           191
  PREREQUISITE_OF:  239
  TEACHES:          191   (LO → ConceptInstance)
  INSTANCE_OF:      114   (ConceptInstance → Concept)
  AT_LEVEL:         114   (ConceptInstance → Qualification)
  BELONGS_TO:        82   (Concept → MathDomain)
  DEEPENS:           20   (spiral curriculum chains across qualifications)
  HAS_MASTERY:        1   (live learner mastery edges — grows at runtime)
```

### DEEPENS Chains (spiral curriculum)
```
  0580 → 0606:  3 chains
  0580 → 9709:  3 chains
  0580 → 9231:  1 chain
  0606 → 9709:  9 chains
  9709 → 9231:  4 chains
  Total:        20 DEEPENS edges spanning 5 spiral chains
```

### Phase Status

| Phase | Name | Status | What was built |
|-------|------|--------|----------------|
| 0 | Infrastructure | ✅ COMPLETE | Docker Neo4j 5.x, `db/kg.py` driver, `db/schema.cypher` constraints/indexes |
| 1 | Core Graph Build | ✅ COMPLETE | YAML curriculum → `scripts/ingest_curriculum.py` → Qualification/Topic/Subtopic/LO nodes for all 4 quals |
| 2 | Concept & ConceptInstance Layer | ✅ COMPLETE | `scripts/extract_concepts.py` (LLM extraction), 77 Concepts, 114 ConceptInstances, TEACHES/INSTANCE_OF edges |
| 3 | Multi-Qualification | ✅ COMPLETE | `scripts/derive_deepens.py` → 20 DEEPENS edges, 5 spiral chains, cross-qual prerequisite edges |
| 4 | Planning Agent Migration | ✅ COMPLETE | `agents/planning_agent.py` and `agents/assessment_agent.py` use Neo4j; BKT reads from LO node properties; HAS_MASTERY edges at runtime |
| 5 | RAG Integration | ⏳ NEXT | Add `[:HAS_RESOURCE]` edges from LOs to ChromaDB chunks; add curriculum markdown files for remaining topics |

### What works end-to-end today
- Fresh learner starts at difficulty=1 IGCSE 0580 LO (`0580-core-number-integers-types`)
- Planning Agent queries Neo4j to determine next LO (Cypher, not SQLite)
- BKT mastery updates write to `[:HAS_MASTERY]` edges in Neo4j
- Advancement check (mastery ≥ 0.85 AND evidence ≥ 5) reads from Neo4j
- Session/audit logs still written to SQLite (`poc_learner.db`) — correct
- Chat UI (`chat_ui.py`) and CLI demo (`demo.py`) both use Neo4j routing

### What does NOT work yet (Phase 5 gap)
```
ISSUE:  Tutor Agent RAG (ChromaDB poc_curriculum) only covers 4 topics:
          linear-equations, number-and-algebra-basics, number-basics, quadratic-equations
          (12 chunks total)

EFFECT: Any student question outside those 4 topics triggers C4 fallback:
          "Let me check that with your teacher."
          This is CORRECT constitutional behaviour — not a bug.

FIX:    Phase 5 — add curriculum markdown files for remaining topics and ingest into ChromaDB.
        Optional: add [:HAS_RESOURCE] edges in Neo4j linking LO nodes to chunk IDs.
```

### Key files

| File | Role |
|------|------|
| `docker-compose.neo4j.yml` | Start/stop Neo4j container |
| `db/kg.py` | Neo4j driver, all Cypher query helpers, BKT functions |
| `db/schema.cypher` | Constraints and indexes |
| `scripts/ingest_curriculum.py` | YAML → graph ingestion (idempotent) |
| `scripts/extract_concepts.py` | LLM-based concept extraction per qualification |
| `scripts/derive_deepens.py` | Derives DEEPENS edges from ConceptInstance chains |
| `agents/planning_agent.py` | Neo4j-backed pathway routing (Phase 4) |
| `agents/assessment_agent.py` | BKT scoring → writes to HAS_MASTERY (Phase 4) |
| `KG_PLANNING_DOCUMENT.md` | Full design doc including Phase 5 spec |

### To start Neo4j
```bash
cd ~/projects/mas_education_poc
docker compose -f docker-compose.neo4j.yml up -d
# Browser UI: http://localhost:7474
# Credentials: neo4j / mas_education_poc_dev
```

### To start the Chat UI
```bash
cd ~/projects/mas_education_poc
./start.sh        # start in background
./status.sh       # check status
./stop.sh         # stop
# Open http://localhost:8080 in browser
```

### Phase 5 — What to do next

From `KG_PLANNING_DOCUMENT.md` §11:
1. Write curriculum markdown files for remaining IGCSE 0580 topics (geometry, statistics, probability, vectors, etc.)
2. Ingest into ChromaDB `poc_curriculum` collection: `uv run python scripts/ingest_curriculum.py <file>`
3. Optionally: add `[:HAS_RESOURCE]` edges from LO nodes to ChromaDB chunk IDs
4. Update Tutor Agent to optionally use KG-guided chunk selection (follow HAS_RESOURCE edges)

Estimated effort: 1 day for full IGCSE 0580 coverage.
