"""
MAS Education POC — Interactive CLI Demo
Runs the full multi-agent system directly (no HTTP server needed).
Type your question, get a Socratic tutoring response.
Type 'summary' for a session cost/turn report.
Type 'quit' or Ctrl+C to exit.
"""
import asyncio
import os
import uuid
from dotenv import load_dotenv
load_dotenv()

from anthropic import AsyncAnthropic
from agents.dialogue_agent import DialogueTracker
from orchestrator.poc_orchestrator import create_orchestrator, SessionState
from agents.monitor_agent import print_session_report
from db.init_db import init_database

def main():
    init_database()

    learner_id = "demo-student-001"
    session_id = str(uuid.uuid4())[:8]
    client = AsyncAnthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))
    tracker = DialogueTracker(learner_id, session_id)
    graph = create_orchestrator(client, tracker)

    history = []
    current_topic = None       # set by session_init from Neo4j on first turn
    current_topic_name = None  # set by session_init from Neo4j on first turn
    turn_count = 0

    print("=" * 60)
    print("  MAS Education POC — GCSE Maths Socratic Tutor")
    print(f"  Session: {session_id}")
    print("  Type 'summary' for cost report. 'quit' to exit.")
    print("=" * 60)
    print()

    while True:
        try:
            student_input = input("You: ").strip()
        except (KeyboardInterrupt, EOFError):
            break

        if not student_input:
            continue

        if student_input.lower() == "quit":
            break

        if student_input.lower() == "summary":
            print_session_report(session_id)
            continue

        state = SessionState(
            session_id=session_id,
            learner_id=learner_id,
            student_input=student_input,
            conversation_history=history,
            current_topic=current_topic or "unknown",
            current_topic_name=current_topic_name or "Mathematics",
            intent="unknown",
            agent_response="",
            rag_chunks=[],
            citations=[],
            mastery=0.0,
            engagement_state=tracker.state,
            intervention_prompt="",
            should_assess=False,
            advancement_check={},
            turn_count=turn_count
        )

        result = asyncio.run(graph.ainvoke(state))

        history = result["conversation_history"]
        current_topic = result["current_topic"]
        current_topic_name = result["current_topic_name"]
        turn_count = result["turn_count"]

        response = result["agent_response"]
        if result.get("citations"):
            response += f"\n  ↳ {', '.join(result['citations'][:2])}"

        print()
        print(f"Tutor [{result['engagement_state']}]: {response}")
        print()

    print()
    print_session_report(session_id)
    print("Goodbye!")


if __name__ == "__main__":
    main()
