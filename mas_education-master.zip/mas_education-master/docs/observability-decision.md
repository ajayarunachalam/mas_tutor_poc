# MAS Education POC — Observability Tool Decision

**Source:** ai-engineering-from-scratch · Phase 14, Lesson 24 · Agent Observability — Langfuse, Phoenix, Opik  
**Date:** 2026-06-19  
**Decision:** **Arize Phoenix** (self-hosted locally on WSL2, traces routed from VPS via Tailscale)  
**Status:** ✅ Deployed 2026-06-19 — Phoenix running locally on port 6006, VPS sending traces to `http://100.119.23.55:6006/v1/traces`. "mas-tutor" project confirmed in Phoenix UI.

---

## Decision

**Selected: Arize Phoenix (self-hosted)**

Phoenix wins for the MAS tutor context due to its lightweight single-container footprint (fits alongside `mas-tutor.service` on the Scaleway DEV1-S), strong built-in eval framework aligned with R1 metrics, and OpenTelemetry-native tracing that avoids deep callback lock-in.

---

## Comparison

### Langfuse

**Self-hosting complexity (Scaleway DEV1-S — 1 vCPU, 2GB RAM):**
- Docker Compose with 4 services: `langfuse-web`, `langfuse-worker`, `PostgreSQL`, `ClickHouse`
- Typical RAM at idle: 1.4–1.8GB — **HIGH RISK** on a 2GB server already running `mas-tutor.service` + Caddy
- Would require VPS upgrade to at least DEV1-M (2 vCPU, 4GB RAM) for comfortable coexistence
- Setup time: ~1.5hr including ClickHouse schema initialisation

**LangGraph integration:**
- Official `langfuse.callback.CallbackHandler()` via `langfuse` Python package
- Works with LangGraph `RunnableConfig`: `config = {"callbacks": [langfuse_handler]}`
- Node-level tracing: yes (LangGraph emits span events per node, Langfuse captures them)
- Integration quality: mature, well-documented, production-proven

**Cost:** OSS free; Langfuse Cloud starts at $59/month

**Eval dataset export:** ✅ Full — dataset creation via UI, CSV/JSON export, LLM-as-judge scoring

**Verdict:** Best-in-class LangGraph integration but RAM requirements exceed DEV1-S capacity.

---

### Arize Phoenix ✅ SELECTED

**Self-hosting complexity (Scaleway DEV1-S):**
- Single Docker container: `docker run -p 6006:6006 arizephoenix/phoenix:latest`
- RAM at idle: ~300–500MB — **SAFE** on DEV1-S alongside `mas-tutor.service` + Caddy
- Default storage: SQLite (no external database dependency)
- Setup time: ~45min including LangGraph instrumentation

**LangGraph integration:**
- Via OpenTelemetry (OTEL) — less code lock-in than callback-based solutions
- Instrumentation:
  ```python
  import phoenix as px
  from phoenix.otel import register
  from openinference.instrumentation.langchain import LangChainInstrumentor
  
  tracer_provider = register(project_name="mas-tutor", endpoint="http://localhost:6006/v1/traces")
  LangChainInstrumentor().instrument(tracer_provider=tracer_provider)
  ```
  `LangChainInstrumentor` instruments LangGraph as well (LangGraph extends LangChain's Runnable protocol).
- Node-level tracing: yes (each LangGraph node becomes an OTEL span)
- Integration quality: good; less mature than Langfuse but sufficient for MAS tutor volume

**Cost:** Apache 2.0 OSS — free forever self-hosted; Arize cloud has a free tier (50k spans/month)

**Eval dataset export:** ✅ Good — Phoenix Datasets UI, export to pandas DataFrames, LLM-as-judge built-in. Directly supports the R1 metric definitions (M2 precision, M3 recall via human annotation UI).

**Verdict:** Right fit for the DEV1-S. OTEL means future migration to a heavier tool (Langfuse) is straightforward if the VPS is upgraded.

---

### Opik (Comet)

**Self-hosting complexity (Scaleway DEV1-S):**
- Self-hosted Docker Compose available but documentation is sparse (as of June 2026)
- Opik is primarily a cloud-first product; self-hosted path is less mature
- RAM: unclear from documentation; likely moderate

**LangGraph integration:**
- `opik.integrations.langchain.OpikTracer` — similar to Langfuse callback approach
- Integration quality: newer and less tested in production

**Cost:** Comet cloud free tier (limited); self-hosted free

**Eval dataset export:** ✅ Opik Datasets feature available; less mature than Langfuse/Phoenix

**Verdict:** Skip for now. Not enough self-hosting maturity or community evidence for the DEV1-S.

---

## Summary Table

| Criterion | Langfuse | Phoenix ✅ | Opik |
|-----------|----------|-----------|------|
| DEV1-S RAM footprint | ❌ 1.4-1.8GB | ✅ 300-500MB | ⚠️ unclear |
| LangGraph integration | ✅ Excellent | ✅ Good (OTEL) | ✅ Good |
| Self-host maturity | ✅ Mature | ✅ Mature | ⚠️ Emerging |
| Eval export | ✅ Full | ✅ Good | ✅ Basic |
| Cost (self-hosted) | ✅ Free | ✅ Free | ✅ Free |
| Lock-in risk | Medium (callbacks) | Low (OTEL) | Medium |

---

## Deployment Plan (Sprint 4)

### Prerequisites
- R1 baseline document complete (this is done: `evals/baseline-2026-06.md`)
- Log enrichment deployed (3 fields added to `chat_ui.py` — see baseline doc)

### Step 1 — Deploy Phoenix (✅ DONE — runs locally)

**Deployment decision:** VPS RAM was too constrained (388MB free, Neo4j already running). Phoenix (300-500MB) would push the DEV1-S into OOM territory. Instead: Phoenix runs on the local WSL2 machine (25GB RAM free) and the VPS sends traces across Tailscale.

```bash
# Run locally (already done — do not run again)
docker run -d \
  --name phoenix \
  --restart unless-stopped \
  -p 6006:6006 \
  -v /home/tonyts/.phoenix:/root/.phoenix \
  arizephoenix/phoenix:latest
```

Phoenix is accessible at:
- Locally: `http://localhost:6006`
- Via Tailscale from VPS: `http://100.119.23.55:6006`

### Step 2 — Instrument MAS Tutor (1hr)

Add to `pyproject.toml`:
```toml
[project.dependencies]
arize-phoenix-otel = ">=0.6"
openinference-instrumentation-langchain = ">=0.1"
```

Add to `chat_ui.py` startup (before `app = FastAPI()`):
```python
import phoenix as px
from phoenix.otel import register
from openinference.instrumentation.langchain import LangChainInstrumentor

if os.getenv("PHOENIX_ENABLED", "false").lower() == "true":
    tracer_provider = register(
        project_name="mas-tutor",
        endpoint=os.getenv("PHOENIX_ENDPOINT", "http://localhost:6006/v1/traces"),
    )
    LangChainInstrumentor().instrument(tracer_provider=tracer_provider)
```

Gated behind `PHOENIX_ENABLED=true` env var — traces only when explicitly enabled.

### Step 3 — Verify Traces (30min)
Send one test conversation. In Phoenix UI (port 6006): confirm traces per turn, node-level spans visible, latency per node captured.

### Step 4 — Configure Eval Datasets (30min)
Create a Phoenix Dataset for M2 (topic routing) and M3 (distress recall):
- Upload 20-turn sample from VPS log
- Add human annotation columns: `correct_topic`, `is_distressed`
- Run precision/recall calculation via Phoenix's eval UI

---

## Upgrade Path

If the VPS is upgraded to DEV1-M (4GB RAM) or higher, Langfuse becomes the preferred tool due to its superior LangGraph callback integration and more mature dataset management. Migration from Phoenix is straightforward: replace `LangChainInstrumentor` with `langfuse.callback.CallbackHandler` — the eval dataset structure is similar.

---

*Decision document generated 2026-06-19 · Implements R4 from AI Engineering Implementation Plan · Next action: complete R1 log enrichment, then deploy Phoenix in Sprint 4.*
