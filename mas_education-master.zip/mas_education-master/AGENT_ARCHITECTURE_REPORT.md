# MAS Education POC — Agent Architecture Report

**Project:** MAS Education Proof of Concept — GCSE Maths Socratic Tutor
**Date:** 24 February 2026
**Author:** Thane Thompson-Starkey, Head of Data, Analytics and AI — Cambridge University Press & Assessment
**Status:** POC Complete (all 7 build stages verified)
**Project location:** `/home/tonyts/projects/mas_education_poc/`

---

## Purpose of This Document

This report describes the internal architecture of the MAS Education POC: how the five agents are designed, what each one does, how they coordinate through a LangGraph orchestrator, and how a student actually experiences the system. It is intended as a technical reference for Cambridge colleagues evaluating multi-agent AI approaches to educational software.

---

## 1. System Overview

The POC is a working demonstration of a **multi-agent AI tutoring system** for GCSE Maths. Rather than a single AI model answering questions, five specialised agents collaborate behind the scenes, each with a distinct responsibility. No agent can do another's job. They communicate exclusively through a shared state object managed by the LangGraph orchestrator — they never call each other directly.

**The five agents:**

| Agent | Role |
|---|---|
| **Tutor Agent** | Generates all student-facing responses using the Socratic method, grounded in curriculum content |
| **Assessment Agent** | Scores student answers and updates a probabilistic mastery model (BKT) |
| **Planning Agent** | Maintains the learning pathway — what topic the student is on, what comes next |
| **Dialogue Agent** | Monitors engagement state and injects invisible interventions when a student is stuck |
| **Monitor Agent** | Logs all events and tracks API cost across the session |

**Supporting infrastructure:**

- **RAG pipeline** — ChromaDB + Ollama `qwen3-embedding:8b` (4096-dimensional embeddings). All Tutor responses must be grounded in retrieved curriculum chunks. If no relevant chunks are found, the LLM is never called.
- **Bayesian Knowledge Tracing (BKT)** — a probabilistic mastery model per learner/topic, stored in SQLite. Accounts for the fact that correct answers may be guesses and incorrect answers may be slips.
- **SQLite database** — 5 tables: `learner_state`, `session_log`, `audit_events`, `topics`, `prerequisites`. The GCSE topic prerequisite chain is encoded here.

---

## 2. The Five Agents — In Detail

---

### 2.1 Tutor Agent

**File:** `agents/tutor_agent.py`
**Model:** Claude Sonnet (`claude-sonnet-4-6`)
**Constitutional principle:** C4 — every response must be RAG-grounded. No exceptions.

The Tutor Agent is the only agent the student ever sees. Every message the student receives is generated here. It operates on the Socratic method: ask one guiding question per turn, never give the answer directly, use encouraging language, keep responses under 150 words.

**Processing sequence on each call:**

1. **RAG retrieval (mandatory, before any LLM call).** The agent calls `retrieve()` with the student's message, the subject (`mathematics`), and the current topic. This generates four query variants (original query, HyDE hypothesis, broad paraphrase, narrow paraphrase), retrieves up to 10 candidate chunks from ChromaDB, reranks by term overlap, and returns the top 4 with citation labels (e.g. `quadratic-equations-chunk-2`).

2. **C4 hard gate.** If `retrieve()` returns zero chunks — either because the topic has no curriculum file yet, or because Ollama is not running — the agent does **not** call the LLM. It returns a hardcoded escalation response:
   > *"I couldn't find that in our curriculum materials. Let me check that with your teacher."*
   This is logged as a `c4_fallback` audit event. Hallucination is structurally impossible on curriculum topics because the LLM is never consulted without grounding material.

3. **LLM call with injected context.** When chunks are found, the student's message is combined with the retrieved curriculum text and sent to Claude Sonnet. Only the last 3 turns of conversation history are included (to manage cost). The system prompt enforces: curriculum-only, one question at a time, cite source.

4. **Output** returned to orchestrator: `{response, rag_chunks_used, citations, grounded}`. The `citations` list is displayed in the browser UI below each tutor message.

**What the Tutor Agent does not do:** It does not track whether the student understands anything. It does not decide what topic to work on. It does not detect emotional state. Those are other agents' jobs.

---

### 2.2 Assessment Agent

**File:** `agents/assessment_agent.py`
**Model:** Claude Sonnet
**Invocation trigger:** Student message contains assessment signals ("I think", "the answer is", "equals", "= ", etc.) AND it is not the first turn.

The Assessment Agent's job is to answer the question: *did the student actually understand that?* It is never invoked on a student's opening question — only when the student expresses an answer or attempt.

**Processing sequence:**

1. **LLM-based scoring.** The student's response is sent to Claude Sonnet with a structured scoring prompt. The response is classified as `CORRECT`, `PARTIAL`, or `INCORRECT`, and any identified misconception is named. The output format is strict:
   ```
   SCORE: CORRECT | PARTIAL | INCORRECT
   MISCONCEPTION: [description or "none"]
   CONFIDENCE: HIGH | MEDIUM | LOW
   FEEDBACK: [one sentence of constructive feedback]
   ```

2. **BKT mastery update.** `CORRECT` maps to a positive evidence event; `PARTIAL` and `INCORRECT` both map to negative. The BKT formula is applied:
   - **If correct:** `P(L|correct) = P(L) × (1−slip) / [P(L)×(1−slip) + (1−P(L))×guess]`
   - **If incorrect:** `P(L|incorrect) = P(L) × slip / [P(L)×slip + (1−P(L))×(1−guess)]`
   - **Learning update:** `P(L_new) = P(L|evidence) + (1 − P(L|evidence)) × learn`

   The BKT parameters for quadratic equations: P(L₀)=0.05, P(learn)=0.20, P(slip)=0.15, P(guess)=0.15. A first correct answer raises mastery from 0.05 to approximately 0.38 — not to 0.85, because a single correct answer could be a lucky guess.

3. **Advancement check.** After every BKT update, the Planning Agent's `check_advancement()` is called. This asks SQLite: is `p_mastery ≥ 0.85` AND `evidence_count ≥ 5`? Both conditions must hold. A student cannot advance by getting lucky on one question — they need sustained correct performance.

4. **Self-reflection trigger.** If mastery improvement over the last 3 assessments is less than 10 percentage points (the student is stalling), `should_reflect=True` is returned. In a production system this would trigger a policy adjustment: easier subtopic, more scaffolding, teacher notification. In the POC it is logged for analysis.

5. **Output** returned to orchestrator: `{score, misconception, confidence, feedback, new_mastery, mastered, should_reflect}`. The `feedback` string becomes the student-visible response on assessment turns.

---

### 2.3 Planning Agent

**File:** `agents/planning_agent.py`
**Model:** None — no LLM calls. Pure data querying.

The Planning Agent maintains the student's position in the GCSE Maths topic ladder. It is consulted at session start and after every mastery update. It never generates text for the student.

**The 8-topic GCSE prerequisite chain (seeded into SQLite on first run):**

```
Number Basics → Algebra Basics → Linear Equations → Linear Graphs
  → Simultaneous Equations → Quadratic Factoring → Quadratic Equations → Quadratic Graphs
```

Each topic has a prerequisite pointing to the previous one. `get_next_topic()` walks this chain and returns the first topic where the prerequisite is mastered (or no prerequisite exists). A fresh student therefore starts at Number Basics.

**Two functions used by the orchestrator:**

- `get_learner_plan(learner_id, session_id)` — Called at session start. Returns current topic, list of mastered topics, list of in-progress topics, and overall completion percentage (mastered/8 × 100).

- `check_advancement(learner_id, topic_id, session_id)` — Called after every Assessment Agent run. Returns `{advance: True/False, next_topic: {...}}`. If `advance=True`, the orchestrator immediately updates `current_topic` in the session state — from the next student turn, the Tutor will retrieve from the new topic's curriculum.

---

### 2.4 Dialogue Agent

**File:** `agents/dialogue_agent.py`
**Model:** None — rule-based state machine. No LLM calls.

The Dialogue Agent monitors the *quality* of the tutoring interaction — not whether the student is right or wrong, but whether they are productively engaged. It runs a 5-state engagement machine and, crucially, can **modify the Tutor Agent's behaviour** without the student being aware.

**The 5-state engagement machine:**

| State | Entry condition | Student experience |
|---|---|---|
| `EXPLORING` | Session start (default) | Normal Socratic tutoring |
| `STUCK` | 3+ consecutive responses under 5 words, or IDK expressions | Invisible intervention: Tutor switches to open-ended mode |
| `BREAKTHROUGH` | Response over 30 words after STUCK or EXPLORING | Invisible prompt: Tutor acknowledges insight, builds confidence |
| `CONSOLIDATING` | BREAKTHROUGH + BKT mastery ≥ 0.40 | Tutor reinforces reasoning |
| `MASTERED` | BKT mastery ≥ 0.85 | Session complete for this topic |

The `DialogueTracker` is a stateful Python object, created once per session and held in memory by the orchestrator throughout. It is updated after every exchange by calling `tracker.update(student_input, agent_response, mastery)`.

**The intervention mechanism — how the Dialogue Agent influences the Tutor:**

When the engagement state is `STUCK`, the Dialogue Agent's `get_intervention_prompt()` method returns this string:
```
[DIALOGUE AGENT: Student is STUCK. Switch from closed to open-ended questions.
Ask 'What do you already know about this topic?'
Do NOT provide the answer or a worked example.]
```

The orchestrator appends this string **directly to the student's input** before passing it to the Tutor Agent. Claude Sonnet receives the instruction as part of the user turn and follows it — switching from specific probing questions to open-ended, exploratory ones. The student sees only the change in questioning style; the instruction itself is never visible.

A BREAKTHROUGH intervention works similarly, instructing the Tutor to acknowledge the student's insight and reinforce the reasoning process.

**Quality metrics tracked continuously:**
- `open_question_ratio` — what proportion of tutor questions begin with What/How/Why/Tell me
- `student_elaboration_rate` — what proportion of student turns exceed 20 words
- `breakthroughs` — count of STUCK/EXPLORING → BREAKTHROUGH transitions per session

These are available in the session summary and audit log for learning analytics purposes.

---

### 2.5 Monitor Agent

**File:** `agents/monitor_agent.py`
**Model:** None — aggregation only.

The Monitor Agent provides the audit and cost-tracking layer. It never blocks the response path — all its writes are fire-and-forget.

**Two primary functions:**

- `log_session_event()` — Called by the orchestrator at the end of every turn. Records: turn number, intent classification (tutor/assess), engagement state, citations used.

- `get_session_summary()` — Called on demand (student types `summary`) or at session end. Aggregates from the `audit_events` table: total turns, total Anthropic API calls, estimated cost (in GBP, at $0.000015 per output token × 0.79 FX rate), and the BKT mastery trajectory for the session.

Each of the other four agents also independently writes to `audit_events` for significant decisions: the Tutor logs every RAG grounding and C4 fallback; the Assessment Agent logs every mastery update; the Planning Agent logs every topic advancement; the Dialogue Agent logs every state transition. The Monitor reads this unified audit trail.

---

## 3. The LangGraph Orchestrator

**File:** `orchestrator/poc_orchestrator.py`

Every student message is processed by a **6-node directed graph** compiled with LangGraph. All 5 agents are invoked from within graph nodes. The state passed between nodes is a flat `SessionState` TypedDict — every field is explicitly declared and all agent coordination is inspectable.

**Graph structure:**

```
                    ┌─────────────────┐
   student input ──▶│  SESSION_INIT   │  ← Planning Agent: load learner plan, set current topic
                    └────────┬────────┘
                             │
                    ┌────────▼────────┐
                    │  ROUTE_INTENT   │  ← Rule-based classifier (no LLM): "tutor" or "assess"
                    └────────┬────────┘
                             │
              ┌──────────────┴──────────────┐
    "tutor"   │                             │  "assess"
              ▼                             ▼
   ┌──────────────────┐        ┌──────────────────────┐
   │    TUTORING      │        │     ASSESSMENT       │
   │  (Tutor Agent)   │        │  (Assessment Agent)  │
   │  RAG → LLM →     │        │  LLM score → BKT →   │
   │  Socratic Q      │        │  check advancement   │
   └────────┬─────────┘        └──────────┬───────────┘
            │                             │
            └──────────────┬──────────────┘
                           │
                  ┌────────▼────────┐
                  │    REFLECT      │  ← Dialogue Agent: update state machine
                  │                 │    Planning Agent: apply topic advancement if triggered
                  └────────┬────────┘
                           │
                  ┌────────▼────────┐
                  │    DELIVER      │  ← Format final response (pass-through in current POC)
                  └────────┬────────┘
                           │
                  ┌────────▼────────┐
                  │   LOG_UPDATE    │  ← Monitor Agent: log turn event
                  │                 │    Update conversation history (keep last 6 turns / 12 messages)
                  └────────┬────────┘
                           │
                         END ──▶ response returned to student
```

**Intent routing — how the graph decides which branch to take:**

The `ROUTE_INTENT` node uses a simple rule-based classifier with no LLM call:

```python
assessment_signals = ["answer is", "i think", "the solution", "= ", "equals", "my answer"]
if any(s in text for s in assessment_signals) and turn_count > 1:
    intent = "assess"
else:
    intent = "tutor"
```

Turn 1 always routes to TUTORING regardless of content. From turn 2 onwards, any message containing an assessment signal routes to ASSESSMENT. All other messages route to TUTORING. This is an intentional POC simplification — a production system would use an LLM classifier here.

**The REFLECT node** is where Dialogue Agent state updates and Planning Agent topic advancement are both applied. Topic advancement triggered by Assessment feeds through here: if `check_advancement()` returned `advance=True`, `current_topic` in the session state is updated to the next topic. From the following turn, the Tutor will automatically retrieve from the new topic's curriculum.

---

## 4. Data Flows Summary

```
Every turn:

  Student message
      → SESSION_INIT: Planning Agent queries SQLite → sets current_topic, turn_count
      → ROUTE_INTENT: rule-based → "tutor" or "assess"

  TUTORING path:
      Dialogue Agent.get_intervention_prompt()       [in-memory, instant]
      → RAG retrieve (ChromaDB + Ollama embedding)   [local service, ~200ms]
      → Anthropic API (Claude Sonnet, max 500 tokens) [external, ~1-3s]
      → return response + citations

  ASSESSMENT path:
      Anthropic API (Claude Sonnet, max 150 tokens)  [external, ~0.5-1s]
      → BKT formula applied → SQLite write            [local DB, instant]
      → Planning Agent.check_advancement()            [local DB query, instant]

  Both paths converge at:
      REFLECT: Dialogue Agent.update()                [in-memory state update]
      LOG_UPDATE: Monitor Agent.log_session_event()   [SQLite write, async]

  Session end (or student types 'summary'):
      Monitor Agent.get_session_summary()             [SQLite read, aggregation]
```

---

## 5. Student Walkthrough — Annotated Example

This example traces a complete interaction on the **Quadratic Equations** topic, showing every agent's activity at each step.

**Setup:** Student ID `demo-student-001`. Starting topic: `quadratic-equations` (p_mastery = 0.05). Session ID: `a3f1c2b8`.

---

### Turn 1 — Student opens with a question

**Student:** *"I don't really get how to solve quadratic equations"*

**SESSION_INIT:** Planning Agent reads `learner_state` from SQLite. Topic is `quadratic-equations`. Turn count set to 1.

**ROUTE_INTENT:** No assessment signals. Turn 1. → **TUTORING**

**TUTORING:**
- Dialogue Agent state = EXPLORING (start). `get_intervention_prompt()` returns `""` (no intervention).
- RAG retrieves `quadratic-equations-chunk-1`, `quadratic-equations-chunk-2`. Curriculum content found — C4 gate passes.
- Claude Sonnet generates Socratic response with injected curriculum context.
- Output: *"Good question to explore. Let's start with a specific one. If you had x² + 5x + 6 = 0, what would you try first?"*
- Citations: `[quadratic-equations-chunk-2, quadratic-equations-chunk-1]`

**REFLECT:** Dialogue Agent updates — student input was 12 words, not short, not IDK. Consecutive short count stays 0. State remains EXPLORING.

**LOG_UPDATE:** Monitor logs `{turn:1, intent:tutor, engagement:EXPLORING}`.

```
Tutor [EXPLORING]: Good question to explore. Let's start with a specific one.
  If you had x² + 5x + 6 = 0, what would you try first?
  ↳ quadratic-equations-chunk-2, quadratic-equations-chunk-1
```

*Mastery bar: 5% (BKT not yet updated — no assessment signal)*

---

### Turns 2, 3, 4 — Student gives very short responses

**Student:** *"idk"* / *"Maybe times something?"* / *"idk"*

Each routes to TUTORING. No assessment signals.

**Dialogue Agent tracking (across 3 turns):**
- Turn 2: word count = 1 (< 5 threshold), IDK detected → consecutive short count = 1
- Turn 3: word count = 3 (< 5) → consecutive short count = 2
- Turn 4: word count = 1, IDK → consecutive short count = **3** → threshold reached

**At turn 4:** `consecutive_short >= 3` triggers state transition: **EXPLORING → STUCK**

Audit event written: `state_transition_EXPLORING_to_STUCK`. `intervention_needed = True`.

**TUTORING at turn 4 — with STUCK intervention:**

Before calling the Tutor Agent, the orchestrator calls `get_intervention_prompt()`:
```
[DIALOGUE AGENT: Student is STUCK. Switch from closed to open-ended questions.
Ask 'What do you already know about this topic?'
Do NOT provide the answer or a worked example.]
```

The student's message that is passed to the Tutor Agent becomes:
```
"idk" + "[DIALOGUE AGENT: Student is STUCK. Switch from closed to open-ended questions...]"
```

RAG retrieves `quadratic-equations-chunk-0` (covers factoring fundamentals). Claude Sonnet receives the instruction and switches approach — away from "what would you try first?" toward open-ended grounding:

```
Tutor [STUCK]: That's okay — let's slow down.
  Forget the algebra for a moment. What two numbers, when you
  multiply them, give you 6? Don't worry about x yet.
  ↳ quadratic-equations-chunk-0
```

**The intervention is invisible to the student.** They experience only the change in questioning style.

---

### Turn 5 — Student re-engages

**Student:** *"2 and 3, or 1 and 6"*

**ROUTE_INTENT:** No assessment signals. → TUTORING.

**Dialogue Agent:** word count = 7 (≥ 5). Not IDK. Coming from STUCK. `consecutive_short` resets to 0. State moves from STUCK back to EXPLORING. (7 words is not enough to trigger BREAKTHROUGH, which requires > 30 words.)

**TUTORING:** State = EXPLORING, no intervention. RAG retrieves on "2 and 3, or 1 and 6" query.

```
Tutor [EXPLORING]: Exactly right. Now — which pair of those also adds up to 5?
  ↳ quadratic-equations-chunk-2
```

*Mastery bar: still 5% — no assessment yet*

---

### Turn 6 — Student states an answer

**Student:** *"I think it's 2 and 3 because 2 times 3 is 6 and 2 plus 3 is 5, so the factors are (x+2)(x+3)"*

**ROUTE_INTENT:** "i think" detected, turn > 1. → **ASSESSMENT**

**ASSESSMENT:**

LLM scoring returns:
```
SCORE: CORRECT
MISCONCEPTION: none
CONFIDENCE: HIGH
FEEDBACK: Excellent reasoning — you've identified both factors correctly using the sum-product method.
```

**BKT update:** First correct evidence on quadratic-equations (p_L0=0.05, p_learn=0.20, p_slip=0.15, p_guess=0.15).
- p_mastery updates from 0.05 → **0.38**
- evidence_count = 1

**Advancement check:** p_mastery = 0.38 < 0.85 threshold, evidence_count = 1 < 5 minimum. No advancement yet.

```
Tutor [EXPLORING]: Excellent reasoning — you've identified both factors correctly
  using the sum-product method.
```

*Mastery bar jumps from 5% → 38%*

---

### Turns 7–11 — Continued practice

The student works through further questions. With 4 more CORRECT assessments:

- evidence_count reaches 5
- p_mastery compounds through the BKT formula, reaching approximately 0.87

**At turn 11:**

**ASSESSMENT:** `mastered = True` (p_mastery ≥ 0.85 AND evidence_count ≥ 5).

`check_advancement()` returns:
```python
{
  "advance": True,
  "next_topic": {"topic_id": "quadratic-graphs", "topic_name": "Quadratic Graphs"},
  "mastery_achieved": 0.87
}
```

Assessment node builds student-visible response:
```
Excellent! You've mastered Quadratic Equations! 🎉
Excellent reasoning...
Next up: Quadratic Graphs
```

**REFLECT:** Planning Agent updates `current_topic` to `quadratic-graphs`. Dialogue Agent: mastery = 0.87 ≥ 0.85 → state transitions to **MASTERED**.

From the next turn, the Tutor will automatically retrieve from `quadratic-graphs` curriculum. (In the current POC, this topic has no curriculum file yet — the C4 fallback would trigger until a curriculum file is added.)

---

## 6. Known POC Limitations

These limitations are by design for a proof-of-concept:

| Limitation | Detail |
|---|---|
| **Single learner** | All sessions use `demo-student-001`. No multi-user support. |
| **In-memory session state** | Restarting the server starts a fresh conversation. BKT mastery in SQLite persists; conversation history does not. |
| **3 of 8 topics covered** | Only Quadratic Equations, Linear Equations, and Number/Algebra Basics have curriculum files. The other 5 topics trigger the C4 fallback. |
| **Rule-based intent classification** | The tutor/assess routing uses text pattern matching, not an LLM classifier. False positives and misses are possible. |
| **No authentication** | Any client that can reach port 8080 can use the chat UI. |
| **Self-reflection not actioned** | The Assessment Agent detects mastery stalls but does not yet modify tutoring strategy. The signal is logged only. |

---

## 7. Running the System

Three run modes:

```bash
# Browser UI — recommended for demos
cd ~/projects/mas_education_poc
uv run python chat_ui.py
# Open http://localhost:8080

# CLI demo — fastest, no browser needed
uv run python demo.py

# BeeAI A2A server — for agent-to-agent integration
uv run python main.py
# Agent card: http://localhost:8000/.well-known/agent-card.json
```

Full setup instructions: `USER_GUIDE.md` in the project root.

---

*Document generated: 24 February 2026*
*Related files: `USER_GUIDE.md`, `BUILD_PLAN.md`, `mas_education_architecture_blueprint_v2.md`*
