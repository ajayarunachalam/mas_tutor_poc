#!/usr/bin/env python3
"""Derive DEEPENS edges between ConceptInstances across qualification levels.

DEEPENS(ci_a → ci_b) means ci_b is the same Concept taught at a deeper level
in a higher-order qualification than ci_a, realising the spiral curriculum.

Qualification depth ordering:
  0580  IGCSE Core/Extended     → level 1
  0606  Additional IGCSE        → level 2
  9709  A-Level                 → level 3
  9231  Further Maths A-Level   → level 4

Only consecutive level pairs are connected, per Concept.  All writes use MERGE
so the script is idempotent — safe to re-run at any time.
"""

import logging
import sys
from collections import defaultdict
from pathlib import Path

# Ensure project root is on sys.path when run as a script
PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from db.kg import kg_session  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)

# Authoritative qualification depth ordering
QUAL_ORDER: dict[str, int] = {"0580": 1, "0606": 2, "9709": 3, "9231": 4}


# ─── Core derivation ──────────────────────────────────────────────────────────

def derive_deepens() -> int:
    """Create/merge DEEPENS edges between consecutive ConceptInstances.

    Returns the number of edges created or matched (idempotent runs return same
    number with zero new creation).
    """
    # Step 1: fetch all ConceptInstance → Concept → Qualification triples
    with kg_session() as session:
        result = session.run("""
            MATCH (ci:ConceptInstance)-[:INSTANCE_OF]->(c:Concept)
            MATCH (ci)-[:AT_LEVEL]->(q:Qualification)
            RETURN ci.id   AS ci_id,
                   ci.depth AS ci_depth,
                   c.id    AS concept_id,
                   q.code  AS qual_code
            ORDER BY c.id, q.code
        """)
        rows = [dict(r) for r in result]

    logger.info("Fetched %d ConceptInstance × Qualification pairs.", len(rows))

    # Step 2: group by (concept_id, qual_code) — pick one representative per qual per concept.
    # When multiple tiers exist for the same qual (e.g. 0580 foundation + higher), keep the
    # most advanced instance so DEEPENS connects the deepest treatment to the next qual.
    DEPTH_ORDER = {"introductory": 0, "developing": 1, "advanced": 2, "specialist": 3}

    # Map (concept_id, qual_code) → best ConceptInstance row
    by_concept_qual: dict[tuple[str, str], dict] = {}
    for row in rows:
        key = (row["concept_id"], row["qual_code"])
        existing = by_concept_qual.get(key)
        if existing is None:
            by_concept_qual[key] = row
        else:
            # Replace with higher-depth instance
            existing_depth = DEPTH_ORDER.get(existing.get("ci_depth") or "", 0)
            new_depth = DEPTH_ORDER.get(row.get("ci_depth") or "", 0)
            if new_depth > existing_depth:
                by_concept_qual[key] = row

    # Re-group by concept_id only
    by_concept: dict[str, list[dict]] = defaultdict(list)
    for (concept_id, _qual_code), row in by_concept_qual.items():
        by_concept[concept_id].append(row)

    # Step 3: build consecutive DEEPENS pairs within each Concept group
    pairs: list[tuple[str, str, str, str, str | None, str | None]] = []
    for concept_id, instances in by_concept.items():
        # Sort by known qual level; unknown quals sink to position 99
        instances_sorted = sorted(
            instances,
            key=lambda x: QUAL_ORDER.get(x["qual_code"], 99),
        )
        for i in range(len(instances_sorted) - 1):
            a = instances_sorted[i]
            b = instances_sorted[i + 1]
            # Only connect across different qualification levels
            if (
                a["qual_code"] in QUAL_ORDER
                and b["qual_code"] in QUAL_ORDER
                and a["qual_code"] != b["qual_code"]
            ):
                pairs.append((
                    a["ci_id"], b["ci_id"],
                    a["qual_code"], b["qual_code"],
                    a.get("ci_depth"), b.get("ci_depth"),
                ))

    logger.info("Derived %d DEEPENS pairs across %d concepts.", len(pairs), len(by_concept))

    if not pairs:
        logger.warning("No DEEPENS pairs found — verify ConceptInstance AT_LEVEL edges exist.")
        return 0

    # Step 4: write to Neo4j using MERGE (idempotent)
    merged = 0
    with kg_session() as session:
        for ci_from, ci_to, q_from, q_to, depth_from, depth_to in pairs:
            result = session.run(
                "MATCH (a:ConceptInstance {id: $from_id}) "
                "MATCH (b:ConceptInstance {id: $to_id}) "
                "MERGE (a)-[r:DEEPENS]->(b) "
                "ON CREATE SET r.qual_from   = $q_from, "
                "              r.qual_to     = $q_to, "
                "              r.depth_from  = $depth_from, "
                "              r.depth_to    = $depth_to "
                "RETURN count(r) AS cnt",
                from_id=ci_from, to_id=ci_to,
                q_from=q_from, q_to=q_to,
                depth_from=depth_from, depth_to=depth_to,
            )
            row = result.single()
            if row:
                merged += row["cnt"]

    return merged


# ─── Verification helpers ─────────────────────────────────────────────────────

def count_deepens_edges() -> int:
    with kg_session() as session:
        result = session.run("MATCH ()-[r:DEEPENS]->() RETURN count(r) AS n")
        return result.single()["n"]


def count_chains(min_span: int = 3) -> int:
    """Count Concepts whose ConceptInstances span ≥ min_span distinct quals."""
    with kg_session() as session:
        result = session.run("""
            MATCH (ci:ConceptInstance)-[:INSTANCE_OF]->(c:Concept)
            MATCH (ci)-[:AT_LEVEL]->(q:Qualification)
            WITH c.id AS concept_id, count(DISTINCT q.code) AS span
            WHERE span >= $min_span
            RETURN count(*) AS chains
        """, min_span=min_span)
        row = result.single()
        return row["chains"] if row else 0


def check_cross_concept_deepens() -> int:
    """Return count of DEEPENS edges between ConceptInstances of different Concepts.

    This should always be 0. Any non-zero result violates ISC-A-P3-2.
    """
    with kg_session() as session:
        result = session.run("""
            MATCH (a:ConceptInstance)-[:DEEPENS]->(b:ConceptInstance)
            MATCH (a)-[:INSTANCE_OF]->(ca:Concept)
            MATCH (b)-[:INSTANCE_OF]->(cb:Concept)
            WHERE ca.id <> cb.id
            RETURN count(*) AS violations
        """)
        row = result.single()
        return row["violations"] if row else 0


# ─── Entry point ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    logger.info("─── derive_deepens.py ───────────────────────────────────")
    logger.info("Qualification ordering: 0580→0606→9709→9231")

    merged = derive_deepens()
    logger.info("DEEPENS edges merged: %d", merged)

    total = count_deepens_edges()
    chains_3 = count_chains(min_span=3)
    violations = check_cross_concept_deepens()

    print()
    print("=== DEEPENS Summary ===")
    print(f"  Total DEEPENS edges:          {total}")
    print(f"  Chains spanning 3+ qual lvls: {chains_3}")
    print(f"  Cross-concept violations:     {violations}  (should be 0)")
    print()
    if violations == 0:
        print("✓ Anti-criterion ISC-A-P3-2 satisfied — no cross-concept DEEPENS edges.")
    else:
        print(f"✗ VIOLATION: {violations} cross-concept DEEPENS edges found!")
