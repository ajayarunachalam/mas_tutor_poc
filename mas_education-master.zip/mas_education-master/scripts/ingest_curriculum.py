#!/usr/bin/env python3
"""
Curriculum Ingestion Script — MAS Education POC.

Reads YAML qualification files from data/qualifications/ and writes
the full node/edge graph to Neo4j via the Bolt protocol.

Node types created:
  :Qualification, :Topic, :Subtopic, :LearningObjective

Relationship types created:
  [:HAS_TOPIC], [:HAS_SUBTOPIC], [:HAS_LO], [:PREREQUISITE_OF]

Usage:
    uv run python scripts/ingest_curriculum.py [--file igcse_0580.yaml] [--clear]

Flags:
  --file   Specific YAML file to ingest (default: all files in data/qualifications/)
  --clear  Delete all existing curriculum nodes before ingesting (USE WITH CARE)
  --dry-run  Parse YAML and report counts without writing to Neo4j
"""
from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

import yaml
from dotenv import load_dotenv

# Ensure project root is on sys.path when run as a script
PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from db.kg import kg_session, apply_schema, health_check, get_node_counts

load_dotenv()
logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)

DATA_DIR = PROJECT_ROOT / "data" / "qualifications"


# ---------------------------------------------------------------------------
# YAML parsing
# ---------------------------------------------------------------------------

def load_qualification(yaml_path: Path) -> dict:
    """Load and return a qualification dict from a YAML file."""
    with open(yaml_path) as f:
        data = yaml.safe_load(f)
    return data["qualification"]


def count_los(qual: dict) -> int:
    """Count total LearningObjective entries in a qualification dict."""
    count = 0
    for topic in qual.get("topics", []):
        for subtopic in topic.get("subtopics", []):
            count += len(subtopic.get("learning_objectives", []))
    return count


# ---------------------------------------------------------------------------
# Neo4j ingestion
# ---------------------------------------------------------------------------

def ingest_qualification(session, qual: dict) -> dict:
    """
    Ingest a single qualification and all its curriculum nodes into Neo4j.
    Returns a summary dict with node/relationship counts created.
    """
    code = qual["code"]
    stats = {
        "qualifications": 0,
        "topics": 0,
        "subtopics": 0,
        "learning_objectives": 0,
        "has_topic": 0,
        "has_subtopic": 0,
        "has_lo": 0,
        "prerequisite_of": 0,
    }

    # --- Qualification node ---
    session.run("""
        MERGE (q:Qualification {code: $code})
        SET q.name          = $name,
            q.level         = $level,
            q.awarding_body = $awarding_body,
            q.age_range     = $age_range,
            q.tiers         = $tiers,
            q.active        = $active
    """, code=code, name=qual["name"], level=qual["level"],
         awarding_body=qual.get("awarding_body", "Cambridge International"),
         age_range=qual.get("age_range", ""),
         tiers=qual.get("tiers", []),
         active=qual.get("active", True))
    stats["qualifications"] += 1

    # Collect all LO IDs for prerequisite wiring (second pass)
    all_los: dict[str, dict] = {}

    for topic in qual.get("topics", []):
        # --- Topic node ---
        session.run("""
            MERGE (t:Topic {id: $id})
            SET t.name               = $name,
                t.qualification_code = $qual_code,
                t.order              = $order
        """, id=topic["id"], name=topic["name"],
             qual_code=code, order=topic.get("order", 0))
        stats["topics"] += 1

        # --- HAS_TOPIC edge ---
        session.run("""
            MATCH (q:Qualification {code: $qual_code})
            MATCH (t:Topic {id: $topic_id})
            MERGE (q)-[:HAS_TOPIC]->(t)
        """, qual_code=code, topic_id=topic["id"])
        stats["has_topic"] += 1

        for subtopic in topic.get("subtopics", []):
            # --- Subtopic node ---
            session.run("""
                MERGE (st:Subtopic {id: $id})
                SET st.name = $name,
                    st.tier = $tier
            """, id=subtopic["id"], name=subtopic["name"],
                 tier=subtopic.get("tier"))
            stats["subtopics"] += 1

            # --- HAS_SUBTOPIC edge ---
            session.run("""
                MATCH (t:Topic {id: $topic_id})
                MATCH (st:Subtopic {id: $st_id})
                MERGE (t)-[:HAS_SUBTOPIC]->(st)
            """, topic_id=topic["id"], st_id=subtopic["id"])
            stats["has_subtopic"] += 1

            for lo in subtopic.get("learning_objectives", []):
                # --- LearningObjective node ---
                session.run("""
                    MERGE (lo:LearningObjective {id: $id})
                    SET lo.text              = $text,
                        lo.tier              = $tier,
                        lo.bloom_level       = $bloom_level,
                        lo.difficulty        = $difficulty,
                        lo.lo_type           = $lo_type,
                        lo.exam_command      = $exam_command,
                        lo.bkt_p_init        = $bkt_p_init,
                        lo.bkt_p_learn       = $bkt_p_learn,
                        lo.bkt_p_slip        = $bkt_p_slip,
                        lo.bkt_p_guess       = $bkt_p_guess,
                        lo.qualification_code = $qual_code
                """,
                    id=lo["id"],
                    text=lo["text"],
                    tier=lo.get("tier"),
                    bloom_level=lo.get("bloom_level", "apply"),
                    difficulty=lo.get("difficulty", 2),
                    lo_type=lo.get("lo_type", "procedural"),
                    exam_command=lo.get("exam_command", ""),
                    bkt_p_init=lo.get("bkt_p_init", 0.10),
                    bkt_p_learn=lo.get("bkt_p_learn", 0.20),
                    bkt_p_slip=lo.get("bkt_p_slip", 0.10),
                    bkt_p_guess=lo.get("bkt_p_guess", 0.20),
                    qual_code=code,
                )
                stats["learning_objectives"] += 1

                # --- HAS_LO edge ---
                session.run("""
                    MATCH (st:Subtopic {id: $st_id})
                    MATCH (lo:LearningObjective {id: $lo_id})
                    MERGE (st)-[:HAS_LO]->(lo)
                """, st_id=subtopic["id"], lo_id=lo["id"])
                stats["has_lo"] += 1

                # Collect for prerequisite pass
                all_los[lo["id"]] = lo

    # --- Second pass: PREREQUISITE_OF edges ---
    for lo_id, lo in all_los.items():
        for prereq in lo.get("prerequisites", []):
            prereq_id = prereq["id"]
            strength = prereq.get("strength", "soft")
            if prereq_id in all_los:
                session.run("""
                    MATCH (prereq:LearningObjective {id: $prereq_id})
                    MATCH (lo:LearningObjective {id: $lo_id})
                    MERGE (prereq)-[r:PREREQUISITE_OF]->(lo)
                    SET r.strength = $strength,
                        r.within_qualification = true
                """, prereq_id=prereq_id, lo_id=lo_id, strength=strength)
                stats["prerequisite_of"] += 1
            else:
                logger.warning(
                    "Prerequisite %s for LO %s not found in this qualification — skipping.",
                    prereq_id, lo_id
                )

    return stats


def ingest_poc_mapping(session, qual: dict) -> int:
    """
    Create POC_MAPS_TO relationships between the 8 original SQLite topic IDs
    (as virtual nodes) and their corresponding LearningObjective nodes.
    These allow the Planning Agent to bridge the old SQLite IDs to the KG.
    """
    mapping = qual.get("poc_topic_mapping", [])
    count = 0
    for entry in mapping:
        sqlite_id = entry["sqlite_topic_id"]
        kg_lo_id = entry["kg_lo_id"]
        # Tag the LO node with the legacy SQLite topic ID for backwards compat
        session.run("""
            MATCH (lo:LearningObjective {id: $kg_lo_id})
            SET lo.sqlite_topic_id = $sqlite_id
        """, kg_lo_id=kg_lo_id, sqlite_id=sqlite_id)
        count += 1
        logger.info("  Mapped SQLite topic '%s' → KG LO '%s'", sqlite_id, kg_lo_id)
    return count


def clear_curriculum_nodes(session) -> None:
    """Delete all curriculum nodes. Does NOT touch Learner/HAS_MASTERY nodes."""
    logger.warning("CLEARING all curriculum nodes from Neo4j…")
    session.run("""
        MATCH (n)
        WHERE n:Qualification OR n:Topic OR n:Subtopic OR n:LearningObjective
           OR n:Concept OR n:ConceptInstance OR n:Component OR n:MathDomain
           OR n:Skill OR n:Resource
        DETACH DELETE n
    """)
    logger.warning("Curriculum nodes cleared.")


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(description="Ingest Cambridge curriculum YAML into Neo4j")
    parser.add_argument("--file", help="Specific YAML file name (e.g. igcse_0580.yaml)")
    parser.add_argument("--clear", action="store_true", help="Clear existing curriculum nodes first")
    parser.add_argument("--dry-run", action="store_true", help="Parse only, do not write to Neo4j")
    args = parser.parse_args()

    # --- Discover YAML files ---
    if args.file:
        yaml_files = [DATA_DIR / args.file]
    else:
        yaml_files = sorted(DATA_DIR.glob("*.yaml"))

    if not yaml_files:
        logger.error("No YAML files found in %s", DATA_DIR)
        sys.exit(1)

    # --- Dry run: parse and report only ---
    if args.dry_run:
        print("\n=== DRY RUN — No writes to Neo4j ===")
        for yaml_path in yaml_files:
            qual = load_qualification(yaml_path)
            lo_count = count_los(qual)
            topic_count = len(qual.get("topics", []))
            subtopic_count = sum(
                len(t.get("subtopics", [])) for t in qual.get("topics", [])
            )
            print(f"\n{yaml_path.name}")
            print(f"  Qualification: {qual['code']} — {qual['name']}")
            print(f"  Topics:         {topic_count}")
            print(f"  Subtopics:      {subtopic_count}")
            print(f"  LOs:            {lo_count}")
        return

    # --- Health check ---
    logger.info("Checking Neo4j connectivity…")
    if not health_check():
        logger.error("Cannot connect to Neo4j at bolt://localhost:7687. Is Docker running?")
        sys.exit(1)
    logger.info("Neo4j connection OK.")

    with kg_session() as session:
        # --- Schema ---
        logger.info("Applying schema (constraints + indexes)…")
        apply_schema()

        # --- Optional clear ---
        if args.clear:
            clear_curriculum_nodes(session)

        # --- Ingest each file ---
        total_stats: dict[str, int] = {}
        for yaml_path in yaml_files:
            logger.info("\n=== Ingesting: %s ===", yaml_path.name)
            qual = load_qualification(yaml_path)
            stats = ingest_qualification(session, qual)

            # POC backwards-compat mapping
            mapped = ingest_poc_mapping(session, qual)
            stats["poc_mappings"] = mapped

            # Accumulate totals
            for key, val in stats.items():
                total_stats[key] = total_stats.get(key, 0) + val

            logger.info("  Nodes created/merged:")
            logger.info("    Qualifications:      %d", stats["qualifications"])
            logger.info("    Topics:              %d", stats["topics"])
            logger.info("    Subtopics:           %d", stats["subtopics"])
            logger.info("    LearningObjectives:  %d", stats["learning_objectives"])
            logger.info("  Edges created/merged:")
            logger.info("    HAS_TOPIC:           %d", stats["has_topic"])
            logger.info("    HAS_SUBTOPIC:        %d", stats["has_subtopic"])
            logger.info("    HAS_LO:              %d", stats["has_lo"])
            logger.info("    PREREQUISITE_OF:     %d", stats["prerequisite_of"])
            logger.info("  POC mappings:          %d", stats["poc_mappings"])

    # --- Final node count verification ---
    print("\n=== Neo4j node counts after ingestion ===")
    counts = get_node_counts()
    for label, count in sorted(counts.items()):
        print(f"  {label:30s}: {count}")

    print(f"\n✓ Ingestion complete. Total LOs ingested: {total_stats.get('learning_objectives', 0)}")


if __name__ == "__main__":
    main()
