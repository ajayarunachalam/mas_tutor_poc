"""
Phase 5: Link Resources — MAS Education POC
============================================
Creates [:HAS_RESOURCE] edges from LearningObjective nodes to Resource nodes
that point to ChromaDB chunk IDs.

For each IGCSE 0580 LO:
  1. Query ChromaDB for the top-2 most relevant chunks (using LO text as query)
  2. MERGE Resource nodes (chunk_id, chroma_collection, source_file, topic)
  3. MERGE HAS_RESOURCE edge: (:LearningObjective)-[:HAS_RESOURCE]->(:Resource)

Idempotent: safe to re-run. MERGE prevents duplicate nodes/edges.

Usage:
    uv run python scripts/link_resources.py [--qual CODE]

Options:
    --qual CODE   Qualification code to process (default: 0580)
    --all         Process all qualifications (may take several minutes)
"""
import os
import sys
import argparse
from pathlib import Path

# Ensure project root is on sys.path when run as a script
PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

import chromadb
from chromadb.utils.embedding_functions import VoyageAIEmbeddingFunction
from dotenv import load_dotenv
from db.kg import kg_session

load_dotenv()

CHROMA_PATH      = os.getenv("CHROMA_PATH")
COLLECTION_NAME  = os.getenv("CHROMA_COLLECTION", "poc_curriculum")
EMBEDDING_MODEL  = "voyage-3-lite"  # 512-dim; must match rag/retrieve.py and rag/ingest.py
TOP_K_PER_LO     = 2   # number of chunks to link per LO


def get_chroma_collection():
    """Return the poc_curriculum ChromaDB collection with embedding function."""
    if not CHROMA_PATH:
        raise EnvironmentError("CHROMA_PATH not set — check .env")
    client = chromadb.PersistentClient(path=CHROMA_PATH)
    embedding_fn = VoyageAIEmbeddingFunction(
        model_name=EMBEDDING_MODEL,
        api_key_env_var="VOYAGE_API_KEY",
    )
    return client.get_collection(name=COLLECTION_NAME, embedding_function=embedding_fn)


def get_los_for_qualification(qual_code: str) -> list[dict]:
    """Fetch all LO ids and texts for a given qualification code."""
    cypher = """
        MATCH (q:Qualification {code: $code})-[:HAS_TOPIC]->(:Topic)
              -[:HAS_SUBTOPIC]->(:Subtopic)-[:HAS_LO]->(lo:LearningObjective)
        RETURN lo.id AS lo_id, lo.text AS lo_text
        ORDER BY lo.difficulty ASC
    """
    with kg_session() as session:
        result = session.run(cypher, code=qual_code)
        return [{"lo_id": r["lo_id"], "lo_text": r["lo_text"]} for r in result]


def link_lo_to_chunks(session, lo_id: str, chunks: list[dict]) -> int:
    """
    MERGE Resource nodes and HAS_RESOURCE edges for the given chunks.
    Returns number of new edges created.
    """
    created = 0
    for chunk in chunks:
        chunk_id    = chunk["id"]
        resource_id = f"res-{chunk_id}"

        cypher = """
            MATCH (lo:LearningObjective {id: $lo_id})
            MERGE (r:Resource {id: $resource_id})
              ON CREATE SET
                r.chunk_id          = $chunk_id,
                r.chroma_collection = $collection,
                r.source_file       = $source_file,
                r.topic             = $topic
            MERGE (lo)-[rel:HAS_RESOURCE]->(r)
            RETURN rel
        """
        result = session.run(
            cypher,
            lo_id=lo_id,
            resource_id=resource_id,
            chunk_id=chunk_id,
            collection=COLLECTION_NAME,
            source_file=chunk.get("metadata", {}).get("source", ""),
            topic=chunk.get("metadata", {}).get("topic", ""),
        )
        record = result.single()
        if record:
            created += 1

    return created


def main():
    parser = argparse.ArgumentParser(description="Link LO nodes to ChromaDB Resource chunks")
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--qual", default="0580", help="Qualification code (default: 0580)")
    group.add_argument("--all", action="store_true", help="Process all qualifications")
    args = parser.parse_args()

    # Determine which qualifications to process
    if args.all:
        with kg_session() as session:
            result = session.run("MATCH (q:Qualification) RETURN q.code AS code ORDER BY code")
            qual_codes = [r["code"] for r in result]
    else:
        qual_codes = [args.qual]

    print(f"Linking resources for qualifications: {qual_codes}")
    print(f"ChromaDB: {CHROMA_PATH} | Collection: {COLLECTION_NAME}")

    # Apply schema to ensure Resource constraint exists
    from db.kg import apply_schema
    apply_schema()

    collection = get_chroma_collection()
    total_chunks = collection.count()
    print(f"ChromaDB chunks available: {total_chunks}")

    if total_chunks == 0:
        print("ERROR: poc_curriculum collection is empty — run rag/ingest.py first")
        sys.exit(1)

    total_linked = 0
    total_los = 0

    for qual_code in qual_codes:
        los = get_los_for_qualification(qual_code)
        print(f"\nQualification {qual_code}: {len(los)} LOs to link")

        with kg_session() as session:
            for lo in los:
                lo_id   = lo["lo_id"]
                lo_text = lo["lo_text"]

                # Query ChromaDB for top-K chunks relevant to this LO
                try:
                    n = min(TOP_K_PER_LO, total_chunks)
                    results = collection.query(
                        query_texts=[lo_text],
                        n_results=n,
                        include=["documents", "metadatas"]
                    )
                except Exception as e:
                    print(f"  WARNING: ChromaDB query failed for {lo_id}: {e}")
                    continue

                # Build chunk dicts from ChromaDB results
                chunks = []
                for i, chunk_id in enumerate(results["ids"][0]):
                    chunks.append({
                        "id":       chunk_id,
                        "metadata": results["metadatas"][0][i],
                    })

                linked = link_lo_to_chunks(session, lo_id, chunks)
                total_linked += linked
                total_los += 1

        print(f"  Done: {total_los} LOs processed")

    print(f"\n✅ Linking complete. {total_los} LOs linked, {total_linked} Resource edges created/verified.")

    # Summary of graph state
    with kg_session() as session:
        r = session.run("MATCH (:LearningObjective)-[:HAS_RESOURCE]->(:Resource) RETURN count(*) AS n")
        edge_count = r.single()["n"]
        r2 = session.run("MATCH (r:Resource) RETURN count(r) AS n")
        res_count = r2.single()["n"]
    print(f"Neo4j: {res_count} Resource nodes, {edge_count} HAS_RESOURCE edges")


if __name__ == "__main__":
    main()
