"""
MAS Tutor — Concurrent Load Test

Simulates N virtual users, each opening a session and sending a short
multi-turn conversation against /chat. Parameterized target URL and
payload so the same script works against any sibling deployment
(mas-tutor, sons-personal-tutor, sa-education-platform, etc.) with no
code change — just different --url / --messages.

Usage:
    python3 scripts/load_test.py --url http://localhost:8081 --users 30 --turns 3
    python3 scripts/load_test.py --url http://localhost:8081 --users 3 --turns 2  # validation run

Captures P50/P95/P99 latency, HTTP status breakdown (2xx / 429 / 5xx),
and writes raw per-request results to a JSON file for later analysis.
"""
import argparse
import asyncio
import json
import statistics
import time
import uuid

import httpx

DEFAULT_TURNS = [
    "What is a linear equation?",
    "I think the answer involves x and y",
    "Can you give me an example?",
    "What about quadratic equations?",
]


async def run_user(client: httpx.AsyncClient, url: str, user_idx: int, turns: int, results: list):
    learner_id = f"loadtest-{uuid.uuid4().hex[:8]}-u{user_idx}"
    for turn_idx in range(turns):
        message = DEFAULT_TURNS[turn_idx % len(DEFAULT_TURNS)]
        start = time.monotonic()
        status = None
        error = None
        try:
            resp = await client.post(
                f"{url}/chat",
                json={"message": message, "learner_id": learner_id},
                timeout=60.0,
            )
            status = resp.status_code
        except Exception as e:
            error = str(e)
        elapsed = time.monotonic() - start
        results.append({
            "user": user_idx,
            "turn": turn_idx,
            "learner_id": learner_id,
            "status": status,
            "error": error,
            "latency_s": round(elapsed, 3),
            "ts": time.time(),
        })


async def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--url", required=True, help="Base URL, e.g. http://localhost:8081")
    parser.add_argument("--users", type=int, default=30, help="Number of concurrent virtual users")
    parser.add_argument("--turns", type=int, default=3, help="Turns per user session")
    parser.add_argument("--stagger-ms", type=int, default=0, help="Stagger user start by N ms (0 = all at once)")
    parser.add_argument("--out", default=None, help="Output JSON path (default: auto-named)")
    args = parser.parse_args()

    results: list = []
    out_path = args.out or f"/tmp/loadtest-{args.users}u-{args.turns}t-{int(time.time())}.json"

    print(f"Starting load test: {args.users} users, {args.turns} turns each, target={args.url}")
    overall_start = time.monotonic()

    async with httpx.AsyncClient() as client:
        tasks = []
        for i in range(args.users):
            if args.stagger_ms:
                await asyncio.sleep(args.stagger_ms / 1000)
            tasks.append(asyncio.create_task(run_user(client, args.url, i, args.turns, results)))
        await asyncio.gather(*tasks)

    overall_elapsed = time.monotonic() - overall_start

    latencies = [r["latency_s"] for r in results if r["status"] is not None]
    statuses = [r["status"] for r in results]
    errors = [r for r in results if r["error"] is not None]

    status_2xx = sum(1 for s in statuses if s and 200 <= s < 300)
    status_429 = sum(1 for s in statuses if s == 429)
    status_5xx = sum(1 for s in statuses if s and 500 <= s < 600)
    status_other = len(statuses) - status_2xx - status_429 - status_5xx

    summary = {
        "users": args.users,
        "turns_per_user": args.turns,
        "total_requests": len(results),
        "overall_wallclock_s": round(overall_elapsed, 2),
        "status_2xx": status_2xx,
        "status_429": status_429,
        "status_5xx": status_5xx,
        "status_other": status_other,
        "connection_errors": len(errors),
        "latency_p50_s": round(statistics.median(latencies), 3) if latencies else None,
        "latency_p95_s": round(statistics.quantiles(latencies, n=20)[18], 3) if len(latencies) >= 20 else (round(max(latencies), 3) if latencies else None),
        "latency_p99_s": round(statistics.quantiles(latencies, n=100)[98], 3) if len(latencies) >= 100 else (round(max(latencies), 3) if latencies else None),
        "latency_min_s": round(min(latencies), 3) if latencies else None,
        "latency_max_s": round(max(latencies), 3) if latencies else None,
    }

    with open(out_path, "w") as f:
        json.dump({"summary": summary, "raw": results}, f, indent=2)

    print(json.dumps(summary, indent=2))
    print(f"\nRaw results written to: {out_path}")


if __name__ == "__main__":
    asyncio.run(main())
