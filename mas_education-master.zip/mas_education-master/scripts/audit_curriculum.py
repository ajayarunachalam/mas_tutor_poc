#!/usr/bin/env python3
"""
scripts/audit_curriculum.py — MAS Education POC

Audits all curriculum markdown files for mathematical errors in worked examples.

Strategy (conservative — prefers SKIP over false positives):
  - Extracts ONLY pure-numeric arithmetic claims: "4 × 8 × 3 = 96", "1 − 6 + 9 = 4"
  - Extracts equation-root claims: polynomial = 0 near stated roots
  - Skips any line containing variable letters after normalisation
  - Skips approximation lines (≈, ~, ≤, ≥)

Status per claim:
  PASS  — sympy confirmed claim is correct
  FAIL  — sympy found a discrepancy (real error in curriculum file)
  SKIP  — could not reliably parse / contains variables

Usage:
  uv run python scripts/audit_curriculum.py
  uv run python scripts/audit_curriculum.py --fix   # (future: auto-fix safe errors)

Exit code:
  0 — no FAILs found
  1 — one or more FAILs found

Output:
  Prints findings to stdout.
  Writes AUDIT_REPORT.md to the project root.
"""
import re
import sys
import os
from datetime import datetime
from pathlib import Path

try:
    from sympy import sympify, Rational, Float, simplify, N as symN
    from sympy.parsing.sympy_parser import (
        parse_expr, standard_transformations,
        implicit_multiplication_application, convert_xor
    )
    _SYMPY_OK = True
except ImportError:
    print("ERROR: sympy not installed. Run: uv add sympy && uv sync")
    sys.exit(2)

# --- Paths ---
SCRIPT_DIR = Path(__file__).parent
PROJECT_ROOT = SCRIPT_DIR.parent
CURRICULUM_DIR = PROJECT_ROOT / "curriculum_data"
REPORT_PATH = PROJECT_ROOT / "AUDIT_REPORT.md"

_TRANSFORMS = (
    standard_transformations + (implicit_multiplication_application, convert_xor)
)

# Unicode superscript map
_SUP_DIGIT = {'⁰':0,'¹':1,'²':2,'³':3,'⁴':4,'⁵':5,'⁶':6,'⁷':7,'⁸':8,'⁹':9}

_SUBSCRIPT_STRIP = str.maketrans('₀₁₂₃₄₅₆₇₈₉ᵢⱼ', '0123456789ij')

# Unicode math operator replacements
_UNICODE_OPS = [
    ('\u2212', '-'),   # minus sign (U+2212)
    ('\u00d7', '*'),   # multiplication sign ×
    ('\u00f7', '/'),   # division sign ÷
    ('\u22c5', '*'),   # dot operator ·
    ('\u2014', '-'),   # em dash (sometimes used as minus)
    ('\u2013', '-'),   # en dash
    ('\u2248', '~'),   # approximately equal ≈ (we'll skip these lines)
    ('\u2212', '-'),   # unicode minus (duplicate, harmless)
]


def normalize(text: str) -> str:
    """Convert Unicode math notation to ASCII equivalents."""
    # Apply operator substitutions first
    for unicode_char, ascii_char in _UNICODE_OPS:
        text = text.replace(unicode_char, ascii_char)

    # Normalise square and cube roots BEFORE superscripts so they're not double-processed
    text = re.sub(r'√\(([^)]+)\)', r'((\1)**(0.5))', text)   # √(expr)
    text = re.sub(r'√(\d+(?:\.\d+)?)', r'((\1)**(0.5))', text)  # √N
    text = re.sub(r'∛\(([^)]+)\)', r'((\1)**(1/3))', text)   # ∛(expr)
    text = re.sub(r'∛(\d+)', r'((\1)**(1/3))', text)          # ∛N

    # Replace multi-digit superscript sequences (e.g. ¹⁰ → **10, ⁻¹ → **(-1))
    def _sup_seq(m):
        chars = m.group()
        negative = chars.startswith('⁻')
        digits = ''.join(str(_SUP_DIGIT[c]) for c in chars if c in _SUP_DIGIT)
        if not digits:
            return ''
        return f'**(-{digits})' if negative else f'**{digits}'

    text = re.sub(r'⁻?[⁰¹²³⁴⁵⁶⁷⁸⁹]+', _sup_seq, text)

    # Strip subscripts
    text = text.translate(_SUBSCRIPT_STRIP)

    return text


def _has_variables(expr_str: str) -> bool:
    """Return True if the string contains any alphabetic characters (variable names)."""
    return bool(re.search(r'[a-zA-Z]', expr_str))


def _is_approximate(line: str) -> bool:
    """Return True if the line contains an approximation marker."""
    return bool(re.search(r'[≈~≤≥]|\\approx|approx', line, re.IGNORECASE))


def _preprocess_expr(expr_str: str) -> str:
    """Pre-process expression string before sympy parsing."""
    s = expr_str.strip()
    # Remove thousands-separator commas: "67,000" → "67000"
    s = re.sub(r'(\d),(\d{3})\b', r'\1\2', s)
    # Convert mixed numbers "N M/P" → "(N + M/P)": e.g. "2 1/10" → "(2 + 1/10)"
    s = re.sub(r'(\d+)\s+(\d+)/(\d+)', r'(\1 + \2/\3)', s)
    return s


def _safe_eval(expr_str: str):
    """
    Safely evaluate a pure-numeric expression with sympy.
    Returns a sympy number or None on failure.
    """
    try:
        cleaned = _preprocess_expr(expr_str)
        # Must contain at least one digit
        if not re.search(r'\d', cleaned):
            return None
        # Must not contain letters (variables)
        if _has_variables(cleaned):
            return None
        result = parse_expr(cleaned, transformations=_TRANSFORMS)
        return result
    except Exception:
        return None


def _numeric_close(a, b, tol=1e-9) -> bool:
    """Check if two sympy expressions are numerically equal within tolerance."""
    try:
        diff = float(symN(a - b))
        return abs(diff) < tol
    except Exception:
        try:
            return simplify(a - b) == 0
        except Exception:
            return False


# ---------------------------------------------------------------------------
# Claim extractor 1: Pure numeric arithmetic "expr = result"
# ---------------------------------------------------------------------------

# Matches: "= expr = result" or standalone "expr = result"
# Both sides must be pure numeric (digits, ops, parens, /, .) after normalisation.
# The split point is the LAST "=" in a sequence of numeric tokens.
_ARITH_CLAIM_RE = re.compile(
    r'([\d\s\+\-\*\/\(\)\.\,\[\]]+)\s*=\s*([\-]?\s*[\d\s\+\-\*\/\(\)\.\[\]\/]+)',
)


def extract_numeric_claims(line: str, lineno: int, filepath: str) -> list[dict]:
    """
    Extract pure-numeric arithmetic claims from a line.

    Conservative filters applied (prefer SKIP over false positive):
      - Skip lines with → or -> (step notation in equation solving)
      - Skip approximate lines (≈, ~)
      - Skip LHS starting with + or ** (algebraic fragment after variable cut-off)
      - Skip LHS that is a single parenthesised number (function argument notation)
      - Skip RHS that contains operators (intermediate step, not final answer)
      - Require LHS to have at least two numeric operands (multi-term expression)

    Returns list of dicts:
        { 'lhs': str, 'rhs': str, 'line': int, 'file': str, 'raw': str }
    """
    claims = []

    # Skip step-notation lines (equation solving steps)
    if '→' in line or '->' in line or '⟹' in line:
        return claims

    # Skip approximate lines
    if _is_approximate(line):
        return claims

    norm = normalize(line)
    # Remove thousands-separator commas BEFORE regex so "67,000" → "67000" stays intact
    norm = re.sub(r'(\d),(\d{3})\b', r'\1\2', norm)

    # Find all "numeric_expr = numeric_result" patterns
    for m in _ARITH_CLAIM_RE.finditer(norm):
        lhs_raw = m.group(1).strip()
        rhs_raw = m.group(2).strip()

        # Both sides must be non-empty and contain at least one digit
        if not lhs_raw or not rhs_raw:
            continue
        if not re.search(r'\d', lhs_raw) or not re.search(r'\d', rhs_raw):
            continue

        # Must NOT contain letters (would indicate a variable or word)
        if _has_variables(lhs_raw) or _has_variables(rhs_raw):
            continue

        # Skip LHS that starts with + or ** — these are algebraic fragments
        # (e.g. the " + 6" from "x² + 5x + 6 = 0" after the x² term is cut off)
        if re.match(r'^[\+\*]', lhs_raw):
            continue

        # Skip LHS that is a single parenthesised number or fraction e.g. (-2), (1/9), (5)
        # These are function argument notations: f(-2), log(1/9), ln(5)
        if re.match(r'^\(-?\d+(?:[./]\d+)?\)$', lhs_raw):
            continue
        # Also skip LHS of the form (N)/M — function argument followed by a divisor
        # e.g. "(5)/0.15" from "ln(5)/0.15" after "ln" is stripped
        if re.match(r'^\(-?\d+(?:[./]\d+)?\)/[\d.]+$', lhs_raw):
            continue
        # Skip LHS starting with a digit immediately followed by ( — subscript base notation
        # e.g. "3(1/9)" extracted from "log₃(1/9)" after "log" is stripped
        if re.match(r'^\d+\(', lhs_raw):
            continue
        # Skip LHS starting with (N/M)( — fraction-coeff times paren-expr (π stripped from context)
        # e.g. "(2/3)(8 - 1)" from "4π(2/3)(8-1)" after 4 and π are stripped
        if re.match(r'^\(\d+/\d+\)\(', lhs_raw):
            continue

        # Skip RHS that itself contains arithmetic operators (it's an intermediate step)
        # Final results should be simple numbers or fractions, not multi-term expressions
        rhs_stripped = rhs_raw.strip()
        if re.search(r'[\+\-\*]', rhs_stripped) and not re.match(r'^-?\d', rhs_stripped):
            continue
        # Allow "-N" as RHS (negative result) but not "N op M"
        if re.search(r'[\+\*]', rhs_stripped):
            continue
        if re.search(r'\-', rhs_stripped) and not re.match(r'^-?\d', rhs_stripped):
            continue

        # Require LHS to be a multi-term expression (at least two numeric operands
        # with an operator between them, OR a function call like sqrt/cbrt)
        # This excludes single numbers like "6 = 0" (from polynomial = 0 patterns)
        has_operator = re.search(r'[\+\-\*\/]', lhs_raw)
        has_fn_call = re.search(r'\*\*|\.\d', lhs_raw)
        if not has_operator and not has_fn_call:
            continue

        # The LHS must not be trivially just an operator and single number (e.g. "- 8")
        # Require at least 2 distinct digit groups
        digit_groups = re.findall(r'\d+(?:\.\d+)?', lhs_raw)
        if len(digit_groups) < 2:
            continue

        claims.append({
            'lhs': lhs_raw,
            'rhs': rhs_raw,
            'line': lineno,
            'file': filepath,
            'raw': line.rstrip()
        })

    return claims


# ---------------------------------------------------------------------------
# Claim extractor 2: Equation root checks
# ---------------------------------------------------------------------------

# Find equations of the form "expr = 0" in content
_EQ_ZERO_RE = re.compile(
    r'([a-zA-Z\d\^+\-*/\(\)\s]{3,40}?)\s*=\s*0\b',
    re.IGNORECASE
)

# Find stated roots: "x = N or x = M", "x = N and x = M", "x = N, x = M"
_ROOTS_RE = re.compile(
    r'[a-zA-Z]\s*=\s*(-?\d+(?:\.\d+)?(?:/\d+)?)'
    r'(?:\s*(?:or|and|,)\s*[a-zA-Z]\s*=\s*(-?\d+(?:\.\d+)?(?:/\d+)?))?',
    re.IGNORECASE
)


def extract_root_claims(content: str, filepath: str) -> list[dict]:
    """
    Find polynomial = 0 equations and their stated roots in curriculum content.
    Returns list of root-check dicts.
    """
    claims = []
    norm_content = normalize(content)

    # Find equations then look for roots in nearby text (±5 lines)
    lines = norm_content.split('\n')
    for i, line in enumerate(lines):
        eq_matches = _EQ_ZERO_RE.findall(line)
        for lhs_expr in eq_matches:
            lhs_expr = lhs_expr.strip()
            # Skip if lhs is purely numeric (would be "N = 0" not an equation)
            if not re.search(r'[a-zA-Z]', lhs_expr):
                continue
            # Must look like a polynomial (contains power or variable repeated)
            if not re.search(r'[\^*]|[a-zA-Z]\d|[a-zA-Z]{1}\s*[+\-]', lhs_expr):
                continue

            # Look for roots in the next 3 lines
            window = '\n'.join(lines[i:min(i + 4, len(lines))])
            root_match = _ROOTS_RE.search(window)
            if not root_match:
                continue

            roots = [root_match.group(1)]
            if root_match.group(2):
                roots.append(root_match.group(2))

            for root in roots:
                claims.append({
                    'equation': f"({lhs_expr})",
                    'variable': 'x',  # assume x for now
                    'root': root,
                    'line': i + 1,
                    'file': filepath,
                    'raw': line.rstrip()
                })

    return claims


# ---------------------------------------------------------------------------
# Verification
# ---------------------------------------------------------------------------

def verify_numeric_claim(claim: dict) -> dict:
    """Verify a pure-numeric arithmetic claim. Returns claim with status added."""
    lhs_val = _safe_eval(claim['lhs'])
    rhs_val = _safe_eval(claim['rhs'])

    if lhs_val is None or rhs_val is None:
        return {**claim, 'status': 'SKIP', 'reason': 'parse_error',
                'computed': None, 'expected': None}

    if _numeric_close(lhs_val, rhs_val):
        return {**claim, 'status': 'PASS', 'computed': str(lhs_val), 'expected': str(rhs_val)}
    else:
        return {**claim, 'status': 'FAIL', 'reason': 'value_mismatch',
                'computed': str(float(symN(lhs_val))), 'expected': str(rhs_val)}


def verify_root_claim(claim: dict) -> dict:
    """Verify that a stated root satisfies the polynomial = 0."""
    from rag.math_verify import check_equation_solution
    result = check_equation_solution(
        f"{claim['equation']} = 0",
        claim['variable'],
        claim['root']
    )
    if result is None:
        return {**claim, 'status': 'SKIP', 'reason': 'parse_error'}
    elif result:
        return {**claim, 'status': 'PASS', 'computed': 'satisfies equation'}
    else:
        return {**claim, 'status': 'FAIL', 'reason': 'root_incorrect',
                'computed': 'does not satisfy equation', 'expected': 'should satisfy equation'}


# ---------------------------------------------------------------------------
# Per-file audit
# ---------------------------------------------------------------------------

def audit_file(filepath: Path) -> list[dict]:
    """Audit a single curriculum markdown file. Returns all claim results."""
    results = []
    try:
        content = filepath.read_text(encoding='utf-8')
        lines = content.split('\n')

        # Numeric arithmetic claims (line-by-line)
        for i, line in enumerate(lines, start=1):
            claims = extract_numeric_claims(line, i, str(filepath.name))
            for claim in claims:
                result = verify_numeric_claim(claim)
                result['claim_type'] = 'numeric'
                results.append(result)

        # Root claims (whole-file context)
        root_claims = extract_root_claims(content, str(filepath.name))
        for claim in root_claims:
            result = verify_root_claim(claim)
            result['claim_type'] = 'root'
            results.append(result)

    except Exception as e:
        results.append({
            'file': str(filepath.name),
            'status': 'SKIP',
            'reason': f'file_read_error: {e}',
            'claim_type': 'error',
            'line': 0,
            'raw': ''
        })
    return results


# ---------------------------------------------------------------------------
# Report writer
# ---------------------------------------------------------------------------

def write_report(all_results: list[dict], files_checked: int) -> None:
    """Write AUDIT_REPORT.md to project root."""
    passes = [r for r in all_results if r['status'] == 'PASS']
    fails  = [r for r in all_results if r['status'] == 'FAIL']
    skips  = [r for r in all_results if r['status'] == 'SKIP']

    lines = [
        f"# Curriculum Math Audit Report",
        f"",
        f"**Run date:** {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}  ",
        f"**Files checked:** {files_checked}  ",
        f"**Claims verified:** {len(passes) + len(fails)}  ",
        f"**PASS:** {len(passes)} | **FAIL:** {len(fails)} | **SKIP (unparseable):** {len(skips)}",
        f"",
    ]

    if fails:
        lines += [
            "## ❌ FAILURES — Mathematical Errors Found",
            ""
        ]
        for r in fails:
            lines.append(f"### {r['file']} line {r['line']}")
            lines.append(f"```")
            lines.append(f"Claim:    {r.get('raw', '')}")
            if r['claim_type'] == 'numeric':
                lines.append(f"LHS:      {r.get('lhs', '')} → computed {r.get('computed', '?')}")
                lines.append(f"RHS:      {r.get('rhs', '')} (stated result)")
            elif r['claim_type'] == 'root':
                lines.append(f"Equation: {r.get('equation', '')} = 0")
                lines.append(f"Root:     {r.get('variable', 'x')} = {r.get('root', '?')} — {r.get('computed', '')}")
            lines.append(f"```")
            lines.append("")
    else:
        lines += ["## ✅ No mathematical errors found in curriculum files", ""]

    if passes:
        lines += [
            "## ✅ Verified Claims (PASS)",
            ""
        ]
        for r in passes:
            if r['claim_type'] == 'numeric':
                lines.append(f"- `{r.get('lhs', '')} = {r.get('rhs', '')}` — {r['file']}:{r['line']}")
            elif r['claim_type'] == 'root':
                lines.append(f"- root x={r.get('root','')} in `{r.get('equation','')}=0` — {r['file']}:{r['line']}")

    report = '\n'.join(lines)
    REPORT_PATH.write_text(report, encoding='utf-8')


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    md_files = sorted(CURRICULUM_DIR.glob("*.md"))
    if not md_files:
        print(f"No .md files found in {CURRICULUM_DIR}")
        sys.exit(2)

    print(f"Auditing {len(md_files)} curriculum files...")
    print()

    all_results = []
    for f in md_files:
        file_results = audit_file(f)
        fails   = [r for r in file_results if r['status'] == 'FAIL']
        passes  = [r for r in file_results if r['status'] == 'PASS']
        skips   = [r for r in file_results if r['status'] == 'SKIP']
        status_char = '❌' if fails else '✅'
        print(f"  {status_char} {f.name:50s}  "
              f"PASS:{len(passes):3d}  FAIL:{len(fails):3d}  SKIP:{len(skips):3d}")
        if fails:
            for r in fails:
                print(f"       ❌ Line {r['line']}: {r.get('raw', '')[:80]}")
                if r['claim_type'] == 'numeric':
                    print(f"          LHS evaluates to {r.get('computed','?')} ≠ stated {r.get('rhs','?')}")
                elif r['claim_type'] == 'root':
                    print(f"          x={r.get('root','?')} does NOT satisfy {r.get('equation','?')}=0")
        all_results.extend(file_results)

    passes = [r for r in all_results if r['status'] == 'PASS']
    fails  = [r for r in all_results if r['status'] == 'FAIL']
    skips  = [r for r in all_results if r['status'] == 'SKIP']

    print()
    print("=" * 60)
    print(f"  Files:  {len(md_files)}")
    print(f"  PASS:   {len(passes)}")
    print(f"  FAIL:   {len(fails)}")
    print(f"  SKIP:   {len(skips)}")
    print("=" * 60)

    write_report(all_results, len(md_files))
    print(f"  Report: {REPORT_PATH}")

    sys.exit(1 if fails else 0)


if __name__ == "__main__":
    main()
