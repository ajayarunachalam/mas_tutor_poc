#!/usr/bin/env python3
"""
Phase 2 — Concept/ConceptInstance Extraction.

Reads all LearningObjective nodes from Neo4j, sends them to Claude in a
single API call for concept mapping, then writes:
  - :MathDomain nodes (6 fixed)
  - :Concept nodes (deduplicated from LLM output)
  - :ConceptInstance nodes (one per Concept × qualification_code × tier)
  - [:TEACHES]     LearningObjective → ConceptInstance
  - [:INSTANCE_OF] ConceptInstance → Concept
  - [:AT_LEVEL]    ConceptInstance → Qualification
  - [:BELONGS_TO]  Concept → MathDomain
  - [:PREREQUISITE_OF] Concept → Concept (derived from LO prereq graph)

Usage:
    uv run python scripts/extract_concepts.py [--dry-run]

Flags:
    --dry-run  Print extraction output without writing to Neo4j
    --clear    Remove existing Concept/ConceptInstance nodes first (for re-runs)
"""
from __future__ import annotations

import argparse
import json
import logging
import re
import sys
import time
from collections import defaultdict
from pathlib import Path
from typing import Any

import anthropic
from dotenv import load_dotenv

PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from db.kg import kg_session, health_check

load_dotenv()
logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

VALID_DOMAINS = {"Number", "Algebra", "Geometry", "Calculus", "Statistics", "Discrete"}
VALID_DEPTHS  = {"introductory", "developing", "advanced", "specialist"}

MATH_DOMAINS = [
    {"name": "Number",     "description": "Arithmetic, numeracy, ratio, indices, estimation"},
    {"name": "Algebra",    "description": "Expressions, equations, inequalities, graphs, functions"},
    {"name": "Geometry",   "description": "Shapes, angles, trigonometry, transformations, vectors, mensuration"},
    {"name": "Calculus",   "description": "Differentiation, integration, rates of change"},
    {"name": "Statistics", "description": "Data representation, averages, probability"},
    {"name": "Discrete",   "description": "Sequences, combinatorics, proof, matrices, networks"},
]

EXTRACTION_SYSTEM_PROMPT = """You are a Cambridge International Mathematics curriculum expert.
Your task: map each Learning Objective to the abstract mathematical concept it primarily teaches.

RULES:
1. concept_name MUST be a canonical Cambridge mathematics concept name (e.g. "Quadratic Equations", "Trigonometric Ratios", "Probability", "Vectors").
2. concept_domain MUST be exactly one of: Number, Algebra, Geometry, Calculus, Statistics, Discrete.
3. concept_instance_depth MUST be exactly one of: introductory, developing, advanced, specialist.
   - introductory: Core/foundation level (IGCSE Core tier, difficulty 1)
   - developing: Standard application (IGCSE Extended tier, difficulty 2-3)
   - advanced: Complex problem-solving (A-Level equivalent, difficulty 4-5)
   - specialist: Highly abstract (Further Maths, difficulty 5+)
4. Be CONSISTENT: the SAME concept must have the SAME concept_name across ALL learning objectives.
   If two LOs both teach "Quadratic Equations", they MUST both return concept_name="Quadratic Equations".
5. Group LOs at the right granularity — not too broad ("Algebra") nor too narrow ("Solving x²+5x+6=0 by factoring").

Return a JSON array ONLY — no other text. Each element:
{
  "lo_id": "string",
  "concept_name": "string",
  "concept_domain": "Number|Algebra|Geometry|Calculus|Statistics|Discrete",
  "concept_instance_depth": "introductory|developing|advanced|specialist"
}"""

DESCRIPTIONS_SYSTEM_PROMPT = """You are a Cambridge International Mathematics curriculum expert.
Given a list of mathematical concept names, return a JSON object mapping each concept name
to a single sentence describing the abstract mathematical concept.
Return JSON only — no other text. Format: {"Concept Name": "one sentence description", ...}"""

# ---------------------------------------------------------------------------
# Step 1: Fetch LOs from Neo4j
# ---------------------------------------------------------------------------

def fetch_los(qualification: str | None = None) -> list[dict]:
    """Fetch LearningObjective nodes, optionally filtered to one qualification."""
    where = "WHERE lo.qualification_code = $qual" if qualification else ""
    cypher = f"""
        MATCH (lo:LearningObjective)
        {where}
        RETURN lo.id AS id, lo.text AS text, lo.tier AS tier,
               lo.difficulty AS difficulty, lo.bloom_level AS bloom_level,
               lo.qualification_code AS qual_code
        ORDER BY lo.difficulty ASC, lo.id ASC
    """
    params = {"qual": qualification} if qualification else {}
    with kg_session() as session:
        result = session.run(cypher, **params)
        return [dict(record) for record in result]


# ---------------------------------------------------------------------------
# Step 2: LLM extraction
# ---------------------------------------------------------------------------

def _llm_call(
    client: anthropic.Anthropic,
    system: str,
    user: str,
    max_tokens: int = 8000,
    model: str = "claude-haiku-4-5-20251001",
) -> str:
    """
    Make a single LLM call with exponential backoff for 529 overload errors.
    Returns raw text response.
    """
    max_attempts = 6
    for attempt in range(1, max_attempts + 1):
        try:
            response = client.messages.create(
                model=model,
                max_tokens=max_tokens,
                system=system,
                messages=[{"role": "user", "content": user}],
            )
            if response.stop_reason == "max_tokens":
                logger.warning(
                    "⚠️  Response truncated (stop_reason=max_tokens). "
                    "max_tokens=%d may be too low.", max_tokens
                )
            return response.content[0].text.strip()
        except Exception as exc:
            if "overloaded" in str(exc).lower() and attempt < max_attempts:
                wait = 20 * (2 ** (attempt - 1))  # 20, 40, 80, 160, 320 s
                logger.warning(
                    "API overloaded (attempt %d/%d) — waiting %ds…",
                    attempt, max_attempts, wait,
                )
                time.sleep(wait)
            else:
                raise


def fetch_existing_concept_names() -> list[str]:
    """Return sorted list of all Concept names currently in the graph."""
    with kg_session() as session:
        result = session.run("MATCH (c:Concept) RETURN c.name AS name ORDER BY name")
        return [row["name"] for row in result]


def extract_concepts_via_llm(
    los: list[dict],
    qual_label: str = "Cambridge Mathematics",
    known_concepts: list[str] | None = None,
) -> list[dict]:
    """
    Send all LOs to Haiku in a single call (no descriptions — keeps output compact).
    Returns list of extraction records: {lo_id, concept_name, concept_domain,
    concept_instance_depth}.

    known_concepts: if provided, LLM is instructed to PREFER these names to
    maximise concept reuse across qualifications.
    """
    client = anthropic.Anthropic()

    lo_lines = []
    for lo in los:
        tier_str = f" [{lo['tier']}]" if lo['tier'] else ""
        lo_lines.append(
            f"- lo_id: {lo['id']} | difficulty: {lo['difficulty']}{tier_str} | "
            f"bloom: {lo['bloom_level']} | text: {lo['text']}"
        )

    known_section = ""
    if known_concepts:
        names_str = "\n".join(f"  - {n}" for n in sorted(known_concepts))
        known_section = (
            "\n\nKNOWN CONCEPT NAMES (prefer these exact names when the concept matches):\n"
            + names_str
            + "\nOnly introduce a new concept name if none of the above fits.\n"
        )

    user_content = (
        f"Map each of these {qual_label} Learning Objectives to its abstract concept.\n\n"
        "LEARNING OBJECTIVES:\n" + "\n".join(lo_lines)
        + known_section
        + "\n\nReturn JSON array only."
    )

    logger.info("Sending %d LOs to Haiku for concept extraction…", len(los))
    raw = _llm_call(client, EXTRACTION_SYSTEM_PROMPT, user_content, max_tokens=8000)

    raw = re.sub(r"^```(?:json)?\s*", "", raw)
    raw = re.sub(r"\s*```$", "", raw)

    try:
        records = json.loads(raw)
    except json.JSONDecodeError as e:
        logger.error("JSON parse error: %s\nRaw (first 500 chars):\n%s", e, raw[:500])
        raise

    logger.info("Received %d concept mappings.", len(records))
    return records


def generate_concept_descriptions(concept_names: list[str]) -> dict[str, str]:
    """
    One-shot call to generate a one-sentence description for each unique concept.
    Returns {concept_name: description} dict.
    """
    client = anthropic.Anthropic()
    user_content = (
        "Write a one-sentence description for each of these Cambridge mathematics concepts:\n"
        + "\n".join(f"- {name}" for name in sorted(concept_names))
        + "\n\nReturn JSON only: {\"Concept Name\": \"description\", ...}"
    )
    logger.info("Generating descriptions for %d unique concepts…", len(concept_names))
    raw = _llm_call(client, DESCRIPTIONS_SYSTEM_PROMPT, user_content, max_tokens=4000)

    raw = re.sub(r"^```(?:json)?\s*", "", raw)
    raw = re.sub(r"\s*```$", "", raw)

    try:
        return json.loads(raw)
    except json.JSONDecodeError as e:
        logger.warning("Failed to parse concept descriptions: %s — using empty strings.", e)
        return {name: "" for name in concept_names}


# ---------------------------------------------------------------------------
# Step 3: Validate and clean LLM output
# ---------------------------------------------------------------------------

def validate_and_clean(records: list[dict], los: list[dict]) -> list[dict]:
    """
    Validate domains/depths, fix obvious issues, report anomalies.
    Returns cleaned records.
    """
    lo_ids = {lo["id"] for lo in los}
    cleaned = []
    issues = []

    for rec in records:
        lo_id = rec.get("lo_id", "")
        if lo_id not in lo_ids:
            issues.append(f"Unknown lo_id: {lo_id}")
            continue

        # Normalise concept name: title case, strip whitespace
        concept = rec.get("concept_name", "Unknown").strip().title()
        # Handle common edge cases
        concept = concept.replace("Hcf", "HCF").replace("Lcm", "LCM")
        concept = concept.replace("Bodmas", "BODMAS").replace("Bidmas", "BIDMAS")
        rec["concept_name"] = concept

        # Validate domain
        domain = rec.get("concept_domain", "")
        if domain not in VALID_DOMAINS:
            issues.append(f"Invalid domain '{domain}' for {lo_id} — defaulting to Algebra")
            rec["concept_domain"] = "Algebra"

        # Validate depth
        depth = rec.get("concept_instance_depth", "")
        if depth not in VALID_DEPTHS:
            issues.append(f"Invalid depth '{depth}' for {lo_id} — defaulting to developing")
            rec["concept_instance_depth"] = "developing"

        cleaned.append(rec)

    if issues:
        logger.warning("Validation issues found (%d):", len(issues))
        for issue in issues:
            logger.warning("  %s", issue)

    # Check for missing LOs
    covered_ids = {r["lo_id"] for r in cleaned}
    missing = lo_ids - covered_ids
    if missing:
        logger.warning("LOs not covered by extraction (%d): %s", len(missing), missing)

    return cleaned


# ---------------------------------------------------------------------------
# Step 4: Group into ConceptInstances
# ---------------------------------------------------------------------------

def group_into_instances(records: list[dict], los: list[dict]) -> dict:
    """
    Group extraction records by (concept_name, qual_code, tier).
    Returns a dict with:
      - concepts: {concept_name: {domain, description}} (deduplicated)
      - instances: {(concept_name, qual_code, tier): {depth, lo_ids: []}}
    """
    # Build a lookup for LO tier and qual_code
    lo_info: dict[str, dict] = {lo["id"]: lo for lo in los}

    concepts: dict[str, dict] = {}
    instances: dict[tuple, dict] = {}

    for rec in records:
        lo_id = rec["lo_id"]
        lo = lo_info.get(lo_id, {})
        qual_code = lo.get("qual_code", "0580")
        tier = lo.get("tier")  # Core | Extended | None

        concept_name = rec["concept_name"]
        domain = rec["concept_domain"]
        depth = rec["concept_instance_depth"]

        # Accumulate concepts (descriptions added in a separate call after grouping)
        if concept_name not in concepts:
            concepts[concept_name] = {"domain": domain, "description": ""}

        # Group into ConceptInstances
        key = (concept_name, qual_code, tier)
        if key not in instances:
            instances[key] = {"depth": depth, "lo_ids": [], "qual_code": qual_code, "tier": tier}
        instances[key]["lo_ids"].append(lo_id)

    logger.info(
        "Grouped into %d distinct Concepts and %d ConceptInstances.",
        len(concepts), len(instances)
    )
    return {"concepts": concepts, "instances": instances}


# ---------------------------------------------------------------------------
# Step 5: Derive Concept-level prerequisites
# ---------------------------------------------------------------------------

def derive_concept_prerequisites(
    records: list[dict], los: list[dict]
) -> list[tuple[str, str]]:
    """
    Derive Concept→Concept PREREQUISITE_OF edges from LO-level edges in the graph.
    Returns list of (from_concept, to_concept) pairs (deduplicated).
    """
    # Build lo_id → concept_name mapping
    lo_to_concept = {rec["lo_id"]: rec["concept_name"] for rec in records}

    # Fetch all LO-level PREREQUISITE_OF edges from Neo4j
    cypher = """
        MATCH (from_lo:LearningObjective)-[:PREREQUISITE_OF]->(to_lo:LearningObjective)
        RETURN from_lo.id AS from_id, to_lo.id AS to_id
    """
    concept_edges: set[tuple[str, str]] = set()
    with kg_session() as session:
        result = session.run(cypher)
        for record in result:
            from_concept = lo_to_concept.get(record["from_id"])
            to_concept = lo_to_concept.get(record["to_id"])
            if from_concept and to_concept and from_concept != to_concept:
                concept_edges.add((from_concept, to_concept))

    logger.info("Derived %d Concept-level PREREQUISITE_OF edges.", len(concept_edges))
    return list(concept_edges)


# ---------------------------------------------------------------------------
# Step 6: Write to Neo4j
# ---------------------------------------------------------------------------

def write_to_neo4j(grouped: dict, concept_prereqs: list[tuple[str, str]]) -> dict:
    """Write all Phase 2 nodes and edges to Neo4j. Returns stats dict."""
    concepts = grouped["concepts"]
    instances = grouped["instances"]

    stats = {
        "math_domains": 0,
        "concepts": 0,
        "concept_instances": 0,
        "belongs_to": 0,
        "instance_of": 0,
        "at_level": 0,
        "teaches": 0,
        "concept_prereqs": 0,
    }

    with kg_session() as session:

        # --- MathDomain nodes ---
        for domain in MATH_DOMAINS:
            session.run(
                "MERGE (d:MathDomain {name: $name}) SET d.description = $description",
                name=domain["name"], description=domain["description"]
            )
            stats["math_domains"] += 1

        # --- Concept nodes + BELONGS_TO edges ---
        for concept_name, props in concepts.items():
            concept_id = "concept-" + concept_name.lower().replace(" ", "-").replace("/", "-")
            session.run("""
                MERGE (c:Concept {id: $id})
                SET c.name           = $name,
                    c.domain         = $domain,
                    c.description    = $description,
                    c.spiral_depth_max = 1
            """, id=concept_id, name=concept_name,
                 domain=props["domain"], description=props["description"])
            stats["concepts"] += 1

            # BELONGS_TO
            session.run("""
                MATCH (c:Concept {id: $concept_id})
                MATCH (d:MathDomain {name: $domain})
                MERGE (c)-[:BELONGS_TO]->(d)
            """, concept_id=concept_id, domain=props["domain"])
            stats["belongs_to"] += 1

        # --- ConceptInstance nodes + INSTANCE_OF + AT_LEVEL edges ---
        # Also collect instance_id per (concept_name, qual, tier) for TEACHES
        instance_id_map: dict[tuple, str] = {}

        for (concept_name, qual_code, tier), inst in instances.items():
            concept_id = "concept-" + concept_name.lower().replace(" ", "-").replace("/", "-")
            tier_slug = (tier or "all").lower()
            instance_id = f"ci-{concept_id[8:]}-{qual_code.lower()}-{tier_slug}"

            session.run("""
                MERGE (ci:ConceptInstance {id: $id})
                SET ci.depth              = $depth,
                    ci.qualification_code = $qual_code,
                    ci.tier               = $tier,
                    ci.description        = $description
            """, id=instance_id, depth=inst["depth"],
                 qual_code=qual_code, tier=tier,
                 description=f"{concept_name} at {inst['depth']} level ({qual_code} {tier or 'all tiers'})")
            stats["concept_instances"] += 1

            # INSTANCE_OF
            session.run("""
                MATCH (ci:ConceptInstance {id: $ci_id})
                MATCH (c:Concept {id: $c_id})
                MERGE (ci)-[:INSTANCE_OF]->(c)
            """, ci_id=instance_id, c_id=concept_id)
            stats["instance_of"] += 1

            # AT_LEVEL
            session.run("""
                MATCH (ci:ConceptInstance {id: $ci_id})
                MATCH (q:Qualification {code: $qual_code})
                MERGE (ci)-[:AT_LEVEL]->(q)
            """, ci_id=instance_id, qual_code=qual_code)
            stats["at_level"] += 1

            instance_id_map[(concept_name, qual_code, tier)] = instance_id

        # --- TEACHES edges: LO → ConceptInstance ---
        for (concept_name, qual_code, tier), inst in instances.items():
            ci_id = instance_id_map[(concept_name, qual_code, tier)]
            for lo_id in inst["lo_ids"]:
                session.run("""
                    MATCH (lo:LearningObjective {id: $lo_id})
                    MATCH (ci:ConceptInstance {id: $ci_id})
                    MERGE (lo)-[:TEACHES]->(ci)
                """, lo_id=lo_id, ci_id=ci_id)
                stats["teaches"] += 1

        # --- Concept-level PREREQUISITE_OF edges ---
        for from_concept, to_concept in concept_prereqs:
            from_id = "concept-" + from_concept.lower().replace(" ", "-").replace("/", "-")
            to_id = "concept-" + to_concept.lower().replace(" ", "-").replace("/", "-")
            # Verify both concepts exist before creating edge
            result = session.run(
                "MATCH (a:Concept {id: $from_id}) "
                "MATCH (b:Concept {id: $to_id}) "
                "MERGE (a)-[:PREREQUISITE_OF]->(b) RETURN count(*) AS created",
                from_id=from_id, to_id=to_id
            )
            record = result.single()
            if record and record["created"] > 0:
                stats["concept_prereqs"] += 1

    return stats


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(description="Phase 2/3: Extract Concepts from LOs via LLM")
    parser.add_argument("--dry-run", action="store_true",
                        help="Extract and print without writing to Neo4j")
    parser.add_argument("--clear", action="store_true",
                        help="Clear existing Concept/ConceptInstance nodes before extraction")
    parser.add_argument("--qualification", metavar="CODE",
                        help="Process only LOs for this qualification code (e.g. 0606)")
    args = parser.parse_args()

    # --- Health check ---
    if not health_check():
        logger.error("Neo4j not reachable. Is Docker running?")
        sys.exit(1)

    # --- Optional clear ---
    if args.clear and not args.dry_run:
        logger.warning("Clearing existing Concept and ConceptInstance nodes…")
        with kg_session() as session:
            session.run("""
                MATCH (n) WHERE n:Concept OR n:ConceptInstance OR n:MathDomain
                DETACH DELETE n
            """)
        logger.info("Cleared.")

    # --- Step 1: Fetch LOs ---
    los = fetch_los(qualification=args.qualification)
    qual_log_label = f" [{args.qualification}]" if args.qualification else ""
    logger.info("Fetched %d LearningObjective nodes%s from Neo4j.", len(los), qual_log_label)

    # --- Step 2: LLM extraction ---
    # Build qual-specific label and fetch known concepts for name consistency
    qual_display_map = {
        "0580": "Cambridge IGCSE 0580 Mathematics",
        "0606": "Cambridge IGCSE 0606 Additional Mathematics",
        "9709": "Cambridge A-Level 9709 Mathematics",
        "9231": "Cambridge A-Level 9231 Further Mathematics",
    }
    qual_display = qual_display_map.get(args.qualification or "", "Cambridge Mathematics")
    known = fetch_existing_concept_names() if args.qualification else None
    if known:
        logger.info("Providing %d known concept names as hints to LLM.", len(known))
    records = extract_concepts_via_llm(los, qual_label=qual_display, known_concepts=known)

    # --- Step 3: Validate ---
    records = validate_and_clean(records, los)

    # --- Step 4: Group ---
    grouped = group_into_instances(records, los)

    # --- Step 4b: Generate concept descriptions (separate compact call) ---
    descriptions = generate_concept_descriptions(list(grouped["concepts"].keys()))
    for concept_name, desc in descriptions.items():
        if concept_name in grouped["concepts"]:
            grouped["concepts"][concept_name]["description"] = desc

    # --- Step 5: Derive Concept prerequisites ---
    concept_prereqs = derive_concept_prerequisites(records, los)

    # --- Dry run report ---
    if args.dry_run:
        print("\n=== DRY RUN — Phase 2 Extraction Results ===")
        print(f"\nDistinct Concepts ({len(grouped['concepts'])}):")
        by_domain: dict[str, list[str]] = defaultdict(list)
        for name, props in sorted(grouped["concepts"].items()):
            by_domain[props["domain"]].append(name)
        for domain, names in sorted(by_domain.items()):
            print(f"  {domain}:")
            for name in sorted(names):
                print(f"    - {name}")

        print(f"\nConceptInstances ({len(grouped['instances'])}):")
        for (concept, qual, tier), inst in sorted(grouped["instances"].items()):
            print(f"  [{inst['depth']:15}] {concept} ({qual}, {tier or 'all'}) — {len(inst['lo_ids'])} LOs")

        print(f"\nConcept-level prerequisites: {len(concept_prereqs)} edges")
        return

    # --- Step 6: Write to Neo4j ---
    logger.info("Writing Phase 2 nodes and edges to Neo4j…")
    stats = write_to_neo4j(grouped, concept_prereqs)

    print("\n=== Phase 2 Ingestion Complete ===")
    print(f"  MathDomain nodes:       {stats['math_domains']}")
    print(f"  Concept nodes:          {stats['concepts']}")
    print(f"  ConceptInstance nodes:  {stats['concept_instances']}")
    print(f"  BELONGS_TO edges:       {stats['belongs_to']}")
    print(f"  INSTANCE_OF edges:      {stats['instance_of']}")
    print(f"  AT_LEVEL edges:         {stats['at_level']}")
    print(f"  TEACHES edges:          {stats['teaches']}")
    print(f"  Concept PREREQ edges:   {stats['concept_prereqs']}")

    # --- Coverage check ---
    print("\n=== Coverage Check ===")
    with kg_session() as session:
        result = session.run("""
            MATCH (lo:LearningObjective)
            WHERE NOT (lo)-[:TEACHES]->()
            RETURN count(lo) AS orphaned
        """)
        orphaned = result.single()["orphaned"]
        if orphaned == 0:
            print("  ✓ All LOs have TEACHES edges (no orphans)")
        else:
            print(f"  ✗ WARNING: {orphaned} LOs have no TEACHES edge!")

        result2 = session.run("""
            MATCH (n) RETURN labels(n)[0] AS label, count(n) AS count ORDER BY label
        """)
        print("\n  Final node counts:")
        for record in result2:
            print(f"    {record['label']:30s}: {record['count']}")


if __name__ == "__main__":
    main()
