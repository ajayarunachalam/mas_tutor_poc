#!/usr/bin/env bash
# status.sh — Check the MAS Education chat UI service status

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG="$SCRIPT_DIR/chat_ui.log"
PORT=8080

PID=$(lsof -ti tcp:$PORT 2>/dev/null)

if [ -n "$PID" ]; then
    echo "✅ MAS chat UI is RUNNING"
    echo "   PID:  $PID"
    echo "   Port: $PORT  →  http://localhost:$PORT"
    if [ -f "$LOG" ]; then
        echo ""
        echo "--- Last 5 log lines ---"
        tail -5 "$LOG"
    fi
else
    echo "⛔ MAS chat UI is STOPPED (nothing on port $PORT)"
    if [ -f "$LOG" ]; then
        echo ""
        echo "--- Last 5 log lines ---"
        tail -5 "$LOG"
    fi
fi
