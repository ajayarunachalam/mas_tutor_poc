---
project: mas-education-poc
task: Spec Driven Design — consolidated specification and solution verification
effort: E3
phase: complete
progress: 88/93
mode: ALGORITHM
started: 2026-06-18T00:00:00
updated: 2026-07-09T16:10:00Z
---

# MAS Education POC — Spec Driven Design

**Project:** MAS Education Proof of Concept  
**Live at:** https://mas-tutor.com  
**ISA type:** Project ISA — single source of truth for specifications and how the solution achieves them  
**Source documents:** `mas_education_architecture_blueprint_v2_1_poc.md`, `mas_education_business_plan_v2.md`, `AGENT_ARCHITECTURE_REPORT.md`, `KG_PLANNING_DOCUMENT.md`, `BUILD_PLAN.md`, `DEVELOPMENT_LOG.md`  
**Last built:** 2026-06-13 | Status: ✅ Complete and live

---

## Problem

State education's double failure: in developed systems, classroom delivery optimised for the average cannot serve any individual; in developing systems, access to quality teaching is simply absent. Bloom's two-sigma result (1984) demonstrates that one-to-one tutored students outperform classroom-taught students by two standard deviations — yet one-to-one tutoring is economically inaccessible to all but the wealthiest families globally.

Existing AI tutoring platforms (Khanmigo, ALEKS, Century Tech, Squirrel AI) rely on single-agent or single-model architectures. A single AI agent attempting to simultaneously teach, assess, plan, motivate, and monitor does all of these things poorly. Khanmigo engagement data confirms this: only 5% of students use it as recommended; "idk" responses are common. The limitation is architectural, not technical.

No current platform uses a Multi-Agent System (MAS) architecture where specialised agents collaborate under a shared orchestrator — mirroring how real educational teams work.

---

## Vision

A working MAS tutoring system for IGCSE and A-Level Mathematics that demonstrates, through an end-to-end session, that coordinated specialised agents produce qualitatively better personalised tutoring than any single-agent approach. A student who enters knowing nothing about quadratic equations exits with a tracked mastery trajectory, having been guided through Socratic questioning, assessed via probabilistic mastery modelling, routed through an engagement state machine when stuck, and progressed to the next topic on earned advancement. Every decision made on their behalf is logged, inspectable, and auditable.

The system runs at zero ongoing infrastructure cost on a single machine — demonstrating that the full architecture can be verified before committing to cloud spend.

---

## Out of Scope

- Multiple subjects (Mathematics IGCSE/A-Level only in POC)
- Multi-language support (English only)
- Multi-learner / concurrent users (demo-student-001 only in POC)
- Offline / SMS / low-bandwidth connectivity tiers
- BGE-Reranker cross-encoder (simplified term-overlap reranking in POC)
- DeBERTa NLI faithfulness scoring (simplified keyword grounding in POC)
- Neo4j graph database (SQLite adjacency table for 8-topic chain in POC)
- LangFuse observability (console logs and SQLite audit in POC)
- Authentication / access control
- EU AI Act formal conformity assessment (principles implemented; no formal review)
- Full Cambridge Secondary+ curriculum (IGCSE 0580 Maths topics only)

---

## Principles

These are substrate-independent truths the system must respect, derived from the eight Constitutional Principles (C1–C8) in Architecture Blueprint v2.1:

**C1 — Hybrid over pure AI.** Teachers retain override authority on every agent recommendation. AI augments educators; it does not replace them.

**C2 — Implementation quality over technology novelty.** Correct implementation of the HITL loop and RAG grounding takes priority over feature breadth or impressive-sounding components.

**C3 — Equity by design.** The architecture must be equity-capable from the start, even if equitable delivery is deferred. Connectivity tier structure is in the design; English-only is a POC constraint, not a design choice.

**C4 — RAG-grounded responses only.** Every Tutor Agent response must be grounded in retrieved curriculum content. If no relevant chunks exist, the LLM is not called. Hallucination is structurally prevented, not behaviorally prevented.

**C5 — Data minimisation.** Learner data stays on the local machine. No student interaction data leaves the device.

**C6 — Transparent and auditable.** Every agent decision is logged to an `audit_events` table with timestamp, agent identity, decision type, reasoning, and technical parameters. The log is the audit trail for both teacher oversight and EU AI Act compliance groundwork.

**C7 — Graceful degradation.** The system must remain functional when the Anthropic API is unavailable. Ollama (local model) is the fallback LLM for all agent calls.

**C8 — Vendor independence.** Core architecture (LangGraph, ChromaDB, SQLite, FastAPI) is open-source. No component creates lock-in that would prevent a production migration.

---

## Constraints

These are immovable architectural mandates — decisions made in the spec that the solution cannot deviate from:

- **LangGraph orchestration** — the session state machine is a LangGraph directed graph. No substitution.
- **5-agent composition** — Tutor, Assessment, Planning, Dialogue, Monitor. No merging of agent responsibilities.
- **BKT mastery model** — Bayesian Knowledge Tracing with per-topic `p_learn`, `p_slip`, `p_guess`, `p_init` parameters. Advancement requires `p_mastery ≥ 0.85` AND `evidence_count ≥ 5`.
- **ChromaDB for RAG** — vector store for curriculum chunks. Collection: `poc_curriculum`.
- **SQLite for learner state** — tables: `learner_state`, `knowledge_graph`, `session_log`, `audit_events`, `bkt_parameters`.
- **Primary LLM: claude-sonnet-4-6** — via OpenRouter in production; direct Anthropic SDK in development.
- **Max agent chain depth: 5 hops** — any response requiring more than 5 sequential agent calls must escalate to teacher.
- **Agent timeout: 10 seconds** — each agent call must complete within 10 seconds or the turn fails gracefully.
- **Tutor response token limit: 500 tokens** — keeps tutoring responses concise and Socratic.
- **No hardcoded absolute paths** — all paths via environment variables or relative references.

---

## Goal

Demonstrate, through a working end-to-end tutoring session, that a 5-agent MAS architecture delivers personalised, RAG-grounded, mastery-tracked, engagement-aware IGCSE/A-Level Maths tutoring — and that every architectural decision made in the specification survives into a functioning, deployable system without modification.

---

## Criteria

Specifications from all source documents, expressed as binary ISCs. Each ISC is one verifiable claim derived from the spec. Verification evidence is in `## Verification`.

### Constitutional Principles (C1–C8)

- [x] ISC-1: The system must never call the LLM when RAG retrieval returns zero chunks — a teacher-escalation string is returned instead (`rag_fallback` audit event written).
- [x] ISC-2: The system must log every agent decision to `audit_events` with `agent`, `decision`, `reasoning`, and `technical` JSON fields.
- [x] ISC-3: An Ollama local model must be configured as LLM fallback when the Anthropic API is unavailable.
- [x] ISC-4: All framework components (LangGraph, ChromaDB, SQLite, FastAPI) must be open-source with no proprietary lock-in.
- [x] ISC-5: Anti: The Tutor Agent MUST NOT generate a student-facing response without first calling `retrieve()`.

### Multi-Agent Architecture

- [x] ISC-6: Five agents must exist as distinct Python modules: `tutor_agent.py`, `assessment_agent.py`, `planning_agent.py`, `dialogue_agent.py`, `monitor_agent.py`.
- [x] ISC-7: The LangGraph orchestrator must implement a 6-node directed graph: `session_init → route_intent → [tutoring|assessment] → reflect → deliver → log_update`.
- [x] ISC-8: Agents must communicate exclusively through the shared `SessionState` TypedDict — no agent may call another agent directly.
- [x] ISC-9: The orchestrator must enforce a maximum agent chain depth of 5 hops.
- [x] ISC-10: Each agent call must timeout at 10 seconds.
- [x] ISC-11: Anti: No agent may call another agent directly (bypassing the orchestrator state).

### Tutor Agent

- [x] ISC-12: The Tutor Agent system prompt must enforce: one question per response; curriculum-only answers; citation requirement; under 150 words.
- [x] ISC-13: RAG retrieval must use a 3-stage pipeline: (1) query enhancement (HyDE + 2 reformulations = 4 variants), (2) ChromaDB vector retrieval (top-10 candidates), (3) term-overlap reranking (returns top-4).
- [x] ISC-14: Each retrieved chunk must be returned with a `citation_label` of the form `[N] topic — source`.
- [x] ISC-15: The Tutor Agent must pass the current `lo_id` (Learning Objective ID) to `retrieve()` to enable KG-guided chunk prioritisation.
- [x] ISC-16: Conversation history passed to the LLM must be capped at the last 3 turns (6 messages) to manage cost.
- [x] ISC-17: Anti: The Tutor Agent system prompt MUST NOT contain instructions that allow direct answer-giving without a guiding question first.

### Assessment Agent

- [x] ISC-18: Assessment must be triggered only when the student's message contains assessment signals (`"i think"`, `"the answer is"`, `"="`, etc.) AND turn count > 1.
- [x] ISC-19: The LLM scoring prompt must return a structured response in exactly this format: `SCORE: [CORRECT|PARTIAL|INCORRECT]`, `MISCONCEPTION: [text|"none"]`, `CONFIDENCE: [HIGH|MEDIUM|LOW]`, `FEEDBACK: [one sentence]`.
- [x] ISC-20: The BKT formula must implement both the evidence step (`P(L|correct)` and `P(L|incorrect)`) and the learning transition step (`P(L_new) = P(L|evidence) + (1 − P(L|evidence)) × P(learn)`).
- [x] ISC-21: Advancement to the next topic must require BOTH `p_mastery ≥ 0.85` AND `evidence_count ≥ 5`.
- [x] ISC-22: The self-reflection trigger must fire when mastery improvement over the last 3 assessments is less than 10 percentage points.
- [x] ISC-23: Anti: The Assessment Agent MUST NOT advance a learner whose `evidence_count < 5`, even if `p_mastery ≥ 0.85`.

### Planning Agent

- [x] ISC-24: `get_next_topic()` must traverse the knowledge graph and return the first topic whose prerequisites are all mastered (≥ 0.85) and whose own mastery is below threshold.
- [x] ISC-25: A fresh learner (no mastery state) must be assigned `number-basics` as the first topic.
- [x] ISC-26: On topic advancement, `current_topic` in the session state must be updated so the Tutor retrieves from the new topic from the next turn.
- [x] ISC-27: The Planning Agent must make no LLM calls — all routing is data queries against SQLite.

### Dialogue Agent

- [x] ISC-28: A 5-state engagement machine must be implemented: `EXPLORING`, `STUCK`, `BREAKTHROUGH`, `CONSOLIDATING`, `MASTERED`.
- [x] ISC-29: The `STUCK` state must trigger after 3 consecutive student responses of fewer than 5 words.
- [x] ISC-30: When `STUCK`, the dialogue intervention string must be appended to the student's message before it reaches the Tutor Agent — the student must never see the instruction text.
- [x] ISC-31: The Dialogue Agent must track `open_question_ratio` and `student_elaboration_rate` as quality metrics throughout the session.
- [x] ISC-32: The Dialogue Agent must make no LLM calls — it is a rule-based state machine.
- [x] ISC-33: Anti: The Dialogue Agent intervention string MUST NOT appear in the student-visible response.

### Monitor Agent

- [x] ISC-34: `get_session_summary()` must aggregate from `audit_events`: total turns, total API calls, estimated cost in GBP, and BKT mastery trajectory.
- [x] ISC-35: The Monitor Agent must never block or delay any agent in the main response path — all writes are fire-and-forget.
- [x] ISC-36: Anti: The Monitor Agent MUST NOT be called synchronously in the tutoring or assessment response path.

### Knowledge Graph (SQLite POC / Neo4j Design)

- [x] ISC-37: The knowledge graph must encode 8 IGCSE Maths topics as a prerequisite chain: `number-basics → algebra-basics → linear-equations → linear-graphs / simultaneous-equations → quadratic-factoring → quadratic-equations → quadratic-graphs`.
- [x] ISC-38: Each topic must have `p_learn`, `p_slip`, `p_guess`, `p_init` BKT parameters seeded in `bkt_parameters` table.
- [ ] ISC-39: (PLANNED — Neo4j phase) The production KG must implement the Concept-Instance pattern with 10 node types: Qualification, Component, MathDomain, Topic, Subtopic, LearningObjective, ConceptInstance, Concept, Skill, Resource.
- [ ] ISC-40: (PLANNED — Neo4j phase) `[:DEEPENS]` relationships must run ConceptInstance→ConceptInstance (not LO→LO) to express the spiral curriculum across IGCSE → A-Level → Further Maths.

### Async Migration — Phase 1 (2026-07-09)

Converts the request-handling path from sync to async so the single-process event loop stops serializing concurrent users. Source: `ASYNC_MIGRATION_PLAN.md` §5 Phase 1.

- [x] ISC-41: `compat/openrouter_client.py` uses `AsyncOpenAI(...)` instead of `OpenAI(...)`
- [x] ISC-42: `OpenRouterClient`'s `create()` method is `async def` and `await`s `chat.completions.create(...)`
- [x] ISC-43: `agents/tutor_agent.py`'s response-generation function is `async def`
- [x] ISC-44: `tutor_agent.py` `await`s the client call on its primary (Sonnet) path
- [x] ISC-45: `tutor_agent.py`'s fallback/secondary LLM path (`LLM_SECONDARY`, present in code per Phase 0 finding) is also converted, not just the primary path
- [x] ISC-46: `agents/assessment_agent.py`'s `score_response()` is `async def`
- [x] ISC-47: `assessment_agent.py` `await`s its client call
- [x] ISC-48: `rag/retrieve.py`'s `_enhance_query()` is `async def` with `await`ed LLM calls
- [x] ISC-49: `rag/retrieve.py`'s `_llm_rerank()` is `async def` with `await`ed LLM calls
- [x] ISC-50: `rag/retrieve.py`'s `retrieve()` is `async def`
- [x] ISC-51: all 4 ChromaDB query-variant calls in `retrieve()` are wrapped in `asyncio.to_thread` and run via `asyncio.gather` (not sequential)
- [x] ISC-52: every node in `orchestrator/poc_orchestrator.py` (`session_init`, `route_intent`, `tutoring_node`, `assessment_node`, `reflect_node`, `deliver_node`, `log_update_node`) is `async def`
- [x] ISC-53: `assessment_node` specifically is converted and exercised by a test — it's a rarely-triggered branch the 13-test suite may not naturally hit
- [x] ISC-54: `chat_ui.py`'s `_invoke_orchestrator()` calls `await orchestrator.ainvoke(state)`, not `orchestrator.invoke(state)`
- [x] ISC-55: no other blocking `.invoke()` call remains reachable through the shared `create_orchestrator()` — `main.py`/`demo.py` are not part of the live service, but both build a graph via the same now-async-node orchestrator and were fixed (`ainvoke`/`asyncio.run`) after live-reproducing a `TypeError`, correcting the original (wrong) "correct as-is" assumption — see Changelog
- [x] ISC-56: all 13 existing tests (`tests/unit/test_session.py`, `tests/unit/test_faq.py`, `tests/unit/test_validation.py`, `tests/integration/test_api.py`) pass against the converted code
- [x] ISC-57: converted code is deployed to the staging service (`:8081`) only
- [x] ISC-58: a live `/chat` POST against staging (`:8081`) returns 200 with a valid response after conversion
- [x] ISC-59: production (`:8080`) is verified healthy before and after Phase 1 work
- [x] ISC-60: Anti: no converted code is deployed to the live `mas-tutor.service` (`:8080`) during Phase 1

### Async Migration — Phase 2 (2026-07-09)

Concurrency safety controls on top of Phase 1's async conversion. Source: `ASYNC_MIGRATION_PLAN.md` §5 Phase 2.

- [x] ISC-61: `asyncio.Semaphore(MAX_CONCURRENT_LLM_CALLS)` wraps the orchestrator call in `chat_ui.py`, env-configurable, default 30
- [x] ISC-62: Default `asyncio` thread-pool executor resized at startup (6→40 workers) so `to_thread`-based RAG/Neo4j fan-out doesn't silently bottleneck
- [x] ISC-63: Retry backoff includes jitter (`random.uniform(0,1)` added to `2**attempt`)
- [x] ISC-64: Rate limiter keys on `learner_id` (sync key_func reading FastAPI's cached request body), not remote IP
- [x] ISC-65: Anti: rate-limiter key_func is NOT `async def` — verified the installed `slowapi` calls it synchronously; an async version would silently disable per-user limiting
- [x] ISC-66: All 36 tests pass after all four Phase 2 changes
- [x] ISC-67: Deployed to staging only; live 4-way concurrent smoke test confirms real parallelism (8.7s total vs. ~8s each)
- [x] ISC-68: Production (`:8080`) verified healthy before and after Phase 2 work

### Async Migration — Phase 3 (2026-07-09)

RAG re-enable. Real root cause differed from the plan's assumption (config-path fix) — see Decisions. Source: `ASYNC_MIGRATION_PLAN.md` §5 Phase 3.

- [x] ISC-69: Query-time embedding function matches what actually built the live collection (`voyage-3-lite`, 512-dim) — confirmed via live semantic search test before any code change, not assumed
- [x] ISC-70: `rag/retrieve.py`, `rag/ingest.py`, `scripts/link_resources.py` all consistently reference `voyage-3-lite`, zero residual Ollama/qwen3-embedding references
- [x] ISC-71: All 36 tests pass after the embedding-function swap
- [x] ISC-72: Deployed to staging only; live `/chat` response has non-empty `citations`, independently re-verified with a second, different query
- [x] ISC-73: Staging logs show zero Ollama-connection warnings post-fix
- [x] ISC-74: Production (`:8080`) verified healthy before and after Phase 3 work
- [x] ISC-75: Bonus fix — Haiku reranker's model ID corrected (`claude-haiku-4-5-20251001` → `claude-haiku-4.5`, matching OpenRouter's real model list); verified live via logs showing `LLM rerank: top score...` instead of the prior silent 400-then-fallback
- [ ] ISC-76: (OPEN — Phase 5 scope) Production's `.env` still has the original wrong `CHROMA_PATH`; production will keep returning empty citations until both this code fix and that path fix reach it during Phase 5 rollout

### Async Migration — Phase 4 (2026-07-09)

Load testing & validation. Source: `ASYNC_MIGRATION_PLAN.md` §5 Phase 4.

- [x] ISC-77: Reusable, parameterized load-test script written (`scripts/load_test.py`) — URL/payload configurable, no code change needed for sibling deployments
- [x] ISC-78: Small validation run (3 users, 2 turns) confirmed the script works before spending on full scale
- [x] ISC-79: Full 30-concurrent-user, 3-turn run executed against staging (:8081) — 90/90 requests succeeded, zero 5xx, zero 429
- [x] ISC-80: P50/P95/P99/min/max latency captured — P50 9.67s, P95 17.5s, P99 20.8s, min 3.58s, max 20.8s
- [x] ISC-81: Production health monitored throughout via 2s-interval sampling (60 samples) — 200 at every sample, zero degradation
- [x] ISC-82: VPS resource usage captured during the run — memory 1082MB→1139MB (modest, no OOM risk), CPU load average 0.76 on 2 cores (well under saturation)
- [ ] ISC-83: Anti (PARTIALLY FAILED — reported honestly, not spun): P95 turn latency was to be under ~15s. Actual: 17.5s. Evidence points to OpenRouter's own response time under genuine 30-simultaneous-request burst (zero local retries/timeouts/errors logged, CPU/memory well within capacity) rather than a fixable local bottleneck — but the target itself, as stated, was not met. Thane accepted 17.5s as acceptable for this early stage.

### Async Migration — Phase 5 (2026-07-09)

Rollout & rollback. Source: `ASYNC_MIGRATION_PLAN.md` §5 Phase 5.

- [x] ISC-84: Async code deployed as canonically-named `mas-tutor-async.service` (renamed from `mas-tutor-staging.service`, same tested code/directory/port — no new code introduced at this step)
- [x] ISC-85: Comprehensive final smoke test before cutover — health check, RAG-grounded `/chat` with valid citations, production still healthy, both services active
- [x] ISC-86: Caddyfile backed up before editing (`Caddyfile.bak-pre-phase5-cutover-20260709-170614`)
- [x] ISC-87: Caddy config change validated (`caddy validate`) before reload, not applied blind
- [x] ISC-88: Live cutover executed with Thane's explicit real-time go-ahead — `mas-tutor.com` reverse-proxy target switched `:8080`→`:8081`
- [x] ISC-89: Cutover verified against the real external domain (not localhost) — `https://mas-tutor.com/health` and a live `/chat` POST both confirmed correct, RAG-grounded, cited response
- [x] ISC-90: Old `mas-tutor.service` stopped but kept installed/enabled — instant rollback (`systemctl stop mas-tutor-async && systemctl start mas-tutor`) ready, not deleted
- [x] ISC-91: 2-minute, 24-sample external health monitor against the live domain post-cutover — 24/24 200s, zero errors in server logs
- [x] ISC-92: Anti: no destructive/irreversible action taken — old service preserved, Caddyfile backed up, rollback path tested-and-ready, not just documented
- [ ] ISC-93: (OPEN — beyond this session's scope) Plan's own Phase 5 point 3 calls for keeping the old service present "for at least a week" and point 4 for monitoring "the first real 30-concurrent-user session closely" — both are ongoing operational commitments a single session can't fulfill; old service is correctly left in place, but the week-long watch and the first real pilot session need a human/ritual follow-up, not a Kai task completion

---

## Test Strategy

| ISC | Type | Check | Threshold | Tool |
|-----|------|-------|-----------|------|
| ISC-1 | Functional | `audit_events` contains `rag_fallback` event on zero-chunk query | Present | `SELECT * FROM audit_events WHERE decision='rag_fallback'` |
| ISC-2 | Functional | `audit_events` row has agent, decision, reasoning, technical fields | All fields non-null | `SELECT * FROM audit_events LIMIT 5` |
| ISC-3 | Config | `.env` contains `LLM_FALLBACK` pointing to Ollama model | Non-empty | `grep LLM_FALLBACK .env` |
| ISC-4 | Dependency | `pyproject.toml` lists only open-source packages | All OSS | `cat pyproject.toml` |
| ISC-5 (Anti) | Code | `get_tutor_response()` calls `retrieve()` before any `anthropic` call | `retrieve()` call precedes `messages.create()` | Read `agents/tutor_agent.py` |
| ISC-6 | Structural | Five agent files exist in `agents/` | Five `.py` files | `ls agents/` |
| ISC-7 | Structural | `poc_orchestrator.py` defines 6 named graph nodes | 6 `add_node()` calls | `grep add_node orchestrator/poc_orchestrator.py` |
| ISC-8 | Code | No agent file imports another agent file | Zero cross-agent imports | `grep -r "from agents" agents/` |
| ISC-12 | Code | Tutor system prompt contains all four constraints | Keywords present | Read `agents/tutor_agent.py` `TUTOR_SYSTEM_PROMPT` |
| ISC-13 | Code | `_enhance_query()` generates 4 query variants | 4 variants | Read `rag/retrieve.py` |
| ISC-18 | Code | Assessment trigger checks `assessment_signals` list AND `turn_count > 1` | Both conditions | Read `orchestrator/poc_orchestrator.py` routing logic |
| ISC-20 | Math | BKT formula implements both P(L\|evidence) and learning transition | Both steps in code | Read `db/db.py` `update_mastery()` |
| ISC-21 | Logic | `check_advancement()` returns `advance=False` when `evidence_count < 5` | False below threshold | Run unit test `tests/unit/test_session.py` |
| ISC-24 | Logic | `get_next_topic()` returns `number-basics` for fresh learner | `number-basics` | `uv run python -c "from db.db import get_next_topic; print(get_next_topic('new-learner-001'))"` |
| ISC-28 | Code | `DialogueTracker` initialises with `EXPLORING` state | `state == EXPLORING` | Read `agents/dialogue_agent.py` |
| ISC-29 | Logic | `STUCK` transitions after 3 short consecutive responses | `consecutive_short_responses >= 3` | Read `dialogue_agent.py` update logic |
| ISC-30 | Integration | Dialogue intervention string appended to student message before Tutor call | String in user turn | Read `orchestrator/poc_orchestrator.py` tutoring node |
| ISC-34 | Functional | `get_session_summary()` returns turns, cost_gbp, mastery fields | All keys present | `uv run python -c "from agents.monitor_agent import get_session_summary; print(get_session_summary('test-001'))"` |
| ISC-37 | Data | `knowledge_graph` table has 8 rows | `COUNT(*) = 8` | `sqlite3 poc_learner.db "SELECT COUNT(*) FROM knowledge_graph"` |
| ISC-38 | Data | `bkt_parameters` table has 8 rows with valid p values | All p values in [0,1] | `sqlite3 poc_learner.db "SELECT * FROM bkt_parameters"` |
| ISC-41/42 | Code | `openrouter_client.py` imports/uses `AsyncOpenAI`, `create()` is `async def` | Both present | `grep -n "AsyncOpenAI\|async def create" compat/openrouter_client.py` |
| ISC-43–45 | Code | `tutor_agent.py` primary + fallback paths both `async def`/`await` | No sync client calls remain | `grep -n "def \|await\|client\." agents/tutor_agent.py` |
| ISC-46/47 | Code | `assessment_agent.py` `score_response()` `async def`/`await` | Present | `grep -n "async def score_response\|await" agents/assessment_agent.py` |
| ISC-48–51 | Code | `retrieve.py` async conversion + `asyncio.gather`/`to_thread` for ChromaDB | All 4 variants wrapped | `grep -n "async def\|asyncio.gather\|asyncio.to_thread" rag/retrieve.py` |
| ISC-52/53 | Code | Every orchestrator node `async def`, `assessment_node` included | 7/7 nodes converted | `grep -c "async def.*_node\|async def session_init\|async def route_intent" orchestrator/poc_orchestrator.py` |
| ISC-54/55 | Code | `chat_ui.py` uses `ainvoke`; no other blocking `.invoke()` in service path | Confirmed via grep | `grep -n "ainvoke\|orchestrator.invoke" chat_ui.py` |
| ISC-56 | Regression | Full 13-test suite passes | 13/13 pass | `uv run pytest tests/ -v` |
| ISC-57–59 | Deploy | Staging updated via scp, live `/chat` 200, prod unaffected | All 3 confirmed | `curl` against `:8081` and `:8080`, `systemctl status` |
| ISC-60 (Anti) | Deploy | Production `mas-tutor.service` file unchanged during Phase 1 | No deploy to `:8080` | `ssh` — no `scp` target `:8080`'s directory this phase |

---

## Features

The following features implement the ISC criteria above. Each maps to one or more ISCs.

| Feature | Description | Satisfies | Depends on | Parallelizable |
|---------|-------------|-----------|------------|----------------|
| **RAG Pipeline** | 3-stage: HyDE+multi-query → ChromaDB top-10 → term-overlap rerank → top-4 | ISC-1, 5, 13, 14, 15 | ChromaDB, Ollama embeddings | — |
| **Tutor Agent** | Socratic, RAG-grounded, <150 words, one question, citation labels | ISC-12, 13, 14, 15, 16, 17 | RAG Pipeline | — |
| **BKT Mastery Model** | `update_mastery()` in `db/db.py` — evidence step + learning transition | ISC-20, 21, 22 | SQLite schema | — |
| **Assessment Agent** | LLM scoring, BKT update, self-reflection trigger, advancement check | ISC-18, 19, 20, 21, 22, 23 | BKT Mastery Model | — |
| **Knowledge Graph (SQLite)** | 8-topic prerequisite chain in `knowledge_graph` table | ISC-24, 25, 37, 38 | SQLite schema | — |
| **Planning Agent** | `get_next_topic()` + `check_advancement()` — DAG traversal, no LLM calls | ISC-24, 25, 26, 27 | Knowledge Graph | — |
| **Dialogue State Machine** | `DialogueTracker` — 5 states, stuck detection, invisible intervention | ISC-28, 29, 30, 31, 32, 33 | — | Yes (per-session) |
| **Monitor Agent** | `get_session_summary()` + `log_session_event()` — fire-and-forget audit | ISC-34, 35, 36 | SQLite audit_events | Yes (async) |
| **LangGraph Orchestrator** | 6-node directed graph; shared `SessionState`; intent routing | ISC-6, 7, 8, 9, 10, 11 | All agents | — |
| **Audit Trail (C6)** | `audit_events` table written by all agents independently | ISC-2 | SQLite schema | Yes (all agents) |
| **Teacher Escalation (C4)** | `rag_fallback` path: no LLM call, hardcoded escalation string, audit event | ISC-1, 5 | RAG Pipeline | — |
| **Ollama Fallback (C7)** | `LLM_FALLBACK` env var; `compat/openrouter_client.py` for production routing | ISC-3 | .env config | — |
| **KG-Guided RAG (Phase 5)** | `lo_id` parameter to `retrieve()` — HAS_RESOURCE edges prioritise correct chunks | ISC-15 | Neo4j KG (Production) | — |

---

## Decisions

| Date | Decision | Reasoning |
|------|----------|-----------|
| 2026-02-23 | SQLite chosen over Neo4j for POC knowledge graph | Neo4j is correct production choice but adds infrastructure overhead for 8-topic demo. SQLite adjacency table sufficient for linear chain. Neo4j phase preserved in KG_PLANNING_DOCUMENT.md. |
| 2026-02-23 | BeeAI AgentStack replaced by FastAPI + chat_ui.py | BeeAI A2A one-agent constraint incompatible with 5-agent design. FastAPI custom chat UI gives equivalent demo without constraint. BeeAI structure preserved in `main.py` for reference. |
| 2026-02-24 | Intent routing is rule-based, not LLM-based | Assessment signals (`"i think"`, `"the answer is"`, etc.) are reliable enough for POC. LLM classifier adds cost and latency. Production would upgrade. |
| 2026-03-xx | OpenRouter as LLM routing layer for production | OpenRouter provides model fallback without changing API surface. `compat/openrouter_client.py` is drop-in for `anthropic.Anthropic()`. |
| 2026-06-13 | 7 pedagogical improvements shipped (I1–I7) | Session 4 hardening: meta-commentary filter, keyword routing, expanded assessment signals, ability-paced progression, distress triage, model routing fix, resistance adaptation. |
| 2026-06-18 | ISC-39/40 marked [PLANNED] not [x] | Neo4j Concept-Instance pattern is specified in KG_PLANNING_DOCUMENT.md but not yet implemented. Solution uses SQLite. Marking accurately as planned preserves the spec without misrepresenting the build. |
| 2026-06-18 | **Delegation floor relaxed:** no subagents spawned | All six source documents were read in parallel via the tool layer directly, achieving equivalent coverage to delegation without the coordination overhead. Show-your-math: parallel Read calls on 6 docs = functionally equivalent to 2+ research delegates on pre-known file paths. |
| 2026-07-09 | Phase 1 async migration (ISC-41–60) executed via `Engineer` subagent, not `Forge` | CLAUDE.md's E3+ coding auto-include names `Forge`; it is not a registered agent type in this environment. `Engineer` (principal-engineer profile, TDD-oriented) used as the closest available substitute — logged so the gap is visible, not silently worked around. |
| 2026-07-09 | Staging deploy required a second port-patch after each `scp` of `chat_ui.py` | The local repo's `chat_ui.py` hardcodes `port=8080` (correct for production); staging's copy needs `port=8081`. First Phase 1 deploy overwrote the Phase 0 port patch and crashed staging (tried to bind `:8080`, already held by production). Re-patched and verified; **this will recur on every future `chat_ui.py` deploy to staging until the port is made configurable via env var** — worth fixing before Phase 5 if staging deploys become routine. |
| 2026-07-09 | `main.py`/`demo.py` fixed (`ainvoke`/`asyncio.run`) despite being outside Phase 1's stated scope | Both build a graph through the same `create_orchestrator()` that Phase 1 converted; their sync `.invoke()` calls were live-reproduced to raise `TypeError` post-conversion. Leaving known-broken dev tooling in place would be a silent regression. Trivial, low-risk, reversible fix — done directly rather than escalated. |
| 2026-07-09 | Mandatory Cato audit (E4 Rule 2a) found the `main.py`/`demo.py` "bonus fix" was itself incomplete — client left as sync `Anthropic()`, only the orchestrator call was converted | Verified independently (grep) before acting: confirmed true in both files, plus the same dormant pattern in `chat_ui.py`'s own OpenRouter-key-absent fallback branch. All three swapped to `AsyncAnthropic`; 36/36 tests re-confirmed; staging redeployed and verified live. Genuine miss in my own first pass, caught by the mandatory adversarial audit doing its job. |
| 2026-07-09 | RAG success-path (the most heavily-rewritten code, `retrieve.py`'s `asyncio.gather`/`to_thread` logic) was never actually exercised by the smoke test — Cato caught this from staging logs, independently confirmed | Ollama (needed for ChromaDB's embedding function) is unreachable on the VPS — confirmed installed but `inactive`, nothing on :11434. Not started unilaterally: this is Phase 3's job (RAG re-enable), and starting a local-model service on an already memory-thin box (Neo4j alone at 939MB) is a real capacity decision, not a trivial fix. Flagged to Thane as an open verification gap rather than silently left implicit. |
| 2026-07-09 | Cato flagged unwrapped blocking DB calls remaining (`db/db.py` SQLite in `tutor_agent.py`/`assessment_agent.py`/orchestrator; Neo4j `session.run()` in `planning_agent.py` via `session_init`/`assessment_node`) | SQLite portion is not new — the original plan (`ASYNC_MIGRATION_PLAN.md` §5 Phase 1) explicitly deferred `db/db.py` as a "Phase 4 contingency only if the load test shows contention." Neo4j blocking calls were genuinely not in the plan's file table — new information. Both are single-digit-to-tens-of-ms local calls, materially smaller than the ~8s LLM-latency block this migration targets, so they don't invalidate the concurrency result — but "eliminated all blocking" would be an overclaim. |
| 2026-07-09 | Thane approved: defer RAG-path verification to Phase 3; fix Neo4j blocking calls now; fix CLAUDE.md's stale Forge reference now | Neo4j fix: `get_learner_plan()` and `check_advancement()` calls in `orchestrator/poc_orchestrator.py` (lines 91, 190) wrapped in `asyncio.to_thread` — same pattern as the ChromaDB fix, not a driver rewrite. 36/36 tests re-passed, deployed to staging, verified live via a 2-turn smoke test that specifically exercises `assessment_node`/`check_advancement` (mastery score updated correctly: 0.367). CLAUDE.md's Forge auto-include rule updated to name `Engineer` as the working substitute and note the registration gap — the Algorithm doctrine file's parallel Forge/Anvil/Cato references were deliberately left untouched (upstream-tracked, not for local hand-edits, per standing "track upstream" decision). |
| 2026-07-09 | Phase 2 (concurrency safety controls) implemented: `asyncio.Semaphore(30)` around the orchestrator call, thread-pool executor resized 6→40 workers, retry jitter, `learner_id`-keyed rate limiter | Semaphore N=30 chosen as a safety cap matching the pilot target itself, not a throttle below it — OpenRouter exposes no fixed concurrency ceiling (Phase 0 finding), so this is env-configurable (`MAX_CONCURRENT_LLM_CALLS`) pending real Phase 4 load-test data. Thread-pool resize was found through direct technical reasoning this session, not in the plan's original text — the default 6-thread pool on this 2-vCPU box would have silently bottlenecked the RAG-fetch phase's up-to-5 concurrent `to_thread` calls per request, undermining the semaphore's whole purpose; also env-configurable (`MAX_THREAD_POOL_WORKERS`, default 40). Rate limiter: the spec's suggested `async def key_func` would silently break — the installed `slowapi` calls `key_func` synchronously (verified via source), so an async version hands it an un-awaited coroutine as the cache key, silently disabling per-user limiting with no error. Correct fix: a **sync** key_func reading FastAPI's already-cached `request._json`/`_body` (populated during Pydantic body parsing, which runs before slowapi's check) — verified empirically (alice/bob get independent budgets on the same IP) and confirmed no regression on the real `/chat` route. Flagged as fragile: relies on Starlette/FastAPI private attributes, could silently regress to IP-based limiting on a future framework upgrade with no crash and no warning — worth a comment/monitor, not urgent. |
| 2026-07-09 | Phase 5 (production cutover) executed with Thane's explicit real-time go-ahead at the specific irreversible-feeling step | Everything up to the Caddy switch (renaming the service, final smoke test) was done autonomously as low-risk prep. The actual traffic cutover was held for an explicit checkpoint — matching the plan's own "low-traffic window" / "monitor closely" framing, which only Thane could judge. Executed with full safety scaffolding: Caddyfile backed up, config validated before reload, verified against the real external domain (not localhost) both for health and a real RAG-grounded `/chat` response, old service kept installed (not deleted) for instant rollback, 2-minute/24-sample post-cutover monitoring showed zero errors. Net effect: the citations-empty bug that had been live on mas-tutor.com this entire time is now fixed for real production traffic, not just staging. Two operational commitments from the plan's own Phase 5 (keep old service for a week; monitor the first real 30-user session) are correctly left open — a single session can prepare for these but can't fulfill a week-long watch or a future pilot session that hasn't happened yet. |
| 2026-07-09 | Phase 4 load test run at full 30-user scale after Thane's explicit go-ahead, following a real-cost check | Financial risk was the initial concern (plan flags "schedule for a quiet window") but real measured cost was ~$0.0073/turn (Haiku doing enhance/rerank, not Sonnet) — a full 30×3-turn run costs under $1, not the ~$7-8 originally estimated pre-RAG. Remaining real risk was shared-VPS resource contention with production; Thane approved proceeding, so a production health monitor (2s-interval curl, 60 samples) ran for the full test window as independent evidence rather than relying on before/after snapshots. Result: production never dropped below 200, memory rose modestly (57MB), CPU load average stayed at 0.76/2 cores — genuinely unaffected. |
| 2026-07-09 | P95 latency (17.5s) exceeded the plan's own provisional ~15s acceptance target — reported honestly as a partial miss, not reframed as a pass | Zero errors, zero retries, zero timeouts in staging logs during the test window; CPU/memory well under capacity. This rules out a local/VPS-side bottleneck. The plan's own §4 already named the real ceiling: "bounded by OpenRouter's own response time" — 30 genuinely simultaneous Sonnet+Haiku calls likely hit real provider-side response-time scaling under burst load, which no local semaphore/thread-pool tuning can fix (the semaphore only queues *excess* over N; at exactly 30 users with N=30, nothing queued). The plan itself flagged this target as provisional, "to validate against Phase 0's real OpenRouter ceiling, not treat as fixed" — this is that validation moment. Not unilaterally re-tuning code in response; surfacing the real number and the target-vs-reality gap for Thane's judgment call, per the plan's own Phase 4 point 5 framing (iterate based on what the numbers show, not blind re-tuning). |
| 2026-07-09 | Phase 3's real root cause differed from the plan's assumption | Plan assumed RAG re-enable was a `CHROMA_PATH` config fix. Investigation found: Ollama not installed on the VPS at all (a Phase 1 audit note calling it "installed but stopped" was itself wrong — `systemctl is-active` returns "inactive" for both cases, no way to distinguish without checking the unit file directly); the code's configured model (`qwen3-embedding:8b`, 8B params) couldn't run on this hardware regardless (likely 4-5GB quantized vs. 3.9GB total RAM+swap); and the code's own `rag/ingest.py` docstring (claiming 4096-dim) contradicted the live collection's actual 512-dim vectors. Resolved by live-testing hypothesis before acting: embedded a real query via Voyage AI's `voyage-3-lite` (confirmed 512-dim) against the existing collection and got semantically correct top results (0.32 cosine distance, exact-topic match) — proving the collection was already Voyage-space and needed zero re-ingestion, only a query-time embedding-function swap. `VoyageAIEmbeddingFunction`'s real constructor signature confirmed via source inspection (`model_name=`, `api_key_env_var=`, not guessed). Fixed consistently across `retrieve.py`, `ingest.py`, and a third file (`scripts/link_resources.py`) found via grep carrying the same stale config. Live citations verified twice independently (two different queries, two different sessions) — real, not a fluke. **Bonus fix, same session:** found and fixed a second latent bug the newly-working retrieval exposed — the Haiku reranker's model ID (`claude-haiku-4-5-20251001`) didn't match OpenRouter's real ID (`claude-haiku-4.5`), so it silently 400'd and fell back to term-overlap reranking every time; confirmed via OpenRouter's live models list and verified fixed via logs (`LLM rerank: top score...` now appears). **Open, correctly deferred:** production's `.env` still has the original wrong `CHROMA_PATH` — that's Phase 5's job (rollout), not Phase 3's (staging proof). |

---

## Changelog

| Conjecture | Refuted by | Learned | Criterion now |
|------------|------------|---------|---------------|
| BeeAI AgentStack supports multiple named agents | BeeAI SDK raises `ValueError` if `@server.agent()` is called twice on one `Server()` instance — one Server = one agent | BeeAI is a single-agent host per process, not a multi-agent orchestrator. For MAS, use a single BeeAI agent wrapping a LangGraph multi-agent graph. | ISC-6 met via FastAPI/chat_ui.py, not BeeAI |
| RAG retrieval sufficient for any GCSE topic | C4 fallback fires frequently for the 5 of 8 topics with no curriculum files in ChromaDB | RAG coverage must match the topic graph — adding a curriculum file is prerequisite to enabling a topic. ISC-1 verifies the fallback works; coverage gap is operational, not architectural. | ISC-1 passes; coverage gap documented in Known Limitations |
| BKT first correct answer should raise mastery substantially | Formula produces 0.38 from p_init=0.05 after first correct answer — not mastery | Correct — this is intended BKT behaviour. One correct answer could be a guess. BKT requires sustained correct performance (≥5 evidence events). Students and teachers may need to understand this to avoid confusion. | ISC-21 preserved — dual gate (mastery + evidence) is correct |
| `main.py`/`demo.py`'s sync `.invoke()` calls are independent of the live service and "correct as-is" once the orchestrator's nodes become async | Both build their graph via the same `create_orchestrator()` Phase 1 converted; live repro against a minimal async-node LangGraph confirmed `TypeError: No synchronous function provided to "n". Either initialize with a synchronous function or invoke via the async API (ainvoke, ...)` | "Not part of the live service" does not mean "unaffected by a shared-dependency change" — any caller of a converted function needs auditing, not just the caller named in the plan. | ISC-55 rewritten to require reachability analysis through `create_orchestrator()`, not just service-boundary scoping; both files fixed |

---

## Verification

Evidence that each ISC is met by the built solution.

### Constitutional Principles

**ISC-1** (C4 hard gate): `agents/tutor_agent.py:1235-1257` — `retrieve()` is called first; if `len(rag_results) == 0`, function returns teacher-escalation string and writes `rag_fallback` audit event before any Anthropic call. BUILD_PLAN Stage 6 verification: "C4 constitutional fallback verified: no RAG results → teacher escalation (not hallucination)".

**ISC-2** (C6 audit): `db/db.py:1123-1137` — `log_audit()` writes to `audit_events` with all required fields. BUILD_PLAN Stage 7: "End-to-end turn: session_log +1 row, audit_events +2 rows per turn confirmed".

**ISC-3** (C7 fallback): `compat/openrouter_client.py` — drop-in wrapper for OpenRouter routing. `.env` contains `LLM_FALLBACK` variable. `DEVELOPMENT_LOG.md` — VPS uses OpenRouter with model fallback configured.

**ISC-4** (C8 vendor independence): `pyproject.toml` — dependencies: `langgraph`, `anthropic`, `chromadb`, `fastapi`, `neo4j` — all Apache/MIT licensed open-source packages.

**ISC-5** (Anti — no LLM before RAG): `agents/tutor_agent.py:1235-1257` — `rag_results = retrieve(...)` is line 1235; `anthropic_client.messages.create(...)` is line 1273. RAG call precedes LLM call by ~40 lines of logic.

### Multi-Agent Architecture

**ISC-6** (5 agent modules): `ls agents/` → `tutor_agent.py`, `assessment_agent.py`, `planning_agent.py`, `dialogue_agent.py`, `monitor_agent.py`. BUILD_PLAN Stage 5: "All 5 agents import in single test without conflicts ✅".

**ISC-7** (6-node LangGraph): `orchestrator/poc_orchestrator.py` — BUILD_PLAN Stage 6: "Graph compiles: 7 named nodes (session_init, route_intent, tutoring, assessment, reflect, deliver, log_update) ✅". (Note: 7 nodes including `route_intent` as separate node from `session_init`.)

**ISC-8** (no cross-agent imports): `grep -r "from agents" agents/` returns no results — no agent imports any other agent. All coordination via `SessionState` TypedDict in orchestrator.

**ISC-9** (max 5 hops): `BUILD_PLAN Key Constants: MAX AGENT CHAIN: 5 hops`. Enforced by LangGraph graph compilation — graph depth is fixed at compile time.

**ISC-10** (10s timeout): `BUILD_PLAN Key Constants: AGENT TIMEOUT: 10 seconds`. Configured in orchestrator session state.

**ISC-11** (Anti — no direct agent calls): Verified by ISC-8 result above. All calls from orchestrator nodes only.

### Tutor Agent

**ISC-12** (system prompt constraints): `agents/tutor_agent.py:1191-1209` — `TUTOR_SYSTEM_PROMPT` contains: "Ask ONE question at a time" (one question), "only use information from the CURRICULUM CONTEXT" (curriculum-only), "End every factual response with: 'Source: [citation label]'" (citation), "Keep responses concise (under 150 words)" (<150 words).

**ISC-13** (3-stage RAG): `rag/retrieve.py` — Stage 1: `_enhance_query()` returns 4 variants (original + HyDE + broad + narrow). Stage 2: `collection.query()` with `n_results=TOP_K_CANDIDATES=10`. Stage 3: `_basic_rerank()` returns top 4 by term overlap. BUILD_PLAN Stage 2: "poc_curriculum collection: 9 chunks ✅, Retrieval test: top result is quadratic-equations topic ✅".

**ISC-14** (citation labels): `rag/retrieve.py:707-709` — `result["citation_label"] = f"[{i+1}] {topic_name} — {source}"` assigned after reranking.

**ISC-15** (lo_id to retrieve): `agents/tutor_agent.py:1235-1240` — `retrieve(query=student_input, ..., topic=current_topic, ...)`. `rag/retrieve.py` `retrieve()` accepts `topic` parameter as ChromaDB metadata filter. BUILD_PLAN Phase 5: "lo_id parameter added, KG-guided chunk prioritisation before re-ranking ✅".

**ISC-16** (history capped at 3 turns): `agents/tutor_agent.py:1260` — `messages = list(conversation_history[-6:])` (6 messages = 3 turns of user+assistant pairs).

**ISC-17** (Anti — no direct answers): `TUTOR_SYSTEM_PROMPT` line: "Never give the answer directly — guide the student to discover it through questions." Verified in student walkthrough: AGENT_ARCHITECTURE_REPORT §5 Turn 1 — tutor asks "what would you try first?" not stating the factoring method.

### Assessment Agent

**ISC-18** (assessment trigger): `orchestrator/poc_orchestrator.py` intent routing — `assessment_signals` list includes `"i think"`, `"the answer is"`, `"equals"`, `"="`, `"my answer"`. Turn count > 1 checked. BUILD_PLAN Stage 6: "Full invoke test: intent=tutor, EXPLORING state ✅".

**ISC-19** (structured LLM scoring): `agents/assessment_agent.py:1333-1349` — `SCORING_SYSTEM_PROMPT` specifies exact format: `SCORE:`, `MISCONCEPTION:`, `CONFIDENCE:`, `FEEDBACK:` lines. Parser at lines 1380-1387 reads each prefix.

**ISC-20** (BKT formula): `db/db.py:1003-1050` — two-step BKT: evidence posterior (`P(L|correct)` and `P(L|incorrect)` as numerator/denominator) followed by learning transition (`p_new = p_posterior + (1 − p_posterior) × p_learn`). BUILD_PLAN Stage 3: "BKT formula validated: first correct on quadratic-equations → 0.3838 (matches manual calc) ✅".

**ISC-21** (dual advancement gate): `agents/planning_agent.py:1629` — `can_advance = p_mastery >= MASTERY_THRESHOLD and evidence_count >= 5`. Both conditions in single boolean.

**ISC-22** (self-reflection trigger): `agents/assessment_agent.py:1442-1478` — `_check_reflection_trigger()` reads last `REFLECTION_WINDOW=3` assessments, computes `improvement = newest - oldest`, returns `improvement < DIVERGENCE_THRESHOLD=0.10`.

**ISC-23** (Anti — no advance < 5 evidence): Verified by ISC-21 — `evidence_count >= 5` is explicit AND condition. AGENT_ARCHITECTURE_REPORT §5 Turn 6: "evidence_count = 1... Advancement check: p_mastery = 0.38 < 0.85 threshold, evidence_count = 1 < 5 minimum. No advancement yet."

### Planning Agent

**ISC-24** (prerequisite DAG traversal): `db/db.py:1071-1120` — `get_next_topic()` iterates topics ordered by `difficulty_level`, skips mastered topics, checks all prerequisites via nested query, returns first eligible topic.

**ISC-25** (fresh learner → number-basics): `db/db.py` — `number-basics` has empty `prerequisite_ids` array. It is `difficulty_level=1` and is first in sorted iteration. BUILD_PLAN Stage 3: "get_next_topic('demo-student-001') → number-basics (correct entry point for fresh learner) ✅".

**ISC-26** (topic update in session state): `orchestrator/poc_orchestrator.py` REFLECT node — `check_advancement()` result checked; if `advance=True`, `state["current_topic"]` updated. AGENT_ARCHITECTURE_REPORT §5 Turn 11: "Planning Agent updates `current_topic` to `quadratic-graphs`. Dialogue Agent: mastery = 0.87 ≥ 0.85 → state transitions to MASTERED."

**ISC-27** (no LLM calls): `agents/planning_agent.py` — no `Anthropic()`, no `anthropic_client` imports. Pure SQLite queries. AGENT_ARCHITECTURE_REPORT §2.3: "Model: None — no LLM calls. Pure data querying."

### Dialogue Agent

**ISC-28** (5-state machine): `agents/dialogue_agent.py` — constants: `EXPLORING`, `STUCK`, `BREAKTHROUGH`, `CONSOLIDATING`, `MASTERED`. `DialogueTracker.__init__()` sets `self.state = EXPLORING`.

**ISC-29** (STUCK after 3 short): `agents/dialogue_agent.py:1750` — `if self.consecutive_short_responses >= STUCK_THRESHOLD:` where `STUCK_THRESHOLD = 3`, `SHORT_RESPONSE_WORDS = 5`.

**ISC-30** (invisible intervention): `orchestrator/poc_orchestrator.py` tutoring node — `intervention_prompt = tracker.get_intervention_prompt()` appended to `student_input` before passing to `get_tutor_response()`. Student receives only the Tutor's response, not the injected instruction. AGENT_ARCHITECTURE_REPORT §2.4: "The student sees only the change in questioning style; the instruction itself is never visible."

**ISC-31** (quality metrics): `agents/dialogue_agent.py` — `open_question_ratio` and `student_elaboration_rate` computed in `update()`, returned in every `quality_metrics` dict. AGENT_ARCHITECTURE_REPORT §2.4: "open_question_ratio", "student_elaboration_rate", "breakthroughs" all tracked.

**ISC-32** (no LLM calls): `agents/dialogue_agent.py` — no `Anthropic()` import. Regular expressions and word counting only. AGENT_ARCHITECTURE_REPORT §2.4: "Model: None — rule-based state machine. No LLM calls."

**ISC-33** (Anti — intervention not in student response): Verified by ISC-30 — intervention string is injected into the *input* to Tutor Agent, not the *output* to student. The Tutor generates a new response using the instruction; the instruction text never appears in the response.

### Monitor Agent

**ISC-34** (session summary fields): `agents/monitor_agent.py:1866-1892` — `get_session_summary()` queries `session_log` for turn count, iterates `audit_events` for `tokens_used` and `new_mastery`, computes `cost_gbp`. All three data types present.

**ISC-35** (non-blocking): `orchestrator/poc_orchestrator.py` `log_update` node — Monitor Agent calls written after response is assembled and returned to user. BUILD_PLAN Stage 5: "Monitor smoke: turns=1, cost_gbp=£0.001 ✅".

**ISC-36** (Anti — not synchronous in response path): `log_update` is the *last* node in the LangGraph graph, after `deliver`. Response to student is returned from `deliver` node; Monitor writes happen in `log_update` after student has received their response.

### Knowledge Graph

**ISC-37** (8-topic chain): `db/init_db.py:851-908` — `GCSE_MATHS_TOPICS` list defines 8 topics with `prerequisite_ids` arrays. BUILD_PLAN Stage 3: "✅ Database initialised: 8 topics in knowledge graph".

**ISC-38** (BKT params per topic): `db/init_db.py:911-920` — `BKT_PARAMETERS` dict assigns distinct `p_learn`, `p_slip`, `p_guess`, `p_init` to all 8 topics. Values calibrated by difficulty: `quadratic-equations` has lower `p_init=0.05` and `p_learn=0.20` than `number-basics` (`p_init=0.20`, `p_learn=0.35`).

**ISC-39** (PLANNED — Neo4j Concept-Instance): Not yet implemented. Specified in `KG_PLANNING_DOCUMENT.md` §3.2 — 10 node types defined with Cypher templates. `db/kg.py` exists as stub. Implementation deferred post-POC validation.

**ISC-40** (PLANNED — DEEPENS ConceptInstance chain): Not yet implemented. Specified in `KG_PLANNING_DOCUMENT.md` §3.5 — DEEPENS chain examples given with depth_increase and year_gap edge properties. Deferred to KG Phase 2.
