"""
Shared database helpers — MAS Education POC.
All agents import from here. Handles BKT updates, topic progression, audit logging.
"""
import sqlite3
import json
import os
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()

DB_PATH = os.getenv("DB_PATH", "poc_learner.db")

MASTERY_THRESHOLD = 0.85   # C1: advance to next topic at this level
MASTERY_DIVERGENCE = 0.10  # 10pp over 3-session window triggers Planning self-reflection


def get_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def update_mastery(learner_id: str, topic_id: str, correct: bool) -> float:
    """
    Bayesian Knowledge Tracing (BKT) update. Returns new p_mastery estimate.

    BKT formula:
      P(Ln | correct)   = P(Ln-1)*(1-P(slip)) / [P(Ln-1)*(1-P(slip)) + (1-P(Ln-1))*P(guess)]
      P(Ln | incorrect) = P(Ln-1)*P(slip)      / [P(Ln-1)*P(slip)     + (1-P(Ln-1))*(1-P(guess))]
      P(Ln+1) = P(Ln|evidence) + (1 - P(Ln|evidence)) * P(learn)
    """
    conn = get_conn()

    # Fetch topic-specific BKT parameters
    params = conn.execute(
        "SELECT p_learn, p_slip, p_guess, p_init FROM bkt_parameters WHERE topic_id = ?",
        (topic_id,)
    ).fetchone()

    if params:
        p_learn = params["p_learn"]
        p_slip  = params["p_slip"]
        p_guess = params["p_guess"]
        p_init  = params["p_init"]
    else:
        # Default parameters (uninitialised topic)
        p_learn, p_slip, p_guess, p_init = 0.30, 0.10, 0.20, 0.10

    # Fetch current mastery
    row = conn.execute(
        "SELECT p_mastery, evidence_count FROM learner_state WHERE learner_id=? AND topic_id=?",
        (learner_id, topic_id)
    ).fetchone()

    p_mastery     = row["p_mastery"]     if row else p_init
    evidence_count = row["evidence_count"] if row else 0

    # Step 1: Posterior given evidence
    if correct:
        numerator   = p_mastery * (1 - p_slip)
        denominator = numerator + (1 - p_mastery) * p_guess
    else:
        numerator   = p_mastery * p_slip
        denominator = numerator + (1 - p_mastery) * (1 - p_guess)

    p_posterior = numerator / denominator if denominator > 0 else p_mastery

    # Step 2: Learning transition
    p_new = p_posterior + (1 - p_posterior) * p_learn

    # Clamp to [0.0, 1.0]
    p_new = max(0.0, min(1.0, p_new))
    evidence_count += 1

    # Upsert learner state
    conn.execute(
        """INSERT INTO learner_state (learner_id, topic_id, p_mastery, evidence_count, last_assessed)
           VALUES (?, ?, ?, ?, ?)
           ON CONFLICT(learner_id, topic_id) DO UPDATE SET
               p_mastery      = excluded.p_mastery,
               evidence_count = excluded.evidence_count,
               last_assessed  = excluded.last_assessed""",
        (learner_id, topic_id, p_new, evidence_count, datetime.utcnow().isoformat())
    )
    conn.commit()
    conn.close()
    return p_new


def get_mastery(learner_id: str, topic_id: str) -> float:
    """Return current mastery probability for a learner + topic."""
    conn = get_conn()
    row = conn.execute(
        "SELECT p_mastery FROM learner_state WHERE learner_id=? AND topic_id=?",
        (learner_id, topic_id)
    ).fetchone()
    conn.close()
    if row:
        return row["p_mastery"]
    # Return p_init if no data yet
    conn2 = get_conn()
    params = conn2.execute(
        "SELECT p_init FROM bkt_parameters WHERE topic_id=?", (topic_id,)
    ).fetchone()
    conn2.close()
    return params["p_init"] if params else 0.10


def get_next_topic(learner_id: str) -> dict | None:
    """
    Planning Agent: select the next topic for a learner.
    Returns topic dict or None if all topics mastered.
    Rules: skip topics already at MASTERY_THRESHOLD; only suggest topics
    where ALL prerequisites are also at MASTERY_THRESHOLD.
    """
    conn = get_conn()
    topics = conn.execute(
        "SELECT * FROM knowledge_graph ORDER BY difficulty_level, topic_id"
    ).fetchall()

    for topic in topics:
        topic_id      = topic["topic_id"]
        prerequisites = json.loads(topic["prerequisite_ids"])

        state = conn.execute(
            "SELECT p_mastery FROM learner_state WHERE learner_id=? AND topic_id=?",
            (learner_id, topic_id)
        ).fetchone()
        current_mastery = state["p_mastery"] if state else 0.0

        if current_mastery >= MASTERY_THRESHOLD:
            continue  # already mastered

        prereqs_met = all(
            (conn.execute(
                "SELECT p_mastery FROM learner_state WHERE learner_id=? AND topic_id=?",
                (learner_id, prereq_id)
            ).fetchone() or {"p_mastery": 0.0})["p_mastery"] >= MASTERY_THRESHOLD
            for prereq_id in prerequisites
        )

        if prereqs_met:
            conn.close()
            return {
                "topic_id":       topic_id,
                "topic_name":     topic["topic_name"],
                "current_mastery": current_mastery,
                "prerequisites":  prerequisites
            }

    conn.close()
    return None  # all topics mastered


def log_session(session_id: str, learner_id: str, agent: str,
                event_type: str, input_text: str = "", output_text: str = "",
                metadata: dict | None = None) -> None:
    """Append a session log entry."""
    conn = get_conn()
    conn.execute(
        """INSERT INTO session_log
           (session_id, learner_id, timestamp, agent, event_type, input_text, output_text, metadata)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
        (session_id, learner_id, datetime.utcnow().isoformat(),
         agent, event_type, input_text, output_text, json.dumps(metadata or {}))
    )
    conn.commit()
    conn.close()


def log_audit(session_id: str, learner_id: str, agent: str,
              decision: str, reasoning: str, technical: dict | None = None) -> None:
    """C6 — Log every agent decision to audit_events for transparency."""
    conn = get_conn()
    conn.execute(
        """INSERT INTO audit_events
           (timestamp, session_id, learner_id, agent, decision, reasoning, technical)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (datetime.utcnow().isoformat(), session_id, learner_id,
         agent, decision, reasoning, json.dumps(technical or {}))
    )
    conn.commit()
    conn.close()
