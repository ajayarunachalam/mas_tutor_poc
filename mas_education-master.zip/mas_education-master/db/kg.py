"""
Neo4j Knowledge Graph driver — MAS Education POC.

Driver infrastructure delegates to the shared cambridge-knowledge-graph package.
All curriculum-specific query helpers remain here.

Usage:
    from db.kg import health_check, kg_session

    with kg_session() as session:
        result = session.run("MATCH (q:Qualification) RETURN q.name")
        for record in result:
            print(record["q.name"])
"""
from __future__ import annotations

import logging
from pathlib import Path

from dotenv import load_dotenv

# Driver infrastructure from shared package — get_driver, close_driver,
# kg_session, and health_check are all re-exported from here for backward compat.
from cambridge_kg.driver import (  # noqa: F401
    get_driver,
    close_driver,
    kg_session,
    health_check,
)

load_dotenv()

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Schema initialisation
# ---------------------------------------------------------------------------
def apply_schema() -> None:
    """
    Apply constraints and indexes from db/schema.cypher.
    Idempotent — safe to call on every startup.
    """
    schema_path = Path(__file__).parent / "schema.cypher"
    if not schema_path.exists():
        raise FileNotFoundError(f"Schema file not found: {schema_path}")

    cypher_text = schema_path.read_text()

    # Split on semicolons, strip comments and blank lines
    statements = [
        stmt.strip()
        for stmt in cypher_text.split(";")
        if stmt.strip() and not stmt.strip().startswith("//")
    ]

    with kg_session() as session:
        for stmt in statements:
            if stmt:
                try:
                    session.run(stmt)
                except Exception as exc:
                    logger.warning("Schema statement skipped (%s): %.120s", exc, stmt)

    logger.info("Schema applied: %d statements processed.", len(statements))


# ---------------------------------------------------------------------------
# Curriculum query helpers (used by Planning Agent)
# ---------------------------------------------------------------------------
def get_next_lo(learner_id: str) -> dict | None:
    """
    Return the next LearningObjective for a learner.

    Picks the lowest-difficulty unmastered LO whose hard prerequisites
    are all mastered by this learner. Falls back to easiest unmastered LO
    if no prerequisites exist yet.
    """
    cypher = """
        MATCH (lo:LearningObjective)
        WHERE NOT EXISTS {
            MATCH (:Learner {id: $learner_id})-[:HAS_MASTERY {mastered: true}]->(lo)
        }
        AND ALL(prereq IN [
            (lo)<-[:PREREQUISITE_OF {strength: "hard"}]-(p) | p
        ] WHERE EXISTS {
            MATCH (:Learner {id: $learner_id})-[:HAS_MASTERY {mastered: true}]->(prereq)
        })
        RETURN lo
        ORDER BY lo.difficulty ASC
        LIMIT 1
    """
    with kg_session() as session:
        result = session.run(cypher, learner_id=learner_id)
        record = result.single()
        return dict(record["lo"]) if record else None


def get_lo_by_id(lo_id: str) -> dict | None:
    """Fetch a single LearningObjective by its id property."""
    with kg_session() as session:
        result = session.run(
            "MATCH (lo:LearningObjective {id: $id}) RETURN lo",
            id=lo_id,
        )
        record = result.single()
        return dict(record["lo"]) if record else None


def get_prerequisites(lo_id: str) -> list[dict]:
    """Return all hard prerequisite LOs for a given LO."""
    cypher = """
        MATCH (prereq:LearningObjective)-[:PREREQUISITE_OF {strength: "hard"}]->
              (lo:LearningObjective {id: $id})
        RETURN prereq
        ORDER BY prereq.difficulty ASC
    """
    with kg_session() as session:
        result = session.run(cypher, id=lo_id)
        return [dict(record["prereq"]) for record in result]


def update_mastery_kg(
    learner_id: str,
    lo_id: str,
    p_mastery: float,
    mastered: bool,
    evidence_count: int,
) -> None:
    """
    Upsert a HAS_MASTERY relationship between Learner and LearningObjective.
    Creates the Learner node if it doesn't exist yet.
    """
    cypher = """
        MERGE (learner:Learner {id: $learner_id})
        WITH learner
        MATCH (lo:LearningObjective {id: $lo_id})
        MERGE (learner)-[m:HAS_MASTERY]->(lo)
        SET m.p_mastery      = $p_mastery,
            m.mastered        = $mastered,
            m.evidence_count  = $evidence_count,
            m.last_updated    = datetime()
    """
    with kg_session() as session:
        session.run(
            cypher,
            learner_id=learner_id,
            lo_id=lo_id,
            p_mastery=p_mastery,
            mastered=mastered,
            evidence_count=evidence_count,
        )


def get_concept_path(from_lo_id: str, to_qualification_level: str) -> list[dict]:
    """
    Given a mastered LO, find A-Level LOs reachable via DEEPENS chain.
    Used for cross-qualification mastery transfer recommendations.
    """
    cypher = """
        MATCH (lo:LearningObjective {id: $lo_id})
              -[:TEACHES]->(ci:ConceptInstance)
              -[:DEEPENS*1..3]->(deeper_ci:ConceptInstance)
              -[:AT_LEVEL]->(:Qualification {level: $level})
              <-[:TEACHES]-(next_lo:LearningObjective)
        RETURN next_lo, deeper_ci.depth AS concept_depth
        ORDER BY next_lo.difficulty ASC
    """
    with kg_session() as session:
        result = session.run(cypher, lo_id=from_lo_id, level=to_qualification_level)
        return [
            {"lo": dict(record["next_lo"]), "depth": record["concept_depth"]}
            for record in result
        ]


def get_learner_mastery(learner_id: str, lo_id: str) -> dict | None:
    """
    Return current HAS_MASTERY edge properties for (learner, LO).
    Returns None if no mastery record exists yet.
    """
    cypher = """
        MATCH (learner:Learner {id: $learner_id})-[m:HAS_MASTERY]->(lo:LearningObjective {id: $lo_id})
        RETURN m.p_mastery AS p_mastery,
               m.mastered   AS mastered,
               m.evidence_count AS evidence_count
    """
    with kg_session() as session:
        result = session.run(cypher, learner_id=learner_id, lo_id=lo_id)
        record = result.single()
        if record is None:
            return None
        return {
            "p_mastery":      record["p_mastery"],
            "mastered":       record["mastered"],
            "evidence_count": record["evidence_count"],
        }


def bkt_update_kg(learner_id: str, lo_id: str, correct: bool) -> float:
    """
    Full BKT update using per-LO parameters stored on the LearningObjective node.
    Reads current mastery from HAS_MASTERY edge, computes BKT update,
    writes result back. Returns new p_mastery.
    """
    # Fetch LO BKT params + current mastery in one query
    cypher = """
        MATCH (lo:LearningObjective {id: $lo_id})
        OPTIONAL MATCH (learner:Learner {id: $learner_id})-[m:HAS_MASTERY]->(lo)
        RETURN lo.bkt_p_learn AS p_learn,
               lo.bkt_p_slip  AS p_slip,
               lo.bkt_p_guess AS p_guess,
               lo.bkt_p_init  AS p_init,
               m.p_mastery     AS cur_mastery,
               m.evidence_count AS cur_evidence
    """
    with kg_session() as session:
        record = session.run(cypher, learner_id=learner_id, lo_id=lo_id).single()

    if record is None:
        raise ValueError(f"LearningObjective not found: {lo_id}")

    p_learn    = record["p_learn"]    or 0.30
    p_slip     = record["p_slip"]     or 0.10
    p_guess    = record["p_guess"]    or 0.20
    p_init     = record["p_init"]     or 0.10
    p_mastery  = record["cur_mastery"]  if record["cur_mastery"]  is not None else p_init
    evidence   = record["cur_evidence"] if record["cur_evidence"] is not None else 0

    # BKT posterior given evidence
    if correct:
        numerator   = p_mastery * (1 - p_slip)
        denominator = numerator + (1 - p_mastery) * p_guess
    else:
        numerator   = p_mastery * p_slip
        denominator = numerator + (1 - p_mastery) * (1 - p_guess)

    p_posterior = numerator / denominator if denominator > 0 else p_mastery

    # Learning transition
    p_new      = p_posterior + (1 - p_posterior) * p_learn
    p_new      = max(0.0, min(1.0, p_new))
    evidence  += 1
    mastered   = p_new >= 0.85

    update_mastery_kg(
        learner_id=learner_id,
        lo_id=lo_id,
        p_mastery=p_new,
        mastered=mastered,
        evidence_count=evidence,
    )
    return p_new


def check_advancement_kg(
    learner_id: str,
    lo_id: str,
    mastery_threshold: float = 0.85,
    evidence_threshold: int = 5,
) -> dict:
    """
    Check whether a learner should advance from the current LO.
    Returns a dict compatible with the orchestrator's advancement_check field.
    """
    state = get_learner_mastery(learner_id, lo_id)

    if state is None:
        return {"advance": False, "reason": "no_data"}

    p_mastery      = state["p_mastery"]
    evidence_count = state["evidence_count"]

    can_advance = p_mastery >= mastery_threshold and evidence_count >= evidence_threshold

    if can_advance:
        next_lo = get_next_lo(learner_id)
        return {
            "advance":         True,
            "next_topic":      next_lo,
            "mastery_achieved": p_mastery,
        }

    return {
        "advance":          False,
        "current_mastery":  p_mastery,
        "evidence_count":   evidence_count,
        "needed_mastery":   mastery_threshold,
        "needed_evidence":  max(0, evidence_threshold - evidence_count),
    }


def get_node_counts() -> dict:
    """Return node count per label — useful for validation."""
    cypher = """
        MATCH (n)
        RETURN labels(n)[0] AS label, count(n) AS count
        ORDER BY label
    """
    with kg_session() as session:
        result = session.run(cypher)
        return {record["label"]: record["count"] for record in result}
