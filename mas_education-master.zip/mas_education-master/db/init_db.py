"""
Database initialisation — creates SQLite schema and seeds knowledge graph.
Run once before starting the POC server (idempotent — safe to re-run).

Usage:
    uv run python db/init_db.py
    uv run initdb
"""
import sqlite3
import json
import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

DB_PATH = os.getenv("DB_PATH", "poc_learner.db")
SCHEMA_PATH = Path(__file__).parent / "poc_schema.sql"

# GCSE Mathematics knowledge graph — 8 core topics
# Prerequisite structure: must master prerequisites before attempting a topic
GCSE_MATHS_TOPICS = [
    {
        "topic_id": "number-basics",
        "topic_name": "Number and Operations",
        "description": "Integers, fractions, decimals, percentages, negative numbers",
        "difficulty_level": 1,
        "prerequisite_ids": []
    },
    {
        "topic_id": "algebra-basics",
        "topic_name": "Algebraic Expressions",
        "description": "Simplifying expressions, expanding brackets, factorising",
        "difficulty_level": 1,
        "prerequisite_ids": ["number-basics"]
    },
    {
        "topic_id": "linear-equations",
        "topic_name": "Linear Equations",
        "description": "Solving one- and two-step equations, equations with variables on both sides",
        "difficulty_level": 1,
        "prerequisite_ids": ["algebra-basics"]
    },
    {
        "topic_id": "linear-graphs",
        "topic_name": "Linear Graphs (y = mx + c)",
        "description": "Gradient, y-intercept, plotting straight lines, parallel and perpendicular",
        "difficulty_level": 2,
        "prerequisite_ids": ["linear-equations"]
    },
    {
        "topic_id": "simultaneous-equations",
        "topic_name": "Simultaneous Equations",
        "description": "Solving systems of two linear equations by substitution and elimination",
        "difficulty_level": 2,
        "prerequisite_ids": ["linear-equations"]
    },
    {
        "topic_id": "quadratic-factoring",
        "topic_name": "Quadratic Factoring",
        "description": "Factorising quadratics, difference of two squares",
        "difficulty_level": 2,
        "prerequisite_ids": ["algebra-basics", "linear-equations"]
    },
    {
        "topic_id": "quadratic-equations",
        "topic_name": "Quadratic Equations",
        "description": "Solving quadratics by factoring, quadratic formula, completing the square",
        "difficulty_level": 2,
        "prerequisite_ids": ["quadratic-factoring"]
    },
    {
        "topic_id": "quadratic-graphs",
        "topic_name": "Quadratic Graphs and Turning Points",
        "description": "Parabolas, axis of symmetry, vertex, discriminant and roots",
        "difficulty_level": 2,
        "prerequisite_ids": ["quadratic-equations", "linear-graphs"]
    }
]

# BKT parameters per topic (research-calibrated defaults)
BKT_PARAMETERS = {
    "number-basics":          {"p_learn": 0.35, "p_slip": 0.08, "p_guess": 0.25, "p_init": 0.20},
    "algebra-basics":         {"p_learn": 0.30, "p_slip": 0.10, "p_guess": 0.20, "p_init": 0.10},
    "linear-equations":       {"p_learn": 0.30, "p_slip": 0.10, "p_guess": 0.20, "p_init": 0.10},
    "linear-graphs":          {"p_learn": 0.25, "p_slip": 0.12, "p_guess": 0.18, "p_init": 0.10},
    "simultaneous-equations": {"p_learn": 0.25, "p_slip": 0.12, "p_guess": 0.15, "p_init": 0.08},
    "quadratic-factoring":    {"p_learn": 0.25, "p_slip": 0.12, "p_guess": 0.15, "p_init": 0.08},
    "quadratic-equations":    {"p_learn": 0.20, "p_slip": 0.15, "p_guess": 0.15, "p_init": 0.05},
    "quadratic-graphs":       {"p_learn": 0.20, "p_slip": 0.15, "p_guess": 0.12, "p_init": 0.05},
}


def init_database(db_path: str | None = None) -> None:
    """Create all tables and seed reference data. Idempotent — safe to call multiple times."""
    path = db_path or DB_PATH
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    # Create schema (all tables use IF NOT EXISTS)
    schema = SCHEMA_PATH.read_text(encoding="utf-8")
    cursor.executescript(schema)

    # Seed knowledge graph (INSERT OR IGNORE — won't overwrite existing rows)
    for topic in GCSE_MATHS_TOPICS:
        cursor.execute(
            """INSERT OR IGNORE INTO knowledge_graph
               (topic_id, topic_name, description, difficulty_level, prerequisite_ids)
               VALUES (?, ?, ?, ?, ?)""",
            (
                topic["topic_id"],
                topic["topic_name"],
                topic["description"],
                topic["difficulty_level"],
                json.dumps(topic["prerequisite_ids"])
            )
        )

    # Seed BKT parameters (INSERT OR IGNORE)
    for topic_id, params in BKT_PARAMETERS.items():
        cursor.execute(
            """INSERT OR IGNORE INTO bkt_parameters
               (topic_id, p_learn, p_slip, p_guess, p_init)
               VALUES (?, ?, ?, ?, ?)""",
            (topic_id, params["p_learn"], params["p_slip"], params["p_guess"], params["p_init"])
        )

    conn.commit()

    count = cursor.execute("SELECT COUNT(*) FROM knowledge_graph").fetchone()[0]
    print(f"✅ Database initialised: {count} topics in knowledge graph")
    print(f"   DB path: {path}")

    print("\nKnowledge Graph (Foundation → Higher):")
    for row in cursor.execute(
        "SELECT topic_id, topic_name, prerequisite_ids FROM knowledge_graph ORDER BY difficulty_level, topic_id"
    ):
        prereqs = json.loads(row["prerequisite_ids"])
        suffix = f" (requires: {', '.join(prereqs)})" if prereqs else " (entry point)"
        print(f"  {row['topic_id']}: {row['topic_name']}{suffix}")

    conn.close()


if __name__ == "__main__":
    init_database()
