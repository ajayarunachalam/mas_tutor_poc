// MAS Education POC — Neo4j Schema: Constraints and Indexes
// Run once on a fresh Neo4j instance. Safe to re-run (IF NOT EXISTS guards).

// ===== UNIQUE CONSTRAINTS =====
// (Constraints automatically create lookup indexes)

CREATE CONSTRAINT qualification_code IF NOT EXISTS
  FOR (q:Qualification) REQUIRE q.code IS UNIQUE;

CREATE CONSTRAINT concept_id IF NOT EXISTS
  FOR (c:Concept) REQUIRE c.id IS UNIQUE;

CREATE CONSTRAINT concept_instance_id IF NOT EXISTS
  FOR (ci:ConceptInstance) REQUIRE ci.id IS UNIQUE;

CREATE CONSTRAINT lo_id IF NOT EXISTS
  FOR (lo:LearningObjective) REQUIRE lo.id IS UNIQUE;

CREATE CONSTRAINT topic_id IF NOT EXISTS
  FOR (t:Topic) REQUIRE t.id IS UNIQUE;

CREATE CONSTRAINT subtopic_id IF NOT EXISTS
  FOR (st:Subtopic) REQUIRE st.id IS UNIQUE;

CREATE CONSTRAINT component_code IF NOT EXISTS
  FOR (comp:Component) REQUIRE comp.code IS UNIQUE;

CREATE CONSTRAINT resource_id IF NOT EXISTS
  FOR (r:Resource) REQUIRE r.id IS UNIQUE;

// ===== LOOKUP INDEXES =====

CREATE INDEX lo_difficulty IF NOT EXISTS
  FOR (lo:LearningObjective) ON (lo.difficulty);

CREATE INDEX lo_bloom IF NOT EXISTS
  FOR (lo:LearningObjective) ON (lo.bloom_level);

CREATE INDEX lo_tier IF NOT EXISTS
  FOR (lo:LearningObjective) ON (lo.tier);

CREATE INDEX concept_domain IF NOT EXISTS
  FOR (c:Concept) ON (c.domain);

// ===== VERIFICATION QUERY =====
// SHOW CONSTRAINTS;
// SHOW INDEXES;
