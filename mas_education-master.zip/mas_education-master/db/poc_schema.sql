-- MAS Education POC — SQLite Schema
-- Replaces PostgreSQL (learner state) + Neo4j (knowledge graph) from v2.0 production

-- Learner state (one row per learner per knowledge component)
CREATE TABLE IF NOT EXISTS learner_state (
    learner_id TEXT NOT NULL,
    topic_id TEXT NOT NULL,
    p_mastery REAL DEFAULT 0.1,         -- BKT mastery probability (0.0–1.0)
    evidence_count INTEGER DEFAULT 0,    -- Number of assessed interactions
    last_assessed TEXT,                  -- ISO-8601 datetime
    next_review TEXT,                    -- ISO-8601 datetime (spaced repetition)
    PRIMARY KEY (learner_id, topic_id)
);

-- Knowledge graph (adjacency list — replaces Neo4j for POC)
-- Prerequisite: must master 'from_topic' before attempting 'to_topic'
CREATE TABLE IF NOT EXISTS knowledge_graph (
    topic_id TEXT PRIMARY KEY,
    topic_name TEXT NOT NULL,
    description TEXT,
    difficulty_level INTEGER DEFAULT 1,  -- 1=Foundation, 2=Higher
    prerequisite_ids TEXT DEFAULT '[]'   -- JSON array of prerequisite topic_ids
);

-- Session log (each agent interaction in a tutoring session)
CREATE TABLE IF NOT EXISTS session_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL,
    learner_id TEXT NOT NULL,
    timestamp TEXT NOT NULL,             -- ISO-8601
    agent TEXT NOT NULL,                 -- tutor-agent | assessment-agent | etc.
    event_type TEXT NOT NULL,            -- interaction | mastery_update | state_change | etc.
    input_text TEXT,
    output_text TEXT,
    metadata TEXT DEFAULT '{}'           -- JSON: BKT params, RAG chunks used, etc.
);

-- Audit events (C6 — transparent and auditable — every agent decision)
CREATE TABLE IF NOT EXISTS audit_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL,
    session_id TEXT NOT NULL,
    learner_id TEXT NOT NULL,
    agent TEXT NOT NULL,
    decision TEXT NOT NULL,              -- e.g. 'advance_topic', 'trigger_stuck', 'mastery_update'
    reasoning TEXT,                      -- Human-readable explanation
    technical TEXT DEFAULT '{}',         -- JSON: parameters, thresholds, values used
    human_override_available INTEGER DEFAULT 1
);

-- BKT parameters per topic (research-calibrated values)
CREATE TABLE IF NOT EXISTS bkt_parameters (
    topic_id TEXT PRIMARY KEY,
    p_learn REAL DEFAULT 0.3,            -- Probability of learning per interaction
    p_slip REAL DEFAULT 0.1,             -- Probability of incorrect response despite mastery
    p_guess REAL DEFAULT 0.2,            -- Probability of correct response without mastery
    p_init REAL DEFAULT 0.1              -- Prior mastery probability
);
