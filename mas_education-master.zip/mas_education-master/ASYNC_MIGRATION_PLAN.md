# MAS Tutor — Async Migration Plan

**Goal:** make `mas-tutor.com` handle 30 concurrent users starting a session at the same moment, without degrading response quality, ahead of a planned concurrent-load test.

**Status:** PLAN ONLY — nothing in this document has been implemented. No code has been changed, no service has been restarted.

**Author:** Kai, investigating live at `51.15.38.155` (Scaleway DEV1-S, 2 vCPU / 2GB RAM) — 2026-07-06.

---

## 1. Executive Summary

The live site is not slow because the model is slow — a single reproduced request against the production endpoint completed in 6.5s. It is slow *unpredictably*, up to ~50s, because the request-handling architecture serializes every user's turn behind every other user's turn:

- `chat_ui.py` runs a single `uvicorn` worker.
- Inside that one process, the async `/chat` route calls the LangGraph orchestrator **synchronously** (`orchestrator.invoke(state)`), which internally uses the plain `Anthropic`/OpenAI-compatible client — a blocking network call.
- A blocking call inside an `async def` route freezes the **entire process event loop**, not just that one request. While user A's Claude call is in flight, user B, C, D... cannot even *start* being processed.
- On top of that, any transient failure retries the **whole multi-step turn** up to 3 times (1s/2s/4s backoff), so one hiccup re-queues everyone behind it again.

At today's ~1-2 simultaneous users this is occasionally annoying. At **30 concurrent users starting at once**, it does not degrade gracefully — it queues. The math is in §3.

Two more things were found along the way that materially affect the "same quality" bar and the rollout itself:

- **RAG grounding is currently silently disabled in production.** The VPS `.env` has `CHROMA_PATH` pointing at an empty local path (`/home/tonyts/.pai/rag/chromadb` — a leftover WSL2 laptop path) instead of the real ingested collection (`/home/mas_app/.pai/rag/chromadb`, 146 chunks). The tutor is answering from general model knowledge, not the curriculum, and citations are silently empty. Confirmed directly: my test response returned `"citations":[]`.
- **The rate limiter will reject students before the model ever sees them.** `slowapi` is configured at 20 requests/minute **per IP** (`chat_ui.py:219,375`). If 30 students share one school network's public IP, roughly a third of the class gets HTTP 429 in the first minute — independent of every fix below.

This plan addresses all three, in the order that makes each subsequent step testable.

---

## 2. Current Architecture (as verified against the live VPS)

```
Caddy (TLS, :443 → :8080)
  → uvicorn (single process, no workers= set)
    → FastAPI async route  POST /chat
      → orchestrator.invoke(state)      ⚠ BLOCKING — freezes the whole process
        → LangGraph nodes (session_init → route_intent → tutoring|assessment → reflect → deliver → log_update)
          → agents/tutor_agent.py        — sync Anthropic/OpenRouter client, .messages.create()
          → agents/assessment_agent.py   — sync client, .messages.create() (when triggered)
          → rag/retrieve.py              — sync client (HyDE enhance + Haiku rerank) + sync ChromaDB .query()
```

Evidence gathered live (2026-07-06, `ssh root@51.15.38.155`):

| Check | Result |
|---|---|
| Single reproduced `/chat` call | 6.5s, HTTP 200 |
| `uvicorn.run(app, host="0.0.0.0", port=8080)` | no `workers=` — confirmed in `chat_ui.py:731` |
| Client type | `OpenAI(...)` sync client wrapped by `compat/openrouter_client.py:61` — not `AsyncOpenAI` |
| Orchestrator invocation | `chat_ui.py:300-319` — `_invoke_orchestrator()` calls `orchestrator.invoke(state)` directly, with a comment explaining this was a deliberate workaround for a LangGraph/asyncio conflict |
| Retry policy | up to 3 attempts, `await asyncio.sleep(2 ** attempt)` — retries the **whole graph**, not the failed sub-call |
| Rate limiter | `Limiter(key_func=get_remote_address)`, `20/minute` on `/chat` — per-IP |
| `CHROMA_PATH` on VPS `.env` | `/home/tonyts/.pai/rag/chromadb` → 0 collections. Real data lives at `/home/mas_app/.pai/rag/chromadb` → `poc_curriculum`, 146 chunks |
| VPS memory at idle | 125MB free / 1.9GB total, 0 swap — already thin, independent of this feature |
| VPS CPU | 2 vCPU, load average 0.11 at idle |
| Haiku fallback (`LLM_SECONDARY`) | present in code (`agents/tutor_agent.py:49`, "Improvement 6") but never set on the VPS — every message pays full Sonnet latency even trivial ones |

---

## 3. Why "add more workers" (my earlier suggestion) does not solve this

Before this target concurrency number was known, I'd suggested `workers=2` as a quick fix. Worked through against 30 concurrent users, it doesn't hold up — worth stating plainly since it corrects my own earlier recommendation:

| Configuration | Concurrent capacity | 30 requests × ~7-10s each | Worst-case wait, last student |
|---|---|---|---|
| Today (1 worker, blocking) | 1 | fully serialized | ~3.5–5 min |
| `workers=2` | 2 | 15 sequential batches | ~1.75–2.5 min |
| **Fully async (this plan)** | ~30 (I/O-bound coroutines) | all fire concurrently | ~7–15s, bounded by OpenRouter's own response time |

There's also a correctness reason to avoid multi-worker scaling here specifically, not just a performance one: this app's ChromaDB collection is an **embedded `PersistentClient`** (local SQLite-backed), not the client/server mode. SQLite serializes writes, and multiple OS processes hitting the same `PersistentClient(path=...)` directory concurrently risk lock collisions. Async concurrency inside **one process** sidesteps this entirely — which is also why the target design below is explicitly single-process.

---

## 4. Target Architecture

```
Caddy (unchanged)
  → uvicorn (single process — unchanged, and deliberately not multi-worker)
    → FastAPI async route  POST /chat
      → await orchestrator.ainvoke(state)          — no longer blocks the loop
        → async LangGraph nodes
          → agents/tutor_agent.py        — AsyncOpenAI/AsyncAnthropic, await .messages.create()
          → agents/assessment_agent.py   — same
          → rag/retrieve.py              — await for LLM calls; chromadb .query() wrapped in
                                            asyncio.to_thread (no native async client exists for
                                            the embedded PersistentClient — confirmed via research,
                                            only the HTTP client mode has AsyncHttpClient)
      → bounded by an asyncio.Semaphore(N) sized to the verified OpenRouter capacity (§5, Phase 0)
```

The single most important shift: the app goes from *serializing on OS-level concurrency* (which this VPS has almost none of — 2 vCPU) to *serializing on I/O wait* (which async handles cheaply — dozens of concurrent network waits cost almost nothing on a small box, because the CPU isn't doing anything during the wait).

---

## 5. Phased Plan

### Phase 0 — Prerequisites & Verification — **COMPLETE 2026-07-09**

Nothing here touched production traffic. Live findings below replace the original assumptions.

1. **OpenRouter rate-limit check — done, but the answer isn't a concurrency number.** The `/api/v1/key` endpoint's `rate_limit` field is explicitly deprecated by OpenRouter (`-1`, "safe to ignore") — there's no fixed RPM/concurrency ceiling to read off this key. What the endpoint *does* show: **`limit: 50` with `limit_reset: null`** — this key has a **$50 total spend cap, no listed reset date**, $0.51 used so far. At Sonnet-4.6 pricing ($3/M input, $15/M output) a tutoring turn costs ~$0.02; a single 30-student pilot session (~12 turns/student) costs ~$7.50 — several isolated pilot runs are fine, but **daily classroom use would exhaust the $50 cap in under a week**, and a cap hit reads as a simultaneous hard outage for every active student. **Action needed from Thane, not decided here:** raise the OpenRouter spend limit (or set a billing alert) before this moves past occasional pilot testing. This replaces the semaphore-sizing question Phase 0 originally asked — OpenRouter's real per-second throughput is dynamic/credit-scaled, not a fixed number this key exposes.
2. **Rate-limiter fix — decided 2026-07-09:** key the limiter on `learner_id` from the request body instead of remote IP. Needs a small custom `key_func`, since `slowapi`'s default only sees the raw request — more correct than raising the per-IP ceiling, and it's the option that actually solves the shared-school-IP scenario rather than just widening the window on it.
3. **VPS memory audit — done.** The "125MB free" issue isn't caused by the tutor app — **Neo4j is consuming 939MB (46.8%) of the box's 1.9GB RAM**, over 5x the tutor's own Python process (187MB). This is part of the mas-tutor stack (curriculum knowledge graph), not an unrelated process. Given this, a 2GB swapfile was added (`/swapfile`, persisted in `/etc/fstab`) before doing anything else memory-hungry — cheap, reversible, standard practice for a memory-thin box. Confirmed active and being used (339MB swapped after staging came up) without any service disruption.
4. **Staging copy — live on `:8081`.** One blocker found and worked around: the VPS disk was **95% full (502MB free)**, and a full duplicate venv (~500MB) wouldn't have fit — attempting it risked filling the disk during the copy, which could have broken SQLite writes, journald, or Neo4j on the *live* box. Staging instead **shares the existing production venv** (`/home/mas_app/mas_education_poc/.venv`) read-only — zero extra disk for packages, since Phases 0-4 don't change dependencies yet. Only the app code (~2MB, `syllabuses/` reference data excluded as build-time-only) and a corrected `.env` were copied. Staging's `CHROMA_PATH` points at the real ingested collection (`/home/mas_app/.pai/rag/chromadb`) from the start — the bug flagged in the executive summary is already fixed here, proving the fix before it reaches production. Verified live: `curl localhost:8081/health` → `{"status":"ok"}`, production `:8080` unaffected throughout (`200` before, during, and after). **Note for Phase 1:** once the async client conversion changes dependencies, staging will need its own venv — the shared-venv approach is a Phase 0-4 stopgap, not permanent.

### Phase 1 — Async client + LangGraph conversion (the core fix)

File-by-file:

| File | Change |
|---|---|
| `compat/openrouter_client.py` | `OpenAI(...)` → `AsyncOpenAI(...)`; `create()` becomes `async def create()`, `await self._client.chat.completions.create(...)` |
| `agents/tutor_agent.py` | The response-generation function becomes `async def`; `await client.messages.create(...)` |
| `agents/assessment_agent.py` | `score_response()` becomes `async def`; same `await` pattern |
| `rag/retrieve.py` | `_enhance_query()`, `_llm_rerank()`, `retrieve()` become `async def`. LLM calls get `await`. The `for variant in query_variants: collection.query(...)` loop — currently 4 **sequential** blocking calls — becomes `asyncio.gather(*[asyncio.to_thread(collection.query, query_texts=[v], ...) for v in query_variants])`, since ChromaDB's embedded client has no native async form (verified — `AsyncHttpClient` only exists for client/server mode, not `PersistentClient`). This is a real latency win independent of the concurrency fix: 4 sequential round-trips become 1 concurrent wait. |
| `orchestrator/poc_orchestrator.py` | Every node (`session_init`, `route_intent`, `tutoring_node`, `assessment_node`, `reflect_node`, `deliver_node`, `log_update_node`) becomes `async def` with `await` added at each call site. `graph.add_node(...)` wiring is unchanged — LangGraph accepts async node callables transparently. |
| `chat_ui.py` | `_invoke_orchestrator()`: replace `orchestrator.invoke(state)` with `await orchestrator.ainvoke(state)`. This is the actual fix for the asyncio conflict described in the existing code comment — `.ainvoke()` runs inside the already-active event loop instead of calling `asyncio.run()` internally, which is what `.invoke()` does and why it couldn't safely be awaited before. |

Convert node-by-node, running the existing test suite after each (`tests/unit/test_session.py`, `tests/unit/test_faq.py`, `tests/unit/test_validation.py`, `tests/integration/test_api.py` — 13 tests total covering session lifecycle, FAQ short-circuit, request validation, and API contract) as a regression safety net before moving to the next file.

**Not changing:** `db/db.py`'s synchronous `sqlite3.connect()` calls. At this scale (small local reads/writes per turn) these are fast enough not to matter, and SQLite's own write-serialization is a non-issue for a single process. Flagged as a Phase 4 contingency only if the load test shows contention — not a day-one requirement.

### Phase 2 — Concurrency safety controls

1. **`asyncio.Semaphore(N)`** wrapping the orchestrator call in `chat_ui.py`, where `N` is the number verified in Phase 0. This makes the app self-limit concurrent in-flight LLM calls to what the OpenRouter account can actually sustain, rather than firing all 30 at once and hoping. If `N < 30`, some requests queue briefly and safely — better than errors, but Thane should know the real number ahead of the pilot.
2. **Jitter on retry backoff** — add `random.uniform(0, 1)` to the existing `2 ** attempt` sleep, so a shared transient failure across many concurrent users doesn't cause synchronized retry storms.
3. **Rate-limiter fix** — implement the `learner_id`-keyed `key_func` decided in Phase 0.

### Phase 3 — RAG re-enable + parallelize (decided 2026-07-09: bundled into this pass, not a separate follow-up)

1. Fix `CHROMA_PATH` in the VPS `.env` to the real ingested path.
2. The `asyncio.gather` parallelization from Phase 1 already covers the 4-query-variant fan-out.
3. Re-measure latency budget with RAG active — this adds 2 more LLM calls per turn (HyDE enhance + Haiku rerank), now async and covered by the same semaphore, but this must be **measured under the Phase 4 load test**, not assumed safe just because it's async.
4. This restores the product's actual intended behavior — curriculum-grounded answers with citations — which is currently missing in production regardless of the speed question.

### Phase 4 — Load testing & validation

1. Write a small k6 (or locust) script simulating 30 concurrent virtual users, each opening a session and sending a short multi-turn conversation against `/chat`. Parameterize the target URL and payload — this is the one piece of this plan worth making generically reusable (see §7), since the same script works against any of the sibling deployments later with no code change.
2. Run it against the **staging** copy (Phase 0's port-8081 instance) first. The VPS only has 2GB RAM, so staging and a full 30-user load test should not run simultaneously with production traffic — schedule for a quiet window.
3. Capture P50/P95/P99 latency, HTTP error rate (5xx and 429 separately), and VPS memory/CPU during the run.
4. **Provisional acceptance target** (to validate against Phase 0's real OpenRouter ceiling, not treat as fixed): P95 turn latency under ~15s, zero unhandled 5xx errors, and any 429s attributable only to the *intentional* semaphore queueing, not the rate limiter rejecting legitimate students.
5. Iterate on the semaphore size / retry tuning based on what the numbers actually show.

### Phase 5 — Rollout & rollback

1. Deploy the async version as a new systemd service (`mas-tutor-async.service`) on the Phase 0 staging port, smoke-test manually.
2. Cut Caddy's reverse-proxy target from `:8080` to the new service's port during a low-traffic window.
3. Keep the current `mas-tutor.service` (untouched, still sync) stopped-but-present for at least a week — instant rollback is `systemctl stop mas-tutor-async && systemctl start mas-tutor`.
4. Monitor the first real 30-concurrent-user session closely, with the rollback command ready in an open terminal.

---

## 6. Risks & Mitigations

| Risk | Mitigation |
|---|---|
| One node's async conversion has a subtle bug and re-blocks the loop | Convert and test node-by-node against the existing 13-test suite before moving to the next file |
| ChromaDB embedded client has no native async — `asyncio.to_thread` wrapping needed | Confirmed via research this is expected (only `AsyncHttpClient`, for client/server mode, is native); default thread pool sizing should be checked against this VPS's 2 vCPUs during Phase 4, not assumed |
| OpenRouter/Anthropic account ceiling is below 30 concurrent | Semaphore caps effective throughput safely; real number must come from Phase 0, not be discovered live during the pilot |
| VPS memory is already thin (125MB free at idle) independent of this feature | Phase 0 explicitly audits this before load testing, so a pre-existing issue isn't misattributed to the concurrency fix |
| Retry storm if OpenRouter itself degrades under load | Jitter + semaphore reduce this but don't eliminate it; true circuit-breaker resilience is out of scope for this plan (see §7) |
| Rate limiter blocks legitimate students during the actual pilot | Fixed in Phase 2, verified in Phase 4's load test before the real pilot, not assumed fixed |
| RAG re-enable is bundled into the same Phase 5 rollout as the async conversion — a post-deploy regression is harder to attribute to one change or the other | Load test (Phase 4) exercises both together before rollout, so the combined behavior is proven pre-launch; no independent kill-switch exists for RAG alone today, so if Phase 5 monitoring shows an issue, rollback is to the whole `mas-tutor-async.service` (per §5 Phase 5), not a partial toggle |

---

## 7. Explicitly Out of Scope

- **Multi-VPS / load balancer / managed database migration.** Not justified by the numbers gathered — this is a 30-user classroom-scale target, not a public-internet-scale one.
- **A shared "async framework" across the wider POC family** (sons-personal-tutor, sa-education-platform, future Cambridge POCs). Considered directly via aperture oscillation (tactical vs. strategic scope) during this planning session: the code fix stays scoped to mas-tutor only. The one piece worth making portable is the Phase 4 load-test script (parameterized URL/payload, effectively free to generalize) — not the async code itself, which hasn't been proven in production yet and would be premature abstraction ahead of that proof. This also respects the current PROJECTS.md STOP-list constraint ("new tool/platform evaluations... stopped unless serving an active flagship").
- **Circuit-breaker-grade resilience engineering.** Noted as a possible future item if the pilot reveals it's actually needed — not required to hit the 30-user target.

**Related flag, not a task:** `sons-personal-tutor` is a direct fork of this exact stack and carries the identical sync-client-in-async-handler pattern. It would hit the same bug under concurrent family use (e.g. both boys using it at once). No action is proposed here — flagging only, since this plan is deliberately scoped to mas-tutor.

---

## 8. Definition of Done

- [ ] All 13 existing unit/integration tests pass against the async code path.
- [ ] Load test: 30 simulated concurrent users, each completing a multi-turn conversation, run against staging — P95 latency, error rate, and VPS resource usage captured and shared before any go/no-go decision.
- [ ] No process-based multi-worker scaling introduced (single async process, per the SQLite-safety finding in §3).
- [ ] Rollback path tested, not just documented — confirm the old service actually restarts cleanly within a defined window (target: under 60 seconds).
- [ ] `CHROMA_PATH` fix verified live — a real response shows non-empty `citations` (if Phase 3 is included).
- [ ] Rate-limiter fix verified — a simulated burst from one IP with 30 distinct `learner_id`s does not produce spurious 429s.

---

## 9. Effort Estimate

| Phase | Estimate |
|---|---|
| 0 — Prerequisites & staging | 0.5 day |
| 1 — Async conversion | 1–1.5 days |
| 2 — Concurrency controls | 0.5 day |
| 3 — RAG re-enable (recommended) | 0.5 day |
| 4 — Load testing | 0.5–1 day |
| 5 — Rollout & monitored pilot | 0.5 day + monitored window |
| **Total** | **~3.5–4.5 working days** |

---

## 10. Open Decisions for Review

1. ~~Rate-limiter fix: per-`learner_id` key vs. raised per-IP ceiling?~~ **Decided 2026-07-09: per-`learner_id` key.**
2. ~~Include Phase 3 (RAG re-enable) in this same pass, or ship separately?~~ **Decided 2026-07-09: bundled into this pass.** (Trade-off accepted: harder to isolate cause if a Phase 5 regression appears — see §6.)
3. **Still open — deferred, not decidable yet:** confirm the provisional P95/error-rate acceptance target in §5 Phase 4 once Phase 0's real OpenRouter ceiling is known — it may need adjusting. This can only be answered after Phase 0 runs.

**Decisions 1 and 2 are final. Nothing below this line has been implemented. Phase 0 has not started — awaiting go-ahead.**
