# MAS Education POC — Eval Baseline

**Date:** 2026-06-19  
**Approach:** Eval-driven agent development (ai-engineering-from-scratch P14-L30)  
**Commitment:** No MAS tutor improvement ships without delta measurement against this baseline.

---

## Baseline Summary

| Metric | Status | Baseline Value |
|--------|--------|----------------|
| M1: Mastery signal accuracy | NOT YET BASELINED | Needs post-session test mechanism |
| M2: Topic routing precision | 🔄 LOGGING LIVE | Pull 20-turn sample from VPS log — human review pending |
| M3: Distress detection recall | 🔄 LOGGING LIVE | Pull 20-turn sample from VPS log — human review pending |
| M4: Session completion rate | 🔄 LOGGING LIVE | session_start/session_end now logged — accumulate data |
| M5: Response latency P95 | ✅ BASELINED | 6,279ms (dev) → 6,837ms (first prod turn 2026-06-19) |

**Update 2026-06-19:** Log enrichment deployed to VPS. `topic`, `mastery`, `engagement_state` now captured per turn. Session lifecycle events (`session_start`, `session_end` with reason) now logged. M2, M3, M4 can be baselined once ≥20 production turns accumulate. Pull VPS log to compute: `scp root@51.15.38.155:/home/mas_app/mas_education_poc/chat_ui.log ./evals/vps-log-YYYYMMDD.jsonl`

---

## Metric Definitions

### M1: Mastery Signal Accuracy

**Definition:** The percentage of topic-mastery declarations by the agent that are correct — i.e., the learner demonstrated genuine mastery, not just pattern-matching.

**Rationale:** The agent declares mastery when `mastery ≥ 0.85`. This metric checks whether that declaration corresponds to actual learner competence.

**Measurement method:**
1. Identify sessions where `mastery` field reached 0.85 on a topic
2. Administer a 5-question cold test on that topic at the next session start
3. Accuracy = % of mastery declarations followed by ≥80% cold test score

**Target threshold:** ≥70% accuracy (mastery declaration is correct in 7/10 cases)

**Baseline value:** `NOT YET BASELINED`

**Why not baselined:** Requires a post-session test mechanism that does not currently exist. Proxy baseline option: track "did learner return to same topic in next session?" as a weak signal.

**Logging needed:** Session lifecycle events (`session_start`, `session_end` with reason: `mastery_achieved | timeout | user_exit`), plus per-topic mastery history.

---

### M2: Topic Routing Precision

**Definition:** The percentage of learner messages that are correctly routed to the appropriate Knowledge Graph topic node.

**Rationale:** The Keyword Topic Routing (Improvement I2) routes messages based on detected keywords. Incorrect routing assigns learner to wrong topic, wasting turns.

**Measurement method:**
1. Sample 20 conversations from production logs (Tailscale access to VPS)
2. For each turn: human reviewer classifies the "correct" topic based on message content
3. Compare to `topic` field in the log
4. Precision = matched / total

**Target threshold:** ≥85% precision on human review sample

**Baseline value:** `NOT YET BASELINED`

**Why not baselined:** `topic` field is returned in `ChatResponse` but NOT currently captured in `chat_ui.log`. Only `latency_ms`, `learner_id`, and `turn` are logged per turn.

**Logging needed:** Add `"topic": result["current_topic"]` to the JSON log entry at line 448 in `chat_ui.py`.

```python
# chat_ui.py line 448 — add topic, mastery, engagement_state to log
_json_logger.info(json.dumps({
    "ts": datetime.utcnow().isoformat(),
    "learner_id": req.learner_id,
    "turn": session["turn_count"],
    "latency_ms": latency_ms,
    "topic": result["current_topic"],          # ADD THIS
    "mastery": round(result.get("mastery", 0.0), 3),   # ADD THIS
    "engagement_state": result["engagement_state"],     # ADD THIS
    "tokens_in": 0,
    "tokens_out": 0,
}))
```

---

### M3: Distress Detection Recall

**Definition:** The percentage of learner messages expressing confusion or frustration that correctly triggered the Distress Triage (Improvement I5).

**Rationale:** Missed distress signals leave struggling learners without appropriate support. High recall is a learner welfare metric.

**Measurement method:**
1. Sample 20 conversations from production logs
2. For each turn: human reviewer labels whether the message expressed distress
3. Check whether `engagement_state` for that turn was `"distressed"` or equivalent
4. Recall = correct distress detections / total actual distress messages

**Target threshold:** ≥75% recall (missing 1 in 4 distress signals is the maximum acceptable miss rate)

**Baseline value:** `NOT YET BASELINED`

**Why not baselined:** `engagement_state` is returned in `ChatResponse` but not logged. Production log does not exist locally (only 5 dev turns from 2026-06-13). VPS log required.

**Logging needed:** Same as M2 — add `engagement_state` to JSON log (see code above).

---

### M4: Session Completion Rate

**Definition:** The percentage of sessions that reach a natural conclusion (mastery achieved or explicit farewell) rather than timing out.

**Rationale:** A high timeout rate suggests learners are disengaging before completing a topic — an experience quality signal.

**Measurement method:**
1. Pull session records: `total_sessions` from `/admin/metrics` at session end
2. Track session endings: timeout (30min TTL) vs natural end (mastery=0.85, 'summary' keyword)
3. Completion rate = natural endings / total sessions

**Target threshold:** ≥60% completion (majority of sessions end naturally)

**Baseline value:** `NOT YET BASELINED`

**Why not baselined:** Session lifecycle events are not logged. `cleanup_stale_sessions_sync()` removes sessions without logging whether they timed out vs ended naturally.

**Logging needed:** Add logging to session lifecycle:
```python
# When mastery achieved (in orchestrator)
_json_logger.info(json.dumps({"event": "session_end", "reason": "mastery_achieved", "learner_id": learner_id, "ts": ...}))

# When timeout cleanup runs
_json_logger.info(json.dumps({"event": "session_end", "reason": "timeout", "learner_id": k, "ts": ...}))
```

---

### M5: Response Latency P95

**Definition:** The 95th percentile end-to-end response time in milliseconds, measured from request receipt to first response byte.

**Rationale:** Learner experience degrades sharply above 8,000ms. This is the only fully automated metric currently measurable from existing logs.

**Measurement method:**
```bash
grep '{"ts"' ~/projects/mas_education_poc/chat_ui.log \
  | python3 -c "
import json, sys
rows = [json.loads(l) for l in sys.stdin]
lats = sorted(r['latency_ms'] for r in rows)
p95 = lats[int(len(lats)*0.95)]
print(f'P95: {p95}ms (n={len(rows)})')
"
```

**Target threshold:** P95 ≤ 8,000ms (at full production load)

**Baseline value:** **6,279ms** (P95 from 5 dev turns, 2026-06-13, local environment)

**Caveats:** 5 data points from dev testing only. Production P95 will differ — local runs include model cold-start overhead that production doesn't. Pull production baseline from VPS once log enrichment is deployed: `scp root@51.15.38.155:/path/to/chat_ui.log ./evals/vps-log-2026-06.jsonl`.

---

## Logging Gaps — Action Required Before Sprints 3–4

The following fields must be added to `chat_ui.py` (line 448 JSON log) before M1–M4 can be baselined:

| Field | Variable | Source |
|-------|----------|--------|
| `topic` | `result["current_topic"]` | orchestrator result |
| `mastery` | `result.get("mastery", 0.0)` | orchestrator result |
| `engagement_state` | `result["engagement_state"]` | orchestrator result |

Session lifecycle logging (session start/end with reason) requires 3 additional log calls in `get_or_create_session()` and `cleanup_stale_sessions_sync()`.

**This is a prerequisite for Sprint 4 (observability implementation).** Langfuse/Phoenix can only surface metrics that exist in the log.

---

## How to Re-Baseline After a Change

After any MAS tutor improvement is deployed:

1. Pull the VPS log: `scp root@51.15.38.155:~/mas-tutor/chat_ui.log ./evals/post-<change-name>.jsonl`
2. Re-run M5 (latency) using the bash command above against the new log
3. For M1–M4 (once logging enrichment is deployed): run the human review sample for M2 and M3 (20 turns each)
4. Record delta in `evals/delta-log.md`
5. If any metric regresses beyond threshold: revert the change

---

*Baseline document generated 2026-06-19 · Implements R1 from AI Engineering Implementation Plan · Next action: add 3 log fields to chat_ui.py, then pull VPS production log for true baseline.*
