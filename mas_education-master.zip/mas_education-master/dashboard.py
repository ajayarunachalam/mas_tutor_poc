"""
MAS Education POC — Learning Progress Dashboard
FastAPI router mounted on the main chat_ui app.

Serves:
  GET /dashboard          — dashboard HTML page
  GET /api/dashboard/{id} — JSON data for a learner

Audience: learners, parents, teachers.
"""
from __future__ import annotations

import os
from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse

from db.kg import kg_session

router = APIRouter()


# ── Data helpers ───────────────────────────────────────────────────────────────

def _get_overview(learner_id: str) -> dict:
    """Overall mastery stats for a learner across all LOs."""
    cypher = """
        MATCH (lo:LearningObjective)
        OPTIONAL MATCH (l:Learner {id: $lid})-[m:HAS_MASTERY]->(lo)
        WITH
            count(lo) AS total,
            sum(CASE WHEN m IS NOT NULL AND m.mastered = true  THEN 1 ELSE 0 END) AS mastered,
            sum(CASE WHEN m IS NOT NULL AND m.mastered = false THEN 1 ELSE 0 END) AS in_progress
        RETURN total, mastered, in_progress
    """
    try:
        with kg_session() as session:
            r = session.run(cypher, lid=learner_id).single()
    except Exception:
        return {"total": 0, "mastered": 0, "in_progress": 0, "not_started": 0, "pct": 0.0}

    if r is None:
        return {"total": 0, "mastered": 0, "in_progress": 0, "not_started": 0, "pct": 0.0}

    total       = r["total"]       or 0
    mastered    = r["mastered"]    or 0
    in_progress = r["in_progress"] or 0
    return {
        "total":       total,
        "mastered":    mastered,
        "in_progress": in_progress,
        "not_started": total - mastered - in_progress,
        "pct":         round(mastered / total * 100, 1) if total else 0.0,
    }


def _get_topics(learner_id: str) -> list[dict]:
    """Per-topic mastery aggregation for a learner."""
    cypher = """
        MATCH (q:Qualification)-[:HAS_TOPIC]->(t:Topic)
              -[:HAS_SUBTOPIC]->(st:Subtopic)-[:HAS_LO]->(lo:LearningObjective)
        OPTIONAL MATCH (l:Learner {id: $lid})-[m:HAS_MASTERY]->(lo)
        WITH q, t,
            count(lo)  AS total,
            sum(CASE WHEN m IS NOT NULL AND m.mastered = true  THEN 1 ELSE 0 END) AS mastered,
            sum(CASE WHEN m IS NOT NULL AND m.mastered = false THEN 1 ELSE 0 END) AS in_progress,
            avg(COALESCE(m.p_mastery, 0.0)) AS avg_mastery
        RETURN
            t.id           AS topic_id,
            t.name         AS topic_name,
            t.order        AS topic_order,
            q.code         AS qual_code,
            q.name         AS qual_name,
            total, mastered, in_progress, avg_mastery
        ORDER BY q.code, t.order
    """
    try:
        with kg_session() as session:
            rows = list(session.run(cypher, lid=learner_id))
    except Exception:
        return []

    topics = []
    for r in rows:
        total       = r["total"]       or 0
        mastered    = r["mastered"]    or 0
        in_progress = r["in_progress"] or 0
        avg_mastery = float(r["avg_mastery"] or 0.0)
        pct = round(mastered / total * 100, 1) if total else 0.0

        if mastered == total and total > 0:
            status = "mastered"
        elif mastered > 0 or in_progress > 0:
            status = "in_progress"
        else:
            status = "not_started"

        topics.append({
            "topic_id":    r["topic_id"],
            "topic_name":  r["topic_name"],
            "topic_order": r["topic_order"] or 0,
            "qual_code":   r["qual_code"],
            "qual_name":   r["qual_name"],
            "total":       total,
            "mastered":    mastered,
            "in_progress": in_progress,
            "not_started": total - mastered - in_progress,
            "avg_mastery": round(avg_mastery * 100, 1),
            "pct":         pct,
            "status":      status,
        })
    return topics


def _get_graph(topics: list[dict]) -> dict:
    """Build Cytoscape-compatible nodes and edges for the curriculum knowledge map."""
    nodes: list[dict] = []
    edges: list[dict] = []
    seen_quals: set[str] = set()

    # Qualification parent nodes
    for t in topics:
        qc = t["qual_code"]
        if qc not in seen_quals:
            seen_quals.add(qc)
            nodes.append({"data": {
                "id":        f"qual_{qc}",
                "label":     qc,
                "full_name": t["qual_name"],
                "type":      "qualification",
            }})

    # Topic nodes + qual→topic edges
    for t in topics:
        nodes.append({"data": {
            "id":          t["topic_id"],
            "label":       t["topic_name"],
            "type":        "topic",
            "qual_code":   t["qual_code"],
            "total":       t["total"],
            "mastered":    t["mastered"],
            "in_progress": t["in_progress"],
            "pct":         t["pct"],
            "avg_mastery": t["avg_mastery"],
            "status":      t["status"],
        }})
        edges.append({"data": {
            "id":     f"ht_{t['qual_code']}_{t['topic_id']}",
            "source": f"qual_{t['qual_code']}",
            "target": t["topic_id"],
            "type":   "has_topic",
        }})

    # Cross-topic prerequisite edges (topic-level aggregation)
    prereq_cypher = """
        MATCH (t1:Topic)-[:HAS_SUBTOPIC]->(:Subtopic)-[:HAS_LO]->(lo1:LearningObjective)
              -[:PREREQUISITE_OF]->
              (lo2:LearningObjective)<-[:HAS_LO]-(:Subtopic)<-[:HAS_SUBTOPIC]-(t2:Topic)
        WHERE t1.id <> t2.id
        RETURN DISTINCT t1.id AS from_id, t2.id AS to_id
        LIMIT 100
    """
    try:
        with kg_session() as session:
            for r in session.run(prereq_cypher):
                edge_id = f"prereq_{r['from_id']}_{r['to_id']}"
                # Avoid duplicate edges
                if not any(e["data"]["id"] == edge_id for e in edges):
                    edges.append({"data": {
                        "id":     edge_id,
                        "source": r["from_id"],
                        "target": r["to_id"],
                        "type":   "prerequisite",
                    }})
    except Exception:
        pass  # Cross-topic prereqs are optional — dashboard still works without them

    return {"nodes": nodes, "edges": edges}


def _get_next_los(learner_id: str) -> list[dict]:
    """Return up to 5 recommended next LOs (lowest difficulty, prerequisites met)."""
    cypher = """
        MATCH (q:Qualification)-[:HAS_TOPIC]->(t:Topic)-[:HAS_SUBTOPIC]->(st:Subtopic)-[:HAS_LO]->(lo:LearningObjective)
        WHERE NOT EXISTS {
            MATCH (:Learner {id: $lid})-[:HAS_MASTERY {mastered: true}]->(lo)
        }
        AND ALL(prereq IN [(lo)<-[:PREREQUISITE_OF {strength: "hard"}]-(p) | p]
            WHERE EXISTS {
                MATCH (:Learner {id: $lid})-[:HAS_MASTERY {mastered: true}]->(prereq)
            })
        OPTIONAL MATCH (l:Learner {id: $lid})-[m:HAS_MASTERY]->(lo)
        RETURN
            lo.id          AS lo_id,
            lo.text        AS lo_text,
            lo.difficulty  AS difficulty,
            t.name         AS topic,
            st.name        AS subtopic,
            q.code         AS qual_code,
            COALESCE(m.p_mastery, 0.0) AS mastery
        ORDER BY lo.difficulty ASC
        LIMIT 5
    """
    try:
        with kg_session() as session:
            return [
                {
                    "lo_id":      r["lo_id"],
                    "lo_text":    r["lo_text"],
                    "difficulty": r["difficulty"] or 1,
                    "topic":      r["topic"],
                    "subtopic":   r["subtopic"],
                    "qual_code":  r["qual_code"],
                    "mastery":    round(float(r["mastery"] or 0.0) * 100, 1),
                }
                for r in session.run(cypher, lid=learner_id)
            ]
    except Exception:
        return []


def _get_qualifications() -> list[dict]:
    """Return all distinct qualifications with LO counts."""
    cypher = """
        MATCH (q:Qualification)-[:HAS_TOPIC]->(:Topic)-[:HAS_SUBTOPIC]->(:Subtopic)-[:HAS_LO]->(lo:LearningObjective)
        WITH DISTINCT q.code AS code, q.name AS name, count(DISTINCT lo) AS lo_count
        RETURN code, name, lo_count
        ORDER BY code
    """
    try:
        with kg_session() as session:
            return [
                {"code": r["code"], "name": r["name"], "lo_count": r["lo_count"]}
                for r in session.run(cypher)
            ]
    except Exception:
        return []


def _get_learners() -> list[str]:
    """Return all known Learner node IDs from Neo4j."""
    try:
        with kg_session() as session:
            result = session.run("MATCH (l:Learner) RETURN l.id AS id ORDER BY l.id")
            ids = [r["id"] for r in result]
        return ids if ids else ["demo-student-001"]
    except Exception:
        return ["demo-student-001"]


def _get_knowledge_map(learner_id: str) -> list[dict]:
    """
    Build Domain→Branch→Area→Concept hierarchy with derived learner mastery.
    Mastery is derived at query time from LO→TEACHES→ConceptInstance→INSTANCE_OF→Concept.
    """
    cypher = """
        MATCH (d:Domain)-[:HAS_BRANCH]->(b:Branch)-[:HAS_AREA]->(a:Area)-[:HAS_CONCEPT]->(c:Concept)
        OPTIONAL MATCH (l:Learner {id: $lid})-[m:HAS_MASTERY]->(lo:LearningObjective)
                       -[:TEACHES]->(ci:ConceptInstance)-[:INSTANCE_OF]->(c)
        WITH d, b, a, c,
             avg(m.p_mastery) AS avg_mastery,
             count(lo)        AS lo_count
        RETURN
            d.id   AS domain_id,   d.name AS domain_name,
            b.id   AS branch_id,   b.name AS branch_name,
            a.id   AS area_id,     a.name AS area_name,
            c.id   AS concept_id,  c.name AS concept_name,
            avg_mastery, lo_count
        ORDER BY d.name, b.name, a.name, c.name
    """
    try:
        with kg_session() as session:
            rows = list(session.run(cypher, lid=learner_id))
    except Exception:
        return []

    # Build nested structure
    domains: dict[str, dict] = {}
    for r in rows:
        did = r["domain_id"]
        if did not in domains:
            domains[did] = {"id": did, "name": r["domain_name"], "branches": {}}

        bid = r["branch_id"]
        if bid not in domains[did]["branches"]:
            domains[did]["branches"][bid] = {"id": bid, "name": r["branch_name"], "areas": {}}

        aid = r["area_id"]
        if aid not in domains[did]["branches"][bid]["areas"]:
            domains[did]["branches"][bid]["areas"][aid] = {
                "id": aid, "name": r["area_name"], "concepts": []
            }

        mastery = float(r["avg_mastery"]) if r["avg_mastery"] is not None else None
        domains[did]["branches"][bid]["areas"][aid]["concepts"].append({
            "id":          r["concept_id"],
            "name":        r["concept_name"],
            "avg_mastery": round(mastery, 3) if mastery is not None else None,
            "lo_count":    r["lo_count"] or 0,
        })

    # Compute area-level avg_mastery and flatten to list
    result = []
    for d in domains.values():
        branches = []
        for b in d["branches"].values():
            areas = []
            for a in b["areas"].values():
                concept_masteries = [c["avg_mastery"] for c in a["concepts"] if c["avg_mastery"] is not None]
                area_mastery = sum(concept_masteries) / len(concept_masteries) if concept_masteries else None
                areas.append({
                    "id":          a["id"],
                    "name":        a["name"],
                    "avg_mastery": round(area_mastery, 3) if area_mastery is not None else None,
                    "concepts":    a["concepts"],
                })
            branches.append({"id": b["id"], "name": b["name"], "areas": areas})
        result.append({"id": d["id"], "name": d["name"], "branches": branches})

    return result


def _get_concept_qualifications(concept_id: str) -> list[dict]:
    """Return all qualifications that teach a given Concept, with depth info."""
    cypher = """
        MATCH (c:Concept {id: $concept_id})
        MATCH (ci:ConceptInstance)-[:INSTANCE_OF]->(c)
        MATCH (ci)-[:AT_LEVEL]->(q:Qualification)
        RETURN q.code AS code, q.name AS name, q.syllabus_year AS year,
               ci.depth AS depth
        ORDER BY ci.depth, q.code, q.syllabus_year
    """
    try:
        with kg_session() as session:
            rows = list(session.run(cypher, concept_id=concept_id))
        return [{"code": r["code"], "name": r["name"], "year": r["year"], "depth": r["depth"]} for r in rows]
    except Exception:
        return []


# ── Endpoints ──────────────────────────────────────────────────────────────────

@router.get("/api/health")
async def health_check():
    """Health check — verifies Neo4j and ChromaDB are reachable."""
    status = "ok"
    http_status = 200

    # Check Neo4j
    neo4j_status = "ok"
    neo4j_lo_count = 0
    try:
        with kg_session() as session:
            r = session.run("MATCH (lo:LearningObjective) RETURN count(lo) AS n").single()
            neo4j_lo_count = r["n"] if r else 0
    except Exception as e:
        neo4j_status = f"error: {e}"
        status = "degraded"
        http_status = 503

    # Check ChromaDB
    chromadb_chunks = 0
    chromadb_status = "ok"
    try:
        chroma_path = os.getenv("CHROMA_PATH")
        if chroma_path:
            import chromadb as _chromadb
            client = _chromadb.PersistentClient(path=chroma_path)
            collection_name = os.getenv("CHROMA_COLLECTION", "poc_curriculum")
            col = client.get_collection(collection_name)
            chromadb_chunks = col.count()
        else:
            chromadb_status = "error: CHROMA_PATH not set"
            status = "degraded"
    except Exception as e:
        chromadb_status = f"error: {e}"
        status = "degraded"

    payload = {
        "status":    status,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "neo4j": {
            "status":   neo4j_status,
            "lo_count": neo4j_lo_count,
        },
        "chromadb": {
            "status": chromadb_status,
            "chunks": chromadb_chunks,
        },
    }
    return JSONResponse(content=payload, status_code=http_status)


@router.post("/api/learner/{learner_id}", status_code=201)
async def create_learner(learner_id: str):
    """Create a new Learner node in Neo4j (MERGE — idempotent)."""
    if not learner_id or len(learner_id) > 64:
        raise HTTPException(status_code=400, detail="learner_id must be 1–64 characters")
    try:
        with kg_session() as session:
            session.run(
                "MERGE (l:Learner {id: $id}) ON CREATE SET l.created = datetime()",
                id=learner_id,
            )
        return JSONResponse({"learner_id": learner_id, "status": "created"}, status_code=201)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/dashboard", response_class=HTMLResponse)
async def dashboard_page():
    """Serve the learning progress dashboard."""
    return HTMLResponse(content=DASHBOARD_HTML)


@router.get("/api/dashboard/{learner_id}/knowledge-map")
async def knowledge_map_data(learner_id: str):
    """Return Domain→Branch→Area→Concept hierarchy with derived mastery."""
    domains = _get_knowledge_map(learner_id)
    return JSONResponse({"learner_id": learner_id, "domains": domains})


@router.get("/api/concept/{concept_id}")
async def concept_detail(concept_id: str):
    """Return cross-qualification data for a specific Concept."""
    quals = _get_concept_qualifications(concept_id)
    return JSONResponse({"concept_id": concept_id, "qualifications": quals})


@router.get("/api/dashboard/{learner_id}")
async def dashboard_data(learner_id: str):
    """Return all dashboard data for a learner as JSON."""
    topics         = _get_topics(learner_id)
    overview       = _get_overview(learner_id)
    graph          = _get_graph(topics)
    next_los       = _get_next_los(learner_id)
    learners       = _get_learners()
    qualifications = _get_qualifications()
    return JSONResponse({
        "learner_id":    learner_id,
        "overview":      overview,
        "topics":        topics,
        "graph":         graph,
        "next_los":      next_los,
        "learners":      learners,
        "qualifications": qualifications,
    })


# ── Dashboard HTML ─────────────────────────────────────────────────────────────

DASHBOARD_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Learning Progress Dashboard — MAS Education</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/cytoscape/3.29.2/cytoscape.min.js"></script>
<style>
* { box-sizing: border-box; margin: 0; padding: 0; }
body {
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
  background: #f0f4f8; min-height: 100vh; color: #1e293b;
}

/* ── Header ── */
header {
  background: #1e40af; color: white; padding: 14px 24px;
  display: flex; align-items: center; justify-content: space-between;
  box-shadow: 0 2px 8px rgba(0,0,0,0.2); position: sticky; top: 0; z-index: 100;
}
header h1 { font-size: 1.05rem; font-weight: 700; letter-spacing: 0.02em; }
.header-right { display: flex; align-items: center; gap: 16px; }
.learner-label { font-size: 0.8rem; color: #93c5fd; }
.learner-select {
  background: rgba(255,255,255,0.12); color: white;
  border: 1px solid rgba(255,255,255,0.3); border-radius: 6px;
  padding: 5px 10px; font-size: 0.82rem; cursor: pointer; outline: none;
}
.learner-select option { background: #1e3a8a; color: white; }
.nav-link {
  color: #93c5fd; font-size: 0.82rem; text-decoration: none;
  padding: 5px 10px; border: 1px solid rgba(255,255,255,0.2); border-radius: 6px;
  transition: background 0.15s;
}
.nav-link:hover { background: rgba(255,255,255,0.1); color: white; }

/* ── Layout ── */
.container { max-width: 1440px; margin: 0 auto; padding: 20px 24px; }

/* ── Stat cards ── */
.stats-grid {
  display: grid; grid-template-columns: repeat(4, 1fr); gap: 14px;
  margin-bottom: 18px;
}
.stat-card {
  background: white; border-radius: 12px; padding: 18px 20px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.08);
  border-top: 3px solid #e2e8f0;
  display: flex; flex-direction: column; gap: 4px;
}
.stat-card.c-mastered    { border-top-color: #22c55e; }
.stat-card.c-progress    { border-top-color: #f59e0b; }
.stat-card.c-remaining   { border-top-color: #94a3b8; }
.stat-card.c-overall     { border-top-color: #3b82f6; }
.stat-label { font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.07em; color: #64748b; font-weight: 600; }
.stat-value { font-size: 2rem; font-weight: 800; color: #0f172a; line-height: 1.1; }
.stat-sub   { font-size: 0.75rem; color: #94a3b8; }

/* ── Overall progress bar ── */
.overall-bar-wrap { margin-bottom: 18px; background: white; border-radius: 12px; padding: 14px 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.08); }
.overall-bar-label { font-size: 0.8rem; font-weight: 600; color: #475569; margin-bottom: 8px; display: flex; justify-content: space-between; }
.overall-bar-bg { height: 10px; background: #f1f5f9; border-radius: 5px; overflow: hidden; }
.overall-bar-fill { height: 100%; background: linear-gradient(90deg, #22c55e, #3b82f6); border-radius: 5px; transition: width 0.8s ease; }

/* ── Two-column layout ── */
.main-grid { display: grid; grid-template-columns: 56% 44%; gap: 16px; margin-bottom: 18px; }
.panel { background: white; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.08); overflow: hidden; display: flex; flex-direction: column; }
.panel-header {
  padding: 14px 20px; border-bottom: 1px solid #f1f5f9;
  display: flex; align-items: center; justify-content: space-between; flex-shrink: 0;
}
.panel-title { font-size: 0.88rem; font-weight: 700; color: #1e293b; }
.panel-sub   { font-size: 0.72rem; color: #94a3b8; }

/* ── Graph ── */
.graph-legend {
  padding: 8px 20px 0; display: flex; gap: 14px; flex-wrap: wrap;
  font-size: 0.72rem; color: #64748b; flex-shrink: 0;
}
.legend-item { display: flex; align-items: center; gap: 5px; }
.legend-dot  { width: 9px; height: 9px; border-radius: 50%; flex-shrink: 0; }
.legend-line { width: 16px; height: 2px; border-top: 2px dashed #f97316; }
#cy { width: 100%; height: 430px; flex: 1; min-height: 0; }
.btn-reset {
  background: none; border: 1px solid #e2e8f0; border-radius: 6px;
  padding: 4px 10px; font-size: 0.72rem; color: #64748b; cursor: pointer;
}
.btn-reset:hover { background: #f8fafc; }

/* ── Tooltip ── */
#tooltip {
  position: fixed; background: #0f172a; color: white;
  padding: 9px 13px; border-radius: 8px; font-size: 0.78rem;
  pointer-events: none; display: none; z-index: 9999;
  box-shadow: 0 4px 16px rgba(0,0,0,0.35); max-width: 220px; line-height: 1.5;
}
#tooltip .tt-name { font-weight: 700; margin-bottom: 3px; color: #e2e8f0; }
#tooltip .tt-qual  { color: #60a5fa; font-size: 0.72rem; margin-bottom: 4px; }
#tooltip .tt-stat  { color: #94a3b8; }
#tooltip .tt-stat span { color: #86efac; font-weight: 600; }

/* ── Topic list ── */
.topic-list { overflow-y: auto; flex: 1; min-height: 0; max-height: 510px; }
.topic-item {
  padding: 11px 20px; border-bottom: 1px solid #f8fafc;
  cursor: pointer; transition: background 0.12s;
}
.topic-item:last-child { border-bottom: none; }
.topic-item:hover      { background: #f8fafc; }
.topic-item.highlighted { background: #eff6ff; border-left: 3px solid #3b82f6; padding-left: 17px; }
.topic-qual-tag { font-size: 0.68rem; color: #94a3b8; margin-bottom: 3px; font-weight: 500; }
.topic-row { display: flex; align-items: center; justify-content: space-between; margin-bottom: 6px; }
.topic-name { font-size: 0.83rem; font-weight: 600; color: #1e293b; }
.topic-badge {
  font-size: 0.67rem; padding: 2px 7px; border-radius: 10px; font-weight: 600; flex-shrink: 0;
}
.badge-mastered    { background: #dcfce7; color: #15803d; }
.badge-in_progress { background: #fef9c3; color: #92400e; }
.badge-not_started { background: #f1f5f9; color: #64748b; }
.progress-row { display: flex; align-items: center; gap: 8px; }
.progress-bg { flex: 1; height: 5px; background: #f1f5f9; border-radius: 3px; overflow: hidden; display: flex; }
.progress-seg { height: 100%; transition: width 0.5s ease; }
.seg-mastered    { background: #22c55e; }
.seg-in_progress { background: #f59e0b; }
.topic-count { font-size: 0.7rem; color: #94a3b8; white-space: nowrap; }

/* ── What's Next ── */
.next-section {
  background: white; border-radius: 12px; padding: 20px 24px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.08); margin-bottom: 8px;
}
.next-header {
  font-size: 0.88rem; font-weight: 700; color: #1e293b; margin-bottom: 14px;
  display: flex; align-items: center; gap: 8px;
}
.next-header-icon { font-size: 1rem; }
.next-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 12px; }
.next-card {
  border: 1px solid #e2e8f0; border-radius: 10px; padding: 14px;
  transition: border-color 0.15s, box-shadow 0.15s;
}
.next-card:hover { border-color: #3b82f6; box-shadow: 0 2px 8px rgba(59,130,246,0.12); }
.next-breadcrumb { font-size: 0.68rem; color: #3b82f6; font-weight: 600; text-transform: uppercase; letter-spacing: 0.04em; margin-bottom: 5px; }
.next-lo-text { font-size: 0.82rem; color: #1e293b; line-height: 1.45; margin-bottom: 9px; }
.next-meta { display: flex; align-items: center; gap: 10px; font-size: 0.7rem; color: #94a3b8; }
.diff-stars { color: #f59e0b; letter-spacing: -1px; font-size: 0.8rem; }
.mastery-mini-wrap { display: flex; align-items: center; gap: 4px; }
.mastery-mini-bg   { width: 40px; height: 4px; background: #f1f5f9; border-radius: 2px; overflow: hidden; }
.mastery-mini-fill { height: 100%; background: #3b82f6; border-radius: 2px; }

/* ── Loading ── */
.loading { display: flex; align-items: center; justify-content: center; padding: 40px; color: #94a3b8; gap: 10px; }
.spinner { width: 22px; height: 22px; border: 3px solid #e2e8f0; border-top-color: #3b82f6; border-radius: 50%; animation: spin 0.75s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }

.error-msg { padding: 20px; color: #ef4444; font-size: 0.85rem; text-align: center; }

/* ── Responsive ── */
@media (max-width: 900px) {
  .main-grid { grid-template-columns: 1fr; }
  .stats-grid { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 500px) {
  .stats-grid { grid-template-columns: 1fr; }
  .header-right { gap: 8px; }
}

/* ── Qualifications Panel ── */
.quals-panel { margin-bottom: 20px; }
.quals-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 10px; }
.qual-card {
  background: white; border-radius: 10px; padding: 14px 16px;
  border-left: 4px solid #1e40af; box-shadow: 0 1px 3px rgba(0,0,0,0.07);
}
.qual-card-code { font-size: 1rem; font-weight: 800; color: #1e40af; }
.qual-card-name { font-size: 0.73rem; color: #64748b; margin-top: 2px; margin-bottom: 8px; line-height: 1.3; }
.qual-card-los  { font-size: 0.72rem; color: #475569; font-weight: 600; }
.qual-badge {
  display: inline-block; font-size: 0.62rem; font-weight: 700;
  background: #eff6ff; color: #1e40af; border: 1px solid #bfdbfe;
  border-radius: 4px; padding: 1px 5px; margin-left: 6px; vertical-align: middle;
}
/* ── New Learner UI ── */
.new-learner-bar {
  display: flex; gap: 8px; align-items: center; margin-top: 10px;
}
.new-learner-input {
  flex: 1; max-width: 260px; padding: 6px 10px; font-size: 0.82rem;
  border: 1px solid #e2e8f0; border-radius: 6px; outline: none;
}
.new-learner-input:focus { border-color: #3b82f6; }
.new-learner-btn {
  padding: 6px 14px; font-size: 0.82rem; font-weight: 600;
  background: #1e40af; color: white; border: none; border-radius: 6px; cursor: pointer;
}
.new-learner-btn:hover { background: #1d4ed8; }
/* ── Tab Navigation ── */
.tab-bar {
  background: white; border-bottom: 1px solid #e2e8f0;
  display: flex; gap: 0; padding: 0 24px;
}
.tab-btn {
  background: none; border: none; border-bottom: 3px solid transparent;
  padding: 12px 18px; font-size: 0.84rem; font-weight: 600; color: #64748b;
  cursor: pointer; transition: all 0.15s; margin-bottom: -1px;
}
.tab-btn:hover { color: #1e40af; }
.tab-btn.active { color: #1e40af; border-bottom-color: #1e40af; }

/* ── Knowledge Map Tree ── */
.km-container { display: flex; gap: 16px; }
.km-tree { flex: 1; min-width: 0; }
.km-detail-panel {
  width: 300px; flex-shrink: 0;
  background: white; border-radius: 12px; padding: 18px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.08); max-height: 80vh; overflow-y: auto;
  position: sticky; top: 80px;
}
.km-detail-panel h3 { font-size: 0.9rem; font-weight: 700; color: #1e293b; margin-bottom: 12px; }
.km-detail-empty { font-size: 0.82rem; color: #94a3b8; font-style: italic; }
.km-qual-item {
  padding: 8px 10px; border-radius: 8px; background: #f8fafc;
  margin-bottom: 6px; font-size: 0.8rem;
}
.km-qual-code { font-weight: 700; color: #1e40af; }
.km-qual-depth { color: #64748b; font-size: 0.72rem; margin-top: 2px; }
.km-domain {
  background: white; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.08);
  margin-bottom: 10px; overflow: hidden;
}
.km-domain-header {
  padding: 14px 18px; background: #1e40af; color: white;
  font-weight: 700; font-size: 0.9rem; cursor: pointer;
  display: flex; align-items: center; justify-content: space-between;
}
.km-caret { font-size: 0.75rem; transition: transform 0.2s; }
.km-caret.open { transform: rotate(90deg); }
.km-branch-header {
  padding: 10px 18px 10px 24px; background: #f8fafc;
  font-weight: 600; font-size: 0.82rem; color: #334155;
  cursor: pointer; border-bottom: 1px solid #f1f5f9;
  display: flex; align-items: center; justify-content: space-between;
}
.km-area {
  padding: 0 18px 0 36px; border-bottom: 1px solid #f8fafc;
}
.km-area-header {
  padding: 8px 0; font-size: 0.78rem; font-weight: 600; color: #475569;
  display: flex; align-items: center; gap: 8px; cursor: pointer;
}
.km-mastery-dot {
  width: 10px; height: 10px; border-radius: 50%; flex-shrink: 0;
  background: #e2e8f0;
}
.km-mastery-dot.green  { background: #22c55e; }
.km-mastery-dot.amber  { background: #f59e0b; }
.km-concepts { padding: 2px 0 8px 18px; }
.km-concept {
  padding: 5px 8px; margin: 2px 0; border-radius: 6px;
  font-size: 0.76rem; color: #475569; cursor: pointer;
  display: flex; align-items: center; gap: 7px; transition: background 0.1s;
}
.km-concept:hover { background: #f1f5f9; }
.km-concept.selected { background: #eff6ff; border: 1px solid #bfdbfe; }
.km-concept-dot {
  width: 7px; height: 7px; border-radius: 50%; flex-shrink: 0;
  background: #e2e8f0;
}
.km-concept-dot.green  { background: #22c55e; }
.km-concept-dot.amber  { background: #f59e0b; }
.km-concept-name { flex: 1; }
.km-lo-count { font-size: 0.68rem; color: #94a3b8; }
.km-legend {
  display: flex; gap: 14px; margin-bottom: 14px; flex-wrap: wrap;
  font-size: 0.75rem; color: #475569;
}
.km-legend-item { display: flex; align-items: center; gap: 5px; }
</style>
</head>
<body>

<header>
  <h1>&#127891; Learning Progress Dashboard</h1>
  <div class="header-right">
    <span class="learner-label">Learner:</span>
    <select class="learner-select" id="learner-select" onchange="loadDashboard(this.value)">
      <option value="demo-student-001">demo-student-001</option>
    </select>
    <div class="new-learner-bar">
      <input class="new-learner-input" id="new-learner-input" type="text" placeholder="new-learner-id" maxlength="64">
      <button class="new-learner-btn" onclick="createLearner()">+ Add</button>
    </div>
    <a href="/" class="nav-link">&#8592; Tutor Chat</a>
  </div>
</header>

<div class="tab-bar">
  <button class="tab-btn active" id="tab-progress-btn" onclick="switchTab('progress')">&#128218; Learning Progress</button>
  <button class="tab-btn" id="tab-km-btn" onclick="switchTab('knowledge-map')">&#127760; Knowledge Map</button>
</div>

<div id="tab-progress">
<div class="container">

  <!-- Qualifications summary -->
  <div class="quals-panel">
    <div class="quals-grid" id="quals-grid">
      <div class="loading" style="grid-column:1/-1"><div class="spinner"></div></div>
    </div>
  </div>

  <!-- Stats -->
  <div class="stats-grid" id="stats-grid">
    <div class="loading" style="grid-column:1/-1"><div class="spinner"></div> Loading...</div>
  </div>

  <!-- Progress bar -->
  <div class="overall-bar-wrap" id="overall-bar-wrap" style="display:none">
    <div class="overall-bar-label">
      <span>Overall Curriculum Progress</span>
      <span id="overall-pct-label">0%</span>
    </div>
    <div class="overall-bar-bg">
      <div class="overall-bar-fill" id="overall-bar-fill" style="width:0%"></div>
    </div>
  </div>

  <!-- Main panels -->
  <div class="main-grid">

    <!-- Graph panel -->
    <div class="panel">
      <div class="panel-header">
        <span class="panel-title">&#127760; Curriculum Knowledge Map</span>
        <button class="btn-reset" id="reset-btn" onclick="resetGraph()">Reset view</button>
      </div>
      <div class="graph-legend">
        <div class="legend-item"><div class="legend-dot" style="background:#1e40af"></div> Qualification</div>
        <div class="legend-item"><div class="legend-dot" style="background:#22c55e"></div> Mastered</div>
        <div class="legend-item"><div class="legend-dot" style="background:#f59e0b"></div> In Progress</div>
        <div class="legend-item"><div class="legend-dot" style="background:#60a5fa"></div> Progressing (&gt;50%)</div>
        <div class="legend-item"><div class="legend-dot" style="background:#94a3b8"></div> Not Started</div>
        <div class="legend-item"><div class="legend-line"></div> Prerequisite</div>
      </div>
      <div id="cy"></div>
    </div>

    <!-- Topic list panel -->
    <div class="panel">
      <div class="panel-header">
        <span class="panel-title">&#128218; Topic Progress</span>
        <span class="panel-sub" id="topic-summary"></span>
      </div>
      <div class="topic-list" id="topic-list">
        <div class="loading"><div class="spinner"></div> Loading...</div>
      </div>
    </div>

  </div>

  <!-- What's Next -->
  <div class="next-section">
    <div class="next-header">
      <span class="next-header-icon">&#127919;</span>
      Your Next Steps
      <span style="font-weight:400;color:#94a3b8;font-size:0.78rem;margin-left:4px">— recommended learning objectives</span>
    </div>
    <div class="next-grid" id="next-grid">
      <div class="loading"><div class="spinner"></div> Loading...</div>
    </div>
  </div>

</div><!-- end .container -->
</div><!-- end #tab-progress -->

<!-- Knowledge Map Tab -->
<div id="tab-knowledge-map" style="display:none">
<div class="container">
  <div class="km-legend">
    <div class="km-legend-item"><div class="km-mastery-dot green"></div> Mastered (≥85%)</div>
    <div class="km-legend-item"><div class="km-mastery-dot amber"></div> In Progress (50–85%)</div>
    <div class="km-legend-item"><div class="km-mastery-dot" style="background:#e2e8f0"></div> Not Started</div>
    <span style="margin-left:auto;font-size:0.72rem;color:#94a3b8">Click a concept to see cross-qualification coverage</span>
  </div>
  <div class="km-container">
    <div class="km-tree" id="km-tree">
      <div class="loading"><div class="spinner"></div> Loading knowledge map...</div>
    </div>
    <div class="km-detail-panel" id="km-detail">
      <h3>&#128269; Concept Detail</h3>
      <p class="km-detail-empty">Click any concept to see which qualifications teach it and at what depth.</p>
    </div>
  </div>
</div>
</div><!-- end #tab-knowledge-map -->

<!-- Tooltip -->
<div id="tooltip">
  <div class="tt-name" id="tt-name"></div>
  <div class="tt-qual"  id="tt-qual"></div>
  <div class="tt-stat"  id="tt-stat"></div>
</div>

<script>
// ── State ──────────────────────────────────────────────────────────────────────
let cy = null;
let currentLearner = 'demo-student-001';
let selectedConceptId = null;

// ── Tab Navigation ─────────────────────────────────────────────────────────────
function switchTab(tab) {
  document.getElementById('tab-progress').style.display    = tab === 'progress'      ? '' : 'none';
  document.getElementById('tab-knowledge-map').style.display = tab === 'knowledge-map' ? '' : 'none';
  document.getElementById('tab-progress-btn').classList.toggle('active',    tab === 'progress');
  document.getElementById('tab-km-btn').classList.toggle('active', tab === 'knowledge-map');
  if (tab === 'knowledge-map') loadKnowledgeMap(currentLearner);
}

// ── Knowledge Map ──────────────────────────────────────────────────────────────
function masteryDotClass(mastery) {
  if (mastery === null || mastery === undefined) return '';
  if (mastery >= 0.85) return 'green';
  if (mastery >= 0.50) return 'amber';
  return '';
}

function depthLabel(depth) {
  if (depth === 1 || depth === 'introductory') return 'Introductory';
  if (depth === 2 || depth === 'developing')   return 'Developing';
  if (depth === 3 || depth === 'advanced')     return 'Advanced';
  return String(depth);
}

async function loadConceptDetail(conceptId, conceptName) {
  selectedConceptId = conceptId;
  document.querySelectorAll('.km-concept').forEach(el => el.classList.remove('selected'));
  document.querySelectorAll('[data-concept-id="' + conceptId + '"]').forEach(el => el.classList.add('selected'));

  const panel = document.getElementById('km-detail');
  panel.innerHTML = '<h3>&#128269; ' + conceptName + '</h3><div class="loading"><div class="spinner"></div></div>';

  try {
    const res = await fetch('/api/concept/' + encodeURIComponent(conceptId));
    const data = await res.json();
    const quals = data.qualifications;
    if (!quals.length) {
      panel.innerHTML = '<h3>&#128269; ' + conceptName + '</h3><p class="km-detail-empty">No qualification teaches this concept yet.</p>';
      return;
    }
    let html = '<h3>&#128269; ' + conceptName + '</h3>';
    html += '<p style="font-size:0.72rem;color:#64748b;margin-bottom:10px">Taught in ' + quals.length + ' qualification(s):</p>';
    quals.forEach(q => {
      html += '<div class="km-qual-item">';
      html += '<div class="km-qual-code">' + q.code + ' <span style="font-weight:400;color:#64748b">(' + q.year + ')</span></div>';
      html += '<div class="km-qual-depth">Depth: ' + depthLabel(q.depth) + '</div>';
      if (q.name) html += '<div style="font-size:0.7rem;color:#94a3b8;margin-top:2px">' + q.name + '</div>';
      html += '</div>';
    });
    panel.innerHTML = html;
  } catch (e) {
    panel.innerHTML = '<h3>&#128269; ' + conceptName + '</h3><p class="km-detail-empty">Failed to load detail.</p>';
  }
}

function renderKnowledgeMap(domains) {
  const tree = document.getElementById('km-tree');
  if (!domains.length) {
    tree.innerHTML = '<div class="loading">No domain data available.</div>';
    return;
  }

  let html = '';
  domains.forEach((domain, di) => {
    const domId = 'km-dom-' + di;
    html += '<div class="km-domain">';
    html += '<div class="km-domain-header" onclick="toggleSection(\'' + domId + '\')">';
    html += '&#128198; ' + domain.name;
    html += '<span class="km-caret open" id="caret-' + domId + '">&#9658;</span></div>';
    html += '<div id="' + domId + '">';

    domain.branches.forEach((branch, bi) => {
      const brId = domId + '-br-' + bi;
      html += '<div class="km-branch-header" onclick="toggleSection(\'' + brId + '\')">';
      html += '&#128207; ' + branch.name;
      html += '<span class="km-caret open" id="caret-' + brId + '">&#9658;</span></div>';
      html += '<div id="' + brId + '">';

      branch.areas.forEach((area, ai) => {
        const areaId = domId + '-br-' + bi + '-ar-' + ai;
        const dotCls = masteryDotClass(area.avg_mastery);
        const masteryPct = area.avg_mastery !== null ? Math.round(area.avg_mastery * 100) + '%' : 'No data';
        html += '<div class="km-area">';
        html += '<div class="km-area-header" onclick="toggleSection(\'' + areaId + '\')">';
        html += '<div class="km-mastery-dot ' + dotCls + '" title="' + masteryPct + '"></div>';
        html += area.name;
        html += '<span style="color:#94a3b8;font-size:0.68rem;margin-left:auto">' + masteryPct + '</span>';
        html += '</div>';
        html += '<div class="km-concepts" id="' + areaId + '">';

        area.concepts.forEach(concept => {
          const cDotCls = masteryDotClass(concept.avg_mastery);
          const cPct = concept.avg_mastery !== null ? Math.round(concept.avg_mastery * 100) + '%' : '';
          html += '<div class="km-concept" data-concept-id="' + concept.id + '" ';
          html += 'onclick="loadConceptDetail(\'' + concept.id + '\', \'' + concept.name.replace(/'/g, "\\'") + '\')">';
          html += '<div class="km-concept-dot ' + cDotCls + '"></div>';
          html += '<span class="km-concept-name">' + concept.name + '</span>';
          if (cPct) html += '<span class="km-lo-count">' + cPct + '</span>';
          if (concept.lo_count > 0) html += '<span class="km-lo-count" style="color:#3b82f6">' + concept.lo_count + ' LO' + (concept.lo_count !== 1 ? 's' : '') + '</span>';
          html += '</div>';
        });

        html += '</div>'; // km-concepts
        html += '</div>'; // km-area
      });

      html += '</div>'; // brId
    });

    html += '</div>'; // domId
    html += '</div>'; // km-domain
  });

  tree.innerHTML = html;
}

function toggleSection(id) {
  const el = document.getElementById(id);
  const caret = document.getElementById('caret-' + id);
  if (!el) return;
  const isHidden = el.style.display === 'none';
  el.style.display = isHidden ? '' : 'none';
  if (caret) caret.classList.toggle('open', isHidden);
}

async function loadKnowledgeMap(learnerId) {
  document.getElementById('km-tree').innerHTML = '<div class="loading"><div class="spinner"></div> Loading knowledge map...</div>';
  document.getElementById('km-detail').innerHTML = '<h3>&#128269; Concept Detail</h3><p class="km-detail-empty">Click any concept to see which qualifications teach it and at what depth.</p>';
  try {
    const res = await fetch('/api/dashboard/' + encodeURIComponent(learnerId) + '/knowledge-map');
    const data = await res.json();
    renderKnowledgeMap(data.domains);
  } catch (e) {
    document.getElementById('km-tree').innerHTML = '<div class="loading">Failed to load knowledge map: ' + e.message + '</div>';
  }
}

// ── Helpers ────────────────────────────────────────────────────────────────────
function nodeColor(status, pct) {
  if (status === 'mastered')    return '#22c55e';
  if (status === 'in_progress') return pct >= 50 ? '#60a5fa' : '#f59e0b';
  return '#94a3b8';
}
function nodeBorder(status, pct) {
  if (status === 'mastered')    return '#16a34a';
  if (status === 'in_progress') return pct >= 50 ? '#2563eb' : '#d97706';
  return '#64748b';
}
function diffStars(d) {
  const n = Math.min(5, Math.max(1, Math.round(d)));
  return '★'.repeat(n) + '☆'.repeat(5 - n);
}
function loadingEl(text) {
  return '<div class="loading"><div class="spinner"></div>' + (text || '') + '</div>';
}

// ── Stats cards ────────────────────────────────────────────────────────────────
function renderStats(ov) {
  document.getElementById('stats-grid').innerHTML = `
    <div class="stat-card c-mastered">
      <div class="stat-label">Mastered</div>
      <div class="stat-value">${ov.mastered}</div>
      <div class="stat-sub">Learning objectives</div>
    </div>
    <div class="stat-card c-progress">
      <div class="stat-label">In Progress</div>
      <div class="stat-value">${ov.in_progress}</div>
      <div class="stat-sub">Actively working on</div>
    </div>
    <div class="stat-card c-remaining">
      <div class="stat-label">Remaining</div>
      <div class="stat-value">${ov.not_started}</div>
      <div class="stat-sub">Not yet started</div>
    </div>
    <div class="stat-card c-overall">
      <div class="stat-label">Overall Progress</div>
      <div class="stat-value">${ov.pct}<span style="font-size:1rem;font-weight:600">%</span></div>
      <div class="stat-sub">of ${ov.total} objectives</div>
    </div>
  `;
  // Overall progress bar
  const wrap = document.getElementById('overall-bar-wrap');
  wrap.style.display = '';
  document.getElementById('overall-pct-label').textContent = ov.pct + '%';
  setTimeout(() => {
    document.getElementById('overall-bar-fill').style.width = ov.pct + '%';
  }, 50);
}

// ── Topic list ─────────────────────────────────────────────────────────────────
function renderTopics(topics) {
  const mastered = topics.filter(t => t.status === 'mastered').length;
  document.getElementById('topic-summary').textContent =
    mastered + ' of ' + topics.length + ' topics complete';

  // Sort: mastered first, then in_progress, then not_started; within group by % desc
  const order = { mastered: 0, in_progress: 1, not_started: 2 };
  const sorted = [...topics].sort((a, b) => {
    const od = order[a.status] - order[b.status];
    return od !== 0 ? od : b.pct - a.pct;
  });

  document.getElementById('topic-list').innerHTML = sorted.map(t => {
    const masteredPct    = t.pct;
    const inProgressPct  = t.total > 0 ? Math.round(t.in_progress / t.total * 100) : 0;
    return `
      <div class="topic-item" id="topic-item-${t.topic_id}"
           onclick="highlightTopic('${t.topic_id}')">
        <div class="topic-qual-tag">${t.qual_code} &mdash; ${t.qual_name}</div>
        <div class="topic-row">
          <div class="topic-name">${t.topic_name}</div>
          <span class="topic-badge badge-${t.status}">${t.status.replace('_', '\u00a0')}</span>
        </div>
        <div class="progress-row">
          <div class="progress-bg">
            <div class="progress-seg seg-mastered"    style="width:${masteredPct}%"></div>
            <div class="progress-seg seg-in_progress" style="width:${inProgressPct}%"></div>
          </div>
          <div class="topic-count">${t.mastered}/${t.total} LOs</div>
        </div>
      </div>
    `;
  }).join('');
}

// ── Qualifications panel ────────────────────────────────────────────────────────
function renderQualifications(quals) {
  const grid = document.getElementById('quals-grid');
  if (!quals || !quals.length) { grid.innerHTML = ''; return; }
  grid.innerHTML = quals.map(q => `
    <div class="qual-card">
      <div class="qual-card-code">${q.code}</div>
      <div class="qual-card-name">${q.name}</div>
      <div class="qual-card-los">${q.lo_count} learning objectives</div>
    </div>
  `).join('');
}

// ── What's Next ────────────────────────────────────────────────────────────────
function renderNextLos(nextLos) {
  if (!nextLos.length) {
    document.getElementById('next-grid').innerHTML =
      '<p style="color:#64748b;font-size:0.88rem;padding:4px 0">&#127881; All available learning objectives are complete or no pathway data is loaded yet.</p>';
    return;
  }
  document.getElementById('next-grid').innerHTML = nextLos.map(lo => `
    <div class="next-card">
      <div class="next-breadcrumb">
        ${lo.topic} › ${lo.subtopic}
        ${lo.qual_code ? '<span class="qual-badge">' + lo.qual_code + '</span>' : ''}
      </div>
      <div class="next-lo-text">${lo.lo_text}</div>
      <div class="next-meta">
        <span class="diff-stars" title="Difficulty ${lo.difficulty}/5">${diffStars(lo.difficulty)}</span>
        <div class="mastery-mini-wrap">
          <div class="mastery-mini-bg">
            <div class="mastery-mini-fill" style="width:${lo.mastery}%"></div>
          </div>
          <span>${lo.mastery}% started</span>
        </div>
      </div>
    </div>
  `).join('');
}

// ── Cytoscape graph ────────────────────────────────────────────────────────────
function renderGraph(graphData) {
  if (cy) { cy.destroy(); cy = null; }

  cy = cytoscape({
    container: document.getElementById('cy'),
    elements:  [...graphData.nodes, ...graphData.edges],

    style: [
      // Qualification nodes — prominent blue boxes
      {
        selector: 'node[type="qualification"]',
        style: {
          'background-color':   '#1e40af',
          'border-color':       '#1e3a8a',
          'border-width':        2,
          'color':              'white',
          'label':              'data(label)',
          'font-size':          '13px',
          'font-weight':        '800',
          'text-valign':        'center',
          'text-halign':        'center',
          'width':               72,
          'height':              42,
          'shape':              'roundrectangle',
          'text-wrap':          'none',
        }
      },
      // Topic nodes — ellipses, sized by LO count, colored by mastery
      {
        selector: 'node[type="topic"]',
        style: {
          'background-color': function(ele) {
            return nodeColor(ele.data('status'), ele.data('pct'));
          },
          'border-color': function(ele) {
            return nodeBorder(ele.data('status'), ele.data('pct'));
          },
          'border-width': 2,
          'color':        '#1e293b',
          'label':        'data(label)',
          'font-size':    '9px',
          'font-weight':  '600',
          'text-valign':  'bottom',
          'text-halign':  'center',
          'text-margin-y': 5,
          'width':  function(ele) { return 28 + Math.min(ele.data('total') || 0, 25) * 1.4; },
          'height': function(ele) { return 28 + Math.min(ele.data('total') || 0, 25) * 1.4; },
          'shape':  'ellipse',
          'text-wrap': 'wrap',
          'text-max-width': '80px',
          'text-background-color':   'rgba(255,255,255,0.85)',
          'text-background-opacity':  1,
          'text-background-padding': '2px',
          'text-background-shape':   'roundrectangle',
        }
      },
      // HAS_TOPIC edges — thin grey connector
      {
        selector: 'edge[type="has_topic"]',
        style: {
          'width':                1.5,
          'line-color':           '#cbd5e1',
          'target-arrow-color':   '#cbd5e1',
          'target-arrow-shape':   'none',
          'curve-style':          'bezier',
          'opacity':               0.8,
        }
      },
      // PREREQUISITE edges — orange dashed arrows
      {
        selector: 'edge[type="prerequisite"]',
        style: {
          'width':                1.8,
          'line-color':           '#f97316',
          'target-arrow-color':   '#f97316',
          'target-arrow-shape':   'triangle',
          'curve-style':          'bezier',
          'opacity':               0.65,
          'line-style':           'dashed',
          'line-dash-pattern':    [6, 4],
        }
      },
      // Highlighted state
      {
        selector: 'node.highlighted',
        style: {
          'border-width':  4,
          'border-color':  '#1d4ed8',
          'overlay-color': '#3b82f6',
          'overlay-opacity': 0.12,
          'overlay-padding': 6,
        }
      },
    ],
  });

  // Run breadthfirst layout with qual nodes as roots
  const qualNodes = cy.nodes('[type="qualification"]');
  cy.layout({
    name:           'breadthfirst',
    directed:        true,
    roots:           qualNodes,
    padding:         28,
    spacingFactor:   1.55,
    avoidOverlap:    true,
    animate:         false,
    maximal:         true,
  }).run();

  // ── Tooltip ──────────────────────────────────────────────────────────────────
  const tooltip = document.getElementById('tooltip');

  cy.on('mouseover', 'node[type="topic"]', function(e) {
    const d = e.target.data();
    document.getElementById('tt-name').textContent = d.label;
    document.getElementById('tt-qual').textContent  = d.qual_code;
    document.getElementById('tt-stat').innerHTML =
      '<span>' + d.mastered + '</span> of ' + d.total + ' LOs mastered (' + d.pct + '%)' +
      '<br>Avg mastery score: <span>' + d.avg_mastery + '%</span>';
    tooltip.style.display = 'block';
  });

  cy.on('mouseover', 'node[type="qualification"]', function(e) {
    const d = e.target.data();
    document.getElementById('tt-name').textContent = d.full_name;
    document.getElementById('tt-qual').textContent  = d.label;
    document.getElementById('tt-stat').textContent  = '';
    tooltip.style.display = 'block';
  });

  cy.on('mousemove', function(e) {
    tooltip.style.left = (e.originalEvent.clientX + 14) + 'px';
    tooltip.style.top  = (e.originalEvent.clientY - 10) + 'px';
  });

  cy.on('mouseout', 'node', function() {
    tooltip.style.display = 'none';
  });

  // Click topic → highlight in graph + scroll topic list
  cy.on('tap', 'node[type="topic"]', function(e) {
    highlightTopic(e.target.id());
  });

  // Click qual → fit to its neighbourhood
  cy.on('tap', 'node[type="qualification"]', function(e) {
    cy.nodes('.highlighted').removeClass('highlighted');
    const hood = e.target.closedNeighborhood();
    cy.animate({ fit: { eles: hood, padding: 30 }, duration: 350 });
  });
}

function resetGraph() {
  if (!cy) return;
  cy.nodes().removeClass('highlighted');
  document.querySelectorAll('.topic-item').forEach(el => el.classList.remove('highlighted'));
  cy.animate({ fit: { eles: cy.elements(), padding: 24 }, duration: 350 });
  document.getElementById('tooltip').style.display = 'none';
}

// ── Cross-link: highlight topic ────────────────────────────────────────────────
function highlightTopic(topicId) {
  // Graph
  if (cy) {
    cy.nodes().removeClass('highlighted');
    const node = cy.getElementById(topicId);
    if (node.length) {
      node.addClass('highlighted');
      cy.animate({
        zoom:   { level: Math.max(cy.zoom(), 1.4), position: node.position() },
        duration: 380,
      });
    }
  }
  // List
  document.querySelectorAll('.topic-item').forEach(el => el.classList.remove('highlighted'));
  const listEl = document.getElementById('topic-item-' + topicId);
  if (listEl) {
    listEl.classList.add('highlighted');
    listEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }
}

// ── New learner creation ────────────────────────────────────────────────────────
async function createLearner() {
  const input = document.getElementById('new-learner-input');
  const learnerId = input.value.trim();
  if (!learnerId) return;
  try {
    const res = await fetch('/api/learner/' + encodeURIComponent(learnerId), { method: 'POST' });
    if (!res.ok) {
      const err = await res.json();
      alert('Failed to create learner: ' + (err.detail || res.status));
      return;
    }
    input.value = '';
    // Reload dashboard for the new learner — selector will update
    loadDashboard(learnerId);
  } catch (e) {
    alert('Error: ' + e.message);
  }
}

// ── Learner selector ───────────────────────────────────────────────────────────
function populateLearnerSelect(learners, current) {
  const sel = document.getElementById('learner-select');
  sel.innerHTML = learners.map(id =>
    '<option value="' + id + '"' + (id === current ? ' selected' : '') + '>' + id + '</option>'
  ).join('');
}

// ── Main load ──────────────────────────────────────────────────────────────────
async function loadDashboard(learnerId) {
  currentLearner = learnerId;

  // Reset loading states
  document.getElementById('stats-grid').innerHTML =
    '<div class="loading" style="grid-column:1/-1"><div class="spinner"></div></div>';
  document.getElementById('overall-bar-wrap').style.display = 'none';
  document.getElementById('topic-list').innerHTML = loadingEl();
  document.getElementById('next-grid').innerHTML  = loadingEl();
  if (cy) { cy.destroy(); cy = null; }
  document.getElementById('cy').innerHTML = loadingEl('Building graph…');

  try {
    const res = await fetch('/api/dashboard/' + encodeURIComponent(learnerId));
    if (!res.ok) throw new Error('HTTP ' + res.status + ' — ' + res.statusText);
    const data = await res.json();

    populateLearnerSelect(data.learners, learnerId);
    renderQualifications(data.qualifications);

    // Refresh Knowledge Map if that tab is currently active
    if (document.getElementById('tab-km-btn').classList.contains('active')) {
      loadKnowledgeMap(learnerId);
    }

    renderStats(data.overview);
    renderTopics(data.topics);
    renderNextLos(data.next_los);

    // Small delay so cy container is fully laid out before Cytoscape mounts
    setTimeout(() => {
      document.getElementById('cy').innerHTML = '';
      renderGraph(data.graph);
    }, 60);

  } catch (err) {
    document.getElementById('stats-grid').innerHTML =
      '<div class="error-msg" style="grid-column:1/-1">&#9888; Could not load dashboard: ' + err.message +
      '<br><small>Is Neo4j running? Try: <code>docker compose -f docker-compose.neo4j.yml up -d</code></small></div>';
    document.getElementById('topic-list').innerHTML = '';
    document.getElementById('next-grid').innerHTML  = '';
  }
}

// Boot
loadDashboard(currentLearner);
</script>
</body>
</html>"""
