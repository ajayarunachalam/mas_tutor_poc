# MAS Education — Neo4j Knowledge Graph Planning Document

**Project:** MAS Education POC — Planning Agent Upgrade
**Date:** 24 February 2026
**Author:** Thane Thompson-Starkey, Head of Data, Analytics and AI — Cambridge University Press & Assessment
**Status:** PLANNING — Pre-implementation research and design
**Scope:** Cambridge Secondary+ Mathematics Pathway (IGCSE → A-Level → Further Maths)

---

## Executive Summary

The current Planning Agent uses a flat SQLite table with 8 topics in a linear prerequisite chain. This is sufficient for a single-qualification POC but cannot represent the richness of the Cambridge curriculum: concepts that spiral across qualifications at increasing depth, non-linear prerequisites, cross-strand relationships, or the multi-qualification pathway from IGCSE to Further Mathematics.

This document proposes replacing the SQLite model with a **Neo4j property graph** that models the full Cambridge Secondary+ Mathematics curriculum. The architecture decision that makes this genuinely differentiated is the introduction of **shared Concept nodes** — abstract mathematical concepts that are linked to by Learning Objective nodes across qualifications. This captures the spiral curriculum structure (the same concept at increasing depth across IGCSE, A-Level, Further Maths) in a way that is structurally impossible in a relational model.

**Key design decisions (confirmed):**
- Scope: Cambridge Secondary+ (IGCSE → AS/A-Level → Further Maths)
- Granularity: Full hierarchy — Qualification → Topic → Subtopic → LearningObjective + shared Concept nodes
- Cross-qualification: Shared Concept nodes with Concept-Instance pattern — abstract `:Concept` + qualification-specific `:ConceptInstance` nodes connected by `[:TEACHES]`, `[:INSTANCE_OF]`, and `[:DEEPENS]` relationships
- Deployment: Docker + Neo4j Community 5.x on WSL2

---

## 1. The Problem with the Current SQLite Approach

The existing `topics` table and `prerequisites` table in `mas_poc.db` represents the curriculum as:

```sql
-- 8 rows, linear chain
topics: (topic_id, topic_name, subject, difficulty_level, description)
prerequisites: (topic_id, prereq_topic_id)
```

This works for a single qualification demo but fails on:

| Limitation | Impact |
|---|---|
| **Linear only** | Real prerequisites are a DAG, not a chain (e.g. Trigonometry requires both Geometry AND Algebra) |
| **Single qualification** | No way to model "IGCSE quadratics" → "A-Level quadratics" as the same concept at different depth |
| **No cross-strand links** | Cannot express that Statistics requires Number but not Geometry |
| **No spiral structure** | Bruner's spiral curriculum — same concept revisited at increasing complexity — is invisible |
| **No tier distinction** | Core vs Extended in IGCSE is a flat flag, not a structural relationship |
| **No Bloom's taxonomy** | Cannot distinguish "recall a formula" from "derive and apply a formula" |
| **No LO-level granularity** | One row per topic; a real syllabus has 50-200 learning objectives per qualification |

A graph database resolves all of these structurally rather than through workarounds.

---

## 2. Cambridge Secondary+ Mathematics Syllabuses

### 2.1 The Full Pathway (Secondary+)

The four qualifications in scope, in progression order:

| Code | Qualification | Age | Level | Notes |
|---|---|---|---|---|
| **0580** | Cambridge IGCSE Mathematics | 14-16 | IGCSE | Core and Extended tiers; ~130 learning objectives |
| **0606** | Cambridge IGCSE Additional Mathematics | 14-16 | IGCSE | Extended only; bridges to A-Level; ~80 LOs |
| **9709** | Cambridge International AS & A Level Mathematics | 16-18 | AS/A | 6 components (Pure 1/2/3, Mechanics 1, Stats 1/2) |
| **9231** | Cambridge International AS & A Level Further Mathematics | 16-18 | AS/A | For highest-achieving students; Further Pure + Further Stats/Mechanics |

Note: Cambridge O Level Mathematics (4024) covers the same content as IGCSE but for different markets; it can share Topic and Concept nodes with 0580 without duplication.

### 2.2 Cambridge IGCSE Mathematics (0580) — Topic Structure

The syllabus organises content into **4 strands**, each with topics and subtopics:

**Strand 1: Number**
- Natural numbers, integers, prime numbers, square/cube numbers
- HCF, LCM
- Rational and irrational numbers
- Fractions, decimals, percentages (conversion, operations, recurring decimals)
- The four rules and order of operations
- Directed numbers
- Powers and roots (squares, cubes; fractional/negative indices — Extended)
- Ordering and set notation (inequalities, Venn diagrams — Extended)
- Ratio, proportion and rate; direct and inverse proportion
- Estimation and limits of accuracy; upper and lower bounds (Extended)
- Standard form
- Units, conversions, time, currency

**Strand 2: Algebra and Graphs**
- Algebraic representation and formulae; rearranging formulae (complex — Extended)
- Algebraic manipulation: simplifying, expanding, factorisation; quadratic factorisation (Extended); algebraic fractions (Extended)
- Solutions of equations and inequalities: linear equations; quadratic equations — Extended (formula, completing the square); simultaneous equations; graphical/algebraic inequalities (Extended)
- Graphs in practical situations: conversion, travel, speed-time; curved graphs (Extended)
- Straight-line graphs: y = mx + c; gradient and intercept; parallel and perpendicular lines
- Graphs of functions: quadratic, reciprocal, exponential; gradient estimation; turning points
- Number sequences: patterns, nth term, general rules
- Indices: negative and fractional indices; index laws
- Variation: direct and inverse (Extended)
- Linear programming: graphical inequalities, feasible regions (Extended)
- Functions: notation, inverse, composite functions
- Differentiation: gradients of curves, turning points (Extended)

**Strand 3: Geometry and Trigonometry**
- Angle properties: facts, parallel lines, polygons; circles (Extended); cyclic quadrilaterals (Extended); alternate segment theorem (Extended)
- Geometrical terms and relationships: bearings, nets, congruence (Extended); similarity; scale factors for areas and volumes (Extended)
- Geometrical constructions: locus, bisectors, scale drawings
- Trigonometry: Pythagoras theorem; sine, cosine, tangent ratios; 3D trigonometry (Extended); sine and cosine rules (Extended)
- Mensuration: perimeter and area; circle calculations; volumes and surface areas of 3D solids
- Symmetry: lines of symmetry, rotational symmetry; 2D and 3D shapes
- Vectors: column vectors, magnitude, addition/subtraction (Extended: resultants, applications)
- Transformations: translations, reflections, rotations, enlargements; combined transformations (Extended); matrix representation (Extended)

**Strand 4: Statistics and Probability**
- Statistical representation: frequency tables, bar charts, pie charts, scatter diagrams, histograms; cumulative frequency (Extended); box plots (Extended)
- Statistical measures: mode, median, mean, range; stem-and-leaf diagrams; interquartile range (Extended)
- Probability: probability scale; calculating probabilities; mutually exclusive events; Venn diagrams; tree diagrams; conditional probability (Extended)

### 2.3 Cambridge IGCSE Additional Mathematics (0606) — Topic Structure

Designed as a bridge from IGCSE Extended to A-Level:

- Functions (domain, range, inverse, composite, modulus functions)
- Quadratics (discriminant, completing the square, inequalities)
- Equations, inequalities and graphs (cubic, reciprocal, modulus graphs)
- Indices and surds
- Factors of polynomials (factor theorem, remainder theorem, polynomial division)
- Simultaneous equations (one linear, one non-linear)
- Logarithmic and exponential functions (laws of logarithms, equations)
- Straight-line graphs (linear law, transforming to linear form)
- Circular measure (radians, arc length, sector area)
- Trigonometry (exact values, identities sin²+cos²=1, tan=sin/cos; equations; addition formulae; double angle formulae; R(a sin θ + b cos θ) form)
- Permutations and combinations
- Binomial expansion
- Vectors in 2D (unit vectors, parallel vectors, position vectors)
- Matrices (addition, multiplication, inverse; simultaneous equations by matrices)
- Differentiation (chain, product, quotient rules; rates of change; tangents/normals; stationary points; second derivatives)
- Integration (definite and indefinite; areas; volumes of revolution; integration by substitution and parts)

### 2.4 Cambridge International AS & A Level Mathematics (9709) — Component Structure

Nine components (A-Level students take six or more):

**Pure Mathematics 1 (Paper 1 — AS and A-Level):**
- Quadratics (completing the square, discriminant)
- Functions (domain, range, inverse, composite, graphs)
- Coordinate geometry (circles — equation, tangent, chord)
- Circular measure (radians)
- Trigonometry (identities, equations, graphs, solving)
- Series (binomial expansion; arithmetic and geometric progressions; sum to infinity)
- Differentiation (first principles; chain/product/quotient rules; implicit; stationary points)
- Integration (indefinite and definite; area and volume; by substitution)

**Pure Mathematics 2 (Paper 2 — AS only) / Pure Mathematics 3 (Paper 3 — A-Level):**
- Algebra (polynomials, partial fractions, rational inequalities)
- Logarithms and exponential functions (differentiation and integration involving e^x and ln x)
- Trigonometry (double angle formulae; harmonic form; inverse trig functions — P3)
- Differentiation (parametric and implicit; exponential and log — P3 adds more)
- Integration (by parts; by substitution — more complex; partial fractions)
- Numerical methods (iteration, Newton-Raphson, trapezium rule)
- Vectors (3D; magnitude; angle between vectors; equation of line and plane)
- Differential equations (formation and solution — P3)
- Complex numbers (Argand diagram, modulus-argument — P3)

**Mechanics 1 (Paper 4):**
- Forces in equilibrium (resolving, triangle of forces, Lami's theorem)
- Kinematics of motion in a straight line (equations of motion; velocity-time graphs)
- Newton's laws of motion (F=ma, connected particles, pulleys)
- Energy, work and power (kinetic and potential energy, conservation, power)
- Momentum (impulse, collision, elastic and inelastic)

**Probability and Statistics 1 (Paper 5):**
- Representation of data (stem-and-leaf, box plots, frequency distributions, measures)
- Permutations and combinations
- Probability (conditional probability, Bayes' theorem)
- Discrete random variables (expectation, variance)
- Binomial distribution
- Normal distribution (standardisation, use of tables)

**Probability and Statistics 2 (Paper 6 — A-Level):**
- Poisson distribution
- Linear combinations of random variables
- Continuous random variables (probability density functions)
- Sampling (Central Limit Theorem, unbiased estimators)
- Hypothesis testing (z-tests, t-tests — if variance unknown in Poisson or Binomial)
- Confidence intervals

### 2.5 Cambridge International Further Mathematics (9231) — Component Structure

**Further Pure Mathematics 1 (Paper 1):**
- Matrices (determinant, inverse, eigenvalues, transformations)
- Proof by induction
- Summation of series (method of differences)
- Rational functions and asymptotes
- Polar coordinates
- Complex numbers (De Moivre's theorem, roots of unity, complex conjugate root theorem)
- Differential equations (second order, complementary functions, particular integrals)
- Vector geometry (plane equations, line-plane intersections, shortest distance)

**Further Pure Mathematics 2 (Paper 2):**
- Hyperbolic functions
- Maclaurin series and approximations
- Further integration techniques (reduction formulae, improper integrals)
- Differential equations (systems of equations)

**Further Mechanics (Paper 3):**
- Circular motion (uniform, non-uniform)
- Hooke's law and elasticity
- Linear motion under variable force

**Further Statistics (Paper 4):**
- Further probability distributions
- Inference (two-sample tests, goodness of fit, contingency tables)
- Non-parametric tests (Wilcoxon, Mann-Whitney)

---

## 3. The Knowledge Graph Design

### 3.1 Theoretical Foundations

Three bodies of research inform the schema design:

**A. The Spiral Curriculum (Jerome Bruner, 1960)**
Bruner's fundamental insight: concepts are best learned by revisiting them at increasing levels of sophistication, not taught once and moved on. "Quadratic equations" in IGCSE, A-Level, and Further Maths is the *same concept* at different *depth*. A flat relational model treats these as three separate, unrelated items. A graph with a shared `:Concept` node can express that all three Learning Objectives are instances of the same underlying mathematical idea — enabling the system to understand that a student who has mastered IGCSE quadratics has a foundation for A-Level quadratics, not zero prior knowledge.

**B. CTDL-ASN — The International Competency Framework Standard**
The Credential Transparency Description Language for Achievement Standards (CTDL-ASN) is the international standard for representing curriculum frameworks and competency structures. Its entity model directly informs our schema:
- `CompetencyFramework` → our `:Qualification`
- `Competency` → our `:LearningObjective`
- `hasChild / isChildOf` → our `[:HAS_LO]` and `[:HAS_SUBTOPIC]` structural edges
- `prerequisiteAlignment` → our `[:PREREQUISITE_OF]`
- `exactAlignment / narrowAlignment / broadAlignment` → our `[:DEEPENS]` and `[:SAME_CONCEPT_AS]`

Designing to CTDL-ASN principles means the graph is interoperable with global curriculum registries and can be exported to standard formats.

**C. Cambridge International's Own Curriculum Design Methodology**
Cambridge designs progression *backwards* — starting from the target qualification (IGCSE/A-Level) and working back to identify prerequisites at each stage. Progression is examined in *five directions*:
- Forward/backward (sequential staging)
- Up/down (vertical within a subject — ensuring 2D shapes are taught before coordinate geometry)
- Across strands (e.g. decimals in Number strand introduced before used in Statistics)
- Across subjects (mathematics prerequisites introduced one stage *before* their use in Science)

This multi-directional model is exactly what a graph captures naturally and what a relational model cannot express without proliferating junction tables.

### 3.2 Node Type Definitions

The proposed schema uses 10 node types:

---

**`:Qualification`**
The qualification itself — the top-level container.

```cypher
(:Qualification {
  code: "0580",               // Cambridge subject code
  name: "IGCSE Mathematics",
  level: "IGCSE",             // IGCSE | AS | A | Further
  awarding_body: "Cambridge International",
  age_range: "14-16",
  tiers: ["Core", "Extended"], // or null for single-tier
  active: true
})
```

---

**`:Component`**
A paper or component within a qualification. Allows "ASSESSED_IN" edges from Learning Objectives to specific papers.

```cypher
(:Component {
  code: "P1",
  name: "Pure Mathematics 1",
  qualification_code: "9709",
  type: "Pure",              // Pure | Statistics | Mechanics | Mixed
  weight_pct: 33             // Assessment weighting
})
```

---

**`:MathDomain`**
Top-level mathematical domain — the broadest conceptual grouping. Six domains cover all secondary maths:

```cypher
(:MathDomain { name: "Number" })
(:MathDomain { name: "Algebra" })
(:MathDomain { name: "Geometry" })
(:MathDomain { name: "Calculus" })
(:MathDomain { name: "Statistics" })
(:MathDomain { name: "Discrete" })  // Combinatorics, proof, matrices
```

---

**`:Topic`**
Top-level content area within a qualification/component (corresponds to Cambridge's "strand" at IGCSE level, "paper" at A-Level).

```cypher
(:Topic {
  id: "0580-number",
  name: "Number",
  qualification_code: "0580",
  order: 1                   // Recommended teaching order
})
```

---

**`:Subtopic`**
Named subdivision — the level Cambridge explicitly documents in their syllabuses (e.g. "Trigonometry" under Geometry).

```cypher
(:Subtopic {
  id: "0580-geometry-trigonometry",
  name: "Trigonometry",
  tier: "Core"               // Core | Extended | null (both)
})
```

---

**`:LearningObjective`** *(the primary knowledge node)*
A specific, testable learning statement. This is the atomic unit of curriculum. Properties are deliberately rich to support adaptive tutoring.

```cypher
(:LearningObjective {
  id: "0580-ext-algebra-quadratic-factorisation",
  text: "Solve quadratic equations by factorisation",
  tier: "Extended",          // Core | Extended | null
  bloom_level: "apply",      // remember|understand|apply|analyse|evaluate|create
  difficulty: 2,             // 1-5 scale
  lo_type: "procedural",     // procedural | conceptual | applied
  exam_command: "solve",     // Cambridge command word: find, calculate, show, prove...
  bkt_p_init: 0.10,
  bkt_p_learn: 0.20,
  bkt_p_slip: 0.10,
  bkt_p_guess: 0.25
})
```

---

**`:ConceptInstance`** *(qualification-specific realisation of a Concept)*
A specific instantiation of an abstract Concept at a particular qualification level and depth. The Concept-Instance pattern is the key architectural upgrade: rather than Learning Objectives pointing directly at an abstract `:Concept`, they point at a `:ConceptInstance` that captures how that concept appears at a specific qualification level. This enables `[:DEEPENS]` relationships to run between ConceptInstances across qualifications — expressing spiral curriculum depth in a structurally precise way.

```cypher
(:ConceptInstance {
  id: "ci-quadratic-equations-igcse-extended",
  depth: "developing",           // introductory | developing | advanced | specialist
  bloom_level: "apply",
  qualification_code: "0580",
  tier: "Extended",
  description: "Solving quadratics by factorisation and formula at IGCSE Extended level"
})
```

> **Why this pattern over direct RELATES\_TO?** If LOs point directly at a Concept, `[:DEEPENS]` must run LO→LO (across qualifications), which creates a many-to-many tangle as each qualification adds more LOs for the same concept. The ConceptInstance acts as an aggregation point per qualification level: all IGCSE Extended LOs about quadratics point to the same ConceptInstance, which then has a single clean `[:DEEPENS]` edge to the A-Level ConceptInstance.

---

**`:Concept`** *(the USP node — shared across qualifications)*
An abstract mathematical concept that may appear across multiple qualifications at increasing depth. This is the node that makes the graph genuinely powerful.

```cypher
(:Concept {
  id: "concept-quadratic-equations",
  name: "Quadratic Equations",
  domain: "Algebra",         // Which MathDomain this belongs to
  description: "Equations of degree 2 in one variable; factorisation, formula, and graphical solution methods",
  spiral_depth_max: 4        // How many distinct depth levels this concept reaches (IGCSE Core → IGCSE Ext → A-Level → Further)
})
```

---

**`:Skill`**
Mathematical skill type — used to classify Learning Objectives independently of content. Enables queries like "find all applied-type objectives at difficulty ≥ 3".

```cypher
(:Skill {
  id: "skill-algebraic-manipulation",
  name: "Algebraic manipulation",
  type: "procedural"         // procedural | conceptual | applied | proof
})
```

---

**`:Resource`**
Curriculum material — links Learning Objectives to ChromaDB chunks (the RAG pipeline integration). This is the bridge between the KG and the RAG system.

```cypher
(:Resource {
  id: "res-qe-chunk-2",
  type: "curriculum_chunk",
  chroma_collection: "poc_curriculum",
  chunk_id: "quadratic-equations-chunk-2",
  source_file: "quadratic_equations.md"
})
```

---

### 3.3 Relationship Type Definitions

The schema uses 14 relationship types across four categories:

**Structural (hierarchy):**

```cypher
(:Qualification)-[:HAS_COMPONENT]->(:Component)
(:Qualification)-[:HAS_TOPIC]->(:Topic)         // For IGCSE (no component layer)
(:Component)-[:HAS_TOPIC]->(:Topic)              // For A-Level (component → topic)
(:Topic)-[:HAS_SUBTOPIC]->(:Subtopic)
(:Subtopic)-[:HAS_LO]->(:LearningObjective)
```

**Concept abstraction — Concept-Instance pattern (the USP):**

```cypher
(:LearningObjective)-[:TEACHES]->(:ConceptInstance)
// "Solve quadratic equations by factorisation" TEACHES the IGCSE Extended ConceptInstance
// Multiple LOs within the same qualification level point to the same ConceptInstance

(:ConceptInstance)-[:INSTANCE_OF]->(:Concept)
// The IGCSE Extended ConceptInstance is an INSTANCE_OF the abstract "Quadratic Equations" Concept

(:ConceptInstance)-[:AT_LEVEL]->(:Qualification)
// Explicitly binds a ConceptInstance to its qualification (for cross-qualification queries)

(:ConceptInstance)-[:DEEPENS { depth_increase: 1, year_gap: 2 }]->(:ConceptInstance)
// The IGCSE Extended ConceptInstance DEEPENS the A-Level Pure 1 ConceptInstance
// Properties: depth_increase (spiral depth step), year_gap (typical years between qualifications)
// This replaces the previous LO-to-LO DEEPENS — cleaner because it aggregates per qualification level

(:Concept)-[:BELONGS_TO]->(:MathDomain)
```

> **Relationship count note:** The Concept-Instance pattern adds 3 relationship types (`[:TEACHES]`, `[:INSTANCE_OF]`, `[:AT_LEVEL]`) and retires the previous direct `[:RELATES_TO]` LO→Concept edge. `[:DEEPENS]` is retained but moves from LO→LO to ConceptInstance→ConceptInstance. Total relationship types: **14** (was 12).

**Prerequisites (multi-level):**

```cypher
(:LearningObjective)-[:PREREQUISITE_OF { strength: "hard" }]->(:LearningObjective)
// Hard: cannot proceed without this. Soft: recommended.
// Properties: strength ("hard" | "soft"), within_qualification (bool)

(:Concept)-[:PREREQUISITE_OF]->(:Concept)
// Abstract prerequisite chain at concept level: "Factorisation" PREREQUISITE_OF "Quadratic equations"

(:Qualification)-[:PREREQUISITE_OF { typical_gap_years: 2 }]->(:Qualification)
// IGCSE PREREQUISITE_OF AS-Level; AS-Level PREREQUISITE_OF A-Level
```

**Assessment and learning:**

```cypher
(:LearningObjective)-[:ASSESSED_IN]->(:Component)
(:LearningObjective)-[:REQUIRES_SKILL]->(:Skill)
(:LearningObjective)-[:HAS_RESOURCE]->(:Resource)
```

---

### 3.4 Schema Option Comparison

Three schema options were considered:

| | **Option A: Flat Extended** | **Option B: Full Hierarchy + Concept-Instance** *(chosen)* | **Option C: Concept-Centric** |
|---|---|---|---|
| **Structure** | Qualification → LO (no sub-layers) | Qual → Component → Topic → Subtopic → LO → ConceptInstance → Concept | Concept as primary organiser; Quals attach to Concepts |
| **Concept nodes** | No | Yes — shared Concept + qualification-specific ConceptInstance | Yes — primary nodes |
| **Pros** | Simple; maps directly from SQLite; fast to build | Faithful to Cambridge syllabus structure; spiral curriculum expressed precisely via ConceptInstance→ConceptInstance DEEPENS; clean cross-qual queries; easy to ingest from PDFs | Maximum cross-qualification power; elegant queries |
| **Cons** | Loses all sub-structure; no cross-qual links | More complex ingestion; need to populate ~400-600 nodes + ~150-200 ConceptInstances | Hard to map from syllabuses as written; Concepts need manual definition; harder first pass |
| **Node count** | ~80 (4 quals × ~20 topics) | ~900-1,100 (across 4 qualifications to LO depth + ConceptInstances) | ~500-700 (Concept nodes + LO links) |
| **Query for "what comes before X?"** | Simple chain walk | Multi-hop: LO → ConceptInstance → DEEPENS → ConceptInstance → LO | Very clean but requires full Concept graph to be defined first |
| **Recommended for** | Rapid MVP, single qual only | **Production design — chosen approach** | End-state v2.0 or concurrent with Option B |

**Decision: Option B with the Concept-Instance upgrade (Full Hierarchy + ConceptInstance layer).**

The practical reason: Cambridge syllabuses are written as Qualification → Topic → Subtopic → LO. Ingesting them into Option B is mechanical. The Concept-Instance upgrade was incorporated after research identified that LO→LO DEEPENS creates a many-to-many tangle as qualifications grow — ConceptInstance nodes act as clean aggregation points per qualification level, making the spiral curriculum structurally precise.

---

### 3.5 Cross-Qualification Concept Mapping — The USP in Detail

This is the architectural feature that most differentiates the system. Here is a worked example using the concept of "quadratic equations" across the full Secondary+ pathway:

With the Concept-Instance pattern, the three-layer structure looks like this:

```
:Concept { name: "Quadratic Equations", id: "concept-quadratic-equations" }
  │
  ├── INSTANCE_OF ←── :ConceptInstance { id: "ci-quad-igcse-core",
  │                    depth: "introductory", qualification_code: "0580", tier: "Core" }
  │                       │
  │                       └── TEACHES ←── :LO { id: "0580-core-algebra-quadratic-solve-trial",
  │                                              text: "Understand that quadratics have solutions",
  │                                              bloom_level: "understand", difficulty: 1 }
  │
  ├── INSTANCE_OF ←── :ConceptInstance { id: "ci-quad-igcse-extended",
  │                    depth: "developing", qualification_code: "0580", tier: "Extended" }
  │                       │
  │                       ├── TEACHES ←── :LO { id: "0580-ext-algebra-quadratic-factorise",
  │                       │                      text: "Solve quadratic equations by factorisation",
  │                       │                      bloom_level: "apply", difficulty: 2 }
  │                       │
  │                       └── TEACHES ←── :LO { id: "0580-ext-algebra-quadratic-formula",
  │                                              text: "Solve quadratic equations using the quadratic formula",
  │                                              bloom_level: "apply", difficulty: 3 }
  │
  ├── INSTANCE_OF ←── :ConceptInstance { id: "ci-quad-igcse-addmaths",
  │                    depth: "developing", qualification_code: "0606", tier: null }
  │                       │
  │                       └── TEACHES ←── :LO { id: "0606-quadratics-complete-square",
  │                                              text: "Express ax²+bx+c in completed square form",
  │                                              bloom_level: "apply", difficulty: 3 }
  │
  └── INSTANCE_OF ←── :ConceptInstance { id: "ci-quad-alevel-p1",
                       depth: "advanced", qualification_code: "9709", tier: null }
                          │
                          ├── TEACHES ←── :LO { id: "9709-P1-quadratics-disguised",
                          │                      text: "Solve equations reducible to quadratic form",
                          │                      bloom_level: "analyse", difficulty: 4 }
                          │
                          └── TEACHES ←── :LO { id: "9709-P1-quadratics-discriminant",
                                                 text: "Use the discriminant to determine the nature of roots",
                                                 bloom_level: "apply", difficulty: 3 }
```

**DEEPENS relationships — ConceptInstance to ConceptInstance (the spiral curriculum chain):**

```cypher
// The depth chain runs between ConceptInstances, not between individual LOs
// This is the Concept-Instance pattern's key advantage: clean single edge per qualification step

(:ConceptInstance {id:"ci-quad-igcse-core"})-[:DEEPENS { depth_increase:1, year_gap:0 }]->
  (:ConceptInstance {id:"ci-quad-igcse-extended"})

(:ConceptInstance {id:"ci-quad-igcse-extended"})-[:DEEPENS { depth_increase:1, year_gap:1 }]->
  (:ConceptInstance {id:"ci-quad-igcse-addmaths"})

(:ConceptInstance {id:"ci-quad-igcse-addmaths"})-[:DEEPENS { depth_increase:1, year_gap:2 }]->
  (:ConceptInstance {id:"ci-quad-alevel-p1"})
```

**What this enables (queries impossible in SQLite):**

```cypher
// "Given a student has mastered IGCSE Extended quadratics, what A-Level LOs are they prepared for?"
MATCH (mastered_lo:LearningObjective {id:"0580-ext-algebra-quadratic-factorise"})
      -[:TEACHES]->(ci:ConceptInstance)
      -[:DEEPENS*1..3]->(deeper_ci:ConceptInstance)
      -[:AT_LEVEL]->(:Qualification {level:"A"})
      <-[:TEACHES]-(alevel_lo:LearningObjective)
RETURN alevel_lo.text, alevel_lo.difficulty ORDER BY alevel_lo.difficulty

// "Find all LOs across all qualifications that teach 'quadratic equations'"
MATCH (:Concept {name:"Quadratic Equations"})
      <-[:INSTANCE_OF]-(ci:ConceptInstance)
      -[:AT_LEVEL]->(q:Qualification)
      <-[:TEACHES]-(lo:LearningObjective)
      <-[:HAS_LO]-(st:Subtopic)<-[:HAS_SUBTOPIC]-(t:Topic)
RETURN q.name, t.name, st.name, lo.text, lo.difficulty, ci.depth
ORDER BY q.level, lo.difficulty

// "What are the prerequisite concepts for differential equations?"
MATCH (:Concept {name:"Differential Equations"})<-[:PREREQUISITE_OF*1..5]-(prereq:Concept)
RETURN prereq.name

// "What mastery transfer should a student get for A-Level from their IGCSE mastery?"
// (Concept-level mastery inference — cross-qualification adaptive learning)
MATCH (learner:Learner {id: $learner_id})
      -[:HAS_MASTERY {mastered: true}]->(mastered_lo:LearningObjective)
      -[:TEACHES]->(ci:ConceptInstance)
      -[:DEEPENS]->(next_ci:ConceptInstance)
      <-[:TEACHES]-(next_lo:LearningObjective)
WHERE NOT (learner)-[:HAS_MASTERY]->(next_lo)
RETURN next_lo, next_ci.depth AS recommended_starting_depth
```

---

## 4. Neo4j Deployment — Docker on WSL2

### 4.1 Docker Compose Configuration

```yaml
# ~/projects/mas_education_poc/docker-compose.neo4j.yml
version: '3.8'

services:
  neo4j:
    image: neo4j:5.26-community
    container_name: mas_neo4j
    ports:
      - "7474:7474"   # Neo4j Browser UI
      - "7687:7687"   # Bolt protocol (Python driver)
    environment:
      NEO4J_AUTH: neo4j/mas_education_poc_dev
      NEO4J_PLUGINS: '["apoc"]'              # APOC procedures for advanced graph ops
      NEO4J_dbms_security_procedures_unrestricted: "apoc.*"
    volumes:
      - neo4j_data:/data
      - neo4j_logs:/logs
      - ./neo4j/import:/var/lib/neo4j/import  # For bulk import files
    restart: unless-stopped

volumes:
  neo4j_data:
  neo4j_logs:
```

**Start/stop commands:**
```bash
# Start
docker compose -f docker-compose.neo4j.yml up -d

# Check status
docker compose -f docker-compose.neo4j.yml ps

# Browser UI (Windows browser)
# http://localhost:7474

# Stop
docker compose -f docker-compose.neo4j.yml down
```

### 4.2 Python Driver Setup

```bash
uv add neo4j  # neo4j Python driver (bolt protocol)
```

```python
from neo4j import GraphDatabase

driver = GraphDatabase.driver(
    "bolt://localhost:7687",
    auth=("neo4j", "mas_education_poc_dev")
)

# Health check
with driver.session() as session:
    result = session.run("RETURN 1 AS ok")
    print(result.single()["ok"])  # 1
```

### 4.3 Environment Variables (add to .env)

```bash
NEO4J_URI=bolt://localhost:7687
NEO4J_USER=neo4j
NEO4J_PASSWORD=mas_education_poc_dev
NEO4J_DATABASE=neo4j  # default database
```

---

## 5. Schema Indexes and Constraints

Neo4j needs indexes declared explicitly. These should be created on first run:

```cypher
-- Unique constraints (also create indexes automatically)
CREATE CONSTRAINT qualification_code IF NOT EXISTS
  FOR (q:Qualification) REQUIRE q.code IS UNIQUE;

CREATE CONSTRAINT concept_id IF NOT EXISTS
  FOR (c:Concept) REQUIRE c.id IS UNIQUE;

CREATE CONSTRAINT lo_id IF NOT EXISTS
  FOR (lo:LearningObjective) REQUIRE lo.id IS UNIQUE;

CREATE CONSTRAINT topic_id IF NOT EXISTS
  FOR (t:Topic) REQUIRE t.id IS UNIQUE;

CREATE CONSTRAINT subtopic_id IF NOT EXISTS
  FOR (st:Subtopic) REQUIRE st.id IS UNIQUE;

-- Lookup indexes (not unique)
CREATE INDEX lo_difficulty IF NOT EXISTS FOR (lo:LearningObjective) ON (lo.difficulty);
CREATE INDEX lo_bloom IF NOT EXISTS FOR (lo:LearningObjective) ON (lo.bloom_level);
CREATE INDEX concept_domain IF NOT EXISTS FOR (c:Concept) ON (c.domain);
```

---

## 6. Migration from SQLite — Preserving the POC

The existing 8-topic SQLite chain maps directly into the new KG. The migration is additive, not destructive — the SQLite remains the source for BKT mastery data during the transition.

**Mapping (current → KG):**

| SQLite `topics` row | KG representation |
|---|---|
| `quadratic-equations` | `:LearningObjective {id:"0580-ext-algebra-quadratic-factorise"}` (and related LOs) |
| `number-basics` | Multiple `:LearningObjective` nodes under `:Topic {name:"Number"}` |
| `linear-equations` | `:LearningObjective` nodes under "Equations and Inequalities" subtopic |
| prerequisite chain | `[:PREREQUISITE_OF]` edges between LOs + `[:PREREQUISITE_OF]` between Concepts |

**BKT state migration:**

The existing `learner_state` table:
```sql
learner_state: (learner_id, topic_id, p_mastery, evidence_count, last_updated)
```

Migrates to a relationship on the graph:
```cypher
(:Learner {id:"demo-student-001"})-[:HAS_MASTERY {
  p_mastery: 0.87,
  evidence_count: 5,
  last_updated: "2026-02-24",
  bkt_p_init: 0.05,
  bkt_p_learn: 0.20,
  bkt_p_slip: 0.15,
  bkt_p_guess: 0.15
}]->(:LearningObjective {id:"0580-ext-algebra-quadratic-equations"})
```

Storing BKT state *on the relationship* (not a separate node) is cleaner and more performant for mastery queries.

**Migration procedure:**
1. Build KG with full schema
2. Run migration script: for each `(learner_id, topic_id)` row, find the matching `:LearningObjective` node and create the `[:HAS_MASTERY]` relationship
3. Update `db.py`'s `get_next_topic()` and `update_mastery()` to query Neo4j via Bolt instead of SQLite
4. Keep SQLite running in parallel during validation period
5. Remove SQLite dependency once Neo4j queries are validated

---

## 7. Ingestion Strategy

### 7.1 Phase 1 — Curated YAML (immediate, for POC extension)

Define the graph schema in hand-curated YAML files per qualification. This is the most reliable first pass — human-verified, no extraction errors.

```yaml
# data/qualifications/igcse_0580.yaml
qualification:
  code: "0580"
  name: "Cambridge IGCSE Mathematics"
  level: "IGCSE"
  tiers: [Core, Extended]
  topics:
    - id: "0580-number"
      name: "Number"
      subtopics:
        - id: "0580-number-fractions"
          name: "Fractions, Decimals and Percentages"
          tier: Core
          learning_objectives:
            - id: "0580-core-number-fractions-convert"
              text: "Convert between fractions, decimals and percentages"
              tier: Core
              bloom_level: apply
              difficulty: 1
              concepts: [concept-fractions, concept-decimals, concept-percentages]
              prerequisites: []
```

An ingestion script reads these YAML files and creates the Neo4j graph via the Python driver.

### 7.2 Phase 2 — LLM-Assisted Extraction from Syllabus PDFs

Cambridge publishes official PDF syllabuses. Using Claude (Sonnet, with structured output) to extract:
- Topic names → `:Topic` nodes
- Subtopic names → `:Subtopic` nodes
- Learning objective text → `:LearningObjective` nodes with `text`, `tier`, `exam_command` properties

The Cambridge PDFs use consistent formatting; extraction quality will be high with a well-engineered prompt.

```python
# Pseudocode for extraction pipeline
def extract_syllabus(pdf_path: str, qualification_code: str) -> dict:
    text = extract_pdf_text(pdf_path)
    response = anthropic_client.messages.create(
        model="claude-sonnet-4-6",
        system=EXTRACTION_SYSTEM_PROMPT,
        messages=[{"role": "user", "content": f"Extract the following from this Cambridge syllabus:\n{text}"}],
        max_tokens=8000
    )
    return parse_structured_json(response.content[0].text)
```

### 7.3 Phase 3 — Concept and ConceptInstance Extraction

After Phase 1-2 create the LO layer, run a concept extraction pass using the Concept-Instance pattern:
1. For each `:LearningObjective`, use Claude to identify which abstract `:Concept` it teaches
2. Group LOs by qualification level → create one `:ConceptInstance` node per (Concept, qualification, tier) combination
3. Write `[:TEACHES]` edges: LO → ConceptInstance; `[:INSTANCE_OF]` edges: ConceptInstance → Concept
4. Write `[:AT_LEVEL]` edges: ConceptInstance → Qualification
5. Claude identifies the spiral depth chain → creates `[:DEEPENS]` edges between ConceptInstances across qualifications
6. Human review validates the DEEPENS chain (this is high-stakes — one wrong link misroutes learners)
7. Write `[:BELONGS_TO]` edges: Concept → MathDomain

### 7.4 Phase 4 — RAG Integration

Link `:LearningObjective` nodes to ChromaDB chunks:
1. For each `:LearningObjective`, query ChromaDB: `retrieve(query=lo.text, subject="mathematics")`
2. Top chunks become `:Resource` nodes with `[:HAS_RESOURCE]` edges from the LO
3. This creates a live bridge: the KG knows which curriculum chunks are relevant for each LO
4. The Tutor Agent can query Neo4j for the current LO, follow `[:HAS_RESOURCE]` edges, and retrieve exactly the right chunks — rather than relying on semantic search alone

---

## 8. Updated Planning Agent Design

The new `planning_agent.py` will use Neo4j queries instead of SQLite:

```python
# New get_next_topic() — Neo4j version
def get_next_topic(learner_id: str) -> dict:
    with driver.session() as session:
        result = session.run("""
            // Find the highest-difficulty LO the learner hasn't mastered
            // whose prerequisites are all mastered
            MATCH (learner:Learner {id: $learner_id})
            MATCH (lo:LearningObjective)
            WHERE NOT (learner)-[:HAS_MASTERY {mastered: true}]->(lo)
              AND ALL(prereq IN [(lo)<-[:PREREQUISITE_OF]-(p) | p]
                     WHERE (learner)-[:HAS_MASTERY {mastered: true}]->(prereq))
            RETURN lo
            ORDER BY lo.difficulty ASC
            LIMIT 1
        """, learner_id=learner_id)
        return result.single()
```

Key capability upgrades over SQLite:
- Can traverse prerequisite DAGs (not just linear chains)
- Can recommend next LO based on mastered Concepts (cross-qualification awareness)
- Can use graph algorithms (Neo4j APOC): shortest path, centrality, community detection
- Can produce a personalised learning map visualisation via Neo4j Browser

---

## 9. Extensibility — The USP Beyond Cambridge Maths

The schema is deliberately designed to extend beyond Cambridge International Maths. Additions require no schema changes:

**Other Cambridge subjects:** Add `:Qualification {code:"0625", name:"Physics"}` etc. The `:Concept` layer naturally accommodates "force" in Physics and "vector decomposition" in Mathematics being prerequisites of each other — cross-subject, not just cross-qualification. Each subject adds its own `:ConceptInstance` nodes that point at the shared `:Concept` layer.

**Other awarding bodies:** Add `:AwardingBody` node (`{name:"AQA"}`, `{name:"Edexcel"}`). Link to `:Qualification`. The Concept layer is entirely awarding-body-agnostic — `:Concept {name:"Quadratic Equations"}` is shared between Cambridge and AQA. Each awarding body produces its own `:ConceptInstance` nodes, so Cambridge's depth profile and AQA's depth profile for the same concept are separately modelled but linked at the abstract Concept level.

**Other languages:** `:LearningObjective` text is a property — multilingual LOs can be added without schema changes (`text_en`, `text_fr`, etc.).

**Other stages:** Cambridge Primary (ages 5-11) would add `:Qualification {level:"Primary"}` nodes. The `[:DEEPENS]` chain from Primary → IGCSE → A-Level would create a complete 5-18 learning graph.

---

## 10. Estimated Scale

At full Cambridge Secondary+ Maths scope:

| Node Type | Estimated Count |
|---|---|
| `:Qualification` | 4 (0580, 0606, 9709, 9231) |
| `:Component` | ~15 (9709 has 6, 9231 has 4, IGCSE has tiers) |
| `:MathDomain` | 6 |
| `:Topic` | ~50 (across 4 qualifications) |
| `:Subtopic` | ~200 |
| `:LearningObjective` | ~500-700 |
| `:ConceptInstance` | ~150-200 (1-3 per Concept per qualification) |
| `:Concept` | ~150-200 (shared abstract nodes, awarding-body agnostic) |
| `:Skill` | ~20 |
| `:Resource` | ~100-300 (ChromaDB chunk links, grows with RAG content) |
| **Total nodes** | **~1,200-1,500** |
| **Total relationships** | **~4,000-6,000** |

This is well within Neo4j Community Edition limits (no constraint on node count). At this scale, all queries will return in <10ms.

---

## 11. Implementation Roadmap

### Phase 0 — Infrastructure (1-2 hours)
- [ ] Add Docker Compose file for Neo4j 5.26 Community
- [ ] Verify Neo4j Browser accessible at localhost:7474 from Windows browser
- [ ] Add `neo4j` Python package to pyproject.toml
- [ ] Create `.env` variables for Neo4j connection
- [ ] Write `db/kg.py` — Neo4j driver singleton and basic CRUD helpers
- [ ] Create indexes and constraints (Cypher script)

### Phase 1 — Core Graph Build (1-2 days)
- [ ] Create YAML curriculum files for IGCSE 0580 (full topic/subtopic structure)
- [ ] Write ingestion script: YAML → Neo4j nodes and structural edges
- [ ] Seed 0580 qualification, 4 topics, ~40 subtopics, ~130 LOs
- [ ] Add 8 existing POC topics as LOs, preserving IDs for compatibility
- [ ] Validate: Cypher queries return expected topic chains

### Phase 2 — Concept and ConceptInstance Layer (3-4 days)
- [ ] Define ~50 initial Concept nodes for IGCSE Maths (manual YAML)
- [ ] Run concept extraction pass: Claude maps each LO → Concept
- [ ] Create ConceptInstance nodes: one per (Concept, qualification, tier) combination
- [ ] Write `[:TEACHES]` edges: LO → ConceptInstance
- [ ] Write `[:INSTANCE_OF]` edges: ConceptInstance → Concept
- [ ] Write `[:AT_LEVEL]` edges: ConceptInstance → Qualification
- [ ] Write `[:PREREQUISITE_OF]` edges between Concepts
- [ ] Human review: validate DEEPENS chain and INSTANCE_OF assignments
- [ ] Validate: cross-concept prerequisite queries work correctly
- [ ] Validate: "path from Number basics to Quadratic equations" query returns sensible result

### Phase 3 — Multi-qualification (1 week)
- [ ] Add IGCSE Additional Maths (0606) — YAML + ingestion
- [ ] Add AS/A-Level (9709) — YAML + ingestion (largest volume)
- [ ] Add Further Maths (9231) — YAML + ingestion
- [ ] Create ConceptInstance nodes for each new qualification level
- [ ] Write `[:DEEPENS]` edges across qualification ConceptInstances (the spiral curriculum chain)
- [ ] Validate cross-qualification queries: mastery transfer, A-Level preparation paths

### Phase 4 — Planning Agent Migration (1-2 days)
- [ ] Rewrite `get_next_topic()` as Cypher query
- [ ] Rewrite `check_advancement()` as Cypher query
- [ ] Migrate `learner_state` to `[:HAS_MASTERY]` relationships
- [ ] Update `demo.py` and `chat_ui.py` to use Neo4j-backed Planning Agent
- [ ] Full end-to-end test: student interaction with Neo4j routing

### Phase 5 — RAG Integration (1 day)
- [ ] Write `[:HAS_RESOURCE]` edges from LOs to ChromaDB chunk IDs
- [ ] Update Tutor Agent RAG retrieval to optionally use KG-guided chunk selection
- [ ] Add more curriculum markdown files to ChromaDB (currently 3 of 8 topics covered)

---

## 12. Open Questions

1. **Concept node seeding:** Should the initial Concept nodes be hand-curated (controlled, accurate but slow) or LLM-extracted from the LO text (faster but needs human review pass)? Recommendation: hand-curate the ~50 most important IGCSE concepts, then LLM-extract for A-Level with review.

2. **BKT parameters per qualification level:** Should IGCSE-level LOs and A-Level LOs have different default BKT parameters? A-Level content is harder to "lucky-guess" (lower P(G)), takes longer to learn (lower P(T)). Recommendation: yes — set defaults by qualification level, overridable per LO.

3. **Partial mastery across qualifications:** If a student has mastered the IGCSE Extended quadratics LO, should their A-Level `p_mastery` for the equivalent LO start above the default P(L₀)=0.10? Recommendation: yes — via the DEEPENS relationship and concept mastery transfer. This is a significant adaptive learning feature worth scoping.

4. **Syllabus PDF access:** Official Cambridge PDF syllabuses are available free on the Cambridge International website. For Phase 2 LLM extraction, do we download them locally or scrape on demand?

5. **Neo4j APOC Plugin:** The Docker config includes APOC (Awesome Procedures on Cypher). This enables advanced graph algorithms (shortest path, centrality, community detection). Is there appetite to use these for learning pathway visualisation?

---

## 13. References and Sources

- [Cambridge International Programmes and Qualifications](https://www.cambridgeinternational.org/programmes-and-qualifications/)
- [Cambridge IGCSE Mathematics (0580) Syllabus 2025-2027](https://www.cambridgeinternational.org/Images/662466-2025-2027-syllabus.pdf)
- [Cambridge International AS & A Level Mathematics (9709)](https://www.cambridgeinternational.org/programmes-and-qualifications/cambridge-international-as-and-a-level-mathematics-9709/)
- [CTDL-ASN: Competency Framework International Standard](https://credreg.net/ctdlasn/terms)
- [CASE — Competencies and Academic Standards Exchange (1EdTech / IMS Global)](https://www.imsglobal.org/activity/case) — standard for machine-readable curriculum frameworks; sits alongside CTDL-ASN as an interoperability target for the KG
- [Systematic Literature Review: Knowledge Graphs in Education (PMC, 2024)](https://pmc.ncbi.nlm.nih.gov/articles/PMC10847940/)
- [Cambridge Curriculum Progression Design Methodology](https://blog.cambridgeinternational.org/developing-curriculum-progression-forwards-backwards-up-down-and-across/)
- [Design and Implementation of Curriculum System Based on Knowledge Graph (arXiv:2012.12522)](https://arxiv.org/abs/2012.12522)
- [Spiral Curriculum — Bruner (1960); research review at Third Space Learning](https://thirdspacelearning.com/us/blog/spiral-curriculum/)
- [Neo4j LLM Knowledge Graph Builder (2025)](https://medium.com/neo4j/llm-knowledge-graph-builder-first-release-of-2025-532828c4ba76)
- [Knowledge Graph in Neo4j for Student Success — ASIS&T Case Study](https://www.asist.org/meetings-events/webinars/knowledge-graph-in-neo4j-for-helping-student-success-a-case-study/)
- [Knewton Adaptive Learning Architecture — Four-Object Model](https://www.knewton.com/resources/blog/) — Concept-Instance pattern informed by Knewton's distinction between abstract concepts and qualification-specific concept instances

---

*Document status: PLANNING*
*Related files: `AGENT_ARCHITECTURE_REPORT.md`, `USER_GUIDE.md`, `BUILD_PLAN.md`*
*Next action: Review open questions (Section 12). On confirmation, proceed to Phase 0 implementation.*
