# Curriculum Math Audit Report

**Run date:** 2026-03-05 07:19 UTC  
**Files checked:** 41  
**Claims verified:** 78  
**PASS:** 78 | **FAIL:** 0 | **SKIP (unparseable):** 44

## ✅ No mathematical errors found in curriculum files

## ✅ Verified Claims (PASS)

- `(8/3 - 8) - (-8/3 + 8) = -16/3 - 16/3` — 0606_calculus.md:105
- `2**3 = 8.` — 0606_logarithms_exponentials.md:15
- `3**(-2) = 1/9.` — 0606_logarithms_exponentials.md:16
- `5**0 = 1` — 0606_polynomial_algebra.md:25
- `9 - 40 = -31` — 0606_polynomial_algebra.md:39
- `6 + 33 + 4 = 43.` — 9231_further_matrices.md:29
- `(2-(-2))/(4-1) = 4/3.` — 9709_functions_coord_geometry.md:53
- `10 * 82 = 820.` — 9709_sequences_series.md:15
- `2 * 243 = 486.` — 9709_sequences_series.md:41
- `2 * 728 / 2 = 728.` — 9709_sequences_series.md:42
- `12 / (2/3) = 18.` — 9709_sequences_series.md:53
- `3 * 210 - 20 = 630 - 20` — 9709_sequences_series.md:88
- `48 + 6 = 54` — algebra_expressions.md:13
- `5**0 = 1` — algebra_index_laws.md:17
- `(1000)**0 = 1` — algebra_index_laws.md:17
- `2**(-1) = 1/2` — algebra_index_laws.md:25
- `2**2 = 4` — algebra_index_laws.md:35
- `2**3 = 8` — algebra_index_laws.md:36
- `4+1 = 5` — algebra_sequences.md:22
- `8+1 = 9` — algebra_sequences.md:22
- `9+3+1 = 13` — algebra_sequences.md:50
- `6/3 = 2.` — algebra_straight_line_graphs.md:23
- `6/2 = 3` — algebra_straight_line_graphs.md:38
- `60 - 12 = 48` — geometry_mensuration.md:43
- `((25)**(0.5)) = 5` — geometry_mensuration.md:53
- `4 * 2 = 8` — geometry_similarity.md:29
- `5 * 2 = 10` — geometry_similarity.md:29
- `9 + 16 = 25` — geometry_trigonometry.md:8
- `169 - 25 = 144` — geometry_trigonometry.md:13
- `74 - 35 = 39` — geometry_trigonometry.md:54
- `((169)**(0.5)) = 13` — geometry_vectors.md:68
- `3 * 4 = 12` — number_and_algebra_basics.md:9
- `(-3) * (-4) = 12` — number_and_algebra_basics.md:10
- `3 * (-4) = -12` — number_and_algebra_basics.md:11
- `(-3) * 4 = -12` — number_and_algebra_basics.md:12
- `5 + (-3) = 5 - 3` — number_and_algebra_basics.md:15
- `3/5 - 1/4 = 12/20 - 5/20` — number_and_algebra_basics.md:24
- `6/12 = 1/2` — number_and_algebra_basics.md:28
- `10/12 = 5/6` — number_and_algebra_basics.md:32
- `20/6 = 10/3` — number_and_algebra_basics.md:36
- `0.30 * 80 = 24` — number_and_algebra_basics.md:40
- `(15/60) * 100 = 25` — number_and_algebra_basics.md:41
- `((16)**(0.5)) = 4` — number_and_algebra_basics.md:57
- `((8)**(1/3)) = 2` — number_and_algebra_basics.md:58
- `3 * 4 = 12` — number_basics.md:9
- `(-3) * (-4) = 12` — number_basics.md:10
- `3 * (-4) = -12` — number_basics.md:11
- `(-3) * 4 = -12` — number_basics.md:12
- `5 + (-3) = 5 - 3` — number_basics.md:15
- `3/5 - 1/4 = 12/20 - 5/20` — number_basics.md:24
- `6/12 = 1/2` — number_basics.md:28
- `10/12 = 5/6` — number_basics.md:32
- `20/6 = 10/3` — number_basics.md:36
- `0.30 * 80 = 24` — number_basics.md:40
- `(15/60) * 100 = 25` — number_basics.md:41
- `((16)**(0.5)) = 4` — number_basics.md:57
- `((8)**(1/3)) = 2` — number_basics.md:58
- `3/4 = 6/8` — number_fractions_percentages.md:7
- `3/5 - 1/3 = 9/15 - 5/15` — number_fractions_percentages.md:12
- `2/3 * 4/5 = 8/15` — number_fractions_percentages.md:16
- `21/10 = 2 1/10` — number_fractions_percentages.md:21
- `28/12 + 15/12 = 43/12` — number_fractions_percentages.md:26
- `3/8 = 3 / 8` — number_fractions_percentages.md:31
- `((49)**(0.5)) = 7` — number_powers_roots.md:7
- `((27)**(1/3)) = 3` — number_powers_roots.md:16
- `(-3)**3 = -27` — number_powers_roots.md:18
- `5**3 = 125` — number_powers_roots.md:24
- `6.7 * 10**4 = 67000` — number_powers_roots.md:44
- `1.2 * 10**(-3) = 0.0012` — number_powers_roots.md:45
- `90 + 150 = 240` — number_ratio_proportion.md:21
- `16+24+32 = 72` — number_ratio_proportion.md:25
- `48 / 4 = 12` — number_ratio_proportion.md:47
- `2 * 3 = 6` — quadratic_equations.md:8
- `2 + 3 = 5.` — quadratic_equations.md:8
- `25/5 = 5` — statistics_measures.md:8
- `8/10 = 4/5` — statistics_probability.md:26
- `12/42 = 2/7` — statistics_probability.md:74
- `144 + 96 + 120 = 360` — statistics_representation.md:14