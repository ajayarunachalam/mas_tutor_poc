# MAS Education POC — Development Guide

> A technical reference for developers. Covers how the system was built, how each component works, and the design decisions behind them.

**Last updated:** 13 June 2026
**Codebase:** `~/projects/mas_education_poc`
**Live service:** https://mas-tutor.com

---

## Contents

1. [Project Overview](#1-project-overview)
2. [Development Chronology](#2-development-chronology)
3. [System Architecture](#3-system-architecture)
4. [API Layer — `chat_ui.py`](#4-api-layer--chat_uipy)
5. [Orchestrator — `orchestrator/poc_orchestrator.py`](#5-orchestrator--orchestratorpoc_orchestratorpy)
6. [Agents](#6-agents)
7. [RAG Pipeline — `rag/`](#7-rag-pipeline--rag)
8. [Database Layer — `db/`](#8-database-layer--db)
9. [OpenRouter Compatibility Layer](#9-openrouter-compatibility-layer)
10. [Dashboard — `dashboard.py`](#10-dashboard--dashboardpy)
11. [Production Deployment](#11-production-deployment)
12. [Testing](#12-testing)
13. [Key Design Decisions](#13-key-design-decisions)
14. [Pedagogical Improvements (June 2026)](#14-pedagogical-improvements-june-2026)

---

## 1. Project Overview

The MAS Education POC is a multi-agent Socratic tutoring system for GCSE Maths, built to demonstrate that AI tutoring can be principled, auditable, and pedagogically sound — not just a chat interface wrapped around an LLM.

**Core thesis:** A single LLM answering questions is a search engine with a personality. Real pedagogical value requires specialised agents with distinct roles, mathematical verification, principled mastery tracking, and behaviour that adapts to each individual learner.

**Technical goals:**
- Show that LangGraph multi-agent coordination scales to real pedagogical problems
- Demonstrate RAG-grounded responses (no hallucination) as a constitutional requirement
- Show that Bayesian Knowledge Tracing can run on Neo4j and update in real time
- Demonstrate that Socratic method can be operationalised in an LLM with guardrails

---

## 2. Development Chronology

The system was built across four sessions between February and June 2026.

### Session 1: Initial Build (23–24 Feb 2026)

Built the complete core system in a single session. Seven stages:

| Stage | What Was Built |
|---|---|
| 1 | Environment: `uv`, Python 3.11, `langgraph`, `anthropic`, `chromadb`, `agentstack-sdk` |
| 2 | RAG pipeline: curriculum ingestion, HyDE retrieval, ChromaDB `poc_curriculum` collection (9 chunks) |
| 3 | SQLite schema: 5 tables, BKT parameters, 8 topic seed data |
| 4 | Tutor Agent (RAG-grounded, Socratic) + Assessment Agent (BKT scoring) |
| 5 | Planning Agent, Dialogue Agent (5-state machine), Monitor Agent (cost tracking) |
| 6 | LangGraph orchestrator: 7-node session graph with conditional intent routing |
| 7 | BeeAI A2A server on port 8000; end-to-end DB writes confirmed |

Immediately after the core build, the Neo4j Knowledge Graph was added (KG Phases 0–5):

| Phase | What Was Built |
|---|---|
| 0 | Docker Neo4j 5.x, `db/kg.py` driver, schema constraints |
| 1 | YAML → Neo4j ingest: Qualification/Topic/Subtopic/LO nodes for all 4 qualifications |
| 2 | LLM concept extraction: 77 Concepts, 114 ConceptInstances, TEACHES/INSTANCE_OF edges |
| 3 | Prerequisite derivation: 20 DEEPENS edges, 5 spiral chains, cross-qual edges |
| 4 | Planning + Assessment agents migrated from SQLite to Neo4j; BKT on LO nodes |
| 5 | 22 new curriculum markdown files; ChromaDB 12 → 79 chunks; 200 HAS_RESOURCE edges |

**State after Session 1:** 5 agents running under LangGraph, Neo4j KG with 4 qualifications, 191 LOs, ChromaDB with 79 chunks.

---

### Session 2: Dashboard + RAG Hardening (4 March 2026)

Three independent improvements:

**Topic Stability Fix** — the orchestrator was calling `get_next_lo()` on every turn, switching topics mid-conversation. Fixed with a first-turn guard: Neo4j is only consulted when `current_topic == "unknown"`.

**Learning Progress Dashboard** — added `dashboard.py` FastAPI router with:
- Stat cards (total LOs, mastered, progress %)
- Cytoscape.js knowledge graph (nodes coloured by mastery)
- "What's Next" LO recommendation cards

**RAG Improvements:**
- Expanded curriculum from 79 to 146 chunks across all 4 qualifications (0580, 0606, 9709, 9231)
- Added `RELEVANCE_THRESHOLD` (default 0.15): chunks scoring below this are filtered post-rerank
- Replaced term-overlap reranker with Claude Haiku cross-encoder — single batch call scores all chunks 0–10

---

### Session 3: Mathematical Verification (5 March 2026)

Three safety layers added to prevent mathematical errors:

**Phase A — Assessment Agent Sympy Check:** Student answers now checked with SymPy. LLM says CORRECT but SymPy says wrong → PARTIAL. LLM says INCORRECT but SymPy confirms → PARTIAL.

**Phase B — Tutor Agent Sympy Check:** Tutor's own assertive claims verified before delivery. Wrong claims trigger one correction regeneration. Exploratory Socratic suggestions ("try x = 3") are deliberately excluded.

**Phase C — Curriculum Audit:** `scripts/audit_curriculum.py` parsed all 41 curriculum files, verified 78 numeric claims symbolically. Result: 0 failures.

---

### Session 4: Production Hardening + Synthetic Testing (June 2026)

**Production hardening (40-ISC build):**
- Migrated from direct Anthropic API to OpenRouter (resilient fallback routing)
- Added `slowapi` rate limiting: 20/min, 200/hr, 1k/day per IP
- Added Pydantic input validation (message length, learner_id pattern)
- Added session capacity limit (200 concurrent sessions, 30-min TTL)
- Added security headers middleware (X-Content-Type-Options, X-Frame-Options, X-XSS-Protection)
- Added structured JSON audit logging to file
- Added retry logic (3 attempts, exponential backoff)
- Added FAQ static intercept (no LLM cost for meta-questions)
- Deployed to Scaleway VPS with Caddy TLS reverse proxy at mas-tutor.com
- Built full test suite (36 tests: 17 unit, 19 integration)

**Synthetic persona testing and 7 pedagogical improvements** (see §14).

---

## 3. System Architecture

```
                    ┌─────────────────────────────────┐
                    │         HTTPS (Caddy TLS)         │
                    │       mas-tutor.com → :8080       │
                    └─────────────────┬───────────────┘
                                      │
                    ┌─────────────────▼───────────────┐
                    │          chat_ui.py              │
                    │       FastAPI + slowapi          │
                    │  Session mgmt · FAQ intercept    │
                    │  Distress triage · Rate limit    │
                    └─────────────────┬───────────────┘
                                      │
                    ┌─────────────────▼───────────────┐
                    │    poc_orchestrator.py           │
                    │    LangGraph 7-node graph        │
                    │                                  │
                    │  session_init → route_intent     │
                    │       ↓               ↓          │
                    │   tutoring       assessment      │
                    │       ↓               ↓          │
                    │    reflect ←──────────┘          │
                    │       ↓                          │
                    │   deliver → log_update → END     │
                    └──┬────────────┬────────────┬────┘
                       │            │            │
          ┌────────────▼──┐  ┌──────▼──────┐  ┌▼─────────────┐
          │ Tutor Agent   │  │ Assessment  │  │ Planning     │
          │               │  │ Agent       │  │ Agent        │
          │ RAG-grounded  │  │ BKT + sympy │  │ Neo4j KG     │
          │ Socratic Q    │  │ scoring     │  │ LO routing   │
          └───────┬───────┘  └─────────────┘  └─────────────┘
                  │
          ┌───────▼──────────────────────────┐
          │          RAG Pipeline             │
          │  Stage 1: HyDE query enhancement  │
          │  Stage 2: ChromaDB retrieval      │
          │  Stage 3: LLM cross-encoder       │
          │  Threshold filter                 │
          └───────┬───────────────────────────┘
                  │
    ┌─────────────▼──────────┐   ┌────────────────────┐
    │  ChromaDB              │   │  Neo4j             │
    │  146 curriculum chunks │   │  4 quals, 191 LOs  │
    │  41 topics             │   │  77 concepts       │
    │  qwen3-embedding:8b    │   │  BKT mastery state │
    └────────────────────────┘   └────────────────────┘

    ┌─────────────────────────────┐
    │  OpenRouter                 │
    │  LLM gateway (OpenAI-compat)│
    │  anthropic/claude-sonnet-4-6│
    └─────────────────────────────┘

    ┌─────────────────────────────┐
    │  SQLite (mas_poc.db)        │
    │  session_log, audit_events  │
    │  learner_state, bkt_params  │
    └─────────────────────────────┘
```

### Technology Stack

| Layer | Technology |
|---|---|
| API server | FastAPI + uvicorn |
| Rate limiting | slowapi |
| Orchestration | LangGraph |
| LLM provider | OpenRouter → claude-sonnet-4-6 |
| LLM client | openai SDK (OpenRouter-compatible endpoint) |
| Vector database | ChromaDB (PersistentClient) |
| Embeddings | Ollama qwen3-embedding:8b (local) |
| Graph database | Neo4j 5.x (Docker) |
| Math verification | SymPy |
| Relational DB | SQLite |
| Reverse proxy | Caddy 2.x (TLS auto-provisioning) |
| Process manager | systemd |
| Dependency manager | uv |

---

## 4. API Layer — `chat_ui.py`

The entry point for all HTTP traffic. FastAPI app serving the chat UI and API endpoints.

### Startup Sequence

```python
init_database()   # SQLite: idempotent table/seed creation
if OPENROUTER_API_KEY:
    anthropic_client = OpenRouterClient(api_key=...)
else:
    anthropic_client = Anthropic(api_key=...)  # fallback for local dev

limiter = Limiter(key_func=get_remote_address)
app = FastAPI(...)
app.state.limiter = limiter
app.include_router(dashboard_router)
```

On startup, a background async task starts the session cleanup loop (every 5 minutes).

### Session Management

Sessions are held in an in-memory dict `active_sessions: dict[str, dict]`. Each entry contains:

```python
{
    "session_id": "a3f1c2b8",
    "tracker": DialogueTracker,     # engagement state machine
    "orchestrator": LangGraph,      # compiled 7-node graph
    "history": [],                  # last 40 message pairs
    "current_topic": None,
    "current_topic_name": "Mathematics",
    "turn_count": 0,
    "last_active": datetime,
    "ability_signal": 0,            # correct-answer streak counter
    "guidance_resistance_count": 0, # direct-answer demand counter
}
```

**Capacity guard:** If `len(active_sessions) >= 200`, new sessions return HTTP 503. Sessions expire after 30 minutes of inactivity.

**Session identity:** `learner_id` is the key. The browser sends a UUID it generated on page load. Different browsers = different sessions.

### Pre-Processing Pipeline (per `/chat` request)

Before the orchestrator is called, the server runs three intercepts in order:

1. **FAQ intercept** — `_check_faq(text)`: keyword matching against known meta-questions. Returns a static string; no LLM call.

2. **Distress triage** — `_check_vague_distress(text)`: matches general helplessness phrases ("I'm completely lost", "I can't do maths"). Returns a static topic-choice menu; no LLM call.

3. **Resistance tracking** — `_is_resistance(text)`: detects direct-answer demands ("just tell me", "give me the answer"). Increments `guidance_resistance_count` in session state. Does NOT intercept — the message still goes to the orchestrator, but with the counter updated.

### Rate Limiting

Three nested limits using `slowapi`:

```python
@limiter.limit("20/minute;200/hour;1000/day")
async def chat(request: Request, req: ChatRequest):
```

The key function is `get_remote_address`, so limits are per client IP.

### Orchestrator Invocation

```python
async def _invoke_orchestrator(orchestrator, state, max_attempts=3):
    for attempt in range(max_attempts):
        try:
            return orchestrator.invoke(state)  # sync call
        except Exception as e:
            if "credit balance" in str(e) or "AuthenticationError" in str(e):
                raise  # permanent errors — don't retry
            await asyncio.sleep(2 ** attempt)  # exponential backoff
```

**Important:** `orchestrator.invoke()` is a synchronous blocking call, not `await`ed. LangGraph's sync interface internally calls `asyncio.run()`, which conflicts with `asyncio.wait_for` when a loop is already running. The timeout is delegated to the OpenRouter/HTTPX client settings instead.

### Security Headers Middleware

```python
response.headers["X-Content-Type-Options"] = "nosniff"
response.headers["X-Frame-Options"] = "DENY"
response.headers["X-XSS-Protection"] = "1; mode=block"
response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
```

Applied to every response via FastAPI middleware.

---

## 5. Orchestrator — `orchestrator/poc_orchestrator.py`

The LangGraph session graph coordinates all agents. It defines the `SessionState` TypedDict and seven nodes wired into a directed graph.

### SessionState

```python
class SessionState(TypedDict):
    session_id: str
    learner_id: str
    student_input: str
    conversation_history: list[dict]
    current_topic: str           # LO ID (e.g. "quadratic-equations")
    current_topic_name: str      # Human text (e.g. "quadratic equations")
    intent: str                  # "tutor" | "assess" | "plan" | "unknown"
    agent_response: str
    rag_chunks: list[dict]
    citations: list[str]
    mastery: float
    engagement_state: str
    intervention_prompt: str
    should_assess: bool
    advancement_check: dict
    turn_count: int
    ability_signal: int          # CORRECT answers accumulated
    guidance_resistance_count: int
```

### Graph Topology

```
session_init
     │
     ▼
route_intent ──── conditional ──── tutoring ──── reflect
                                               /
                              assessment ──────
                                               \
                                           deliver
                                               │
                                          log_update
                                               │
                                             END
```

### Node Descriptions

**`session_init`** — On the first turn (when `current_topic == "unknown"`), queries Neo4j for the learner's lowest-difficulty unmastered LO. On all subsequent turns, preserves the existing topic. Additionally, scans the student's message for topic keywords (e.g. "quadratic", "trigonometry") and overrides `current_topic_name` if a match is found, ensuring the LLM context reflects what the student is actually asking about rather than the curriculum ladder's assignment.

**`route_intent`** — Classifies the message as `"assess"` or `"tutor"` using keyword matching. Assessment signals include a wide range of natural-language answer patterns: "I think", "I got", "the answer is", "so x =", "therefore", "my working shows". Assessment routing only triggers after turn 1 (first turn is always tutoring to establish context).

**`tutoring_node`** — Calls `get_tutor_response()`. Before calling, augments the student input with:
- A dialogue intervention string if the Dialogue Agent detected a state transition
- An ability hint if `ability_signal >= 2` (matched pace, offer extension)
- A resistance hint if `guidance_resistance_count >= 2` (shift Socratic strategy)

**`assessment_node`** — Calls `score_response()`. Filters the `misconception` field: if it contains internal diagnostic language ("the student", "discussing", "rather than") it is suppressed before being shown to the student. Increments `ability_signal` on CORRECT scores.

**`reflect_node`** — Updates the Dialogue Agent's engagement state machine. If `advancement_check` signals topic mastery, updates `current_topic` to the next LO.

**`deliver_node`** — Currently a pass-through. Intended for future response formatting (e.g. LaTeX rendering, citation display formatting).

**`log_update_node`** — Appends the exchange to `conversation_history` (trimmed to last 12 messages / 6 turns). Logs a `turn_complete` event to the session monitor.

### Topic Override Logic

```python
_TOPIC_OVERRIDES: list[tuple[tuple[str, ...], str]] = [
    (("quadratic", "factorise", "x squared", "x²"), "quadratic equations"),
    (("trigonometry", "sine", "cosine", "tangent", "pythagoras"), "trigonometry"),
    # ... 14 topics total
]

def _detect_topic_from_message(text: str) -> str | None:
    lowered = text.lower()
    for keywords, topic_name in _TOPIC_OVERRIDES:
        if any(kw in lowered for kw in keywords):
            return topic_name
    return None
```

This runs on every turn, so if a student switches topic mid-conversation, the system detects it.

---

## 6. Agents

### 6.1 Tutor Agent (`agents/tutor_agent.py`)

The core pedagogical agent. Every response must be grounded in RAG-retrieved curriculum content (C4 constitutional principle).

**Main function:** `get_tutor_response(student_input, conversation_history, session_id, learner_id, current_topic, lo_id, anthropic_client)`

**Flow:**
1. Call `retrieve()` with the student input and current LO ID
2. If RAG returns chunks: inject as `CURRICULUM CONTEXT` into the LLM message; call Claude Sonnet
3. If RAG returns empty: log `rag_fallback_llm` audit event; call Claude Sonnet with a reduced system prompt
4. Apply `_strip_metacommentary()` to the response
5. Call `verify_tutor_claims()` — if SymPy finds a wrong assertion, regenerate once
6. Log audit event with `math_verified`, `math_corrected` flags

**Meta-commentary filter:**
```python
_METACOMMENTARY_PATTERNS = (
    "student appears", "the student has", "let me reconsider",
    "different topic", "student is confusing", ...
)

def _strip_metacommentary(text: str) -> str:
    lines = text.split("\n")
    clean = [l for l in lines if not any(p in l.lower() for p in _METACOMMENTARY_PATTERNS)]
    return "\n".join(clean).strip() or "What part of this topic would you like to explore?"
```

**Model selection:** `_select_model()` can route short messages to a secondary (cheaper) model. Currently disabled unless `LLM_SECONDARY` is explicitly set in the environment — prevents silent failures from an unavailable model ID.

**System prompt excerpt:**
```
ABSOLUTE RULES:
1. You MUST only use information from the CURRICULUM CONTEXT provided
2. If the context does not contain enough information, say: "Let me check that with your teacher."
3. Never give the answer directly — guide the student to discover it through questions
4. Ask ONE question at a time. Never ask multiple questions in one response.
7. NEVER narrate your reasoning or emit meta-commentary.
```

---

### 6.2 Assessment Agent (`agents/assessment_agent.py`)

Scores student responses and updates BKT mastery in Neo4j.

**Main function:** `score_response(student_response, topic_id, expected_concept, session_id, learner_id, anthropic_client, question_context)`

**Scoring:** LLM is prompted for `SCORE: CORRECT|PARTIAL|INCORRECT`, `MISCONCEPTION: [description or "none"]`, `CONFIDENCE: HIGH|MEDIUM|LOW`, `FEEDBACK: [one sentence]`. The system prompt explicitly forbids using the MISCONCEPTION field for topic-mismatch observations — it must describe a mathematical error the student actually made.

**SymPy cross-check:**
```python
math_check = math_verify_response(student_response, question_context)
if score == "CORRECT" and math_check.verified is False:
    score = "PARTIAL"   # LLM over-scored
if score == "INCORRECT" and math_check.verified is True:
    score = "PARTIAL"   # LLM under-scored
```

The `verified=None` case (no equation detected, or ambiguous) is the safe default — no SymPy adjustment.

**BKT update:**
```python
is_correct = (score == "CORRECT")
new_mastery = bkt_update_kg(learner_id, topic_id, is_correct)
mastered = new_mastery >= MASTERY_THRESHOLD  # 0.85
```

**Self-reflection trigger:** checks if mastery has been stalled (< 10% improvement across the last 3 assessment events). Currently returns a flag; the LLM policy adjustment call is logged but not actioned in the POC.

---

### 6.3 Planning Agent (`agents/planning_agent.py`)

Determines the learner's current position in the GCSE topic ladder and manages advancement.

**`get_learner_plan(learner_id, session_id)`** — queries Neo4j for the learner's lowest-difficulty unmastered LO using prerequisite edges. Returns the current LO metadata.

**`check_advancement(learner_id, topic_id, session_id)`** — checks whether the learner has hit the mastery threshold (≥ 0.85 BKT) with sufficient evidence events (≥ 5 CORRECT). If so, queries Neo4j for the next LO in the prerequisite chain.

---

### 6.4 Dialogue Agent (`agents/dialogue_agent.py`)

Manages the 5-state engagement machine for a single session. One `DialogueTracker` instance per session.

**States and transitions:**

```
EXPLORING
  ├─ 3+ short responses (<5 words) OR "idk" patterns → STUCK
  │
STUCK
  ├─ Student elaborates (>20 words) after stuck → BREAKTHROUGH
  │
BREAKTHROUGH
  ├─ mastery ≥ 0.6 → CONSOLIDATING
  │
CONSOLIDATING
  ├─ mastery ≥ 0.85 → MASTERED
  │
MASTERED
  └─ terminal
```

When transitioning to STUCK, `get_intervention_prompt()` returns a string that is appended to the student input before the Tutor Agent is called. This causes the tutor to receive an invisible signal to switch to a more open-ended approach without the student seeing any meta-commentary.

The agent also tracks:
- Open vs closed question ratio in tutor responses
- Student elaboration rate (responses > 20 words)
- Breakthrough event count

---

### 6.5 Monitor Agent (`agents/monitor_agent.py`)

Tracks session cost and logs events. Never sits in the critical response path — runs as read-only observer.

**`log_session_event(session_id, learner_id, event_type, agent, data)`** — writes to SQLite `session_log`.

**`print_session_report(session_id)`** — produces turn count, total cost estimate in GBP, and per-turn breakdown. Triggered on `summary` command.

---

## 7. RAG Pipeline — `rag/`

### 7.1 Three-Stage Retrieval (`retrieve.py`)

**Stage 1 — Query Enhancement (Claude Sonnet):**

The student's raw query is expanded into 4 variants:
1. The original query
2. A HyDE (Hypothetical Document Embedding) excerpt — a short answer the curriculum might contain
3. A broad reformulation
4. A narrow, specific reformulation

A `context_hint` (last tutor message) is passed to anchor short follow-up messages ("I think so") to the ongoing conversation.

**Stage 2 — ChromaDB Multi-Query Retrieval:**

All 4 query variants are sent to ChromaDB. Results are deduplicated by chunk ID, giving up to 40 candidates. Filtered to the `mathematics` subject tag.

**KG Boost:** If an `lo_id` is provided, chunks directly linked to that LO via `HAS_RESOURCE` edges are promoted to the front of the candidate list.

**Stage 3 — LLM Cross-Encoder Reranking (Claude Haiku):**

A single batch call scores all candidates:
```
Score each passage for relevance to the student's question (0-10):
1: [chunk text truncated to 400 chars]
...
N: [chunk text]

Respond with one score per line: "N: score"
```

Scores are normalised to [0.0, 1.0] and sorted descending. Falls back to term-overlap reranking on any exception.

**Threshold filter:** Chunks scoring below `RELEVANCE_THRESHOLD` (default 0.15) are dropped. KG-linked chunks are exempt.

**Final output:** Top 4 chunks with citation labels.

### 7.2 Curriculum Ingest (`ingest.py`)

Markdown files in `curriculum_data/` are chunked at ~200 words with 40-word overlap, embedded with `qwen3-embedding:8b` via Ollama, and upserted to ChromaDB with `subject` and `topic_id` metadata. Idempotent — duplicate chunks are skipped.

**Coverage:**
| Qualification | Topics | Chunks |
|---|---|---|
| 0580 IGCSE Maths | 26 | 79 |
| 0606 Additional Maths | 5 | 21 |
| 9709 AS/A Level | 6 | 28 |
| 9231 Further Maths | 4 | 18 |
| **Total** | **41** | **146** |

### 7.3 Mathematical Verification (`math_verify.py`)

**`verify_response(student_response, question_context)`** — extracts numeric equations and claimed values from student responses using regex; checks whether the claimed value satisfies the equation via SymPy substitution.

**`verify_tutor_claims(tutor_response, student_input)`** — extracts assertive solution statements from tutor responses using:
- `_ASSERTIVE_SOL_RE`: "so x = N", "therefore x = N", "x = N is the solution"
- `_EXPLORATORY_RE`: if any exploratory phrasing detected, returns `verified=None` immediately

Both functions return a `ComputationResult(verified: bool | None, method: str)` dataclass. `verified=None` is the safe default when no claim can be extracted or checked.

---

## 8. Database Layer — `db/`

### 8.1 SQLite (`db/db.py`)

Five tables:

| Table | Purpose |
|---|---|
| `learner_state` | Per-learner current topic and session info |
| `knowledge_graph` | 8-topic GCSE ladder (legacy — Neo4j is primary) |
| `session_log` | Per-turn events: input, output, agent, event type, metadata JSON |
| `audit_events` | Constitutional audit trail: agent decisions, RAG grounding status, BKT updates |
| `bkt_parameters` | Per-topic BKT parameter overrides (P_L0, P_T, P_S, P_G) |

`init_db.py` seeds the database idempotently on startup. If `mas_poc.db` doesn't exist, it is created and populated with the 8-topic starting ladder and default BKT parameters.

### 8.2 Neo4j Knowledge Graph (`db/kg.py`)

The production planning store. Graph schema:

```
(Qualification)-[:HAS_TOPIC]->(Topic)
               -[:HAS_SUBTOPIC]->(Subtopic)
               -[:HAS_LO]->(LearningObjective)
               
(LearningObjective)-[:HAS_MASTERY {mastery, evidence_count, last_updated}]->(Learner)
                  -[:HAS_RESOURCE]->(Resource)
                  -[:TEACHES]->(Concept)
                  -[:DEEPENS]->(LearningObjective)  # prerequisite chain

(Concept)-[:INSTANCE_OF]->(Concept)  # e.g. "quadratic factoring" is an instance of "factoring"
```

`bkt_update_kg(learner_id, lo_id, is_correct)` — applies the BKT formula and writes the updated mastery probability to the `HAS_MASTERY` edge as a relationship property.

The driver delegates to the shared `cambridge_kg` package for connection management (`get_driver`, `kg_session`). All curriculum-specific queries live in `db/kg.py`.

---

## 9. OpenRouter Compatibility Layer

`compat/openrouter_client.py` provides a drop-in replacement for `anthropic.Anthropic()`. All agent code calls the same `client.messages.create(model, max_tokens, system, messages)` interface regardless of whether the underlying client is Anthropic-direct or OpenRouter.

```python
class OpenRouterClient:
    def __init__(self, api_key):
        self.messages = _Messages(
            OpenAI(api_key=api_key, base_url="https://openrouter.ai/api/v1")
        )
```

The wrapper prepends `anthropic/` to model names (OpenRouter convention), converts the Anthropic-style `system` parameter to an OpenAI-style system message, and maps response shape to match `.content[0].text` and `.usage.output_tokens`.

**Why OpenRouter instead of Anthropic direct?**
- API credit exhausted during development; OpenRouter provides model-agnostic routing
- Resilient: if one model is unavailable, OpenRouter can route to an alternative
- Single API key for all Claude model variants
- Drop-in via the compatibility wrapper — zero changes to agent code

---

## 10. Dashboard — `dashboard.py`

FastAPI `APIRouter` mounted at `/dashboard`. Two endpoints:

**`GET /dashboard`** — serves an HTML page with:
- Stat cards (total LOs mastered, overall progress %)
- Per-topic dual-segment progress bars (mastered / in-progress / not-started)
- Cytoscape.js interactive knowledge graph (breadthfirst layout, nodes sized by LO count, colour-coded by mastery: green/amber/grey)
- "What's Next" recommended LO cards (up to 5, with prerequisite-ready indicator)
- Learner selector populated from Neo4j

**`GET /api/dashboard/{learner_id}`** — JSON data endpoint for programmatic access.

The dashboard uses no new Python dependencies — Cytoscape.js is loaded from CDN.

---

## 11. Production Deployment

### Infrastructure

- **Server:** Scaleway DEV1-S (`51.15.38.155`) — 2 vCPU, 2 GB RAM
- **Process management:** systemd service `mas-tutor.service`
- **Reverse proxy:** Caddy 2.x — automatic TLS from Let's Encrypt, port 443 → 8080
- **Domain:** `mas-tutor.com` — A record @ → 51.15.38.155

### systemd Service

```ini
[Unit]
Description=MAS Education POC
After=network.target

[Service]
User=mas_app
WorkingDirectory=/home/mas_app/mas_education_poc
ExecStart=/home/mas_app/.venv/bin/python chat_ui.py
Restart=always
EnvironmentFile=/home/mas_app/mas_education_poc/.env

[Install]
WantedBy=multi-user.target
```

### Deployment Process

The VPS runs a directory copy, not a git clone. Deployment is via `scp`:

```bash
scp chat_ui.py root@51.15.38.155:/home/mas_app/mas_education_poc/
scp agents/tutor_agent.py root@51.15.38.155:/home/mas_app/mas_education_poc/agents/
# etc.
ssh root@51.15.38.155 "systemctl restart mas-tutor"
```

### Environment (VPS `.env`)

```
OPENROUTER_API_KEY=sk-or-v1-...
LLM_PRIMARY=claude-sonnet-4-6
CHROMA_PATH=/home/mas_app/.chromadb
CHROMA_COLLECTION=poc_curriculum
DB_PATH=/home/mas_app/mas_education_poc/mas_poc.db
LOG_FILE=/home/mas_app/mas_education_poc/chat_ui.log
```

**Note:** ChromaDB has not yet been ingested on the VPS. The tutor operates in LLM-fallback mode — RAG pipeline runs but returns empty results, and the tutor falls back to LLM general knowledge. Ingest is the next deployment step.

---

## 12. Testing

The test suite lives in `tests/` with 36 tests (17 unit, 19 integration).

### Structure

```
tests/
├── conftest.py          # Shared fixtures: mock clients, DB setup
├── unit/
│   ├── test_faq.py      # FAQ keyword matching (12 tests)
│   ├── test_validation.py  # Input validation, session limits (5 tests)
├── integration/
│   ├── test_endpoints.py   # /chat, /health, /admin endpoints (8 tests)
│   ├── test_rate_limit.py  # Rate limiting under load (6 tests)
│   └── test_session_mgmt.py # Session capacity, TTL, cleanup (5 tests)
```

### Running Tests

```bash
cd ~/projects/mas_education_poc
uv run pytest tests/ -q          # all 36 tests
uv run pytest tests/unit/ -v     # unit tests only
uv run pytest tests/integration/ # integration tests only
```

### Test Principles

- Unit tests mock the `anthropic_client` and SQLite — no LLM calls
- Integration tests mock the orchestrator but exercise the full FastAPI middleware stack (rate limiting, session management, validation)
- No live LLM calls in any test — deterministic and fast

---

## 13. Key Design Decisions

### C4 Constitutional Principle

The most important architectural constraint: the tutor must never hallucinate. This is implemented as a hard rule in the Tutor Agent's system prompt (`ABSOLUTE RULES: 1. You MUST only use information from the CURRICULUM CONTEXT provided`) and enforced by the RAG pipeline's relevance threshold — if no sufficiently relevant content exists, no curriculum context is injected and the audit trail records this as `rag_fallback_llm`.

The constitutional numbering (C4) comes from the v2.1 architecture blueprint: C1=system initialisation, C2=BKT integrity, C3=audit logging, C4=RAG grounding, C5=Socratic method.

### Why LangGraph for Orchestration?

A simpler approach would be a single LLM call with a large system prompt. LangGraph was chosen because:
- State is explicit and inspectable — the `SessionState` TypedDict documents every field
- Routing is deterministic — `route_intent` uses keyword matching, not LLM judgment
- Each agent is independently testable
- The session graph can be extended (add nodes) without rewriting existing agents
- LangGraph's `invoke()` interface makes the orchestrator synchronous and straightforward

### Why BKT Instead of Simple Scoring?

A rolling average of correct/incorrect answers doesn't account for guessing and slipping. BKT's four parameters model the probabilistic reality: a student who answers correctly once may have guessed (P(G) = 0.25), and a student who answers incorrectly may know the material but have slipped (P(S) = 0.10). The mastery threshold of 0.85 means the system requires a sustained pattern of correct answers before advancing — not just one lucky response.

### Why Not Stream Responses?

The current architecture calls `orchestrator.invoke()` synchronously and returns the complete response. Streaming would require LangGraph's async streaming interface, which conflicts with how the Dialogue Agent, Assessment Agent, and planning checks are wired (they all need the complete tutor response before they can update state). Streaming is deferred to v2.0.

### SQLite + Neo4j Dual Store

SQLite holds the audit trail and session log — append-only, high-write, no graph traversal needed. Neo4j holds the knowledge graph and BKT state — graph traversal for prerequisite chains is its native operation. The two databases serve different access patterns and do not need to be consolidated.

### OpenRouter Client Wrapper

The wrapper pattern (`compat/openrouter_client.py`) was chosen over modifying agent code directly. All five agents call `anthropic_client.messages.create()` — changing the client at startup is sufficient to switch providers. The wrapper is 66 lines and requires zero changes to any agent.

---

## 14. Pedagogical Improvements (June 2026)

Seven improvements derived from multi-persona synthetic testing. All implemented in the same session; all verified live at mas-tutor.com.

### Improvement 1: Meta-Commentary Filter

**Problem discovered:** When the Assessment Agent scored a student response against a mismatched topic, it sometimes generated "meta-diagnostic" text like "the student appears to be confused about the topic rather than attempting a calculation." This text leaked into the student-facing response.

**Root cause:** `assessment_node` in the orchestrator was appending `result['misconception']` verbatim, without checking whether the misconception was an internal diagnostic note or an actual mathematical error description.

**Fix (two layers):**
1. Updated `SCORING_SYSTEM_PROMPT` to explicitly forbid using MISCONCEPTION for topic-mismatch notes
2. Added `_INTERNAL_MISCONCEPTION_MARKERS` filter in `assessment_node` to suppress any misconception containing diagnostic language before it reaches the student
3. Added `_strip_metacommentary()` in `tutor_agent.py` to catch any similar leakage in tutor responses

### Improvement 2: Topic Routing from Message Keywords

**Problem discovered:** A new learner who typed "I want to understand quadratic equations" was assigned the topic "0580-core-number-integers-types" (the lowest unmastered LO in the KG). The assessment agent then scored their quadratic answer against the integers topic, generating nonsensical feedback.

**Fix:** `session_init` now calls `_detect_topic_from_message()` on every turn. If the student's message contains clear topic keywords, `current_topic_name` is overridden — this is the field passed to the LLM as context. The KG-assigned `current_topic` (LO ID) is preserved for BKT tracking purposes, but the LLM sees the correct topic name.

### Improvement 3: Expanded Assessment Signals

**Problem discovered:** The orchestrator's assessment routing only fired on a narrow set of signals ("i think", "answer is", "= "). Natural-language answers like "so x would be -3" or "my working gives 42" were routed to the tutor, which then had to redirect rather than score.

**Fix:** Expanded `assessment_signals` list in `route_intent` to cover 20+ natural-language patterns: "would be", "must be", "could be", "i got", "i calculated", "works out to", "therefore", "which means", "my working".

### Improvement 4: Ability-Paced Progression

**Problem discovered:** The tutor continued re-explaining basics to a student who had answered correctly multiple times in a row, rather than advancing the challenge level.

**Fix:** `SessionState` now tracks `ability_signal: int`. After two CORRECT assessments, `tutoring_node` appends an internal hint: `[INTERNAL: This learner has answered correctly multiple times — match their pace. Offer an extension or harder variant rather than re-explaining basics.]`

### Improvement 5: Distress Triage

**Problem discovered:** A student typing "I don't know where to start, I'm completely lost" received a generic reassurance from the LLM — helpful in tone but unhelpful in practice, since it didn't anchor the next turn to any specific topic.

**Fix:** `_check_vague_distress()` intercepts these messages before the orchestrator and returns a static topic-choice menu. The next student message is then topic-specific, and the orchestrator's `_detect_topic_from_message()` picks it up cleanly.

### Improvement 6: Model Routing (Conditional)

**Design:** Short, symbol-free messages (< 60 chars, no math operators) were identified as candidates for a secondary (cheaper) model to reduce latency and cost.

**Implementation:** `_select_model()` in `tutor_agent.py` — only activates when `LLM_SECONDARY` is explicitly set in the environment AND is different from `LLM_PRIMARY`. Without this guard, the function was silently routing to a misconfigured model ID on the VPS, causing the fallback error message. The guard makes the feature opt-in rather than opt-out.

### Improvement 7: Resistance Adaptation

**Problem discovered:** A student who repeatedly demanded direct answers ("just tell me the answer", "please just confirm") continued to receive the standard Socratic questioning approach, which increased frustration.

**Fix:** `_is_resistance()` detects 15 direct-answer demand phrases. Each detection increments `guidance_resistance_count` in session state. After two resistance events, `tutoring_node` appends an internal hint: `[INTERNAL: Acknowledge their frustration warmly. Offer to verify their own guess via substitution. Offer a partial scaffold (the first step) to unstick them.]` — the Socratic approach is maintained, but the strategy shifts towards warmth and scaffolding.
