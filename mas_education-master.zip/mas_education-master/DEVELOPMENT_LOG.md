# MAS Education POC — Development Log

Chronological record of all iterative development phases. Each entry records what was built, what changed, and the system state afterwards.

---

## Phase 0 → Phase 5: Initial Build (23–24 February 2026)

### POC Stages 1–7 (23 Feb 2026)

Built in a single session. Established the core multi-agent tutoring system from scratch.

| Stage | What Was Built |
|---|---|
| 1 | Environment: uv, Python 3.11, agentstack-sdk, langgraph, anthropic, chromadb |
| 2 | RAG pipeline: curriculum ingestion, HyDE retrieval, ChromaDB `poc_curriculum` collection |
| 3 | SQLite schema: 5 tables, BKT parameters, 8 topic seed data |
| 4 | Tutor + Assessment agents: RAG-grounded Socratic tutor, BKT scoring |
| 5 | Planning + Dialogue + Monitor agents: topic ladder, engagement machine, cost tracking |
| 6 | LangGraph orchestrator: 7-node session graph, conditional intent routing |
| 7 | BeeAI integration: A2A server on port 8000, end-to-end DB writes confirmed |

**State after Stage 7:**
- 5 agents running, orchestrated by LangGraph
- ChromaDB: 12 chunks (3 original curriculum files)
- SQLite-backed planning with 8 hardcoded topics
- No browser UI

### KG Phases 0–5 (23–24 Feb 2026)

Built the Neo4j Knowledge Graph and migrated the system from SQLite planning to graph-native planning.

| Phase | What Was Built |
|---|---|
| 0 | Docker Neo4j 5.x, `db/kg.py` driver, `db/schema.cypher` constraints and indexes |
| 1 | YAML curriculum → `scripts/ingest_curriculum.py` → Qualification/Topic/Subtopic/LO nodes for all 4 quals |
| 2 | `scripts/extract_concepts.py` (LLM extraction) → 77 Concepts, 114 ConceptInstances, TEACHES/INSTANCE_OF edges |
| 3 | `scripts/derive_deepens.py` → 20 DEEPENS edges, 5 spiral chains, cross-qual prerequisite edges |
| 4 | Planning + Assessment agents migrated to Neo4j; BKT params on LO nodes; [:HAS_MASTERY] edges at runtime |
| 5 | 22 new curriculum markdown files (all 0580 topic areas); ChromaDB 12 → 79 chunks; `scripts/link_resources.py`; 200 [:HAS_RESOURCE] edges; KG-guided retrieval in `retrieve()` |

**State after Phase 5:**
- Neo4j KG: 4 quals, 19 topics, 75 subtopics, 191 LOs, 77 concepts, 200 HAS_RESOURCE edges
- ChromaDB: 79 chunks, 26 topics — all IGCSE 0580 content
- RAG pipeline: Stage 1 (HyDE + multi-query), Stage 2 (ChromaDB), Stage 3 (term-overlap reranking), KG boost
- Planning agent reads from Neo4j `get_next_lo()` / `check_advancement_kg()`
- Known limitation: 0606, 9709, 9231 LOs had zero ChromaDB content — caused C4 fallback for those topics

---

## Session: 4 March 2026 — Dashboard, Topic Stability, RAG Improvements

Three independent improvement streams in a single session. All changes are additive; no existing functionality was broken.

### Improvement 1 — Learning Progress Dashboard

**Problem:** No visibility for learners, parents, or teachers into what has been learned, current position, or what comes next.

**Solution:** Added `/dashboard` route to the existing FastAPI server (`chat_ui.py`).

**Files changed:**
- `dashboard.py` — new file; `APIRouter` with two endpoints:
  - `GET /dashboard` — serves full HTML page
  - `GET /api/dashboard/{learner_id}` — JSON data for programmatic access
- `chat_ui.py` — two lines added to include the router

**Features delivered:**
- **Stat cards:** total LOs, mastered count, overall % progress
- **Topic progress list:** dual-segment progress bars (mastered / in-progress / not-started) per topic, grouped by qualification
- **Cytoscape.js knowledge graph:** breadthfirst layout with qualification roots; nodes sized by LO count and coloured by mastery status (green/amber/grey); cross-linked to topic list
- **"What's Next" LO cards:** up to 5 recommended LOs with prerequisite-ready indicator
- **Learner selector:** dropdown populated from Neo4j learner nodes
- No new Python dependencies — Cytoscape.js loaded from CDN

**Access:** `http://localhost:8080/dashboard` (server must be running)

---

### Improvement 2 — Topic Stability Fix

**Problem:** The system jumped between topics on every message turn. A learner asking follow-up questions about quadratic equations would be switched to a different LO mid-conversation.

**Root cause:** `session_init` in `orchestrator/poc_orchestrator.py` called `get_learner_plan()` → `get_next_lo()` on **every turn**, overwriting `current_topic` with the globally lowest-difficulty unmastered LO regardless of what was already being discussed.

**Fix:** Guard the Neo4j lookup with a first-turn check.

```python
# Before: KG queried every turn
plan = get_learner_plan(state["learner_id"], state["session_id"])
current = plan.get("current_lo")

# After: KG only queried when current_topic is unknown (first turn)
if current_topic == "unknown":
    plan = get_learner_plan(state["learner_id"], state["session_id"])
    current = plan.get("current_lo")
```

**File changed:** `orchestrator/poc_orchestrator.py` — `session_init()` function

**Behaviour after fix:**
- First turn: Neo4j consulted → topic set from learner's current LO
- Subsequent turns: topic preserved from session state
- `reflect_node` still triggers advancement when mastery ≥ 0.85 + 5 evidence (unchanged)
- Topic advances correctly when mastery threshold is hit; stable otherwise

---

### Improvement 3 — RAG Coverage: Missing Qualifications (Option 1)

**Problem:** 91 of 191 LOs (all 0606, 9709, and 9231 topics) had zero curriculum content in ChromaDB. Any student question touching Additional Maths, AS-Level, or A-Level content triggered the C4 fallback ("Let me check that with your teacher").

**Solution:** Created and ingested 15 curriculum markdown files covering all missing topics.

**Files created** (in `curriculum_data/`):

| File | Content |
|---|---|
| `0606_functions.md` | Function notation, domain/range, composite/inverse functions, graph transformations, modulus |
| `0606_polynomial_algebra.md` | Surds, laws of indices, discriminant, quadratic inequalities, completing the square, factor/remainder theorem |
| `0606_logarithms_exponentials.md` | Logarithm definition, log laws, solving exponential equations, y=eˣ, growth/decay, linearisation |
| `0606_trigonometry.md` | Exact values, Pythagorean identity, sec/cosec/cot, radians, arc length/sector area, solving trig equations, proving identities |
| `0606_calculus.md` | Standard derivatives, chain/product/quotient rules, stationary points, standard integrals, definite integration and area |
| `9709_algebra.md` | Binomial theorem, general term, rational binomial expansion, roots of polynomials, partial fractions |
| `9709_functions_coord_geometry.md` | Even/odd/periodic functions, modulus at A-Level, circle equations, tangents/normals, parametric equations and gradients |
| `9709_sequences_series.md` | Arithmetic progressions (nth term, sum), geometric progressions (nth term, sum, sum to infinity), sigma notation |
| `9709_trigonometry.md` | Compound angle formulae, double angle formulae, harmonic form (R sin/cos), trigonometric identity proofs |
| `9709_calculus.md` | Chain/product/quotient rules, implicit differentiation, second derivatives, integration by substitution, integration by parts, partial fractions integration, volumes of revolution, first-order DEs |
| `9709_vectors.md` | 3D vectors, modulus/unit vectors, scalar product, angle between vectors, vector equation of a line, intersection/parallel/skew lines, perpendicular distance |
| `9231_complex_numbers.md` | Complex arithmetic, modulus/argument/conjugate, complex roots of polynomials, polar form, De Moivre's theorem, roots of unity |
| `9231_further_matrices.md` | Matrix multiplication, determinants (2×2 and 3×3), inverse matrices, eigenvalues and eigenvectors, diagonalisation |
| `9231_further_calculus.md` | Reduction formulae, arc length (Cartesian and parametric), surface area of revolution, Maclaurin series, Taylor series |
| `9231_further_differential_equations.md` | Second-order linear DEs (homogeneous CF: distinct/repeated/complex roots), particular integrals, initial/boundary conditions, SHM, damped oscillations |

**Ingestion result:**
```
ChromaDB poc_curriculum: 79 chunks → 146 chunks (+67 new, 0 errors, 0 duplicates)
All 15 topic IDs confirmed present in ChromaDB metadata
```

**Retrieval verified:** All 8 sample queries (function notation, logarithms, binomial expansion, integration by parts, arithmetic progressions, 3D vectors, complex numbers, eigenvalues) returned correct topic as top result.

---

### Improvement 4 — RAG Relevance Threshold (Option 2)

**Problem:** `retrieve()` returned up to 4 chunks regardless of their relevance score. Weakly-matched chunks (low term-overlap score) were passed to the LLM as "curriculum context", causing the LLM to fire its System Prompt rule 2 soft fallback — inconsistently and without audit logging.

**Solution:** Added a configurable `RELEVANCE_THRESHOLD` that filters out chunks below the minimum score after reranking.

**File changed:** `rag/retrieve.py`

**Changes:**
```python
RELEVANCE_THRESHOLD = float(os.getenv("RAG_RELEVANCE_THRESHOLD", "0.15"))
```

Post-reranking filter:
```python
filtered = [
    r for r in reranked
    if r["rerank_score"] >= RELEVANCE_THRESHOLD or r["id"] in kg_chunk_ids
]
```

- KG-preferred chunks (from `[:HAS_RESOURCE]` edges) **bypass** the threshold — they were explicitly linked to the current LO
- When all chunks are filtered, `retrieve()` returns `[]` → triggers the hard C4 fallback in `tutor_agent.py` (audited, consistent message)
- Prints count of filtered chunks for observability
- Threshold configurable via `RAG_RELEVANCE_THRESHOLD` env var (documented in `.env.template`)

**File changed:** `agents/tutor_agent.py` — audit log reason updated to `"low_score_filtered or no RAG results — escalating to teacher"`

---

### Improvement 5 — LLM Cross-Encoder Reranking (Option 3)

**Problem:** The Stage 3 term-overlap reranker was too crude for semantic relevance. It matched keywords regardless of meaning (e.g. "capital" in a finance problem scores the same as "capital" in a geography question). It could not distinguish "find the roots of a polynomial" from "quadratic formula" without shared vocabulary.

**Solution:** Replaced term-overlap with a **Claude Haiku cross-encoder** — a single batch API call that scores all retrieved chunks 0–10 for relevance to the student's question, then normalises to [0.0, 1.0].

**File changed:** `rag/retrieve.py`

**New function `_llm_rerank()`:**
- Single Haiku (`claude-haiku-4-5-20251001`) API call — all chunks scored in one prompt
- Each chunk truncated to 400 chars for the scoring context
- Scores parsed from "N: score" format; unparsed chunks default to 0.0
- Sorts descending by score; logs top score and topic
- Falls back to `_basic_rerank()` (term-overlap) on any exception
- `_basic_rerank()` retained unchanged

**`retrieve()` Stage 3 change:**
```python
# Before
reranked = _basic_rerank(query, all_results)[:n_results]
# After
reranked = _llm_rerank(query, all_results, anthropic_client)[:n_results]
```

No new dependencies — uses the existing `Anthropic` client already passed into `retrieve()`.

**Verified results:**
```
Query "find the roots of a second degree polynomial"
  → top score 0.90  topic: quadratic-equations   ✓

Query "prove that cos 3θ = 4cos³θ − 3cosθ"
  → top score 1.00  topic: 9231-complex-numbers   ✓ (De Moivre)
  → score 0.30      topic: 0606-trigonometry
```

---

## Current System State (4 March 2026)

### RAG Pipeline (current)

```
Student query
     │
     ▼
Stage 1: Query Enhancement (Claude Sonnet)
  original + HyDE excerpt + 2 reformulations = 4 variants
     │
     ▼
Stage 2: ChromaDB multi-query retrieval
  4 variants × top-10 candidates, deduplicated
  subject filter: "mathematics"
     │
     ▼
KG Boost (if lo_id provided)
  HAS_RESOURCE-linked chunks promoted to front
     │
     ▼
Stage 3: LLM Cross-Encoder (Claude Haiku)
  Single batch call scores all chunks 0–10 → normalised 0.0–1.0
  Falls back to term-overlap on API failure
     │
     ▼
Relevance Threshold Filter
  Drops chunks with rerank_score < RELEVANCE_THRESHOLD (default 0.15)
  KG-preferred chunks exempt from filtering
     │
     ▼
Top-N results with citation labels
```

### ChromaDB Coverage (current)

| Qualification | Topics | Chunks |
|---|---|---|
| 0580 IGCSE Maths | 26 (all topics) | 79 |
| 0606 Additional Maths | 5 | 21 |
| 9709 AS/A Level Maths | 6 | 28 |
| 9231 Further Maths | 4 | 18 |
| **Total** | **41 topics** | **146 chunks** |

### Files Changed This Session

| File | Change |
|---|---|
| `dashboard.py` | **New** — learning progress dashboard (FastAPI router) |
| `chat_ui.py` | +2 lines — import and include dashboard router |
| `orchestrator/poc_orchestrator.py` | `session_init()` — topic stability guard |
| `curriculum_data/0606_*.md` | **5 new files** — 0606 Additional Maths content |
| `curriculum_data/9709_*.md` | **6 new files** — 9709 AS/A Level content |
| `curriculum_data/9231_*.md` | **4 new files** — 9231 Further Maths content |
| `rag/retrieve.py` | `RELEVANCE_THRESHOLD`, `_llm_rerank()`, Stage 3 swap |
| `agents/tutor_agent.py` | Audit log reason for low-score filtered results |
| `.env.template` | `RAG_RELEVANCE_THRESHOLD` documented |

### Known Remaining Limitations

- `demo.py` still uses the legacy 8-topic SQLite KG, not Neo4j
- No streaming responses in `chat_ui.py`
- No multi-user session management (single learner `demo-student-001`)
- HAS_RESOURCE edges auto-generated by vector similarity — manual review deferred
- Assessment Agent self-reflection (10% divergence trigger wired, but LLM self-reflection call not implemented)
- RAG_RELEVANCE_THRESHOLD = 0.15 is conservative — term-overlap reranker (fallback) will still pass through some off-topic content. Option 3 LLM reranking significantly reduces this but a DeBERTa NLI faithfulness check remains deferred to v2.0

---

## Session: 5 March 2026 — Math Verification (Phases A, B, C)

Three safety layers added to prevent mathematical errors reaching students. All changes are additive; no existing functionality was broken.

### Phase A — Assessment Agent sympy Verification

**Problem:** The Assessment Agent scored student responses using an LLM judge only. An LLM can confidently confirm a wrong answer as correct (e.g. "x = 1 satisfies x² + 5x + 6 = 0" → no, it doesn't).

**Solution:** Added a sympy computation layer that runs alongside the LLM judge. When both produce a verdict, disagreements are flagged as PARTIAL rather than CORRECT or INCORRECT.

**Files changed:**
- `rag/math_verify.py` — **new file**; `ComputationResult` dataclass, `evaluate_expression()`, `check_equation_solution()`, `are_expressions_equivalent()`, `verify_response()`
- `agents/assessment_agent.py` — added `question_context` param to `score_response()`; calls `verify_response()` post-LLM; CORRECT+sympy-False → PARTIAL; INCORRECT+sympy-True → PARTIAL
- `orchestrator/poc_orchestrator.py` — `assessment_node()` extracts last assistant message and passes as `question_context`
- `pyproject.toml` — added `sympy>=1.13.0` dependency

**Logic:**
```python
math_check = math_verify_response(student_response, question_context)
if math_check.verified is not None:
    if score == "CORRECT" and math_check.verified is False:
        score = "PARTIAL"   # LLM said correct but sympy refutes
    elif score == "INCORRECT" and math_check.verified is True:
        score = "PARTIAL"   # LLM said wrong but sympy confirms correct
```

**Key design decision:** `verified=None` is the safe default (no sympy verdict) — avoids false positives for all non-equation questions. Only fires when equation + solution can be reliably extracted.

---

### Phase B — Tutor Agent sympy Verification

**Problem:** The Tutor generates worked examples and arithmetic claims. If the Tutor states "so x = 1" for a quadratic that doesn't have x=1 as a root, students receive that error as curriculum fact.

**Solution:** Added `verify_tutor_claims()` to `math_verify.py`. After response generation, Tutor checks its own assertive claims. Provably wrong claims trigger a single correction regeneration.

**Files changed:**
- `rag/math_verify.py` — added `_ASSERTIVE_SOL_RE`, `_EXPLORATORY_RE`, `verify_tutor_claims()`
- `agents/tutor_agent.py` — added `verify_tutor_claims()` call post-generation; correction regeneration block; `math_verified`/`math_corrected` added to audit log

**Assertive vs exploratory guard (critical design):**
- `_ASSERTIVE_SOL_RE`: matches "so x = N", "therefore x = N", "x = N is the solution", "the answer is N"
- `_EXPLORATORY_RE`: if ANY exploratory language ("try", "what if", "suppose") detected → whole response returns `verified=None`
- This prevents false positives from the Socratic method's deliberate value suggestions

**Correction flow:**
```python
if math_verified is False:
    # One correction attempt only — no retry loops
    correction_messages = [..., internal_note_message]
    response_text = correction_response.content[0].text
    math_corrected = True
```

---

### Phase C — Curriculum Content Audit

**Problem:** Mathematical errors in curriculum markdown files would be served as authoritative RAG context to every student asking about that topic.

**Solution:** Created `scripts/audit_curriculum.py` — a standalone sympy audit script that parses all 41 curriculum files, extracts numeric arithmetic claims, verifies them symbolically, and writes a full report.

**Files created:**
- `scripts/audit_curriculum.py` — full audit script
- `AUDIT_REPORT.md` — written to project root by the script

**Audit result:**
```
Files:  41
PASS:   78
FAIL:   0
SKIP:   44
```

**All 41 curriculum files confirmed mathematically correct.** No errors found.

**Technical challenges resolved:**
- 85 initial false positives (all regex edge cases) reduced to 0 through 3 iterations:
  - Unicode √, ∛, multi-digit superscripts (e.g. `(1.04)¹⁰`) normalized correctly
  - LHS fragment filters: skip lines with `→`, LHS starting with `+` or `**`
  - Thousands commas removed before parsing (`67,000` → `67000`)
  - Mixed number conversion (`2 1/10` → `(2 + 1/10)`)
  - Subscript-base filter (`3(1/9)` from `log₃(1/9)` after subscript stripping)
  - Calculus expression filter (`(N/M)(...)` form from integration steps with π stripped)
- Conservative strategy: require ≥2 digit groups in LHS; skip RHS containing operators

---

### System State After Phase A/B/C

| Component | Before | After |
|---|---|---|
| Assessment scoring | LLM judge only | LLM judge + sympy cross-check → PARTIAL on disagreement |
| Tutor responses | Unverified | Assertive math claims verified; wrong claims trigger correction regeneration |
| Curriculum content | Unaudited | All 41 files audited: 78 claims PASS, 0 FAIL, 44 SKIP |
| `math_verified` audit key | ❌ | ✅ (Assessment + Tutor both log it) |
| `math_corrected` audit key | ❌ | ✅ (Tutor logs correction events) |

### Files Changed This Session

| File | Change |
|---|---|
| `rag/math_verify.py` | **New** — ComputationResult, verify_response(), verify_tutor_claims() |
| `agents/assessment_agent.py` | sympy cross-check on scoring; PARTIAL verdict logic |
| `agents/tutor_agent.py` | verify_tutor_claims() call; correction regeneration; audit keys |
| `orchestrator/poc_orchestrator.py` | question_context extraction for Phase A |
| `pyproject.toml` | sympy>=1.13.0 dependency added |
| `scripts/audit_curriculum.py` | **New** — full curriculum audit script |
| `AUDIT_REPORT.md` | **New** — generated by audit script; 0 FAILs confirmed |
