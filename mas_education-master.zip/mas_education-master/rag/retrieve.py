"""
Advanced RAG Retrieval Pipeline — MAS Education POC

Three-stage pipeline:
  Stage 1: Query Enhancement — original + HyDE excerpt + 2 reformulations (via Claude)
  Stage 2: ChromaDB multi-query vector retrieval (top-10 candidates, deduplicated)
  Stage 3: LLM cross-encoder reranking via Claude Haiku (single batch call, 0-10 scores)
           Falls back to term-overlap reranking if the LLM call fails.
           Chunks below RELEVANCE_THRESHOLD are filtered post-reranking.

Production equivalent (deferred to v2.0):
  - DeBERTa NLI faithfulness check (threshold ≥ 0.85)
"""
import asyncio
import os
import re
import chromadb
from chromadb.utils.embedding_functions import VoyageAIEmbeddingFunction
from anthropic import Anthropic
from dotenv import load_dotenv
from db.kg import kg_session

load_dotenv()

CHROMA_PATH = os.getenv("CHROMA_PATH")
if not CHROMA_PATH:
    raise EnvironmentError("CHROMA_PATH not set — copy .env.template to .env and fill in values")
COLLECTION_NAME = os.getenv("CHROMA_COLLECTION", "poc_curriculum")
# Voyage AI voyage-3-lite produces 512-dim vectors. This MUST match the model that
# built the existing poc_curriculum collection — the live 146 chunks are voyage-3-lite
# embeddings (empirically confirmed), NOT the qwen3-embedding:8b/Ollama config this
# file previously (wrongly) declared. Ollama is not installed on the VPS at all.
EMBEDDING_MODEL = "voyage-3-lite"
TOP_K_CANDIDATES = 10
TOP_K_RERANKED = 4
RELEVANCE_THRESHOLD = float(os.getenv("RAG_RELEVANCE_THRESHOLD", "0.15"))


def _get_collection():
    client = chromadb.PersistentClient(path=CHROMA_PATH)
    # Reads the funded key from the VOYAGE_API_KEY env var (never passed inline, so no
    # secret is persisted into collection config and no DeprecationWarning is raised).
    embedding_fn = VoyageAIEmbeddingFunction(
        model_name=EMBEDDING_MODEL,
        api_key_env_var="VOYAGE_API_KEY",
    )
    return client.get_collection(name=COLLECTION_NAME, embedding_function=embedding_fn)


async def _enhance_query(
    query: str,
    client: Anthropic,
    topic_hint: str | None = None,
    context_hint: str | None = None
) -> list[str]:
    """
    Stage 1 — Query Enhancement using Claude.
    Generates HyDE document + 2 reformulations alongside the original query.
    Returns up to 4 query variants for multi-query retrieval.

    Args:
        topic_hint:   Current topic (e.g. "geometry-vectors") — keeps variants on-topic.
        context_hint: Last tutor message — anchors short/ambiguous student replies
                      (e.g. "I think it is the vector?") to the ongoing conversation.
    """
    topic_line = f"The student is currently studying: {topic_hint}. Keep all variants focused on this topic.\n\n" if topic_hint else ""
    system = (
        "You help improve search queries for a GCSE Mathematics curriculum database. "
        f"{topic_line}"
        "Given a student question, generate exactly three variants:\n"
        "1. A short hypothetical answer excerpt (1-2 sentences) the database might contain\n"
        "2. A broader reformulation of the question\n"
        "3. A narrower, more specific reformulation\n\n"
        "Respond in EXACTLY this format (no extra text):\n"
        "HYDE: [hypothetical answer]\n"
        "BROAD: [broader question]\n"
        "NARROW: [narrower question]"
    )

    context_line = f"Previous tutor message (for context): {context_hint[:200]}\n" if context_hint else ""
    user_content = f"{context_line}Student question: {query}"

    try:
        response = await client.messages.create(
            model=os.getenv("LLM_PRIMARY", "claude-sonnet-4-6"),
            max_tokens=200,
            system=system,
            messages=[{"role": "user", "content": user_content}]
        )
        text = response.content[0].text
        variants = [query]
        for line in text.strip().split("\n"):
            if line.startswith("HYDE:"):
                variants.append(line[5:].strip())
            elif line.startswith("BROAD:"):
                variants.append(line[6:].strip())
            elif line.startswith("NARROW:"):
                variants.append(line[7:].strip())
        return variants[:4]
    except Exception as e:
        print(f"Warning: query enhancement failed ({e}), using original query only")
        return [query]


def _basic_rerank(query: str, results: list[dict]) -> list[dict]:
    """
    Fallback reranker — term-overlap scoring.
    Used when _llm_rerank() fails. Scores each chunk by shared term count with query.
    """
    query_terms = set(re.findall(r'\b\w{3,}\b', query.lower()))
    for result in results:
        doc_terms = set(re.findall(r'\b\w{3,}\b', result["document"].lower()))
        overlap = len(query_terms & doc_terms)
        result["rerank_score"] = overlap / max(len(query_terms), 1)
    return sorted(results, key=lambda x: x["rerank_score"], reverse=True)


async def _llm_rerank(query: str, results: list[dict], client: Anthropic) -> list[dict]:
    """
    Stage 3 — LLM cross-encoder reranking via Claude Haiku.

    Sends a single batch prompt asking the model to rate each chunk's relevance
    to the query on a 0-10 scale. Normalises scores to [0.0, 1.0] and sorts
    descending. Chunks that fail to parse default to 0.0.

    Falls back to _basic_rerank() if the API call fails entirely.
    """
    if not results:
        return results

    # Build numbered passage list (truncate each to 400 chars to stay within token budget)
    passages = "\n\n".join(
        f"[{i + 1}] {r['document'][:400]}"
        for i, r in enumerate(results)
    )

    prompt = (
        f"Rate each passage's relevance to this student question on a scale 0-10.\n"
        f"0 = completely unrelated, 10 = directly answers the question.\n\n"
        f"Question: {query}\n\n"
        f"Passages:\n{passages}\n\n"
        f"Respond ONLY with one score per line in this exact format:\n"
        + "\n".join(f"{i + 1}: <score>" for i in range(len(results)))
    )

    try:
        response = await client.messages.create(
            model="claude-haiku-4.5",
            max_tokens=150,
            messages=[{"role": "user", "content": prompt}]
        )
        text = response.content[0].text.strip()
        scores: dict[int, float] = {}
        for line in text.split("\n"):
            m = re.match(r"(\d+)\s*[:–-]\s*([\d.]+)", line.strip())
            if m:
                idx = int(m.group(1)) - 1
                raw = float(m.group(2))
                scores[idx] = min(raw, 10.0) / 10.0  # normalise to [0, 1]

        for i, result in enumerate(results):
            result["rerank_score"] = scores.get(i, 0.0)

        ranked = sorted(results, key=lambda x: x["rerank_score"], reverse=True)
        print(f"  LLM rerank: top score {ranked[0]['rerank_score']:.2f} "
              f"(topic: {ranked[0]['metadata'].get('topic', '?')})")
        return ranked

    except Exception as e:
        print(f"  Warning: LLM reranking failed ({e}), falling back to term-overlap")
        return _basic_rerank(query, results)


def _get_kg_preferred_chunk_ids(lo_id: str) -> list[str]:
    """
    Phase 5: KG-guided retrieval.
    Follow [:HAS_RESOURCE] edges from the current LO to get preferred chunk IDs.
    Returns empty list if lo_id is unknown, Neo4j is down, or no edges exist.
    """
    try:
        cypher = """
            MATCH (lo:LearningObjective {id: $lo_id})-[:HAS_RESOURCE]->(r:Resource)
            RETURN r.chunk_id AS chunk_id
        """
        with kg_session() as session:
            result = session.run(cypher, lo_id=lo_id)
            return [record["chunk_id"] for record in result if record["chunk_id"]]
    except Exception as e:
        print(f"  KG-guided retrieval skipped ({e})")
        return []


async def retrieve(
    query: str,
    subject: str = "mathematics",
    topic: str | None = None,
    lo_id: str | None = None,
    context_hint: str | None = None,
    n_results: int = TOP_K_RERANKED,
    anthropic_client: Anthropic | None = None,
    concept_ids: list[str] | None = None,
) -> list[dict]:
    """
    Main retrieval function.

    Args:
        query:            Student's question text
        subject:          Filter by subject (default: "mathematics")
        topic:            Optional topic hint for query enhancement
        lo_id:            Optional current LO ID for KG-guided chunk prioritisation
        n_results:        Number of chunks to return (default: TOP_K_RERANKED)
        anthropic_client: Anthropic client for query enhancement
        concept_ids:      Optional list of concept IDs to scope retrieval. When provided,
                          ChromaDB query filters by concept_id metadata. Falls back to
                          unscoped retrieval if no concept-scoped results are found.

    Returns list of dicts:
      [{"id", "document", "metadata", "distance", "rerank_score", "citation_label"}, ...]

    Chunks with rerank_score < RELEVANCE_THRESHOLD are filtered out unless they are
    KG-preferred (HAS_RESOURCE edge). If all chunks are filtered, returns empty list,
    which triggers the C4 hard fallback in tutor_agent.py.

    Called by TutorAgent and AssessmentAgent.
    """
    try:
        collection = _get_collection()
    except Exception:
        # ChromaDB collection absent (e.g. first deploy before ingest) — RAG gracefully unavailable
        return []

    if anthropic_client is None:
        anthropic_client = Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))

    # Phase 5: KG-guided pre-fetch — get preferred chunk IDs from HAS_RESOURCE edges
    kg_chunk_ids: list[str] = []
    if lo_id:
        kg_chunk_ids = _get_kg_preferred_chunk_ids(lo_id)
        if kg_chunk_ids:
            print(f"  KG: {len(kg_chunk_ids)} preferred chunks found for LO {lo_id}")

    # Stage 1: Query Enhancement (topic + conversation context keep short replies on-topic)
    query_variants = await _enhance_query(query, anthropic_client, topic_hint=topic, context_hint=context_hint)
    print(f"  RAG: {len(query_variants)} query variants → ChromaDB...")

    # Stage 2: Multi-query retrieval (deduplicated)
    # Note: topic filter removed for POC — only 3 curriculum files, topic IDs don't yet
    # fully align between DB and ChromaDB (number-basics vs number-and-algebra-basics).
    # Vector similarity handles topic relevance sufficiently at this scale.
    base_filter: dict = {"subject": subject}
    if concept_ids:
        where_filter: dict | None = {"$and": [base_filter, {"concept_id": {"$in": concept_ids}}]}
        print(f"  RAG: concept-scoped retrieval ({len(concept_ids)} concept IDs)")
    else:
        where_filter = base_filter

    total = collection.count()
    if total == 0:
        print("  Warning: poc_curriculum collection is empty — run ingest first")
        return []

    n = min(TOP_K_CANDIDATES, total)

    seen_ids: set[str] = set()
    all_results: list[dict] = []

    # ChromaDB's embedded PersistentClient has no native async API (only AsyncHttpClient,
    # for client/server mode). Each blocking .query() — which embeds the variant via the
    # Voyage AI API — is offloaded to a worker thread and all variants are awaited
    # together, so 4 sequential round-trips become one concurrent wait. Every variant goes
    # through asyncio.to_thread; none is left running inline on the event loop.
    variant_results = await asyncio.gather(
        *[
            asyncio.to_thread(
                collection.query,
                query_texts=[variant],
                n_results=n,
                where=where_filter,
            )
            for variant in query_variants
        ],
        return_exceptions=True,
    )

    for variant, results in zip(query_variants, variant_results):
        if isinstance(results, Exception):
            print(f"  Warning: query variant failed: {results}")
            continue
        for i, doc_id in enumerate(results["ids"][0]):
            if doc_id not in seen_ids:
                seen_ids.add(doc_id)
                all_results.append({
                    "id": doc_id,
                    "document": results["documents"][0][i],
                    "metadata": results["metadatas"][0][i],
                    "distance": results["distances"][0][i]
                })

    # ISC-18: If concept-scoped query returned nothing, fall back to unscoped retrieval
    if not all_results and concept_ids:
        print("  RAG: concept-scoped retrieval returned 0 results — falling back to unscoped")
        seen_ids = set()
        fallback_results = await asyncio.gather(
            *[
                asyncio.to_thread(
                    collection.query,
                    query_texts=[variant],
                    n_results=n,
                    where=base_filter,
                )
                for variant in query_variants
            ],
            return_exceptions=True,
        )
        for variant, results in zip(query_variants, fallback_results):
            if isinstance(results, Exception):
                print(f"  Warning: fallback query variant failed: {results}")
                continue
            for i, doc_id in enumerate(results["ids"][0]):
                if doc_id not in seen_ids:
                    seen_ids.add(doc_id)
                    all_results.append({
                        "id": doc_id,
                        "document": results["documents"][0][i],
                        "metadata": results["metadatas"][0][i],
                        "distance": results["distances"][0][i]
                    })

    if not all_results:
        print("  Warning: no results retrieved from ChromaDB")
        return []

    # Phase 5: Boost KG-preferred chunks — move them to front of results
    if kg_chunk_ids:
        kg_preferred = [r for r in all_results if r["id"] in kg_chunk_ids]
        other        = [r for r in all_results if r["id"] not in kg_chunk_ids]
        all_results  = kg_preferred + other

    # Stage 3: LLM cross-encoder reranking (falls back to term-overlap on failure)
    reranked = (await _llm_rerank(query, all_results, anthropic_client))[:n_results]

    # Filter: keep chunks above threshold, but always keep KG-preferred chunks
    # (they were explicitly linked to this LO via HAS_RESOURCE edges)
    filtered = [
        r for r in reranked
        if r["rerank_score"] >= RELEVANCE_THRESHOLD or r["id"] in kg_chunk_ids
    ]
    n_removed = len(reranked) - len(filtered)
    if n_removed > 0:
        print(f"  RAG: {n_removed} chunk(s) filtered (rerank_score < {RELEVANCE_THRESHOLD:.2f})")
    reranked = filtered

    if not reranked:
        print(f"  RAG: all chunks below relevance threshold {RELEVANCE_THRESHOLD:.2f} — returning empty")
        return []

    # Add citation labels
    for i, result in enumerate(reranked):
        topic_name = result["metadata"].get("topic", "unknown")
        source = result["metadata"].get("source", "curriculum")
        result["citation_label"] = f"[{i + 1}] {topic_name} — {source}"

    return reranked


def format_context(retrieved: list[dict]) -> str:
    """Format retrieved chunks into a context string for LLM prompts."""
    if not retrieved:
        return "No relevant curriculum content found."
    sections = [f"{r['citation_label']}\n{r['document']}" for r in retrieved]
    return "\n\n---\n\n".join(sections)


if __name__ == "__main__":
    test_query = "How do I solve x squared plus 5x plus 6 equals 0?"
    print(f"Testing retrieval for: '{test_query}'")
    results = asyncio.run(retrieve(test_query))
    print(f"\nRetrieved {len(results)} chunks:")
    for r in results:
        print(f"  {r['citation_label']} (rerank_score: {r.get('rerank_score', 0):.3f})")
        print(f"  Preview: {r['document'][:120]}...\n")
    print("✅ retrieve.py self-test complete")
