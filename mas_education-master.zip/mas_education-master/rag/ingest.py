"""
RAG Ingestion Pipeline — MAS Education POC
Ingests curriculum markdown files into ChromaDB poc_curriculum collection.
Uses voyage-3-lite (Voyage AI) for 512-dim embeddings — this MUST stay identical to the
embedding model used by rag/retrieve.py at query time. The live poc_curriculum collection
was built with voyage-3-lite; re-ingesting with any other model would mix incompatible
vector spaces in the same collection and corrupt retrieval. (Ollama is not on the VPS.)

Usage:
    uv run python rag/ingest.py [curriculum_data_dir]
    uv run ingest
"""
import os
import sys
import chromadb
from chromadb.utils.embedding_functions import VoyageAIEmbeddingFunction
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

CHROMA_PATH = os.getenv("CHROMA_PATH")
if not CHROMA_PATH:
    raise EnvironmentError("CHROMA_PATH not set — copy .env.template to .env and fill in values")
COLLECTION_NAME = os.getenv("CHROMA_COLLECTION", "poc_curriculum")
EMBEDDING_MODEL = "voyage-3-lite"  # 512-dim; must match rag/retrieve.py
CHUNK_SIZE = 200   # words per chunk
CHUNK_OVERLAP = 30  # words overlap


def chunk_text(text: str, chunk_size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP) -> list[str]:
    """Split text into overlapping word-based chunks."""
    words = text.split()
    chunks = []
    i = 0
    while i < len(words):
        chunk = " ".join(words[i:i + chunk_size])
        if chunk.strip():
            chunks.append(chunk)
        i += chunk_size - overlap
    return chunks


def get_topic_from_filename(filename: str) -> str:
    """Derive topic ID from filename."""
    return Path(filename).stem.replace("_", "-")


def ingest_file(collection, filepath: Path, topic: str) -> int:
    """Ingest a single curriculum file into ChromaDB. Returns count of new chunks added."""
    text = filepath.read_text(encoding="utf-8")
    chunks = chunk_text(text)

    if not chunks:
        print(f"  Warning: no chunks from {filepath.name}")
        return 0

    ids = [f"{topic}-chunk-{i:03d}" for i in range(len(chunks))]
    metadatas = [
        {
            "topic": topic,
            "difficulty": "GCSE",
            "source": filepath.name,
            "chunk_index": i,
            "subject": "mathematics"
        }
        for i in range(len(chunks))
    ]

    # Check for existing IDs to avoid duplicates
    existing = collection.get(ids=ids)
    existing_ids = set(existing["ids"])

    new_indices = [i for i, id_ in enumerate(ids) if id_ not in existing_ids]
    new_ids = [ids[i] for i in new_indices]
    new_docs = [chunks[i] for i in new_indices]
    new_meta = [metadatas[i] for i in new_indices]

    if new_ids:
        collection.add(ids=new_ids, documents=new_docs, metadatas=new_meta)
        print(f"  Ingested {len(new_ids)} new chunks (skipped {len(existing_ids)} existing)")
    else:
        print(f"  All {len(ids)} chunks already exist — skipped")

    return len(new_ids)


def main():
    curriculum_dir = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("curriculum_data")

    if not curriculum_dir.exists():
        print(f"ERROR: directory not found: {curriculum_dir}")
        sys.exit(1)

    print(f"ChromaDB: {CHROMA_PATH}")
    print(f"Collection: {COLLECTION_NAME}")
    client = chromadb.PersistentClient(path=CHROMA_PATH)

    embedding_fn = VoyageAIEmbeddingFunction(
        model_name=EMBEDDING_MODEL,
        api_key_env_var="VOYAGE_API_KEY",
    )

    collection = client.get_or_create_collection(
        name=COLLECTION_NAME,
        embedding_function=embedding_fn,
        metadata={"hnsw:space": "cosine"}
    )

    print(f"Existing chunks in '{COLLECTION_NAME}': {collection.count()}")

    total_new = 0
    files = sorted(curriculum_dir.glob("*.md")) + sorted(curriculum_dir.glob("*.txt"))
    if not files:
        print("No .md or .txt files found in curriculum_data/")
        sys.exit(1)

    for filepath in files:
        topic = get_topic_from_filename(filepath.name)
        print(f"\nIngesting: {filepath.name} (topic: {topic})")
        count = ingest_file(collection, filepath, topic)
        total_new += count

    final_count = collection.count()
    print(f"\n✅ Ingestion complete. New chunks: {total_new}. Total in '{COLLECTION_NAME}': {final_count}")


if __name__ == "__main__":
    main()
