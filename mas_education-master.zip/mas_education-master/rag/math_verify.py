"""
Math Verification Module — MAS Education POC

Provides symbolic computation checking via sympy to verify mathematical claims.

Used by:
  - Assessment Agent (Phase A): verifies student answer claims
  - Tutor Agent (Phase B): verifies Tutor's assertive solution claims

Strategy: conservative — returns verified=None when the claim cannot be reliably
extracted or parsed. Never raises exceptions to callers.
"""
import re
from dataclasses import dataclass, field
from typing import Any

try:
    import sympy
    from sympy import sympify, simplify, symbols, Eq, solve, N
    from sympy.parsing.sympy_parser import (
        parse_expr, standard_transformations,
        implicit_multiplication_application, convert_xor
    )
    _SYMPY_AVAILABLE = True
except ImportError:
    _SYMPY_AVAILABLE = False


@dataclass
class ComputationResult:
    """
    Result of a symbolic computation check.

    Fields:
        verified:      True = student claim confirmed; False = claim refuted;
                       None = could not verify (no parseable claim found or parse error)
        sympy_value:   What sympy computed (may be None if not applicable)
        student_value: What we extracted from the student's response (may be None)
        method:        Which check was used: "equation_solution", "expression_eval",
                       "algebraic_equivalence", or "none" (when verified=None)
    """
    verified: bool | None = None
    sympy_value: Any = None
    student_value: Any = None
    method: str = "none"


# --- Regex patterns for claim extraction ---

# Assertive solution patterns — Tutor CLAIMING a value is THE answer.
# Matches: "so x = -2", "therefore x = 3", "x = -2 is the solution", "the answer is 6".
# Does NOT match exploratory: "try x = 2", "what if x = -1", "suppose x = 3".
_ASSERTIVE_SOL_RE = re.compile(
    r'(?:so|therefore|thus|hence)\s+([a-zA-Z])\s*=\s*(-?\s*\d+(?:\.\d+)?)'
    r'|([a-zA-Z])\s*=\s*(-?\s*\d+(?:\.\d+)?)\s+is\s+(?:the|a)\s+(?:solution|answer|root)'
    r'|(?:the\s+)?(?:answer|solution|value)\s+is\s+(-?\s*\d+(?:\.\d+)?)',
    re.IGNORECASE
)

# Exploratory language — Tutor suggesting values to try, NOT asserting answers.
_EXPLORATORY_RE = re.compile(
    r'\b(?:try|what\s+if|suppose|let[\'s]*\s+(?:try|see|check)|if\s+we\s+(?:try|use|put|plug))\b',
    re.IGNORECASE
)

# Matches: "x = 2", "x= -3", "x =2.5", "x= 1/2"
_SOLUTION_RE = re.compile(
    r'\b([a-zA-Z])\s*=\s*(-?\s*\d+(?:\.\d+)?(?:\s*/\s*\d+)?)',
    re.IGNORECASE
)

# Matches: "the answer is 6", "answer: -4", "= 5"
_ANSWER_RE = re.compile(
    r'(?:answer\s*(?:is|:)\s*|=\s*)(-?\s*\d+(?:\.\d+)?(?:\s*/\s*\d+)?)',
    re.IGNORECASE
)

# Matches math equations in prose — requires LHS to look like algebra, not English.
# Allows operator-separated terms: "x^2 + 5x + 6 = 0" but NOT "solve me this = 0".
# Key: spaces only permitted around +/- operators, not as arbitrary word separators.
_EQUATION_RE = re.compile(
    r'([a-zA-Z\d](?:[a-zA-Z\d\^\*\(\)]|\s*[\+\-]\s*[a-zA-Z\d])*)\s*=\s*(0|-?\s*\d+(?:\.\d+)?)',
    re.IGNORECASE
)

_PARSE_TRANSFORMS = (
    standard_transformations
    + (implicit_multiplication_application, convert_xor)
)


def evaluate_expression(expr_str: str) -> float | None:
    """
    Safely parse and numerically evaluate a mathematical expression string.

    Returns the float value, or None if parsing fails for any reason.
    Does NOT propagate exceptions.

    Examples:
        "2 + 3"   → 5.0
        "sqrt(4)" → 2.0
        "abc"     → None
    """
    if not _SYMPY_AVAILABLE or not expr_str:
        return None
    try:
        cleaned = expr_str.strip().replace("^", "**")
        expr = parse_expr(cleaned, transformations=_PARSE_TRANSFORMS)
        value = float(N(expr))
        return value
    except Exception:
        return None


def check_equation_solution(
    equation_str: str,
    variable: str,
    student_answer_str: str
) -> bool | None:
    """
    Check whether `student_answer_str` satisfies `equation_str` for `variable`.

    Substitutes the student's numeric answer into the equation's LHS - RHS and
    checks if the result is (approximately) zero.

    Returns True if verified correct, False if refuted, None on any parse error.

    Args:
        equation_str:      The equation text, e.g. "x**2 + 5*x + 6"  (LHS, assumes = 0)
                           or "x**2 + 5*x + 6 = 0" (will strip " = 0")
        variable:          The variable name, e.g. "x"
        student_answer_str: The student's claimed solution, e.g. "2" or "-3"
    """
    if not _SYMPY_AVAILABLE:
        return None
    try:
        # Normalise equation_str — strip "= 0" or "= N" to get expression
        eq_clean = equation_str.strip().replace("^", "**")
        if "=" in eq_clean:
            lhs, rhs = eq_clean.split("=", 1)
            # Build LHS - RHS expression
            expr_str = f"({lhs.strip()}) - ({rhs.strip()})"
        else:
            expr_str = eq_clean

        # Parse equation and student answer
        var = symbols(variable)
        expr = parse_expr(expr_str, transformations=_PARSE_TRANSFORMS, local_dict={variable: var})
        answer = parse_expr(
            student_answer_str.strip().replace("^", "**"),
            transformations=_PARSE_TRANSFORMS
        )

        # Substitute and evaluate
        result = expr.subs(var, answer)
        numerical = float(N(result))
        return abs(numerical) < 1e-6  # True if answer satisfies equation
    except Exception:
        return None


def are_expressions_equivalent(expr_a: str, expr_b: str) -> bool | None:
    """
    Check whether two symbolic expressions are algebraically equivalent.

    Uses sympy.simplify(a - b) == 0.

    Returns True if equivalent, False if not, None on any parse error.
    """
    if not _SYMPY_AVAILABLE:
        return None
    try:
        a = parse_expr(expr_a.strip().replace("^", "**"), transformations=_PARSE_TRANSFORMS)
        b = parse_expr(expr_b.strip().replace("^", "**"), transformations=_PARSE_TRANSFORMS)
        diff = simplify(a - b)
        return diff == 0
    except Exception:
        return None


def verify_response(
    student_response: str,
    question_context: str | None = None
) -> ComputationResult:
    """
    Extract and verify the mathematical claim in a student response.

    Strategy (conservative — prefers verified=None over false negatives):

    1. If question_context contains an equation and student_response contains
       a solution ("x = N"), verify via check_equation_solution.
    2. Otherwise, if student_response contains a plain numeric answer claim,
       evaluate it (for numeric questions like "what is 2 + 3").
    3. If no claim can be reliably extracted, return verified=None.

    All exceptions caught — never propagates to caller.

    Args:
        student_response:  The student's full response text
        question_context:  The tutor's question (last assistant message from history)

    Returns:
        ComputationResult with verified=None when verification is not possible.
    """
    if not _SYMPY_AVAILABLE:
        return ComputationResult(verified=None, method="none")

    try:
        # --- Attempt 1: Equation solution check ---
        # Look for equation in question and solution in student response
        if question_context:
            eq_matches = _EQUATION_RE.findall(question_context)
            sol_matches = _SOLUTION_RE.findall(student_response)

            if eq_matches and sol_matches:
                # Take the first equation and first solution
                lhs, rhs = eq_matches[0]
                equation_lhs = lhs.strip()
                var_name, student_val_str = sol_matches[0]
                student_val_str = student_val_str.replace(" ", "")

                # Reconstruct equation string
                equation_str = f"{equation_lhs} = {rhs.strip()}"
                result = check_equation_solution(equation_str, var_name, student_val_str)

                if result is not None:
                    # Also compute expected solutions for reporting
                    try:
                        var = symbols(var_name)
                        lhs_expr = parse_expr(
                            f"({equation_lhs}) - ({rhs.strip()})".replace("^", "**"),
                            transformations=_PARSE_TRANSFORMS,
                            local_dict={var_name: var}
                        )
                        expected = solve(lhs_expr, var)
                    except Exception:
                        expected = None

                    return ComputationResult(
                        verified=result,
                        sympy_value=expected,
                        student_value=student_val_str,
                        method="equation_solution"
                    )

        # --- Attempt 2: Numeric answer evaluation ---
        # Look for "answer is N" or "= N" patterns in student response
        ans_matches = _ANSWER_RE.findall(student_response)
        if ans_matches:
            student_val_str = ans_matches[0].replace(" ", "")
            student_float = evaluate_expression(student_val_str)
            if student_float is not None:
                # We can confirm the student stated a numeric value, but without
                # knowing the expected answer we can't verify correctness here.
                # Return verified=None — the LLM knows the expected answer.
                pass  # Fall through to return none

        # --- No reliable claim extracted ---
        return ComputationResult(verified=None, method="none")

    except Exception:
        return ComputationResult(verified=None, method="none")


def verify_tutor_claims(
    tutor_response: str,
    student_question: str | None = None
) -> ComputationResult:
    """
    Check whether the Tutor Agent's response contains a provably wrong mathematical claim.

    Only checks ASSERTIVE claims (e.g. "so x = -2", "therefore x = 3", "the answer is 6").
    Exploratory language ("try x = 2", "what if x = -1") is explicitly excluded to avoid
    false positives from the Socratic method's deliberate suggestion of values to test.

    Returns ComputationResult with:
        verified=True   — Tutor's claimed value satisfies the equation in student_question
        verified=False  — Tutor's claimed value does NOT satisfy the equation (arithmetic error)
        verified=None   — No assertive claim found, or unable to verify (safe default)

    Never raises exceptions to caller.

    Args:
        tutor_response:   The Tutor Agent's generated response text
        student_question: The student's input (may contain an equation to check against)
    """
    if not _SYMPY_AVAILABLE or not tutor_response:
        return ComputationResult(verified=None, method="none")

    try:
        # If the sentence containing the claimed solution also contains exploratory language,
        # treat the whole response as exploratory and skip verification.
        if _EXPLORATORY_RE.search(tutor_response):
            # Exploratory phrasing detected — Tutor is suggesting values to test,
            # not asserting an answer. Return None to avoid false positives.
            return ComputationResult(verified=None, method="none")

        # Look for assertive solution patterns in the Tutor's response
        assertive_matches = _ASSERTIVE_SOL_RE.findall(tutor_response)
        if not assertive_matches:
            return ComputationResult(verified=None, method="none")

        # Extract variable and value from the first assertive match
        # Groups: (var_so, val_so) | (var_is, val_is, _, _) | (_, _, val_answer)
        var_name = None
        claimed_val_str = None

        for match in assertive_matches:
            # Pattern 1: "so/therefore/thus/hence X = N"
            if match[0] and match[1]:
                var_name = match[0].strip()
                claimed_val_str = match[1].strip().replace(" ", "")
                break
            # Pattern 2: "X = N is the solution/answer/root"
            elif match[2] and match[3]:
                var_name = match[2].strip()
                claimed_val_str = match[3].strip().replace(" ", "")
                break
            # Pattern 3: "the answer/solution is N" (no variable)
            elif match[4]:
                claimed_val_str = match[4].strip().replace(" ", "")
                break

        if claimed_val_str is None:
            return ComputationResult(verified=None, method="none")

        # If we have an equation in the student's question, verify the claimed value
        if student_question and var_name:
            eq_matches = _EQUATION_RE.findall(student_question)
            if eq_matches:
                lhs, rhs = eq_matches[0]
                equation_str = f"{lhs.strip()} = {rhs.strip()}"
                result = check_equation_solution(equation_str, var_name, claimed_val_str)
                if result is not None:
                    return ComputationResult(
                        verified=result,
                        sympy_value=None,
                        student_value=claimed_val_str,
                        method="equation_solution"
                    )

        # No equation context — evaluate as a numeric expression if possible
        if claimed_val_str:
            val = evaluate_expression(claimed_val_str)
            if val is not None:
                # We know the number parses but can't verify correctness without context
                return ComputationResult(verified=None, method="none")

        return ComputationResult(verified=None, method="none")

    except Exception:
        return ComputationResult(verified=None, method="none")
