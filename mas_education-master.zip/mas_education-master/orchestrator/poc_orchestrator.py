"""
LangGraph Orchestrator — MAS Education POC
Implements the 6-state session machine from v2.0 §4.2:
SESSION_INIT → ROUTE_INTENT → [TUTORING|ASSESSMENT|PLANNING] → REFLECT → DELIVER → LOG_UPDATE
"""
import asyncio
import os
import uuid
import json
from typing import TypedDict, Annotated, Literal
from langgraph.graph import StateGraph, END
from anthropic import Anthropic

from agents.tutor_agent import get_tutor_response
from agents.assessment_agent import score_response
from agents.planning_agent import get_learner_plan, check_advancement
from agents.dialogue_agent import DialogueTracker
from agents.monitor_agent import log_session_event, print_session_report
from db.db import log_audit


class SessionState(TypedDict):
    """State passed through all LangGraph nodes."""
    session_id: str
    learner_id: str
    student_input: str
    conversation_history: list[dict]
    current_topic: str
    current_topic_name: str
    intent: str                      # "tutor" | "assess" | "plan" | "unknown"
    agent_response: str
    rag_chunks: list[dict]
    citations: list[str]
    mastery: float
    engagement_state: str            # EXPLORING | STUCK | BREAKTHROUGH | CONSOLIDATING | MASTERED
    intervention_prompt: str
    should_assess: bool
    advancement_check: dict
    turn_count: int
    ability_signal: int              # Improvement 4: correct first-attempt answers accumulate
    guidance_resistance_count: int   # Improvement 7: times student demanded a direct answer


# Improvement 2: Map topic keywords in student messages to human-readable topic names.
# Used in session_init to override the default KG-assigned LO name.
_TOPIC_OVERRIDES: list[tuple[tuple[str, ...], str]] = [
    (("quadratic", "factorise", "factorize", "trinomial", "x squared", "x²", "x^2"), "quadratic equations"),
    (("graph transform", "f(x+", "f(ax)", "function transform", "translation", "stretch", "reflection of f", "enlargement"), "graph transformations"),
    (("trigonometry", "sin(", "cos(", "tan(", "sine", "cosine", "tangent", "pythagoras"), "trigonometry"),
    (("probability", "likelihood", "dice", "tree diagram", "combined event"), "probability"),
    (("statistics", "mean", "median", "mode", "frequency", "cumulative"), "statistics and data"),
    (("vector", "displacement", "magnitude", "scalar"), "vectors"),
    (("function", "domain", "range", "composite", "inverse function"), "functions"),
    (("area", "volume", "perimeter", "surface area", "cylinder", "sphere", "cone"), "mensuration"),
    (("fraction", "percentage", "%", "ratio", "proportion", "decimal"), "number - fractions, percentages and ratio"),
    (("algebra", "expand", "simplify", "expression", "linear equation", "solve for x", "solve x", "unknown"), "algebra and linear equations"),
    (("geometry", "angle", "triangle", "polygon", "circle", "parallel", "perpendicular", "bisect"), "geometry"),
    (("sequence", "nth term", "arithmetic", "geometric progression"), "sequences"),
    (("simultaneous", "two equations", "system of equations"), "simultaneous equations"),
    (("inequality", "inequalities", "number line"), "inequalities"),
]


def _detect_topic_from_message(text: str) -> str | None:
    """Return a human-readable topic name if the message clearly mentions a maths topic."""
    lowered = text.lower()
    for keywords, topic_name in _TOPIC_OVERRIDES:
        if any(kw in lowered for kw in keywords):
            return topic_name
    return None


def create_orchestrator(anthropic_client: Anthropic, dialogue_tracker: DialogueTracker):
    """Build and compile the LangGraph session graph."""

    async def session_init(state: SessionState) -> SessionState:
        """
        On the first turn of a session (current_topic == "unknown"), load the
        learner's starting LO from the Neo4j knowledge graph.
        Improvement 2: Also detect topic from the student's message and override
        current_topic_name so the LLM context matches what the student is actually
        asking about, regardless of which LO Neo4j assigns as the curriculum starting point.
        On subsequent turns, preserve the existing topic so the learner stays
        on the same LO until they reach mastery threshold (see reflect_node).
        """
        current_topic      = state.get("current_topic", "unknown")
        current_topic_name = state.get("current_topic_name", "Mathematics")

        if current_topic == "unknown":
            try:
                plan    = await asyncio.to_thread(get_learner_plan, state["learner_id"], state["session_id"])
                current = plan.get("current_lo")
                if current:
                    current_topic      = current["id"]
                    current_topic_name = current["text"][:80]
            except Exception:
                pass  # KG unavailable — topic stays "unknown", tutor falls back gracefully

        # Improvement 2: Override topic name from message keywords regardless of KG assignment.
        # This ensures LLM context (RAG hint, assessment expected_concept) matches student intent.
        detected = _detect_topic_from_message(state["student_input"])
        if detected:
            current_topic_name = detected

        return {
            **state,
            "current_topic":      current_topic,
            "current_topic_name": current_topic_name,
            "engagement_state":   dialogue_tracker.state,
            "turn_count":         state.get("turn_count", 0) + 1,
        }

    async def route_intent(state: SessionState) -> SessionState:
        """Classify student intent — tutor, assess, or plan."""
        text = state["student_input"].lower()

        # Improvement 3: Expanded assessment signals to catch natural-language answers
        # (e.g. "x would be 7", "I got 0", "so it must be -3")
        assessment_signals = [
            "answer is", "i think", "the solution", "= ", "equals", "my answer",
            "would be", "must be", "could be", "i got", "i get", "i calculated",
            "works out to", "gives me", "i believe", "is it", "is that right",
            "so it's", "so its", "so x", "so y", "so the",
            "i worked out", "therefore", "which means", "which gives",
            "comes out to", "the answer", "my working",
        ]
        if any(s in text for s in assessment_signals) and state["turn_count"] > 1:
            intent = "assess"
        else:
            intent = "tutor"

        return {**state, "intent": intent}

    async def tutoring_node(state: SessionState) -> SessionState:
        """Tutor Agent generates RAG-grounded Socratic response."""
        # Add dialogue intervention if needed
        intervention = dialogue_tracker.get_intervention_prompt()

        # Improvement 4: Add ability hint for strong learners
        ability_signal = state.get("ability_signal", 0)
        ability_hint = ""
        if ability_signal >= 2:
            ability_hint = " [INTERNAL: This learner has answered correctly multiple times — match their pace. If they clearly understand the current concept, offer an extension or harder variant rather than re-explaining basics.]"

        # Improvement 7: Shift strategy after repeated resistance to Socratic questioning
        resistance_count = state.get("guidance_resistance_count", 0)
        resistance_hint = ""
        if resistance_count >= 2:
            resistance_hint = " [INTERNAL: This learner has asked for direct answers multiple times. Acknowledge their frustration warmly. Offer to verify their own guess via substitution rather than confirming directly. Offer a partial scaffold (e.g. the first step) to unstick them.]"

        student_input_augmented = state["student_input"] + intervention + ability_hint + resistance_hint

        result = await get_tutor_response(
            student_input=student_input_augmented,
            conversation_history=state["conversation_history"],
            session_id=state["session_id"],
            learner_id=state["learner_id"],
            current_topic=state["current_topic_name"],  # LO text for RAG query hint
            lo_id=state["current_topic"],               # Phase 5: LO ID for KG-guided retrieval
            anthropic_client=anthropic_client
        )

        return {
            **state,
            "agent_response": result["response"],
            "rag_chunks": result["rag_chunks_used"],
            "citations": result["citations"],
            "should_assess": False
        }

    async def assessment_node(state: SessionState) -> SessionState:
        """Assessment Agent scores response and updates BKT mastery."""
        # Extract the tutor's last question as context for sympy verification
        history = state.get("conversation_history", [])
        last_assistant = next(
            (msg["content"] for msg in reversed(history) if msg.get("role") == "assistant"),
            None
        )

        result = await score_response(
            student_response=state["student_input"],
            topic_id=state["current_topic"],
            expected_concept=state["current_topic_name"],
            session_id=state["session_id"],
            learner_id=state["learner_id"],
            anthropic_client=anthropic_client,
            question_context=last_assistant
        )

        advancement = await asyncio.to_thread(
            check_advancement, state["learner_id"], state["current_topic"], state["session_id"]
        )

        # Improvement 1: Filter misconceptions that sound like internal diagnostic text.
        # The LLM sometimes returns topic-mismatch notes instead of real misconceptions.
        _INTERNAL_MISCONCEPTION_MARKERS = (
            "student", "discussing", "rather than", "topic", "different subject",
            "not related", "unrelated", "instead of", "instead",
        )
        misconception = result.get("misconception", "none")
        misconception_is_internal = (
            misconception != "none"
            and any(m in misconception.lower() for m in _INTERNAL_MISCONCEPTION_MARKERS)
        )

        # Build response for student
        if result["mastered"]:
            response = f"Excellent! You've mastered {state['current_topic_name']}! 🎉\n{result['feedback']}"
            if advancement.get("next_topic"):
                response += f"\nNext up: {advancement['next_topic']['text'][:60]}"
        else:
            response = result["feedback"]
            if misconception != "none" and not misconception_is_internal:
                response += f"\n\nLet's look at this differently — {misconception}"

        # Improvement 4: Track ability signal — increment when student answers correctly
        new_ability_signal = state.get("ability_signal", 0)
        if result.get("score") == "CORRECT":
            new_ability_signal += 1

        return {
            **state,
            "agent_response": response,
            "mastery": result["new_mastery"],
            "advancement_check": advancement,
            "should_assess": True,
            "ability_signal": new_ability_signal,
        }

    async def reflect_node(state: SessionState) -> SessionState:
        """Update dialogue tracker with latest exchange."""
        dialogue_result = dialogue_tracker.update(
            student_input=state["student_input"],
            agent_response=state["agent_response"],
            mastery=state.get("mastery", 0.0)
        )

        # Update topic if advancement triggered
        new_topic = state["current_topic"]
        new_topic_name = state["current_topic_name"]

        advancement = state.get("advancement_check", {})
        if advancement.get("advance") and advancement.get("next_topic"):
            new_topic = advancement["next_topic"]["id"]
            new_topic_name = advancement["next_topic"]["text"][:80]

        return {
            **state,
            "engagement_state": dialogue_result["state"],
            "current_topic": new_topic,
            "current_topic_name": new_topic_name
        }

    async def deliver_node(state: SessionState) -> SessionState:
        """Format final response for delivery."""
        return state  # Response already formatted; add source display here if needed

    async def log_update_node(state: SessionState) -> SessionState:
        """Update conversation history, log session event."""
        history = list(state.get("conversation_history", []))
        history.append({"role": "user", "content": state["student_input"]})
        history.append({"role": "assistant", "content": state["agent_response"]})

        log_session_event(
            session_id=state["session_id"],
            learner_id=state["learner_id"],
            event_type="turn_complete",
            agent="orchestrator",
            data={
                "turn": state["turn_count"],
                "intent": state["intent"],
                "engagement_state": state["engagement_state"],
                "citations": state.get("citations", [])
            }
        )

        return {**state, "conversation_history": history[-12:]}  # Keep last 6 turns

    def route_after_intent(state: SessionState) -> Literal["tutoring", "assessment"]:
        return "assessment" if state["intent"] == "assess" else "tutoring"

    # Build graph
    graph = StateGraph(SessionState)
    graph.add_node("session_init", session_init)
    graph.add_node("route_intent", route_intent)
    graph.add_node("tutoring", tutoring_node)
    graph.add_node("assessment", assessment_node)
    graph.add_node("reflect", reflect_node)
    graph.add_node("deliver", deliver_node)
    graph.add_node("log_update", log_update_node)

    graph.set_entry_point("session_init")
    graph.add_edge("session_init", "route_intent")
    graph.add_conditional_edges("route_intent", route_after_intent,
                                 {"tutoring": "tutoring", "assessment": "assessment"})
    graph.add_edge("tutoring", "reflect")
    graph.add_edge("assessment", "reflect")
    graph.add_edge("reflect", "deliver")
    graph.add_edge("deliver", "log_update")
    graph.add_edge("log_update", END)

    return graph.compile()
