# Bearings and Scale Drawings — GCSE Mathematics

## Compass Bearings

A bearing is a direction measured as an angle clockwise from North.
Bearings are always written as three digits (e.g., 045°, 090°, 270°).

Key directions:
- North: 000°
- East: 090°
- South: 180°
- West: 270°

## Reading and Calculating Bearings

To measure a bearing from A to B:
1. Stand at point A, face North
2. Rotate clockwise until you face B
3. The angle rotated is the bearing

Example: B is directly east of A. The bearing of B from A is 090°.
Example: C is south-west of A. The bearing of C from A is 225°.

## Back Bearings

If the bearing from A to B is θ°, then the bearing from B to A (the back bearing) is:
- θ + 180° if θ < 180°
- θ − 180° if θ > 180°

Example: Bearing from P to Q is 070°. Bearing from Q to P = 070° + 180° = 250°.

## Bearings Problems

Bearings problems often involve:
- Drawing triangles and using Pythagoras or trigonometry
- Using the sine or cosine rule for non-right-angled situations

Example: A ship travels 8 km on bearing 030°, then 6 km on bearing 120°.
Draw a diagram: first leg is 30° from North (NNE), second leg is 120° (ESE).
The angle between the two legs = 120° − 30° = 90°
Distance from start = √(8² + 6²) = √(64 + 36) = √100 = 10 km

## Scale Drawings

A scale drawing uses a ratio to represent real distances.
Scale 1:50,000 means 1 cm on map = 50,000 cm = 500 m in real life.
Scale 1:25 means 1 cm represents 25 cm.

To find real distance: real distance = map distance × scale denominator
To find map distance: map distance = real distance ÷ scale denominator

Example: Scale 1:200. A room is 6 cm on the plan. Real length = 6 × 200 = 1200 cm = 12 m.

## Loci and Constructions

A locus (plural: loci) is the set of all points satisfying a given condition.
- Points equidistant from a fixed point: circle
- Points equidistant from two points: perpendicular bisector of the line joining them
- Points equidistant from a line: parallel lines on each side
- Points equidistant from two lines: angle bisector

To construct a perpendicular bisector: use compasses set to >half the length, draw arcs above and below, join the intersection points.
To construct an angle bisector: from the vertex, draw equal arcs on both arms, then from those arcs draw equal arcs to find the bisector point.
