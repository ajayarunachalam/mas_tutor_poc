# Functions and Coordinate Geometry — Cambridge International AS & A Level Mathematics (9709)

## Even, Odd and Periodic Functions

**Even function:** f(−x) = f(x) for all x — symmetric about the y-axis.
Examples: cos x, x², |x|.

**Odd function:** f(−x) = −f(x) for all x — 180° rotational symmetry about the origin.
Examples: sin x, x³, tan x.

**Periodic function:** f(x + T) = f(x) for all x, where T is the period.
Examples: sin x (period 2π), cos x (period 2π), tan x (period π).

To determine type, substitute −x and simplify: if you get f(x) → even; if you get −f(x) → odd; otherwise neither.

## Modulus Function at A Level

At A Level, modulus problems become more complex:

To solve |f(x)| = |g(x)|: square both sides (f(x))² = (g(x))², or split into f(x) = g(x) and f(x) = −g(x) — always check solutions in the original equation.

To sketch y = |f(x)|: draw y = f(x) first, then reflect negative portions above the x-axis.

Example: Solve |2x − 1| = |x + 3|.
Case 1: 2x − 1 = x + 3 → x = 4. Check: |7| = |7| ✓.
Case 2: 2x − 1 = −(x + 3) → 3x = −2 → x = −2/3. Check: |−7/3| = |7/3| ✓.

## Circles

The general equation of a circle with centre (a, b) and radius r:

(x − a)² + (y − b)² = r²

The expanded form x² + y² + 2gx + 2fy + c = 0 has:
- centre (−g, −f)
- radius √(g² + f² − c) (provided g² + f² − c > 0)

**To convert to standard form:** complete the square in x and y separately.

Example: Find the centre and radius of x² + y² − 6x + 4y − 3 = 0.
(x² − 6x + 9) + (y² + 4y + 4) = 3 + 9 + 4 = 16
(x − 3)² + (y + 2)² = 16
Centre (3, −2), radius 4.

**Tangent to a circle:** The tangent at point P on a circle is perpendicular to the radius at P.

Strategy:
1. Find the gradient of the radius CP (centre to P)
2. Tangent gradient = −1 / (radius gradient)
3. Use y − y₁ = m(x − x₁) with point P

Example: Find the equation of the tangent to (x−1)² + (y+2)² = 25 at point (4, 2).
Gradient of radius: (2−(−2))/(4−1) = 4/3.
Tangent gradient: −3/4.
Tangent: y − 2 = −3/4 (x − 4) → y = −3x/4 + 5.

## Parametric Equations

A curve defined parametrically gives x and y each as functions of a parameter t (or θ):
x = f(t), y = g(t).

**Converting to Cartesian form:** eliminate t by expressing t from one equation and substituting into the other, or using a trigonometric identity.

Example: x = 2cos θ, y = 3sin θ. Find the Cartesian equation.
cos θ = x/2, sin θ = y/3.
Using sin²θ + cos²θ = 1: x²/4 + y²/9 = 1 (an ellipse).

Example: x = t², y = 2t. Find the Cartesian equation.
t = y/2, so x = (y/2)² = y²/4, giving y² = 4x (a parabola).

## Gradient of a Parametric Curve

Use the chain rule:
dy/dx = (dy/dt) / (dx/dt)

Example: For x = t³, y = t² − 4t, find dy/dx in terms of t.
dx/dt = 3t², dy/dt = 2t − 4.
dy/dx = (2t − 4)/(3t²).

At t = 2: dy/dx = 0/12 = 0 (stationary point).

**Finding a tangent to a parametric curve:**
1. Compute dx/dt and dy/dt
2. Find dy/dx at the given parameter value
3. Find x and y coordinates at that parameter value
4. Write the tangent equation using y − y₀ = m(x − x₀)

Example: For the curve x = t + 1, y = t² − 3, find the equation of the normal at t = 2.
x = 3, y = 1. dx/dt = 1, dy/dt = 2t = 4. dy/dx = 4.
Normal gradient = −1/4.
Normal: y − 1 = −1/4(x − 3) → 4y − 4 = −x + 3 → x + 4y = 7.
