# Straight-Line Graphs — GCSE Mathematics

## The Equation y = mx + c

Every straight line can be written as y = mx + c where:
- m = gradient (slope) — how steep the line is
- c = y-intercept — where the line crosses the y-axis

Examples:
- y = 3x + 2: gradient 3, y-intercept (0, 2)
- y = −2x + 5: gradient −2, y-intercept (0, 5)
- y = 4x: gradient 4, y-intercept (0, 0)

## Finding the Gradient

Gradient = change in y ÷ change in x = (y₂ − y₁) / (x₂ − x₁)

Positive gradient: line slopes upward left to right.
Negative gradient: line slopes downward left to right.
Zero gradient: horizontal line.
Undefined gradient: vertical line.

Example: Points A(1, 3) and B(4, 9). Gradient = (9 − 3)/(4 − 1) = 6/3 = 2.

## Drawing a Straight Line from its Equation

Method 1: Table of values — substitute x values to find y values, plot and join.
Method 2: Use y-intercept (0, c) and gradient — plot (0, c), then go right 1 unit and up m units.

For y = 2x − 1: start at (0, −1), go right 1, up 2 to get (1, 1), right 1, up 2 to get (2, 3). Join.

## Finding the Equation from a Graph or Points

From a graph: read the gradient (rise/run) and y-intercept.
From two points: calculate gradient m = (y₂−y₁)/(x₂−x₁), then substitute one point into y = mx + c to find c.

Example: Find equation of line through (2, 5) and (4, 11).
m = (11−5)/(4−2) = 6/2 = 3
Substitute (2, 5): 5 = 3(2) + c → c = 5 − 6 = −1
Equation: y = 3x − 1

## Parallel and Perpendicular Lines (Extended Tier)

**Parallel lines** have the same gradient.
If a line is y = 3x + 2, a parallel line has gradient 3: e.g., y = 3x − 7.

**Perpendicular lines**: gradients multiply to −1.
If line has gradient m, perpendicular gradient = −1/m.
Example: Line with gradient 2 → perpendicular gradient = −1/2.

To find the equation of a perpendicular line through a specific point:
1. Find the perpendicular gradient
2. Substitute the point into y = mx + c
3. Solve for c

Example: Find the equation of the line perpendicular to y = 2x + 1 passing through (4, 3).
Perpendicular gradient = −1/2
3 = −1/2 × 4 + c → 3 = −2 + c → c = 5
Equation: y = −x/2 + 5 or 2y = −x + 10 or x + 2y = 10

## Special Lines

- x = k: vertical line through (k, 0)
- y = k: horizontal line through (0, k)
- y = x: diagonal line through origin, gradient 1
- y = −x: diagonal line through origin, gradient −1
