# Graphs of Functions — GCSE Mathematics

## Quadratic Graphs (y = ax² + bx + c)

All quadratic graphs are parabolas:
- a > 0: U-shape (minimum point)
- a < 0: ∩-shape (maximum point)

Key features:
- Vertex (turning point): minimum or maximum
- y-intercept: set x = 0 → y = c
- x-intercepts (roots): set y = 0 and solve quadratic
- Line of symmetry: x = −b/(2a)

Sketching y = x² − 2x − 3:
y-intercept: (0, −3)
Roots: x² − 2x − 3 = 0 → (x−3)(x+1) = 0 → x = 3 or x = −1
Vertex at x = 1: y = 1 − 2 − 3 = −4 → vertex (1, −4)

## Cubic Graphs (y = ax³ + ...)

General shape: smooth S-curve with one or two turning points.
y = x³: increases throughout, point of inflexion at origin.
y = −x³: same but reflected.
y = x³ − 3x: has a local maximum and local minimum.

## Exponential Graphs (y = aˣ)

y = 2ˣ: always positive, passes through (0, 1), steeply increasing.
y = (1/2)ˣ: always positive, passes through (0, 1), decreasing.
All exponential graphs of form y = aˣ pass through (0, 1).
Asymptote: the x-axis (y = 0). The curve approaches but never reaches y = 0.

## Reciprocal Graphs (y = k/x)

y = 1/x: two branches, one in first quadrant, one in third quadrant.
Asymptotes: x-axis and y-axis. Graph never crosses either axis.
y = −1/x: branches in second and fourth quadrants.

## Distance-Time and Speed-Time Graphs

**Distance-time graphs:**
- Gradient = speed
- Horizontal line = stationary
- Steeper gradient = faster speed
- Negative gradient = returning toward start

**Speed-time graphs:**
- Gradient = acceleration
- Area under graph = distance travelled
- Horizontal line = constant speed
- Rising line = accelerating
- Falling line = decelerating

## Recognising Graph Types

| Equation | Shape | Key Feature |
|----------|-------|-------------|
| y = mx + c | Straight line | Constant gradient |
| y = ax² + bx + c | Parabola | U or ∩ shape |
| y = ax³ | Cubic | S-curve |
| y = a/x | Hyperbola | Two branches, asymptotes |
| y = aˣ | Exponential | Passes through (0,1), asymptote y=0 |

## Differentiation (Extended Tier)

The gradient of a curve at a point = the gradient of the tangent at that point.

For y = xⁿ: dy/dx = nxⁿ⁻¹

Example: y = 3x² − 4x + 2
dy/dx = 6x − 4

At x = 2: gradient = 6(2) − 4 = 8

Turning points (maxima/minima): set dy/dx = 0 and solve.
Second derivative: d²y/dx² > 0 → minimum; d²y/dx² < 0 → maximum.
