# Trigonometry — Cambridge IGCSE Additional Mathematics (0606)

## Exact Values of Trigonometric Functions

You must know these exact values without a calculator:

| Angle | sin | cos | tan |
|---|---|---|---|
| 0° (0 rad) | 0 | 1 | 0 |
| 30° (π/6) | 1/2 | √3/2 | 1/√3 |
| 45° (π/4) | 1/√2 | 1/√2 | 1 |
| 60° (π/3) | √3/2 | 1/2 | √3 |
| 90° (π/2) | 1 | 0 | undefined |

Memory aid: for sin, the values are 0/2, 1/2, √2/2, √3/2, 2/2 for 0°,30°,45°,60°,90°.

## The Pythagorean Identity

sin²θ + cos²θ = 1 (fundamental — used constantly)

Rearrangements:
- sin²θ = 1 − cos²θ
- cos²θ = 1 − sin²θ

Dividing throughout by cos²θ: tan²θ + 1 = sec²θ
Dividing throughout by sin²θ: 1 + cot²θ = cosec²θ

## Reciprocal Trigonometric Functions

- **secant:** sec θ = 1/cos θ (undefined where cos θ = 0)
- **cosecant:** cosec θ = 1/sin θ (undefined where sin θ = 0)
- **cotangent:** cot θ = cos θ/sin θ = 1/tan θ

Example: If sin θ = 3/5 (in first quadrant), find cos θ, tan θ, sec θ, cosec θ.
cos θ = 4/5 (from sin²θ + cos²θ = 1, taking positive root)
tan θ = (3/5)/(4/5) = 3/4
sec θ = 5/4, cosec θ = 5/3

## Radians and Circle Measure

Radians are the natural unit for angles in advanced mathematics.

π radians = 180°, so 1 radian ≈ 57.3°

**Converting:** degrees → radians: multiply by π/180
radians → degrees: multiply by 180/π

Examples: 60° = π/3 rad, 270° = 3π/2 rad, 1.2 rad = 1.2 × 180/π ≈ 68.8°

**Arc length and sector area** for a sector with radius r and angle θ (in radians):
- Arc length: s = rθ
- Sector area: A = ½r²θ

Example: A sector has radius 8 cm and angle 1.5 rad.
Arc length = 8 × 1.5 = 12 cm
Area = ½ × 64 × 1.5 = 48 cm²

## Solving Trigonometric Equations

**General strategy:**
1. Rearrange to have a single trig function on one side
2. Find the principal value using inverse trig
3. Use symmetry (CAST diagram) to find all solutions in the given interval

CAST diagram (anticlockwise from bottom-right):
- 4th quadrant (0–90°): All positive
- 1st quadrant (90–180°): Sine positive
- 2nd quadrant (180–270°): Tangent positive
- 3rd quadrant (270–360°): Cosine positive

Example: Solve 2cos θ − 1 = 0 for 0° ≤ θ ≤ 360°.
cos θ = 1/2. Principal value: θ = 60°.
Cosine is also positive in 4th quadrant: θ = 360° − 60° = 300°.
Solutions: θ = 60° or θ = 300°.

Example: Solve sin²θ − sin θ = 0 for 0 ≤ θ ≤ 2π.
Factor: sin θ(sin θ − 1) = 0
sin θ = 0: θ = 0, π, 2π
sin θ = 1: θ = π/2
Solutions: θ = 0, π/2, π, 2π.

## Proving Trigonometric Identities

Work on one side only. Use known identities to transform it into the other side.

Useful starting moves:
- Replace sec, cosec, cot with sin/cos equivalents
- Use sin²θ + cos²θ = 1 and its rearrangements
- Factorise or multiply by a conjugate

Example: Prove that (1 − sin²θ)/cos θ = cos θ.
LHS = cos²θ/cos θ = cos θ = RHS ✓

Example: Prove that sec²θ − tan²θ = 1.
LHS = (1/cos²θ) − (sin²θ/cos²θ) = (1 − sin²θ)/cos²θ = cos²θ/cos²θ = 1 = RHS ✓
