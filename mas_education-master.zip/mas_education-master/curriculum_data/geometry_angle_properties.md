# Angle Properties — GCSE Mathematics

## Types of Angles

- Acute angle: less than 90°
- Right angle: exactly 90°
- Obtuse angle: between 90° and 180°
- Straight angle: exactly 180°
- Reflex angle: between 180° and 360°

Angles on a straight line add up to 180°.
Angles around a point add up to 360°.
Vertically opposite angles are equal.

## Angles in Triangles and Polygons

The angles in any triangle add up to 180°.

Example: A triangle has angles 50° and 70°. Find the third angle.
Third angle = 180° − 50° − 70° = 60°

The exterior angle of a triangle equals the sum of the two non-adjacent interior angles.

Sum of interior angles of a polygon = (n − 2) × 180°, where n = number of sides.

For a regular polygon: each interior angle = (n − 2) × 180° ÷ n
Each exterior angle of a regular polygon = 360° ÷ n

Examples:
- Regular hexagon: interior angle = (6 − 2) × 180° ÷ 6 = 120°
- Regular pentagon: exterior angle = 360° ÷ 5 = 72°

## Angles and Parallel Lines

When a transversal crosses two parallel lines:
- Corresponding angles are equal (F-shape)
- Alternate angles are equal (Z-shape)
- Co-interior (same-side interior) angles add up to 180° (C-shape)

Example: Two parallel lines are cut by a transversal. One angle is 65°. Find all other angles.
The corresponding angle is also 65°. The alternate angle is 65°. The co-interior angle is 180° − 65° = 115°.

## Circle Theorems (Extended Tier)

- The angle at the centre is twice the angle at the circumference (same arc).
- Angles in the same segment are equal.
- The angle in a semicircle is 90° (angle in a semicircle theorem).
- Opposite angles in a cyclic quadrilateral add up to 180°.
- The tangent to a circle is perpendicular to the radius at the point of contact.
- Tangents drawn from an external point are equal in length.
- The alternate segment theorem: angle between tangent and chord equals the inscribed angle in the alternate segment.

## Worked Example

A circle has centre O. Points A, B, and C are on the circle. Angle AOC = 110°. Find angle ABC.
Angle ABC = 110° ÷ 2 = 55° (angle at centre = twice angle at circumference)
