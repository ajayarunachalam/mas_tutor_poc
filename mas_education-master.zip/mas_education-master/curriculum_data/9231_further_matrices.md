# Further Matrices — Cambridge International AS & A Level Further Mathematics (9231)

## Matrix Multiplication

For matrices A (m×n) and B (n×p), the product AB is an m×p matrix. Element (AB)ᵢⱼ = row i of A dotted with column j of B.

**Condition:** The number of columns in A must equal the number of rows in B.

Example: A = [[1, 2], [3, 4]], B = [[5, 6], [7, 8]].
AB = [[(1×5+2×7), (1×6+2×8)], [(3×5+4×7), (3×6+4×8)]] = [[19, 22], [43, 50]].

**Key properties:**
- Matrix multiplication is NOT commutative: AB ≠ BA in general
- (AB)C = A(BC) (associativity holds)
- (AB)ᵀ = BᵀAᵀ (transpose reverses order)

## Determinant

**2×2 matrix:** det [[a,b],[c,d]] = ad − bc

**3×3 matrix (cofactor expansion along row 1):**
det [[a,b,c],[d,e,f],[g,h,i]] = a(ei−fh) − b(di−fg) + c(dh−eg)

A matrix is **singular** if det = 0 (non-invertible). A **non-singular** matrix has det ≠ 0.

Example: Find det [[2, 3, 1], [1, −1, 2], [4, 0, −3]].
= 2[(−1)(−3) − (2)(0)] − 3[(1)(−3) − (2)(4)] + 1[(1)(0) − (−1)(4)]
= 2[3] − 3[−11] + 1[4]
= 6 + 33 + 4 = 43.

## Inverse Matrix

For a 2×2 non-singular matrix A = [[a,b],[c,d]]:
A⁻¹ = (1/det A) × [[d, −b], [−c, a]]

(swap the diagonal, negate the off-diagonal, divide by determinant)

**Property:** AA⁻¹ = A⁻¹A = I (identity matrix).

For a 3×3 matrix, use the adjugate (matrix of cofactors, transposed) divided by the determinant. In exams, the method of row reduction or the adjugate formula is used.

Example: Find the inverse of A = [[3, 1], [5, 2]].
det A = 6 − 5 = 1.
A⁻¹ = [[2, −1], [−5, 3]].
Verify: [[3,1],[5,2]] × [[2,−1],[−5,3]] = [[6−5, −3+3],[10−10, −5+6]] = [[1,0],[0,1]] ✓.

**Solving Ax = b using inverse:** x = A⁻¹b.

## Eigenvalues and Eigenvectors

A non-zero vector **v** is an **eigenvector** of matrix A with **eigenvalue** λ if:
A**v** = λ**v**

This means (A − λI)**v** = 0 has a non-trivial solution, which requires:
det(A − λI) = 0 (the **characteristic equation**)

**Finding eigenvalues:**
1. Form A − λI
2. Set det(A − λI) = 0 and solve for λ

**Finding eigenvectors:** For each λ, solve (A − λI)**v** = 0 to find **v**.

Example: Find eigenvalues and eigenvectors of A = [[4, 1], [2, 3]].

**Step 1:** det(A − λI) = det[[4−λ, 1],[2, 3−λ]] = (4−λ)(3−λ) − 2 = 0.
= λ² − 7λ + 12 − 2 = λ² − 7λ + 10 = (λ−2)(λ−5) = 0.
Eigenvalues: λ = 2 and λ = 5.

**Step 2 (λ = 2):** A − 2I = [[2, 1],[2, 1]]. Solve [[2,1],[2,1]]**v** = 0.
2v₁ + v₂ = 0 → v₂ = −2v₁. Eigenvector: (1, −2).

**Step 3 (λ = 5):** A − 5I = [[−1, 1],[2, −2]]. Solve [[−1,1],[2,−2]]**v** = 0.
−v₁ + v₂ = 0 → v₁ = v₂. Eigenvector: (1, 1).

## Diagonalisation

If A has n linearly independent eigenvectors, it can be diagonalised:
A = PDP⁻¹

where P = matrix of eigenvectors (columns) and D = diagonal matrix of eigenvalues.

**Application — computing powers:**
Aⁿ = PDⁿP⁻¹ and Dⁿ = diag(λ₁ⁿ, λ₂ⁿ) is trivially easy to compute.

Example (continued): P = [[1, 1],[−2, 1]], D = [[2, 0],[0, 5]].
P⁻¹ = (1/(1+2)) × [[1, −1],[2, 1]] = [[1/3, −1/3],[2/3, 1/3]].
A¹⁰ = P × [[2¹⁰, 0],[0, 5¹⁰]] × P⁻¹.

**Note:** Not all matrices are diagonalisable (repeated eigenvalues with fewer independent eigenvectors prevent diagonalisation).
