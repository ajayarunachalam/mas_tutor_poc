# Index Laws — GCSE Mathematics

## Basic Index Laws

When working with powers (indices), the following rules apply:

**Multiplication**: xᵃ × xᵇ = xᵃ⁺ᵇ — add indices
Example: x³ × x⁵ = x⁸; 2³ × 2⁴ = 2⁷ = 128

**Division**: xᵃ ÷ xᵇ = xᵃ⁻ᵇ — subtract indices
Example: x⁷ ÷ x³ = x⁴; 5⁶ ÷ 5² = 5⁴ = 625

**Power of a power**: (xᵃ)ᵇ = xᵃᵇ — multiply indices
Example: (x²)³ = x⁶; (3²)⁴ = 3⁸

**Zero power**: x⁰ = 1 (for any x ≠ 0)
Example: 5⁰ = 1; (1000)⁰ = 1

## Negative Indices

x⁻ᵃ = 1/xᵃ

Example: x⁻³ = 1/x³
Example: 4⁻² = 1/4² = 1/16
Example: 2⁻¹ = 1/2 = 0.5

## Fractional Indices (Extended Tier)

x^(1/n) = ⁿ√x (nth root)
Example: x^(1/2) = √x (square root)
Example: x^(1/3) = ∛x (cube root)
Example: 27^(1/3) = ∛27 = 3

x^(m/n) = (ⁿ√x)ᵐ = ⁿ√(xᵐ)
Example: 8^(2/3) = (∛8)² = 2² = 4
Example: 32^(3/5) = (⁵√32)³ = 2³ = 8

## Mixed Examples

Simplify: (3x²y³)² = 9x⁴y⁶
Simplify: (2x³)³/(x²) = 8x⁹/x² = 8x⁷
Simplify: x⁻² × x⁵ = x³

## Standard Form

Standard form (scientific notation) expresses numbers as: a × 10ⁿ, where 1 ≤ a < 10.

Large numbers: 3,400,000 = 3.4 × 10⁶
Small numbers: 0.00056 = 5.6 × 10⁻⁴

Multiplying in standard form:
(3 × 10⁴) × (2 × 10³) = 6 × 10⁷

Dividing in standard form:
(8 × 10⁶) ÷ (4 × 10²) = 2 × 10⁴

Adding/subtracting: convert to same power first.
(3 × 10⁴) + (2 × 10³) = (3 × 10⁴) + (0.2 × 10⁴) = 3.2 × 10⁴

## Surds (Related Topic)

A surd is an irrational root that cannot be simplified to a rational number.
√2, √3, √5 are surds. √4 = 2 is NOT a surd.

Simplifying surds: √12 = √(4×3) = 2√3
Multiplying surds: √a × √b = √(ab) → √5 × √3 = √15
Rationalising the denominator: 1/√2 = √2/2 (multiply numerator and denominator by √2)
