# Vectors — Cambridge International AS & A Level Mathematics (9709)

## 3D Vectors — Basics

A vector in 3D is written in column form or using unit vectors **i**, **j**, **k**:

a = (a₁, a₂, a₃) = a₁**i** + a₂**j** + a₃**k**

**Magnitude (modulus):** |a| = √(a₁² + a₂² + a₃²)

**Unit vector in direction of a:** â = a / |a|

**Addition and scalar multiplication:**
a + b = (a₁+b₁, a₂+b₂, a₃+b₃)
λa = (λa₁, λa₂, λa₃)

Example: If a = (2, −1, 3) and b = (1, 4, −2):
a + b = (3, 3, 1)
|a| = √(4 + 1 + 9) = √14
Unit vector: (2/√14, −1/√14, 3/√14)

**Position vectors:** The position vector of point A is OA = **a** (from origin O to A).
The vector AB = OB − OA = **b** − **a**.

**Midpoint** of AB: (**a** + **b**) / 2.

## The Scalar (Dot) Product

For vectors a and b:
a · b = a₁b₁ + a₂b₂ + a₃b₃ = |a||b| cos θ

where θ is the angle between the vectors.

**Key results:**
- If a · b = 0 and neither vector is zero, then a ⊥ b (perpendicular)
- a · a = |a|²

**Finding the angle between vectors:**
cos θ = (a · b) / (|a||b|)

Example: Find the angle between a = (1, 2, 2) and b = (2, −1, 2).
a · b = 2 − 2 + 4 = 4.
|a| = √9 = 3, |b| = √9 = 3.
cos θ = 4/9 → θ = arccos(4/9) ≈ 63.6°.

Example: Find the value of k such that a = (3, k, 1) is perpendicular to b = (2, −3, 9).
a · b = 6 − 3k + 9 = 0 → 3k = 15 → k = 5.

## Vector Equation of a Straight Line

A line through point A (position vector **a**) with direction vector **d** has vector equation:

**r** = **a** + t**d**, t ∈ ℝ

Or equivalently: **r** = (1−t)**a** + t**b** (line through A and B).

Example: Write the vector equation of the line through (1, 2, −1) and (3, 0, 2).
Direction vector: **d** = (3, 0, 2) − (1, 2, −1) = (2, −2, 3).
**r** = (1, 2, −1) + t(2, −2, 3).
In component form: x = 1+2t, y = 2−2t, z = −1+3t.

**Symmetric (Cartesian) form:** (x − x₀)/d₁ = (y − y₀)/d₂ = (z − z₀)/d₃

## Intersection, Parallel and Skew Lines

**Parallel lines** have the same direction vector (or a scalar multiple).

**Intersecting lines** share a common point: set the two parametric forms equal and solve.

**Skew lines** neither intersect nor are parallel — they exist in 3D and have no meeting point.

To determine the relationship between lines:
1. Check if direction vectors are parallel.
2. If not parallel, set up equations for intersection by equating components.
3. Solve the first two equations for the two parameters, then check if they satisfy the third equation.
   - If yes: lines intersect.
   - If no: lines are skew.

Example: Determine whether the lines intersect.
l₁: **r** = (1, 2, 3) + s(1, 1, −1)
l₂: **r** = (3, 4, 1) + t(2, 1, 0)

Equations: 1 + s = 3 + 2t, 2 + s = 4 + t, 3 − s = 1.
From equation 3: s = 2.
From equation 2: 4 = 4 + t → t = 0.
Check equation 1: 1 + 2 = 3 + 0 ✓. Lines intersect at (3, 4, 1).

## Perpendicular Distance from a Point to a Line

To find the distance from point P to line l (**r** = **a** + t**d**):
1. Find the foot of perpendicular F: set t so that PF · **d** = 0.
2. Compute |PF|.

Example: Find the distance from P(4, 1, 2) to the line **r** = (1, 3, 0) + t(2, 1, 2).
F = (1+2t, 3+t, 2t).
PF = F − P = (−3+2t, 2+t, −2+2t).
PF · (2, 1, 2) = 2(−3+2t) + (2+t) + 2(−2+2t) = −6+4t+2+t−4+4t = −8+9t = 0.
t = 8/9.
F = (1+16/9, 3+8/9, 16/9) = (25/9, 35/9, 16/9).
PF = (25/9−4, 35/9−1, 16/9−2) = (−11/9, 26/9, −2/9).
|PF| = (1/9)√(121 + 676 + 4) = (1/9)√801 = √(801/81) ≈ 3.15.
