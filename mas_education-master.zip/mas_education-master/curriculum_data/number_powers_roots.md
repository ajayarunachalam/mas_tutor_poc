# Powers, Roots, and Indices — GCSE Mathematics

## Square Numbers and Square Roots

Perfect squares: 1, 4, 9, 16, 25, 36, 49, 64, 81, 100, 121, 144, ...
Square root (√) is the inverse of squaring.
√49 = 7, √144 = 12, √0.25 = 0.5

Note: every positive number has two square roots (+ve and −ve).
√25 = ±5, but by convention √25 refers to the positive root = 5.

## Cube Numbers and Cube Roots

Perfect cubes: 1, 8, 27, 64, 125, 216, 343, ...
Cube root (∛) is the inverse of cubing.
∛27 = 3, ∛64 = 4, ∛1000 = 10

Negative cubes: (−3)³ = −27, so ∛(−27) = −3 (cube roots of negative numbers exist).

## Index (Power) Notation

xⁿ means x multiplied by itself n times.
2⁵ = 2 × 2 × 2 × 2 × 2 = 32
5³ = 125, 3⁴ = 81

Key index rules:
- xᵃ × xᵇ = xᵃ⁺ᵇ
- xᵃ ÷ xᵇ = xᵃ⁻ᵇ
- (xᵃ)ᵇ = xᵃᵇ
- x⁰ = 1
- x⁻ⁿ = 1/xⁿ
- x^(1/n) = ⁿ√x (nth root)
- x^(m/n) = (ⁿ√x)ᵐ

## Standard Form

Standard form (scientific notation): a × 10ⁿ where 1 ≤ a < 10 and n is an integer.

Converting to standard form:
4,500,000 = 4.5 × 10⁶ (move decimal point 6 places left)
0.0000032 = 3.2 × 10⁻⁶ (move decimal point 6 places right)

Converting from standard form:
6.7 × 10⁴ = 67,000
1.2 × 10⁻³ = 0.0012

Calculations in standard form:
(5 × 10³) × (4 × 10²) = 20 × 10⁵ = 2 × 10⁶
(9 × 10⁸) ÷ (3 × 10⁵) = 3 × 10³

## Rational and Irrational Numbers

Rational: can be written as a fraction p/q (integers, recurring decimals, fractions)
Examples: 3, −7, ½, 0.333... = 1/3, 0.75

Irrational: cannot be written as a fraction (non-terminating, non-recurring decimals)
Examples: √2 ≈ 1.41421..., √3, π, e

Surds are irrational: √2, √3, √5, √6 are surds. √4 = 2 is NOT a surd.

Simplifying surds: √18 = √(9 × 2) = 3√2
Multiplying surds: √5 × √20 = √100 = 10
Rationalising denominator: 3/√5 = 3√5/5 (multiply top and bottom by √5)

## Worked Examples

Calculate (2.4 × 10⁷) × (5 × 10⁻³):
= (2.4 × 5) × 10^(7 + (−3)) = 12 × 10⁴ = 1.2 × 10⁵

Simplify 27^(2/3):
= (∛27)² = 3² = 9

Simplify √50 + √8:
= 5√2 + 2√2 = 7√2
