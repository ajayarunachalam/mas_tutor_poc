# Sequences and Series — Cambridge International AS & A Level Mathematics (9709)

## Arithmetic Progressions (AP)

An arithmetic progression has a constant common difference d between successive terms.

**General (nth) term:** aₙ = a + (n − 1)d
where a = first term, d = common difference.

**Sum of first n terms:** Sₙ = n/2 × (2a + (n−1)d) = n/2 × (a + l)
where l = last term = a + (n−1)d.

Example: An AP has first term 3 and common difference 4. Find the 20th term and the sum of the first 20 terms.
a₂₀ = 3 + 19 × 4 = 79.
S₂₀ = 20/2 × (3 + 79) = 10 × 82 = 820.

Example: The sum of the first n terms of an AP is 2n² + 3n. Find the first term and common difference.
a₁ = S₁ = 2 + 3 = 5.
a₂ = S₂ − S₁ = (8 + 6) − 5 = 9.
d = a₂ − a₁ = 4.

**Finding terms from conditions:**
- If given two terms, form two equations in a and d and solve simultaneously.
- If given a condition on Sₙ, substitute into the sum formula.

Example: In an AP the 5th term is 17 and the 10th term is 32. Find the first term and d.
a + 4d = 17
a + 9d = 32 → subtracting: 5d = 15, d = 3, a = 5.

## Geometric Progressions (GP)

A geometric progression has a constant common ratio r between successive terms.

**General (nth) term:** aₙ = arⁿ⁻¹

**Sum of first n terms:**
- If r ≠ 1: Sₙ = a(rⁿ − 1)/(r − 1) = a(1 − rⁿ)/(1 − r)
- If r = 1: Sₙ = na

Example: A GP has first term 2 and common ratio 3. Find the 6th term and S₆.
a₆ = 2 × 3⁵ = 2 × 243 = 486.
S₆ = 2(3⁶ − 1)/(3 − 1) = 2 × 728 / 2 = 728.

## Sum to Infinity of a GP

When |r| < 1, the series converges and the sum to infinity is:

S∞ = a / (1 − r)

If |r| ≥ 1 the series diverges and no sum to infinity exists.

Example: A GP has first term 12 and common ratio 1/3. Find S∞.
S∞ = 12 / (1 − 1/3) = 12 / (2/3) = 18.

Example: The sum to infinity of a GP is 8 and the first term is 2. Find r.
8 = 2/(1 − r) → 1 − r = 1/4 → r = 3/4.
Check: |r| = 3/4 < 1 ✓.

## Applications and Mixed Problems

**Condition for GP:** Three quantities a, b, c are in GP if and only if b/a = c/b, i.e. b² = ac.

**Compound interest** follows a GP: Aₙ = P × (1 + r)ⁿ where P = principal, r = rate per period.

Example: £500 is invested at 4% per annum compound interest. Find the value after 10 years and the total number of years for it to exceed £1000.
After 10 years: 500 × (1.04)¹⁰ = 500 × 1.4802 = £740.10.
For > £1000: (1.04)ⁿ > 2 → n ln(1.04) > ln 2 → n > 17.67 → n = 18 years.

**Finding unknown terms:** If a GP has terms that depend on a parameter, use the ratio condition.

Example: The first three terms of a GP are (k+2), k, (k−3). Find k.
Ratio condition: k/(k+2) = (k−3)/k
k² = (k+2)(k−3) = k² − k − 6
0 = −k − 6 → k = −6.
Check: terms are −4, −6, −9; ratio = 3/2 ✓.

## Sigma Notation

Σ (sigma) is shorthand for a sum:
Σ from r=1 to n of f(r) = f(1) + f(2) + ... + f(n)

Useful standard results:
- Σr = n(n+1)/2
- Σr² = n(n+1)(2n+1)/6
- Σr³ = [n(n+1)/2]²

Example: Find Σ from r=1 to 20 of (3r − 1).
= 3Σr − Σ1 = 3 × (20 × 21/2) − 20 = 3 × 210 − 20 = 630 − 20 = 610.
