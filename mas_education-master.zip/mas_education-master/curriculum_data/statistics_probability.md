# Probability — GCSE Mathematics

## Basic Probability

Probability measures how likely an event is to occur.
P(event) = (number of favourable outcomes) / (total number of outcomes)

Probability is always between 0 and 1 inclusive.
P = 0: impossible; P = 0.5: equally likely; P = 1: certain

Example: A bag has 3 red, 5 blue, 2 green balls. Probability of picking red:
P(red) = 3/10

## Complementary Events

P(event does NOT happen) = 1 − P(event happens)
P(A') = 1 − P(A)

Example: P(rain) = 0.3 → P(no rain) = 1 − 0.3 = 0.7

## Mutually Exclusive Events

Two events are mutually exclusive if they cannot both happen at the same time.
P(A or B) = P(A) + P(B)

Example: P(red) = 3/10, P(blue) = 5/10. P(red or blue) = 3/10 + 5/10 = 8/10 = 4/5

## Independent Events

Events are independent if one happening does not affect the probability of the other.
P(A and B) = P(A) × P(B)

Example: Flip a coin twice. P(heads AND heads) = 1/2 × 1/2 = 1/4

## Relative Frequency (Experimental Probability)

Relative frequency = (number of times event occurred) / (total number of trials)
Used when theoretical probability is not known. Approaches true probability as trials increase.

Example: Rolled a die 200 times, got a 6 exactly 28 times.
Relative frequency of 6 = 28/200 = 0.14 (theoretical = 1/6 ≈ 0.167)

## Tree Diagrams

Tree diagrams show all possible outcomes for sequential events.
Probabilities along branches multiply for combined outcomes.
Add final outcome probabilities for "or" questions.

Example: P(pass test) = 0.7. If pass, P(pass re-test) = 0.8. If fail, P(pass re-test) = 0.5.
P(pass first time) = 0.7
P(fail then pass) = 0.3 × 0.5 = 0.15
P(both fail) = 0.3 × 0.5 = 0.15
P(pass at some point) = 0.7 + 0.15 = 0.85 (or 1 − 0.15 = 0.85)

## Venn Diagrams

Venn diagrams show sets and their intersections.
A ∩ B: elements in both A AND B (intersection)
A ∪ B: elements in A OR B (union)
A': elements NOT in A (complement)

P(A ∩ B) = P(A and B)
P(A ∪ B) = P(A) + P(B) − P(A ∩ B)

## Conditional Probability (Extended Tier)

P(A | B) = probability of A given that B has occurred
P(A | B) = P(A ∩ B) / P(B)

Example: In a class, 40% like football, 30% like tennis, 15% like both.
P(football | likes tennis) = P(both) / P(tennis) = 0.15/0.30 = 0.5

Without replacement problems: after selecting one item, the total changes for the next selection.
Example: Bag has 4 red, 3 blue. P(two red) = 4/7 × 3/6 = 12/42 = 2/7
