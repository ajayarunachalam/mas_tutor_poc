# Statistical Measures — GCSE Mathematics

## Averages

There are three types of average:

**Mean**: sum of all values ÷ number of values
Mean of 4, 7, 3, 9, 2 = (4+7+3+9+2)/5 = 25/5 = 5

**Median**: middle value when data is arranged in order
For odd n: middle value. For even n: mean of two middle values.
Ordered: 2, 3, 4, 7, 9 → median = 4
Ordered: 2, 3, 4, 7, 9, 11 → median = (4+7)/2 = 5.5

**Mode**: most frequently occurring value(s)
2, 3, 3, 5, 7, 3, 9 → mode = 3
Modal class in grouped data: the class with highest frequency.

## Range and Interquartile Range

**Range** = maximum − minimum
Measures spread; affected by outliers.

**Quartiles**: divide ordered data into four equal parts.
- Lower quartile Q1: median of lower half
- Upper quartile Q3: median of upper half
- Interquartile range (IQR) = Q3 − Q1

IQR measures the spread of the middle 50% of the data. Less affected by outliers than range.

Example: Data (ordered): 3, 5, 7, 8, 9, 10, 14, 16, 18
Median = 9 (5th value of 9)
Q1 = median of 3, 5, 7, 8 = (5+7)/2 = 6
Q3 = median of 10, 14, 16, 18 = (14+16)/2 = 15
IQR = 15 − 6 = 9

## Mean from Grouped Frequency Tables

Use the midpoint of each class.
Estimated mean = (Σ f × x) / Σ f
where f = frequency and x = class midpoint

| Length (cm) | Frequency (f) | Midpoint (x) | f × x |
|------------|--------------|-------------|-------|
| 10 ≤ l < 20 | 4 | 15 | 60 |
| 20 ≤ l < 30 | 7 | 25 | 175 |
| 30 ≤ l < 40 | 9 | 35 | 315 |
| 40 ≤ l < 50 | 5 | 45 | 225 |
| **Total** | **25** | | **775** |

Estimated mean = 775 / 25 = 31 cm

## Standard Deviation (Extended Tier)

Standard deviation measures how spread out data is from the mean.
A smaller standard deviation means data is more tightly clustered around the mean.
Calculated as: σ = √(Σ(x − x̄)² / n)

## Comparing Data Sets

When comparing two data sets, comment on:
1. Average (mean, median, or mode) — "which is higher?"
2. Spread (range or IQR) — "which is more consistent/variable?"

Example statement: "Class A has a higher mean mark (72) than Class B (65), but Class A also has a greater IQR (18 vs 12), suggesting Class A's results are more variable."

## Choosing the Appropriate Average

- **Mean**: best when data is symmetric and has no outliers
- **Median**: best when data is skewed or has outliers
- **Mode**: best for categorical data, or to find most common value
