# Quadratic Equations — GCSE Mathematics

A quadratic equation is a polynomial equation of degree 2, written in standard form: ax² + bx + c = 0, where a ≠ 0.

## Solving by Factoring

To solve x² + 5x + 6 = 0, find two numbers that multiply to 6 (the constant) and add to 5 (the coefficient of x).
Those numbers are 2 and 3, because 2 × 3 = 6 and 2 + 3 = 5.
So x² + 5x + 6 = (x + 2)(x + 3) = 0
Therefore x = -2 or x = -3.

Another example: x² - 7x + 12 = 0
Factors of 12 that add to -7: -3 and -4.
(x - 3)(x - 4) = 0, so x = 3 or x = 4.

## The Quadratic Formula

For any quadratic ax² + bx + c = 0, the solutions are:
x = (-b ± √(b² - 4ac)) / 2a

Example: Solve 2x² + 3x - 5 = 0
Here a = 2, b = 3, c = -5
x = (-3 ± √(9 + 40)) / 4 = (-3 ± √49) / 4 = (-3 ± 7) / 4
x = 4/4 = 1   or   x = -10/4 = -2.5

## The Discriminant

The discriminant is b² - 4ac and tells us the nature of the roots:
- If b² - 4ac > 0: two distinct real solutions
- If b² - 4ac = 0: one repeated real solution (a perfect square)
- If b² - 4ac < 0: no real solutions (complex roots only)

## Completing the Square

Solving x² + 6x + 5 = 0 by completing the square:
Step 1: Move constant: x² + 6x = -5
Step 2: Add (b/2)² to both sides: x² + 6x + 9 = -5 + 9 = 4
Step 3: Factor left side: (x + 3)² = 4
Step 4: Square root both sides: x + 3 = ±2
Step 5: Solve: x = -1 or x = -5

## Common Mistakes to Avoid

- Forgetting the ± when taking the square root
- Sign errors when substituting negative values into the formula
- Not checking solutions satisfy the original equation
- Assuming every quadratic factorises over integers

## Worked Example — GCSE Style

A rectangle has length (x + 3) cm and width (x - 1) cm. Its area is 15 cm². Find x.
(x + 3)(x - 1) = 15
x² + 2x - 3 = 15
x² + 2x - 18 = 0
Using the formula: x = (-2 ± √(4 + 72)) / 2 = (-2 ± √76) / 2
x ≈ 3.37 (taking positive value since length must be positive)
