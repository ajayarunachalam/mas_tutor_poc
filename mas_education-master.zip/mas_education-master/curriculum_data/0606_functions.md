# Functions — Cambridge IGCSE Additional Mathematics (0606)

## Function Notation, Domain and Range

A function f maps each element of the domain to exactly one element of the codomain. We write f(x) to mean "f of x", the output of f when the input is x.

- **Domain**: the set of allowed inputs (x values)
- **Codomain**: the set of possible outputs
- **Range**: the set of actual outputs (a subset of the codomain)

Example: f(x) = √(x − 2). The domain requires x − 2 ≥ 0, so domain is x ≥ 2. The range is f(x) ≥ 0.

A function is **one-to-one** if every output comes from exactly one input. Use the horizontal line test on a graph: if any horizontal line crosses the graph more than once, the function is many-to-one.

Example: f(x) = x² is many-to-one because f(2) = f(−2) = 4. An inverse function exists only for one-to-one functions.

## Composite Functions

For two functions f and g, the composite fg(x) means "apply g first, then apply f to the result":
fg(x) = f(g(x))

Example: f(x) = 2x + 1 and g(x) = x².
fg(x) = f(g(x)) = f(x²) = 2x² + 1
gf(x) = g(f(x)) = g(2x + 1) = (2x + 1)²

Note: fg(x) ≠ gf(x) in general — the order matters.

## Inverse Functions

The inverse function f⁻¹(x) reverses f: if f(a) = b then f⁻¹(b) = a. The graph of f⁻¹ is the reflection of f in the line y = x.

**To find f⁻¹(x):** Write y = f(x), swap x and y, rearrange for y.

Example: f(x) = 3x − 5. Let y = 3x − 5 → x = 3y − 5 → y = (x + 5)/3. So f⁻¹(x) = (x + 5)/3.

Verify: ff⁻¹(x) = f((x+5)/3) = 3·(x+5)/3 − 5 = x + 5 − 5 = x ✓

The domain of f⁻¹ equals the range of f, and the range of f⁻¹ equals the domain of f.

## Graph Transformations

Starting from y = f(x), the following transformations apply:

| Transformation | Effect |
|---|---|
| y = f(x) + a | Translate a units up (a > 0) or down (a < 0) |
| y = f(x + a) | Translate a units left (a > 0) or right (a < 0) |
| y = af(x) | Stretch vertically by scale factor a |
| y = f(ax) | Stretch horizontally by scale factor 1/a |

Example: y = (x − 3)² + 4 is y = x² translated 3 right and 4 up. Vertex at (3, 4).

Example: y = sin(2x) compresses the period of sin x by a factor of 2. Period becomes π.

## The Modulus Function

The modulus |x| gives the non-negative value: |x| = x if x ≥ 0, |x| = −x if x < 0.

To sketch y = |f(x)|: draw y = f(x), then reflect any parts below the x-axis up above it.

To solve |f(x)| = k (where k > 0): consider two cases:
- Case 1: f(x) = k
- Case 2: f(x) = −k

Example: |2x − 3| = 5
Case 1: 2x − 3 = 5 → x = 4
Case 2: 2x − 3 = −5 → x = −1

To solve |f(x)| < c: solve −c < f(x) < c as a double inequality.
To solve |f(x)| > c: solve f(x) > c OR f(x) < −c separately.

**Common mistake:** Squaring both sides of |f(x)| = |g(x)| gives [f(x)]² = [g(x)]², which can introduce spurious solutions — always check answers in the original equation.
