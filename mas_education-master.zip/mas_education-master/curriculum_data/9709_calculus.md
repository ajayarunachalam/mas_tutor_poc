# Calculus — Cambridge International AS & A Level Mathematics (9709)

## Chain Rule

For a composite function y = f(g(x)):
dy/dx = f'(g(x)) × g'(x)

This extends to chains of any length. Always identify the outer and inner functions.

Example: Differentiate y = (4x² + 1)⁶.
dy/dx = 6(4x² + 1)⁵ × 8x = 48x(4x² + 1)⁵.

Example: Differentiate y = sin³(2x).
Let y = [sin(2x)]³. Outer = u³, inner = sin(2x), innermost = 2x.
dy/dx = 3sin²(2x) × cos(2x) × 2 = 6sin²(2x)cos(2x).

## Product and Quotient Rules

**Product rule:** (uv)' = u'v + uv'
**Quotient rule:** (u/v)' = (u'v − uv') / v²

Example: Differentiate y = x³ ln x.
u = x³, u' = 3x²; v = ln x, v' = 1/x.
dy/dx = 3x² ln x + x³/x = 3x² ln x + x².

Example: Differentiate y = eˣ / (x² + 1).
u = eˣ, u' = eˣ; v = x² + 1, v' = 2x.
dy/dx = [eˣ(x² + 1) − 2xeˣ] / (x² + 1)² = eˣ(x² − 2x + 1) / (x² + 1)².

## Implicit Differentiation

When y is defined implicitly (e.g. x² + y² = 25), differentiate both sides with respect to x, treating y as a function of x and using the chain rule.

d/dx [f(y)] = f'(y) × dy/dx

Example: Find dy/dx for x² + y² = 25.
2x + 2y(dy/dx) = 0 → dy/dx = −x/y.

Example: Find dy/dx for x³ + y³ = 6xy.
3x² + 3y²(dy/dx) = 6y + 6x(dy/dx)
3y²(dy/dx) − 6x(dy/dx) = 6y − 3x²
dy/dx(3y² − 6x) = 6y − 3x²
dy/dx = (6y − 3x²)/(3y² − 6x) = (2y − x²)/(y² − 2x).

## Second Derivatives

The second derivative d²y/dx² = d/dx(dy/dx). It describes the rate of change of the gradient (curvature).

- d²y/dx² > 0: curve is concave up (bowl shape)
- d²y/dx² < 0: curve is concave down (dome shape)

**Stationary points revisited:** At a stationary point (dy/dx = 0):
- d²y/dx² > 0 → local minimum
- d²y/dx² < 0 → local maximum
- d²y/dx² = 0 → inconclusive; use sign analysis

## Integration by Substitution

Choose a substitution u = g(x) to simplify ∫f(x) dx. Then dx = du/g'(x).

Steps:
1. Choose u = inner function
2. Find du/dx, rearrange to get dx = du/(du/dx)
3. Substitute and simplify to ∫h(u) du
4. Integrate, then substitute back

Example: Find ∫x(x² + 1)⁴ dx.
Let u = x² + 1, du = 2x dx, so x dx = du/2.
∫x(x² + 1)⁴ dx = ∫u⁴ (du/2) = u⁵/10 + c = (x² + 1)⁵/10 + c.

Example: Find ∫sin³x cos x dx.
Let u = sin x, du = cos x dx.
∫u³ du = u⁴/4 + c = sin⁴x/4 + c.

**For definite integrals with substitution:** change the limits to u-values, then no back-substitution is needed.

## Integration by Parts

The formula: ∫u dv/dx dx = uv − ∫v du/dx dx

Choose u to be the function that becomes simpler when differentiated (LIATE priority: Logarithm, Inverse trig, Algebraic, Trig, Exponential).

Example: Find ∫x eˣ dx.
Let u = x, dv/dx = eˣ → v = eˣ.
∫x eˣ dx = xeˣ − ∫eˣ dx = xeˣ − eˣ + c = eˣ(x − 1) + c.

Example: Find ∫x² sin x dx.
Apply by parts twice: u = x², dv = sin x dx → v = −cos x.
= −x²cos x + ∫2x cos x dx
= −x²cos x + 2(x sin x − ∫sin x dx)
= −x²cos x + 2x sin x + 2cos x + c.

## Integration Using Partial Fractions

Decompose the rational function first, then integrate each term.

∫ A/(x−a) dx = A ln|x−a| + c
∫ B/(x−a)² dx = −B/(x−a) + c

Example: Find ∫ (x + 3)/[(x−1)(x+1)] dx.
Partial fractions: (x+3)/[(x−1)(x+1)] = 2/(x−1) − 1/(x+1).
∫ = 2ln|x−1| − ln|x+1| + c.

## Volumes of Revolution

Rotating the curve y = f(x) about the x-axis from x = a to x = b gives a volume:

V = π ∫ₐᵇ y² dx

Example: Find the volume when y = √x is rotated about the x-axis from x = 0 to x = 4.
V = π ∫₀⁴ x dx = π [x²/2]₀⁴ = π × 8 = 8π.

## First-Order Differential Equations

**Separating variables:** Rearrange dy/dx = f(x)g(y) to dy/g(y) = f(x) dx, then integrate both sides.

Example: Solve dy/dx = xy with y = 2 when x = 0.
∫dy/y = ∫x dx → ln|y| = x²/2 + C → y = Ae^(x²/2).
y(0) = 2 → A = 2. So y = 2e^(x²/2).

**Modelling with DEs:**
- Population growth: dP/dt = kP → P = P₀eᵏᵗ
- Newton's cooling: dT/dt = k(T − T∞) → T − T∞ = Ae^(kt)
