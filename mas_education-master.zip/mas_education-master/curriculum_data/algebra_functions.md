# Functions — GCSE Mathematics (Extended Tier)

## Function Notation

A function maps each input to exactly one output.
f(x) = 3x + 2 means "the function f applied to x gives 3x + 2".

f(5) means substitute x = 5: f(5) = 3(5) + 2 = 17
f(−2) = 3(−2) + 2 = −4

## Composite Functions

f∘g(x) or fg(x) means "apply g first, then apply f to the result".
fg(x) = f(g(x))

Example: f(x) = 2x + 1, g(x) = x²
fg(x) = f(g(x)) = f(x²) = 2x² + 1
gf(x) = g(f(x)) = g(2x + 1) = (2x + 1)²

Note: fg(x) ≠ gf(x) in general.

fg(3) = f(g(3)) = f(9) = 2(9) + 1 = 19
gf(3) = g(f(3)) = g(7) = 49

## Inverse Functions

The inverse function f⁻¹(x) undoes f(x).
f(f⁻¹(x)) = x and f⁻¹(f(x)) = x

To find the inverse:
1. Write y = f(x)
2. Rearrange to make x the subject
3. Replace x with f⁻¹(y) and y with x (or just replace x with f⁻¹(x) directly)

Example: Find the inverse of f(x) = 3x + 5
y = 3x + 5
y − 5 = 3x
x = (y − 5)/3
f⁻¹(x) = (x − 5)/3

Check: f(f⁻¹(x)) = f((x−5)/3) = 3×(x−5)/3 + 5 = x − 5 + 5 = x ✓

Example: f(x) = (2x − 1)/(x + 3). Find f⁻¹(x).
y(x + 3) = 2x − 1
xy + 3y = 2x − 1
3y + 1 = 2x − xy
3y + 1 = x(2 − y)
x = (3y + 1)/(2 − y)
f⁻¹(x) = (3x + 1)/(2 − x)

## Domain and Range

Domain: the set of valid input values (x values).
Range: the set of possible output values (y values).

For f(x) = √(x − 3): domain is x ≥ 3 (cannot take square root of a negative number).
For f(x) = 1/(x − 2): domain is x ≠ 2 (cannot divide by zero).

## Worked Examples

f(x) = 4x − 3, g(x) = (x + 1)/2

Find fg(x): fg(x) = f((x+1)/2) = 4×(x+1)/2 − 3 = 2(x+1) − 3 = 2x − 1

Find f⁻¹(x): y = 4x − 3 → x = (y+3)/4 → f⁻¹(x) = (x+3)/4

Solve f(x) = g(x): 4x − 3 = (x+1)/2 → 8x − 6 = x + 1 → 7x = 7 → x = 1
