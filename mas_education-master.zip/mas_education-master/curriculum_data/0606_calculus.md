# Calculus — Cambridge IGCSE Additional Mathematics (0606)

## Differentiation from First Principles

Differentiation measures the instantaneous rate of change of a function. The derivative of f(x) is defined as:

f'(x) = lim(h→0) [f(x+h) − f(x)] / h

In practice you will use standard rules rather than the limit definition.

## Standard Derivatives

| Function | Derivative |
|---|---|
| xⁿ | nxⁿ⁻¹ |
| eˣ | eˣ |
| e^(ax+b) | ae^(ax+b) |
| ln x | 1/x |
| ln(ax+b) | a/(ax+b) |
| sin(ax+b) | a cos(ax+b) |
| cos(ax+b) | −a sin(ax+b) |
| tan(ax+b) | a sec²(ax+b) |

Example: Differentiate f(x) = 3x⁴ − 2e^(3x) + ln(2x).
f'(x) = 12x³ − 6e^(3x) + 1/x

## Chain Rule

For a composite function y = f(g(x)):
dy/dx = f'(g(x)) × g'(x)

Think: "derivative of outside × derivative of inside."

Example: Differentiate y = (3x² + 1)⁵.
Let u = 3x² + 1, so y = u⁵.
dy/dx = 5u⁴ × 6x = 30x(3x² + 1)⁴

Example: Differentiate y = sin(x³ − 2x).
dy/dx = cos(x³ − 2x) × (3x² − 2)

## Product Rule

For y = u(x) × v(x):
dy/dx = u'v + uv'

Example: Differentiate y = x² sin x.
u = x², u' = 2x; v = sin x, v' = cos x.
dy/dx = 2x sin x + x² cos x

## Quotient Rule

For y = u(x) / v(x):
dy/dx = (u'v − uv') / v²

Example: Differentiate y = eˣ / (x + 1).
u = eˣ, u' = eˣ; v = x + 1, v' = 1.
dy/dx = [eˣ(x+1) − eˣ] / (x+1)² = xeˣ / (x+1)²

## Stationary Points

At a stationary point, dy/dx = 0.

**To classify the nature of a stationary point:**
- Find dy/dx and solve dy/dx = 0 to get the x-coordinate(s)
- Find d²y/dx² (second derivative)
  - If d²y/dx² > 0 at the point: **minimum**
  - If d²y/dx² < 0 at the point: **maximum**
  - If d²y/dx² = 0: inconclusive — use a sign chart for dy/dx

Example: Find and classify stationary points of y = x³ − 6x² + 9x.
dy/dx = 3x² − 12x + 9 = 3(x − 1)(x − 3)
Stationary points at x = 1 and x = 3.
d²y/dx² = 6x − 12
At x = 1: d²y/dx² = −6 < 0 → maximum. y = 1 − 6 + 9 = 4.
At x = 3: d²y/dx² = 6 > 0 → minimum. y = 27 − 54 + 27 = 0.

## Standard Integrals

Integration is the reverse of differentiation. The constant of integration (+c) is always included for indefinite integrals.

| Function | Integral |
|---|---|
| xⁿ (n ≠ −1) | xⁿ⁺¹/(n+1) + c |
| 1/x | ln|x| + c |
| eˣ | eˣ + c |
| e^(ax+b) | (1/a)e^(ax+b) + c |
| sin(ax+b) | −(1/a)cos(ax+b) + c |
| cos(ax+b) | (1/a)sin(ax+b) + c |
| 1/(ax+b) | (1/a)ln|ax+b| + c |

Example: Find ∫(4x³ − 2sin(3x) + e^(2x)) dx.
= x⁴ + (2/3)cos(3x) + (1/2)e^(2x) + c

## Definite Integration and Area

The definite integral ∫ₐᵇ f(x) dx gives the signed area between the curve and the x-axis from x = a to x = b.

**Key steps:**
1. Integrate f(x) to get F(x)
2. Evaluate F(b) − F(a)
3. If the curve dips below the x-axis, the integral gives a negative value for that region — take the absolute value and add separately

Example: Find the area enclosed by y = x² − 4 and the x-axis between x = −2 and x = 2.
∫₋₂² (x² − 4) dx = [x³/3 − 4x]₋₂²
= (8/3 − 8) − (−8/3 + 8) = −16/3 − 16/3 = −32/3
Area = 32/3 (taking the magnitude since the curve is below the x-axis in this region).

**Area between two curves:** ∫ₐᵇ [f(x) − g(x)] dx where f(x) ≥ g(x) on [a, b].

## Worked Example

A curve has equation y = x³ − 3x² − 9x + 5.

(a) Find dy/dx.
dy/dx = 3x² − 6x − 9 = 3(x² − 2x − 3) = 3(x − 3)(x + 1)

(b) Find stationary points and their nature.
dy/dx = 0 → x = 3 or x = −1.
d²y/dx² = 6x − 6.
At x = 3: d²y/dx² = 12 > 0 → minimum. y = 27 − 27 − 27 + 5 = −22.
At x = −1: d²y/dx² = −12 < 0 → maximum. y = −1 − 3 + 9 + 5 = 10.

(c) Find ∫(x³ − 3x² − 9x + 5) dx.
= x⁴/4 − x³ − 9x²/2 + 5x + c
