# Further Calculus — Cambridge International AS & A Level Further Mathematics (9231)

## Reduction Formulae

A reduction formula expresses the integral Iₙ in terms of Iₙ₋₁ (or Iₙ₋₂), allowing evaluation of a family of integrals by stepping down from n to a base case.

**Deriving a reduction formula:** Integrate by parts once to connect Iₙ to a simpler integral.

**Standard example:** Iₙ = ∫₀^(π/2) sinⁿx dx.

Use integration by parts: u = sinⁿ⁻¹x, dv = sin x dx.
v = −cos x, du = (n−1)sinⁿ⁻²x cos x dx.

Iₙ = [−sinⁿ⁻¹x cos x]₀^(π/2) + (n−1)∫₀^(π/2) sinⁿ⁻²x cos²x dx
= 0 + (n−1)∫₀^(π/2) sinⁿ⁻²x (1−sin²x) dx
= (n−1)Iₙ₋₂ − (n−1)Iₙ

So Iₙ + (n−1)Iₙ = (n−1)Iₙ₋₂, giving:

**Iₙ = (n−1)/n × Iₙ₋₂** (Wallis-type reduction formula)

Base cases: I₀ = π/2, I₁ = 1.

Example: Find ∫₀^(π/2) sin⁴x dx.
I₄ = (3/4)I₂ = (3/4)(1/2)I₀ = (3/4)(1/2)(π/2) = 3π/16.

**Another example:** Iₙ = ∫xⁿeˣ dx.
By parts (u = xⁿ, dv = eˣ dx):
Iₙ = xⁿeˣ − nIₙ₋₁.

## Arc Length

For a curve y = f(x) between x = a and x = b:

L = ∫ₐᵇ √(1 + (dy/dx)²) dx

For a parametric curve x = x(t), y = y(t) between t = t₁ and t = t₂:

L = ∫_{t₁}^{t₂} √((dx/dt)² + (dy/dt)²) dt

Example: Find the arc length of y = (2/3)x^(3/2) from x = 0 to x = 3.
dy/dx = x^(1/2), so 1 + (dy/dx)² = 1 + x.
L = ∫₀³ √(1+x) dx = [(2/3)(1+x)^(3/2)]₀³ = (2/3)(8 − 1) = 14/3.

## Surface Area of Revolution

Rotating y = f(x) about the x-axis from x = a to x = b generates a surface of area:

S = 2π ∫ₐᵇ y √(1 + (dy/dx)²) dx

For parametric curves:
S = 2π ∫_{t₁}^{t₂} y √((dx/dt)² + (dy/dt)²) dt

Example: Find the surface area when y = 2√x is rotated about the x-axis from x = 0 to x = 3.
dy/dx = 1/√x, 1 + (dy/dx)² = 1 + 1/x = (x+1)/x.
S = 2π ∫₀³ 2√x × √((x+1)/x) dx = 4π ∫₀³ √(x+1) dx
= 4π [(2/3)(x+1)^(3/2)]₀³ = 4π(2/3)(8 − 1) = 56π/3.

## Maclaurin Series

The Maclaurin series expands f(x) as a power series about x = 0:

f(x) = f(0) + f'(0)x + f''(0)/2! × x² + f'''(0)/3! × x³ + ...

**Standard series (must know):**

eˣ = 1 + x + x²/2! + x³/3! + ... (all x)
sin x = x − x³/3! + x⁵/5! − ... (all x)
cos x = 1 − x²/2! + x⁴/4! − ... (all x)
ln(1+x) = x − x²/2 + x³/3 − ... (−1 < x ≤ 1)
(1+x)ⁿ = 1 + nx + n(n−1)/2! x² + ... (|x| < 1 for non-integer n)

**Deriving a Maclaurin series:** Repeatedly differentiate, evaluate at x = 0, substitute into the formula.

Example: Derive the series for f(x) = eˢⁱⁿ ˣ up to x³.
f(0) = 1. f'(x) = cos x eˢⁱⁿ ˣ, f'(0) = 1.
f''(x) = (−sin x + cos²x)eˢⁱⁿ ˣ, f''(0) = 1.
f'''(x) = (−3sinx cosx + ...)eˢⁱⁿ ˣ − cos x × ..., f'''(0) = −1.
eˢⁱⁿ ˣ = 1 + x + x²/2 − x³/6 + ...

**Using series to evaluate limits:**
Example: Find lim(x→0) [(sin x − x) / x³].
sin x = x − x³/6 + ..., so sin x − x = −x³/6 + ...
Limit = −1/6.

## Taylor Series

The Taylor series about x = a (more general form):
f(x) = f(a) + f'(a)(x−a) + f''(a)/2! (x−a)² + ...

This extends Maclaurin (which is Taylor about x = 0) to expansion about any point.
