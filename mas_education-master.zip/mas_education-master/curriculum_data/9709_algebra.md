# Algebra — Cambridge International AS & A Level Mathematics (9709)

## The Binomial Theorem

For a positive integer n, the expansion of (a + b)ⁿ is:

(a + b)ⁿ = aⁿ + C(n,1)aⁿ⁻¹b + C(n,2)aⁿ⁻²b² + ... + bⁿ

where the binomial coefficient C(n,r) = n! / (r!(n−r)!) = ⁿCᵣ.

**General term (term r+1):** T_{r+1} = C(n,r) aⁿ⁻ʳ bʳ

Example: Expand (2x + 3)⁴.
a = 2x, b = 3, n = 4.
T₁ = (2x)⁴ = 16x⁴
T₂ = C(4,1)(2x)³(3) = 4 × 8x³ × 3 = 96x³
T₃ = C(4,2)(2x)²(3²) = 6 × 4x² × 9 = 216x²
T₄ = C(4,3)(2x)(3³) = 4 × 2x × 27 = 216x
T₅ = 3⁴ = 81

So (2x + 3)⁴ = 16x⁴ + 96x³ + 216x² + 216x + 81.

**Finding a specific term:** To find the term in xʳ, identify which r makes the power work out, then use the general term formula.

Example: Find the coefficient of x³ in (x + 2/x)⁵.
General term: C(5,r) xˢ (2/x)ʳ = C(5,r) 2ʳ x^(5−2r).
For power = 3: 5 − 2r = 3, so r = 1.
T₂ = C(5,1) × 2¹ × x³ = 5 × 2 × x³ = 10x³.
Coefficient = 10.

## The General Binomial Expansion for Rational n

For |x| < 1 and any rational n:

(1 + x)ⁿ = 1 + nx + n(n−1)/2! x² + n(n−1)(n−2)/3! x³ + ...

This series is infinite and valid only for |x| < 1.

Example: Expand (1 + x)^(−2) up to x³.
= 1 + (−2)x + (−2)(−3)/2 x² + (−2)(−3)(−4)/6 x³ + ...
= 1 − 2x + 3x² − 4x³ + ...

To expand (a + bx)ⁿ: factor out aⁿ first.
(2 + x)^(−1) = (1/2)(1 + x/2)^(−1) = (1/2)(1 − x/2 + x²/4 − ...) for |x| < 2.

## Roots of Polynomials

For the quadratic ax² + bx + c with roots α and β:
- Sum of roots: α + β = −b/a
- Product of roots: αβ = c/a

For the cubic ax³ + bx² + cx + d with roots α, β, γ:
- α + β + γ = −b/a
- αβ + βγ + αγ = c/a
- αβγ = −d/a

Example: The equation 2x² − 5x + 3 = 0 has roots α and β. Find α + β and αβ.
α + β = 5/2, αβ = 3/2.

**Equations reducible to quadratic:** Use a substitution such as u = x² or u = eˣ to convert a higher-degree equation to a quadratic in u.

Example: Solve x⁴ − 5x² + 4 = 0.
Let u = x². Then u² − 5u + 4 = 0 → (u − 1)(u − 4) = 0.
u = 1 or u = 4, so x² = 1 or x² = 4, giving x = ±1 or x = ±2.

## Partial Fractions

A rational function can be decomposed into simpler fractions.

**Distinct linear factors:**
f(x) / [(x−a)(x−b)] = A/(x−a) + B/(x−b)

Multiply both sides by the denominator, then equate coefficients or substitute convenient values of x to find A and B.

Example: Express (3x + 1) / [(x+1)(x−2)] in partial fractions.
(3x + 1) / [(x+1)(x−2)] = A/(x+1) + B/(x−2)
3x + 1 = A(x−2) + B(x+1)
x = 2: 7 = 3B → B = 7/3.
x = −1: −2 = −3A → A = 2/3.
So (3x+1)/[(x+1)(x−2)] = (2/3)/(x+1) + (7/3)/(x−2).

**Repeated linear factor:** Use A/(x−a) + B/(x−a)².

Example: 5x / [(x−1)(x+2)²] = A/(x−1) + B/(x+2) + C/(x+2)².
Multiply through and compare coefficients or substitute values.

**Improper fractions (degree of numerator ≥ degree of denominator):** Perform polynomial long division first to get a proper fraction plus a polynomial part.

## Worked Example

Find the first three terms in the expansion of (1 − 2x)^(1/2) and state the range of validity.

(1 − 2x)^(1/2) = 1 + (1/2)(−2x) + (1/2)(−1/2)/2 × (−2x)² + ...
= 1 − x − x²/2 − ...

Valid for |−2x| < 1, i.e. |x| < 1/2.
