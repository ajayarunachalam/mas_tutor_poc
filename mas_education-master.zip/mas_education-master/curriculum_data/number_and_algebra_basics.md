# Number and Algebra Basics — GCSE Mathematics

## Integers and Directed Numbers

Integers are whole numbers: ..., -3, -2, -1, 0, 1, 2, 3, ...
Positive numbers are greater than zero. Negative numbers are less than zero.

### Rules for Multiplying and Dividing Negative Numbers
- positive × positive = positive: 3 × 4 = 12
- negative × negative = positive: (-3) × (-4) = 12
- positive × negative = negative: 3 × (-4) = -12
- negative × positive = negative: (-3) × 4 = -12

### Adding and Subtracting Negative Numbers
- Adding a negative = subtracting: 5 + (-3) = 5 - 3 = 2
- Subtracting a negative = adding: 5 - (-3) = 5 + 3 = 8

## Fractions

### Adding and Subtracting Fractions
Need a common denominator:
1/3 + 1/4 = 4/12 + 3/12 = 7/12

3/5 - 1/4 = 12/20 - 5/20 = 7/20

### Multiplying Fractions
Multiply numerators together and denominators together:
2/3 × 3/4 = (2×3)/(3×4) = 6/12 = 1/2

### Dividing Fractions
Multiply by the reciprocal:
2/3 ÷ 4/5 = 2/3 × 5/4 = 10/12 = 5/6

### Mixed Numbers
Convert to improper fraction first:
2½ × 1⅓ = 5/2 × 4/3 = 20/6 = 10/3 = 3⅓

## Percentages

To find 30% of 80: 0.30 × 80 = 24
To find what % 15 is of 60: (15/60) × 100 = 25%
Percentage increase: ((new - old) / old) × 100
Percentage decrease: ((old - new) / old) × 100

Example: Price increases from £40 to £52. Percentage increase?
(52 - 40)/40 × 100 = 12/40 × 100 = 30%

## Powers and Roots

Index laws:
- a^m × a^n = a^(m+n): x³ × x⁴ = x⁷
- a^m ÷ a^n = a^(m-n): x⁵ ÷ x² = x³
- (a^m)^n = a^(mn): (x²)³ = x⁶
- a^0 = 1 (for any non-zero a)
- a^(-n) = 1/a^n: x^(-2) = 1/x²

Square roots: √16 = 4, √25 = 5, √144 = 12
Cube roots: ∛8 = 2, ∛27 = 3, ∛125 = 5

## Expanding Brackets

Single bracket: 3(x + 4) = 3x + 12
Double bracket: (x + 2)(x + 5) = x² + 5x + 2x + 10 = x² + 7x + 10
Difference of two squares: (x + 3)(x - 3) = x² - 9
Perfect square: (x + 4)² = x² + 8x + 16

## Factorising

Common factor: 6x² + 9x = 3x(2x + 3)
Trinomial: x² + 5x + 6 = (x + 2)(x + 3)
Difference of squares: x² - 16 = (x + 4)(x - 4)

## Algebraic Fractions

Simplify: (x² - 4)/(x + 2) = (x+2)(x-2)/(x+2) = x - 2 (when x ≠ -2)
