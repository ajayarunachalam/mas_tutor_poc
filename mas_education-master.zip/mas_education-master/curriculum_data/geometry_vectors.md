# Vectors — GCSE Mathematics

## Vector Notation

A vector has magnitude (size) and direction. Unlike a scalar which has only size.

Notation: **a**, a (bold or underline), or written as column vector (x; y)

Column vector (x; y) means x units right and y units up.
Negative values: move left (negative x) or down (negative y).

Example: Vector (3; −2) means 3 right and 2 down.

## Vector Operations

**Addition**: (a; b) + (c; d) = (a+c; b+d)
To add vectors, add corresponding components.

**Subtraction**: (a; b) − (c; d) = (a−c; b−d)

**Scalar multiplication**: k × (a; b) = (ka; kb)
Multiplying by a scalar changes the magnitude but not the direction (if k > 0).
Negative scalar reverses the direction.

## Magnitude of a Vector

|**a**| = √(x² + y²) for column vector (x; y)

Example: Find the magnitude of (3; 4).
|**v**| = √(3² + 4²) = √(9 + 16) = √25 = 5

## Resultant Vectors

The resultant vector is the single vector that has the same effect as two or more vectors combined.

To find the resultant, add the component vectors:
**r** = **a** + **b**

## Vector Geometry

If A, B are points: vector AB = position vector of B − position vector of A = OB − OA

**Equal vectors**: same magnitude and same direction
**Parallel vectors**: one is a scalar multiple of the other (e.g., **b** = 2**a** means **b** is parallel to **a**)

**Proving points are collinear**: Show that one vector is a scalar multiple of another sharing a common point.

Example: O is the origin. A has position vector (2; 1), B has position vector (6; 3).
OA = (2; 1), OB = (6; 3) = 3(2; 1) = 3 × OA
Since OB = 3OA and they share point O, A, O, B are collinear.

## Worked Example (Extended Tier)

OABC is a parallelogram. OA = **a**, OC = **c**.
M is the midpoint of AB. Find OM in terms of **a** and **c**.

OB = OA + AB = **a** + **c** (parallelogram: AB = OC = **c**)
OM = OA + AM = **a** + ½**c**
Or: OM = ½OB... No — M is midpoint of AB, not OB.
AM = ½AB = ½**c**
OM = OA + AM = **a** + ½**c**

## Resultant Navigation Problems

Example: A boat travels 5 km east then 12 km north. Find the resultant displacement.
East = (5; 0), North = (0; 12)
Resultant = (5; 12)
Magnitude = √(25 + 144) = √169 = 13 km
