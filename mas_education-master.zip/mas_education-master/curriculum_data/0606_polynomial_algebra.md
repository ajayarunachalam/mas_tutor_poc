# Polynomial Algebra — Cambridge IGCSE Additional Mathematics (0606)

## Surds

A surd is an irrational root that cannot be simplified to a whole number. Key rules:
- √(ab) = √a × √b
- √(a/b) = √a / √b
- (√a)² = a

**Simplifying surds:** √48 = √(16 × 3) = 4√3

**Adding/subtracting surds:** Only like surds combine. 3√2 + 5√2 = 8√2, but 3√2 + 5√3 cannot be simplified.

**Rationalising the denominator:** Eliminate surds from the denominator.
- Simple: 3/√5 = 3√5/5 (multiply top and bottom by √5)
- Conjugate: 4/(3 + √2) = 4(3 − √2)/((3 + √2)(3 − √2)) = 4(3 − √2)/(9 − 2) = 4(3 − √2)/7

## Laws of Indices

| Law | Example |
|---|---|
| aᵐ × aⁿ = aᵐ⁺ⁿ | x³ × x⁵ = x⁸ |
| aᵐ ÷ aⁿ = aᵐ⁻ⁿ | x⁸ ÷ x³ = x⁵ |
| (aᵐ)ⁿ = aᵐⁿ | (x²)⁴ = x⁸ |
| a⁰ = 1 | 5⁰ = 1 |
| a⁻ⁿ = 1/aⁿ | x⁻³ = 1/x³ |
| aⁿ/ᵐ = (ᵐ√a)ⁿ | 8²/³ = (∛8)² = 4 |

Example: Simplify (4x²)^(3/2). Answer: 4^(3/2) × x³ = (√4)³ × x³ = 8x³

## Quadratic Functions and the Discriminant

For ax² + bx + c = 0, the discriminant is Δ = b² − 4ac:
- Δ > 0: two distinct real roots
- Δ = 0: one repeated real root (the quadratic is a perfect square)
- Δ < 0: no real roots

Example: Determine the nature of roots of 2x² − 3x + 5 = 0.
Δ = (−3)² − 4(2)(5) = 9 − 40 = −31 < 0. No real roots.

**Quadratic inequalities:** Sketch the parabola first, then read off the solution set.

Solve x² − 5x + 6 > 0:
Factorise: (x − 2)(x − 3) > 0. The parabola opens upward; roots at x = 2 and x = 3.
The expression is positive outside the roots: x < 2 or x > 3.

**Completing the square:** Write x² + bx + c in the form (x + p)² + q.
x² + 6x + 2 = (x + 3)² − 9 + 2 = (x + 3)² − 7
So vertex is at (−3, −7), which is the minimum point.

## Factor and Remainder Theorem

**Remainder Theorem:** When f(x) is divided by (x − a), the remainder is f(a).

Example: Find the remainder when f(x) = x³ − 2x² + 3x − 4 is divided by (x − 2).
f(2) = 8 − 8 + 6 − 4 = 2. Remainder = 2.

**Factor Theorem:** (x − a) is a factor of f(x) if and only if f(a) = 0.

**Factorising a cubic:** Given f(x) = x³ + 2x² − 5x − 6:
Test x = 2: f(2) = 8 + 8 − 10 − 6 = 0. So (x − 2) is a factor.
Divide: x³ + 2x² − 5x − 6 = (x − 2)(x² + 4x + 3) = (x − 2)(x + 1)(x + 3)
Roots: x = 2, x = −1, x = −3.

**Solving cubics:** If you know one rational root a (try factors of the constant term), use it to divide out (x − a), then solve the remaining quadratic.

## Worked Example — IGCSE Additional Style

Given that (2x + 1) is a factor of f(x) = 2x³ + ax² − 3x − 2, find a and factorise f(x) fully.
If (2x + 1) is a factor, then f(−½) = 0.
f(−½) = 2(−⅛) + a(¼) − 3(−½) − 2 = −¼ + a/4 + 3/2 − 2 = a/4 + (−¼ + 6/4 − 8/4) = a/4 − 6/4 = 0
So a = 6.
f(x) = 2x³ + 6x² − 3x − 2. Dividing by (2x + 1) gives (x² + 5/2 x − 2) ... factorises as (2x+1)(x+2)(x−1)/... or use long division carefully.
