# Symmetry — GCSE Mathematics

## Line Symmetry (2D)

A shape has line symmetry if a line can divide it into two identical mirror-image halves.

The number of lines of symmetry for regular shapes:
- Equilateral triangle: 3
- Square: 4
- Regular pentagon: 5
- Regular hexagon: 6
- Rectangle: 2
- Parallelogram: 0
- Isosceles triangle: 1
- Circle: infinite

## Rotational Symmetry (2D)

A shape has rotational symmetry of order n if it looks the same after rotating 360°/n.

- Equilateral triangle: order 3 (looks same after 120° rotation)
- Square: order 4 (looks same after 90° rotation)
- Rectangle: order 2
- Parallelogram: order 2
- Regular hexagon: order 6
- Scalene triangle: order 1 (no rotational symmetry)

## Symmetry in 3D Shapes

A plane of symmetry divides a 3D solid into two congruent mirror-image halves.

Examples:
- Cuboid: 3 planes of symmetry (one for each pair of opposite faces)
- Cylinder: infinite planes of symmetry
- Square-based pyramid: 4 planes of symmetry
- Sphere: infinite planes of symmetry

## Nets of 3D Shapes

A net is the flat (2D) shape that folds to make a 3D solid.

Common nets:
- Cube: 6 squares arranged so they connect correctly (11 valid arrangements)
- Cuboid: 6 rectangles (or squares)
- Triangular prism: 2 triangles and 3 rectangles
- Square-based pyramid: 1 square and 4 triangles
- Cylinder: 2 circles and 1 rectangle (rectangle width = circumference = 2πr)

## Worked Example

A prism has a cross-section that is a right-angled triangle with legs 3 cm and 4 cm. The prism has length 10 cm.
Draw the net: it has two right-angled triangles (hypotenuse = 5 cm) and three rectangles (10×3, 10×4, 10×5).

## Properties of Symmetric Shapes

- A line of symmetry acts as a mirror: points on either side are equidistant from the line
- The perpendicular bisector of a chord in a circle passes through the centre (a symmetry property)
- Isosceles triangles have one axis of symmetry along the perpendicular from the apex to the base
- The base angles of an isosceles triangle are equal (symmetry property)
