# Trigonometry — Cambridge International AS & A Level Mathematics (9709)

## Compound Angle Formulae

These identities allow you to express trig functions of sums and differences of angles exactly.

sin(A ± B) = sin A cos B ± cos A sin B
cos(A ± B) = cos A cos B ∓ sin A sin B
tan(A ± B) = (tan A ± tan B) / (1 ∓ tan A tan B)

Example: Find the exact value of sin 75°.
sin 75° = sin(45° + 30°) = sin 45° cos 30° + cos 45° sin 30°
= (1/√2)(√3/2) + (1/√2)(1/2) = (√3 + 1)/(2√2) = (√6 + √2)/4.

Example: Prove that tan(A + B) = (tan A + tan B) / (1 − tan A tan B).
LHS = sin(A+B)/cos(A+B) = (sin A cos B + cos A sin B)/(cos A cos B − sin A sin B).
Divide numerator and denominator by cos A cos B:
= (tan A + tan B)/(1 − tan A tan B) = RHS ✓.

## Double Angle Formulae

Setting B = A in the compound formulae:

sin 2A = 2 sin A cos A
cos 2A = cos²A − sin²A = 1 − 2sin²A = 2cos²A − 1
tan 2A = 2 tan A / (1 − tan²A)

**Key rearrangements (used in integration):**
sin²A = (1 − cos 2A)/2
cos²A = (1 + cos 2A)/2

Example: Given sin θ = 3/5 (0 < θ < π/2), find sin 2θ and cos 2θ.
cos θ = 4/5.
sin 2θ = 2 × (3/5) × (4/5) = 24/25.
cos 2θ = 1 − 2sin²θ = 1 − 18/25 = 7/25.

Example: Solve cos 2x + 3cos x = 1 for 0 ≤ x ≤ 2π.
Substitute cos 2x = 2cos²x − 1:
2cos²x − 1 + 3cos x = 1
2cos²x + 3cos x − 2 = 0
(2cos x − 1)(cos x + 2) = 0
cos x = 1/2 → x = π/3 or 5π/3. (cos x = −2 has no solution.)

## Harmonic Form (R sin and R cos)

Any expression of the form a sin x + b cos x can be written as a single sinusoid:

a sin x + b cos x = R sin(x + α)
where R = √(a² + b²) and tan α = b/a (α in the correct quadrant).

Alternatively: a sin x + b cos x = R cos(x − β) where R = √(a² + b²) and tan β = a/b.

**Why it's useful:** Harmonic form immediately gives the maximum value (R), the minimum value (−R), and the x-value at which they occur. It also simplifies solving equations.

Example: Write 3sin x + 4cos x in the form R sin(x + α).
R = √(9 + 16) = 5. tan α = 4/3 → α = 53.1° (or 0.927 rad).
So 3sin x + 4cos x = 5sin(x + 53.1°).

Maximum value = 5, occurring when x + 53.1° = 90°, i.e. x = 36.9°.

Example: Solve 3sin x + 4cos x = 2 for 0° ≤ x ≤ 360°.
5sin(x + 53.1°) = 2
sin(x + 53.1°) = 0.4
x + 53.1° = 23.6° or 156.4° (principal value and supplement)
Adding 360° to first: x + 53.1° = 383.6° → x = 330.5°
x = 156.4° − 53.1° = 103.3° or x = 330.5°.

## Further Trigonometric Identities

**Half-angle substitution (t = tan(θ/2)):**
sin θ = 2t/(1+t²), cos θ = (1−t²)/(1+t²), tan θ = 2t/(1−t²)

This converts trig equations into algebraic ones — useful for harder problems.

## Proving Identities with Double Angles

Example: Prove sin 3θ = 3sin θ − 4sin³θ.
sin 3θ = sin(2θ + θ) = sin 2θ cos θ + cos 2θ sin θ
= 2sin θ cos²θ + (1 − 2sin²θ)sin θ
= 2sin θ(1 − sin²θ) + sin θ − 2sin³θ
= 2sin θ − 2sin³θ + sin θ − 2sin³θ
= 3sin θ − 4sin³θ ✓
