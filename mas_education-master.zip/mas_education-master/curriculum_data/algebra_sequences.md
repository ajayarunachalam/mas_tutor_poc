# Sequences — GCSE Mathematics

## Types of Sequences

**Arithmetic sequence**: constant difference between consecutive terms (common difference d).
Example: 3, 7, 11, 15, ... (d = +4)
Example: 20, 15, 10, 5, ... (d = −5)

**Geometric sequence**: constant ratio between consecutive terms (common ratio r).
Example: 2, 6, 18, 54, ... (r = 3)
Example: 64, 32, 16, 8, ... (r = 0.5)

## Finding the nth Term of an Arithmetic Sequence

Formula: nth term = a + (n − 1)d, where a = first term, d = common difference.

Simplified form: nth term = dn + (a − d)

Example: Find the nth term of 5, 9, 13, 17, ...
d = 4, a = 5
nth term = 4n + (5 − 4) = 4n + 1
Check: n=1: 4+1=5 ✓; n=2: 8+1=9 ✓

Example: Find the nth term of 1, 4, 9, 16, 25, ... (square numbers)
nth term = n²

## Using the nth Term Formula

Given nth term = 3n − 2:
- 1st term: 3(1) − 2 = 1
- 5th term: 3(5) − 2 = 13
- Is 50 in the sequence? 3n − 2 = 50 → n = 52/3 (not an integer, so 50 is NOT in the sequence)
- Is 46 in the sequence? 3n − 2 = 46 → n = 16 (integer, so YES, it is the 16th term)

## Quadratic Sequences (Extended Tier)

A quadratic sequence has a constant second difference.

Example: 3, 7, 13, 21, 31, ...
First differences: 4, 6, 8, 10 (not constant)
Second differences: 2, 2, 2 (constant → quadratic)

For a quadratic sequence, nth term = an² + bn + c
If second difference = 2k, then a = k.
Here second difference = 2, so a = 1: nth term = n² + bn + c
Substitute n=1: 1 + b + c = 3 → b + c = 2
Substitute n=2: 4 + 2b + c = 7 → 2b + c = 3
Solve: b = 1, c = 1
nth term = n² + n + 1
Check: n=3: 9+3+1=13 ✓

## Special Sequences

- **Square numbers**: 1, 4, 9, 16, 25, ... → nth term = n²
- **Cube numbers**: 1, 8, 27, 64, 125, ... → nth term = n³
- **Triangular numbers**: 1, 3, 6, 10, 15, ... → nth term = n(n+1)/2
- **Fibonacci**: 1, 1, 2, 3, 5, 8, 13, ... (each term = sum of two previous)

## Recognising and Continuing Sequences

To find the next terms:
1. Find the first differences
2. If constant → arithmetic (find d, continue)
3. If not constant, find second differences
4. If constant → quadratic (continue pattern)
5. Check for geometric patterns (divide consecutive terms)
