# Estimation and Bounds — GCSE Mathematics

## Rounding

### Decimal Places
Round to the required number of decimal places by looking at the next digit:
- If next digit ≥ 5: round up
- If next digit < 5: round down

3.4752 to 2 d.p. = 3.48 (third decimal is 5, round up)
7.3341 to 1 d.p. = 7.3 (second decimal is 3, round down)

### Significant Figures
Significant figures count from the first non-zero digit.

4.7839 to 3 s.f. = 4.78
0.004567 to 2 s.f. = 0.0046 (first s.f. is 4, second is 5, third digit is 6 so round up)
34,850 to 2 s.f. = 35,000

## Estimation

Use rounding to approximately 1 significant figure to estimate calculations.

Example: Estimate 38.7 × 5.2 / 9.8
≈ 40 × 5 / 10 = 200 / 10 = 20
(Exact: 20.53... so estimate is good)

Example: Estimate √(98.4)
≈ √100 = 10

## Upper and Lower Bounds

When a measurement is given to a degree of accuracy, the true value lies within bounds:
- Lower bound = stated value − half the degree of accuracy
- Upper bound = stated value + half the degree of accuracy

Example: A length is given as 7.3 cm (to 1 d.p.).
Accuracy = 0.1 cm; half = 0.05 cm
Lower bound = 7.3 − 0.05 = 7.25 cm
Upper bound = 7.3 + 0.05 = 7.35 cm
True length: 7.25 ≤ l < 7.35

## Bounds in Calculations

When combining measurements, use bounds to find the bounds of the result.

**For maximum result:**
- Addition: upper + upper
- Multiplication: upper × upper
- Division: upper ÷ lower (larger ÷ smaller = larger result)
- Subtraction: upper − lower

**For minimum result:**
- Addition: lower + lower
- Multiplication: lower × lower
- Division: lower ÷ upper (smaller ÷ larger = smaller result)
- Subtraction: lower − upper

Example: Rectangle with length 8.4 cm and width 3.2 cm (both to 1 d.p.)
Length: 8.35 ≤ l < 8.45; Width: 3.15 ≤ w < 3.25

Maximum area = 8.45 × 3.25 = 27.4625 cm²
Minimum area = 8.35 × 3.15 = 26.3025 cm²

## Error Intervals

An error interval is written using inequality notation:
7.25 ≤ x < 7.35

The lower bound is included (≥) because the actual value could be exactly 7.25.
The upper bound is excluded (<) because 7.35 rounds up to 7.4, not 7.3.

## Worked Example

A distance is measured as 450 m to the nearest 10 m.
Degree of accuracy = 10 m; half = 5 m
Lower bound = 445 m; Upper bound = 455 m
Error interval: 445 ≤ d < 455
