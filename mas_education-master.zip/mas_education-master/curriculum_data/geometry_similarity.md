# Similarity and Congruence — GCSE Mathematics

## Congruent Shapes

Two shapes are congruent if they are exactly the same size and shape (one may be a reflection or rotation of the other).

Conditions for congruent triangles:
- **SSS**: Three sides equal
- **SAS**: Two sides and the included angle equal
- **ASA**: Two angles and the included side equal
- **RHS**: Right angle, hypotenuse, and one other side equal

## Similar Shapes

Two shapes are similar if they have the same angles and their corresponding sides are in the same ratio (one is an enlargement of the other).

For similar triangles:
- All corresponding angles are equal
- Corresponding sides are in the same ratio (scale factor k)

### Finding Missing Lengths in Similar Triangles

If triangles ABC and PQR are similar with AB corresponding to PQ:
Scale factor k = PQ/AB
Missing side = k × corresponding side

Example: Triangle A has sides 3, 4, 5. Triangle B is similar with shortest side 6. Find the other sides.
Scale factor = 6/3 = 2
Other sides: 4 × 2 = 8 and 5 × 2 = 10

### Area and Volume Scaling

If linear scale factor is k:
- Area scale factor = k²
- Volume scale factor = k³

Example: Two similar cones have radii 3 cm and 6 cm. If the smaller has surface area 30 cm², find the surface area of the larger.
Linear scale factor = 6/3 = 2
Area scale factor = 2² = 4
Larger surface area = 30 × 4 = 120 cm²

Example: Two similar shapes have volumes 8 cm³ and 27 cm³. Find the ratio of their surface areas.
Volume ratio = 8:27, so linear scale factor = ∛(27/8) = 3/2
Area scale factor = (3/2)² = 9/4
Surface area ratio = 9:4

## Proof of Similarity

To prove triangles are similar:
1. Identify matching angles (look for equal angles, angles in parallel lines, angle at a point)
2. State the three equal angles OR calculate ratios of corresponding sides
3. Conclude "therefore the triangles are similar by AA (or SSS or SAS)"

## Common Mistakes

- Confusing similarity with congruence (similar shapes have the same shape but different sizes)
- Using linear scale factor for area problems (must square it)
- Not identifying which sides correspond correctly
