# Transformations — GCSE Mathematics

## The Four Transformations

### 1. Reflection
A shape is reflected in a mirror line. Each point maps to an equal distance on the other side of the line.

Common mirror lines:
- x-axis: (x, y) → (x, −y)
- y-axis: (x, y) → (−x, y)
- y = x: (x, y) → (y, x)
- y = −x: (x, y) → (−y, −x)

To describe a reflection: state the mirror line equation.

### 2. Rotation
A shape is rotated about a centre point through an angle.

To describe a rotation: state the centre, angle, and direction (clockwise or anticlockwise).
90° anticlockwise about origin: (x, y) → (−y, x)
180° about origin: (x, y) → (−x, −y)
90° clockwise about origin: (x, y) → (y, −x)

### 3. Translation
A shape is moved without turning or reflecting. Described by a column vector.

Column vector (a, b) means move a units right (negative = left) and b units up (negative = down).
Example: Translate by (3, −2) means move 3 right and 2 down.

### 4. Enlargement
A shape is scaled from a centre of enlargement by a scale factor k.

New length = k × original length
Scale factor > 1: shape gets bigger
0 < scale factor < 1: shape gets smaller (reduction)
Negative scale factor: shape is enlarged AND reflected through the centre

To find the image: draw lines from the centre of enlargement through each vertex, extend by scale factor k.

To describe: state centre of enlargement and scale factor.

## Properties Preserved

| Transformation | Shape | Size | Orientation |
|---------------|-------|------|-------------|
| Reflection | ✓ | ✓ | Reversed |
| Rotation | ✓ | ✓ | Changed |
| Translation | ✓ | ✓ | Same |
| Enlargement | ✓ | Changes | Same (unless k < 0) |

Reflections, rotations, and translations are **isometries** — they preserve size and shape.

## Transformation Matrices (Extended Tier)

Enlargement by factor k: matrix = (k 0; 0 k)
Reflection in x-axis: matrix = (1 0; 0 −1)
Reflection in y-axis: matrix = (−1 0; 0 1)
90° anticlockwise rotation: matrix = (0 −1; 1 0)
180° rotation: matrix = (−1 0; 0 −1)

Combined transformations: multiply matrices (apply right matrix first).

## Worked Example

Triangle A has vertices at (1,1), (3,1), (2,4). Reflect in the line y = x then rotate 90° anticlockwise about the origin. Find the final image.

Step 1 — Reflect in y = x: swap x and y coordinates.
(1,1)→(1,1), (3,1)→(1,3), (2,4)→(4,2)

Step 2 — Rotate 90° anticlockwise: (x,y)→(−y,x)
(1,1)→(−1,1), (1,3)→(−3,1), (4,2)→(−2,4)
