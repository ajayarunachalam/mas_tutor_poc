# Ratio, Proportion, and Rate — GCSE Mathematics

## Ratio

A ratio compares two or more quantities of the same kind.
Written as a:b or a:b:c.

Simplifying: divide all parts by their HCF.
12:18 = 2:3 (divide by 6)
15:25:35 = 3:5:7 (divide by 5)

## Dividing in a Given Ratio

Total parts = sum of ratio numbers.
Each share = (amount × ratio part) ÷ total parts.

Example: Share £240 in ratio 3:5.
Total parts = 3 + 5 = 8
First share = 240 × 3/8 = £90
Second share = 240 × 5/8 = £150
Check: 90 + 150 = 240 ✓

Example: Share 72 in ratio 2:3:4.
Total parts = 9
Shares: 16, 24, 32. Check: 16+24+32=72 ✓

## Direct Proportion

Two quantities are in direct proportion if their ratio is constant.
As one increases, the other increases by the same factor.
Symbol: y ∝ x means y = kx for some constant k.

Example: 5 apples cost £2.50. How much do 8 apples cost?
Cost per apple = 250 ÷ 5 = 50p
8 apples = 8 × 50p = £4.00

Or: 5 → £2.50, so 1 → £0.50, so 8 → £4.00

## Inverse Proportion

Two quantities are in inverse proportion if their product is constant.
As one doubles, the other halves.
y ∝ 1/x means y = k/x.

Example: 6 workers take 8 days to build a wall. How long do 4 workers take?
Total work = 6 × 8 = 48 worker-days
4 workers: 48 ÷ 4 = 12 days

## Speed, Distance, Time

Speed = Distance ÷ Time (SDT triangle)
Distance = Speed × Time
Time = Distance ÷ Speed

Units: miles per hour (mph), kilometres per hour (km/h), metres per second (m/s)

Example: A car travels 240 km in 3 hours. Find the average speed.
Speed = 240 ÷ 3 = 80 km/h

Example: A train travels at 90 km/h for 2.5 hours. Find the distance.
Distance = 90 × 2.5 = 225 km

## Density, Mass, Volume

Density = Mass ÷ Volume
Mass = Density × Volume
Volume = Mass ÷ Density
Units: g/cm³ or kg/m³

Example: A metal block of volume 50 cm³ has mass 350 g. Find the density.
Density = 350 ÷ 50 = 7 g/cm³

## Worked Examples

Best value: Jar A: 400g for £2.80 → £7 per kg. Jar B: 600g for £3.90 → £6.50 per kg. Jar B is better value.

Exchange rates: £1 = $1.25. Convert £350 to dollars: £350 × 1.25 = $437.50.
Convert $200 to pounds: $200 ÷ 1.25 = £160.
