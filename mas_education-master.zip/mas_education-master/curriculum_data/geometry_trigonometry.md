# Trigonometry — GCSE Mathematics

## Pythagoras' Theorem

In a right-angled triangle: a² + b² = c², where c is the hypotenuse (longest side, opposite the right angle).

Example: Find the hypotenuse when the other sides are 3 cm and 4 cm.
c² = 3² + 4² = 9 + 16 = 25
c = √25 = 5 cm

Finding a shorter side: a² = c² − b²
Example: Hypotenuse = 13, one side = 5. Find the other side.
a² = 13² − 5² = 169 − 25 = 144
a = 12

## SOHCAHTOA — Trigonometric Ratios

In a right-angled triangle, label the sides relative to angle θ:
- Opposite (O): side opposite to θ
- Adjacent (A): side next to θ (not the hypotenuse)
- Hypotenuse (H): longest side, opposite the right angle

sin θ = O/H    cos θ = A/H    tan θ = O/A

**SOHCAHTOA** — a memory aid: Sin=Opposite/Hypotenuse, Cos=Adjacent/Hypotenuse, Tan=Opposite/Adjacent

Finding a side:
Example: Angle = 35°, hypotenuse = 10 cm. Find the opposite side.
sin 35° = O/10 → O = 10 × sin 35° = 10 × 0.574 = 5.74 cm

Finding an angle:
Example: Opposite = 6 cm, hypotenuse = 10 cm. Find the angle.
sin θ = 6/10 = 0.6 → θ = sin⁻¹(0.6) = 36.9°

## The Sine Rule (Extended Tier)

For any triangle with angles A, B, C and opposite sides a, b, c:
a/sin A = b/sin B = c/sin C

Use when you know: two angles and one side, or two sides and a non-included angle.

Example: In triangle ABC, angle A = 40°, angle B = 60°, side a = 7 cm. Find side b.
b/sin 60° = 7/sin 40°
b = 7 × sin 60° / sin 40° = 7 × 0.866 / 0.643 = 9.43 cm

## The Cosine Rule (Extended Tier)

a² = b² + c² − 2bc cos A

Use when you know: two sides and the included angle, or all three sides (to find an angle).

Finding a side:
Example: b = 5, c = 7, A = 60°. Find a.
a² = 25 + 49 − 2(5)(7)cos 60° = 74 − 70 × 0.5 = 74 − 35 = 39
a = √39 ≈ 6.24

Finding an angle:
cos A = (b² + c² − a²) / (2bc)

## Area of a Triangle (Extended Tier)

Area = ½ab sin C

where a and b are two sides and C is the included angle.

## Trigonometry in 3D (Extended Tier)

For problems in 3D, identify the relevant right-angled triangles in horizontal and vertical planes.
Use Pythagoras to find diagonal distances in cuboids and pyramids, then apply SOHCAHTOA.
