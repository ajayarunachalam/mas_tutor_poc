# Fractions, Decimals, and Percentages — GCSE Mathematics

## Fractions

### Equivalent Fractions
Multiply or divide numerator and denominator by the same number.
3/4 = 6/8 = 9/12; 12/20 = 3/5 (divide both by 4)

### Adding and Subtracting Fractions
Find a common denominator, then add/subtract numerators.
1/3 + 1/4 = 4/12 + 3/12 = 7/12
3/5 − 1/3 = 9/15 − 5/15 = 4/15

### Multiplying Fractions
Multiply numerators together and denominators together. Cancel first if possible.
2/3 × 4/5 = 8/15
3/4 × 8/9 = (3×8)/(4×9) = 24/36 = 2/3 (or cancel: 3/4 × 8/9 = 1/4 × 8/3 = 8/12 = 2/3)

### Dividing Fractions
"Keep, change, flip": keep first fraction, change ÷ to ×, flip (reciprocal) second fraction.
3/5 ÷ 2/7 = 3/5 × 7/2 = 21/10 = 2 1/10

### Mixed Numbers
Convert to improper fraction first for calculations.
2⅓ = 7/3 (multiply whole number by denominator, add numerator: 2×3+1=7)
2⅓ + 1¼ = 7/3 + 5/4 = 28/12 + 15/12 = 43/12 = 3 7/12

## Decimals

Converting fractions to decimals: divide numerator by denominator.
3/8 = 3 ÷ 8 = 0.375

Recurring decimals: digits repeat infinitely.
1/3 = 0.333..., 1/7 = 0.142857142857...

Converting recurring decimals to fractions (extended):
Let x = 0.363636...
100x = 36.363636...
99x = 36
x = 36/99 = 4/11

## Percentages

### Converting Between Forms
Percentage to decimal: divide by 100 (35% = 0.35)
Decimal to percentage: multiply by 100 (0.08 = 8%)
Fraction to percentage: divide and multiply by 100 (3/8 = 0.375 = 37.5%)

### Finding a Percentage of an Amount
30% of £250 = 0.30 × 250 = £75
Or: 10% = £25, so 30% = £75

### Percentage Change
Percentage change = (change / original) × 100
Percentage increase: new is higher
Percentage decrease: new is lower

Example: Price rises from £40 to £52. Percentage increase = (12/40) × 100 = 30%
Example: Population falls from 8000 to 6800. Percentage decrease = (1200/8000) × 100 = 15%

### Reverse Percentages
Find original value before a percentage change.
Method: identify the multiplier, then divide.

"Price after 25% increase is £375. Find original."
375 = P × 1.25 → P = 375/1.25 = £300

"After 40% discount, shirt costs £33. Find original price."
33 = P × 0.60 → P = 33/0.60 = £55

## FDP Equivalents to Memorise

| Fraction | Decimal | Percentage |
|---------|---------|-----------|
| 1/2 | 0.5 | 50% |
| 1/4 | 0.25 | 25% |
| 3/4 | 0.75 | 75% |
| 1/3 | 0.333... | 33.3...% |
| 2/3 | 0.666... | 66.6...% |
| 1/5 | 0.2 | 20% |
| 1/10 | 0.1 | 10% |
