# Algebraic Expressions and Manipulation — GCSE Mathematics

## Simplifying Expressions

Collect like terms: terms with the same variable and power.
3x + 2y − x + 5y = 2x + 7y
4a² + 3a − 2a² + a = 2a² + 4a

## Substitution

Replace each variable with the given number.
Example: Find the value of 3x² − 2y when x = 4 and y = −3.
= 3(4²) − 2(−3) = 3(16) + 6 = 48 + 6 = 54

## Expanding Brackets

Single bracket: multiply each term inside by the factor outside.
3(2x − 5) = 6x − 15
−2(x + 4) = −2x − 8

Double bracket (FOIL): multiply each term in the first bracket by each term in the second.
(x + 3)(x − 2) = x² − 2x + 3x − 6 = x² + x − 6
(2x + 1)(x − 4) = 2x² − 8x + x − 4 = 2x² − 7x − 4

Difference of two squares: (a + b)(a − b) = a² − b²
(x + 5)(x − 5) = x² − 25

Perfect square: (a + b)² = a² + 2ab + b²
(x + 3)² = x² + 6x + 9

## Factorising

**Common factor**: find the HCF of all terms.
6x² + 9x = 3x(2x + 3)
12a²b − 8ab² = 4ab(3a − 2b)

**Difference of two squares**: a² − b² = (a + b)(a − b)
x² − 16 = (x + 4)(x − 4)
9x² − 25 = (3x + 5)(3x − 5)

**Quadratic factorisation** (extended): x² + bx + c = (x + p)(x + q) where p + q = b and pq = c
x² + 7x + 12 = (x + 3)(x + 4)
x² − 5x + 6 = (x − 2)(x − 3)

**Algebraic fractions** (extended):
Simplify by factorising numerator and denominator then cancelling common factors.
(x² − 4)/(x + 2) = (x+2)(x−2)/(x+2) = x − 2

## Rearranging Formulae

Make a specific variable the subject by applying inverse operations.
v = u + at → rearrange for a: at = v − u → a = (v − u)/t

Make x the subject: y = (3x + 1)/5
5y = 3x + 1
5y − 1 = 3x
x = (5y − 1)/3

When the subject appears twice: factorise.
ax + b = cx + d → ax − cx = d − b → x(a − c) = d − b → x = (d − b)/(a − c)

## Algebraic Proof (Extended Tier)

To prove a statement:
- Let n be any integer (or any even/odd integer as needed)
- Use algebra to show the result must follow
- Conclude with "therefore the statement is proved"

Example: Prove that the sum of any two consecutive integers is odd.
Let the integers be n and n + 1.
Sum = n + (n + 1) = 2n + 1
2n is even, so 2n + 1 is odd. Therefore the sum of two consecutive integers is always odd. ∎
