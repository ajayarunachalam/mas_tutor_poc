# Statistical Representation — GCSE Mathematics

## Bar Charts and Pie Charts

**Bar charts**: bars of equal width, heights proportional to frequency. Gaps between bars for categorical data.

**Pie charts**: angles proportional to frequency.
Angle for a category = (frequency / total) × 360°

Example: 30 students chose favourite colours — 12 red, 8 blue, 10 green.
Red angle = (12/30) × 360° = 144°
Blue angle = (8/30) × 360° = 96°
Green angle = (10/30) × 360° = 120°
Check: 144 + 96 + 120 = 360° ✓

## Frequency Tables and Two-Way Tables

Two-way tables show data cross-classified by two variables.
Row totals and column totals are called marginal frequencies.

Example: 50 students: 20 boys, 30 girls. 12 boys play sport, 18 girls play sport.

|  | Sport | No Sport | Total |
|--|-------|---------|-------|
| Boys | 12 | 8 | 20 |
| Girls | 18 | 12 | 30 |
| Total | 30 | 20 | 50 |

## Scatter Graphs

Scatter graphs show the relationship (correlation) between two variables.
Each data point is plotted as a coordinate (x, y).

Types of correlation:
- **Positive correlation**: as x increases, y increases (points slope upward)
- **Negative correlation**: as x increases, y decreases (points slope downward)
- **No correlation**: no pattern (points scattered randomly)

**Line of best fit**: a straight line that passes through the middle of the data.
Draw it so roughly equal numbers of points are on each side.
Use the line of best fit to estimate values (interpolation = within data range, extrapolation = outside it).

## Cumulative Frequency (Extended Tier)

Cumulative frequency: running total of frequencies.
Plot upper class boundary against cumulative frequency.
Join points with a smooth S-curve.

Reading from cumulative frequency graph:
- Median = value at 50% of total frequency (n/2)
- Lower quartile Q1 = value at 25% (n/4)
- Upper quartile Q3 = value at 75% (3n/4)
- IQR = Q3 − Q1

## Box Plots (Box-and-Whisker Diagrams) (Extended Tier)

A box plot displays: minimum, Q1, median, Q3, maximum.
- The box spans from Q1 to Q3 (the middle 50% of data)
- A line inside the box marks the median
- Whiskers extend to the minimum and maximum values (or 1.5 × IQR for outlier detection)

Box plots are useful for comparing two distributions side by side.

## Histograms (Extended Tier)

Histograms display grouped continuous data with NO gaps between bars.
Key difference from bar chart: y-axis shows **frequency density**, not frequency.

Frequency density = frequency / class width

To find frequency from histogram: frequency = frequency density × class width

Area of bar = frequency (so areas, not heights, represent frequencies in unequal-width classes).

## Stem-and-Leaf Diagrams

A stem-and-leaf diagram preserves the original data while showing distribution.
The stem is the leading digit(s); leaves are the final digit(s).

Example: 23, 35, 41, 47, 52, 55, 58, 61, 65
2 | 3
3 | 5
4 | 1 7
5 | 2 5 8
6 | 1 5

Key: 4 | 7 represents 47

Back-to-back stem-and-leaf diagrams compare two data sets.
Median is easy to read: count to the middle value.

## Frequency Polygons

Connect the midpoints of bars in a frequency histogram with straight lines.
Useful for comparing two frequency distributions on the same diagram.
