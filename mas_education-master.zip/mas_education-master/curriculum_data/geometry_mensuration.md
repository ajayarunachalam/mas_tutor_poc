# Mensuration — GCSE Mathematics (Area, Perimeter, Volume)

## Perimeter and Area of 2D Shapes

**Rectangle**: Area = length × width; Perimeter = 2(l + w)

**Triangle**: Area = ½ × base × height; Perimeter = sum of all three sides

**Parallelogram**: Area = base × perpendicular height

**Trapezium**: Area = ½(a + b)h, where a and b are the parallel sides and h is the perpendicular height

**Circle**: Area = πr²; Circumference = 2πr = πd

**Sector of a circle**: Area = (θ/360) × πr²; Arc length = (θ/360) × 2πr

Example: Find the area of a circle with radius 5 cm.
Area = π × 5² = 25π ≈ 78.5 cm²

Example: Find the arc length of a sector with radius 8 cm and angle 45°.
Arc length = (45/360) × 2π × 8 = (1/8) × 16π = 2π ≈ 6.28 cm

## Surface Area and Volume of 3D Shapes

**Cuboid**: Volume = l × w × h; Surface area = 2(lw + lh + wh)

**Cylinder**: Volume = πr²h; Curved surface area = 2πrh; Total surface area = 2πr² + 2πrh

**Cone**: Volume = ⅓πr²h; Curved surface area = πrl, where l is the slant height
l = √(r² + h²)

**Sphere**: Volume = (4/3)πr³; Surface area = 4πr²

**Pyramid**: Volume = ⅓ × base area × height

**Prism**: Volume = cross-sectional area × length

## Compound Shapes

For compound shapes, split into simple shapes and add (or subtract) areas/volumes.

Example: An L-shaped area consists of a 10×6 rectangle with a 4×3 corner removed.
Area = 10×6 − 4×3 = 60 − 12 = 48 cm²

## Worked Examples

Example 1: A cylinder has radius 3 cm and height 10 cm. Find volume and total surface area.
Volume = π × 9 × 10 = 90π ≈ 283 cm³
Total surface area = 2π(3)² + 2π(3)(10) = 18π + 60π = 78π ≈ 245 cm²

Example 2: A cone has base radius 4 cm and height 3 cm. Find the volume.
Volume = ⅓ × π × 16 × 3 = 16π ≈ 50.3 cm³
Slant height l = √(16 + 9) = √25 = 5 cm
Curved surface area = π × 4 × 5 = 20π ≈ 62.8 cm²

## Units of Measurement

Length: mm, cm, m, km
Area: mm², cm², m², km² (1 m² = 10,000 cm²)
Volume: mm³, cm³, m³, litres (1 litre = 1000 cm³)

Always include units in your answer and check they are consistent.
