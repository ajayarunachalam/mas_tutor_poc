# Interest and Financial Mathematics — GCSE Mathematics

## Simple Interest

Simple interest is calculated only on the original principal amount.

Formula: Interest = (P × R × T) / 100
where P = principal, R = annual rate (%), T = time (years)

Total amount = P + Interest

Example: £5000 invested at 4% simple interest for 3 years.
Interest = (5000 × 4 × 3) / 100 = £600
Total = £5000 + £600 = £5600

## Compound Interest

Compound interest is calculated on the accumulated amount each period (interest on interest).

Formula: A = P(1 + r/100)ⁿ
where A = final amount, P = principal, r = annual rate (%), n = number of years

Example: £3000 invested at 5% compound interest for 4 years.
A = 3000 × (1.05)⁴ = 3000 × 1.2155 = £3646.50

Compare with simple interest: 3000 × 4 × 5/100 = £600 → £3600.
Compound interest earns more over time.

## Depreciation

Assets lose value over time. Depreciation uses the same formula as compound interest but with a subtraction.

Formula: Value = P(1 − r/100)ⁿ

Example: A car costs £12,000. It depreciates at 15% per year. Value after 3 years:
Value = 12,000 × (0.85)³ = 12,000 × 0.6141 = £7369.20

## Profit and Loss

Profit = Selling price − Cost price
Loss = Cost price − Selling price

Percentage profit = (Profit / Cost price) × 100
Percentage loss = (Loss / Cost price) × 100

Example: Buy for £80, sell for £96.
Profit = 96 − 80 = £16
Percentage profit = (16/80) × 100 = 20%

Example: Selling price £340 after 15% loss. Find original price.
340 = P × 0.85 → P = 340/0.85 = £400

## Percentage Increase and Decrease

Multiplier for r% increase: (1 + r/100)
Multiplier for r% decrease: (1 − r/100)

Example: Increase £460 by 12%: 460 × 1.12 = £515.20
Example: Decrease £90 by 30%: 90 × 0.70 = £63

Reverse percentage (finding original):
"Price after 20% reduction is £240. Find original."
240 = P × 0.80 → P = 240/0.80 = £300

## VAT

VAT (Value Added Tax) in UK is typically 20%.
Price including VAT = original price × 1.20
Original price from VAT-inclusive price = divide by 1.20

Example: TV costs £420 including 20% VAT. Find price before VAT.
Price before VAT = 420/1.20 = £350

## Worked Example — Compound Rates

A savings account pays 3% for the first 2 years, then 4% for the next 3 years.
Initial deposit: £2000.
After 2 years: 2000 × (1.03)² = 2000 × 1.0609 = £2121.80
After 3 more years: 2121.80 × (1.04)³ = 2121.80 × 1.1249 = £2386.68
