# Linear Equations — GCSE Mathematics

A linear equation is an equation where the highest power of the variable is 1. The graph of a linear equation is a straight line.

## Solving One-Step Equations

x + 5 = 12 → subtract 5 from both sides → x = 7
x - 3 = 8 → add 3 to both sides → x = 11
3x = 15 → divide both sides by 3 → x = 5
x/4 = 6 → multiply both sides by 4 → x = 24

## Solving Two-Step Equations

2x + 3 = 11
Step 1: Subtract 3 from both sides → 2x = 8
Step 2: Divide both sides by 2 → x = 4

Rule: Always undo addition/subtraction first, then multiplication/division.

5x - 7 = 28
Step 1: Add 7 → 5x = 35
Step 2: Divide by 5 → x = 7

## Variables on Both Sides

5x + 3 = 3x + 11
Step 1: Collect x terms on left → 5x - 3x = 11 - 3
Step 2: Simplify → 2x = 8
Step 3: Divide → x = 4

Another: 4(x + 2) = 2(x + 7)
Expand: 4x + 8 = 2x + 14
Collect: 2x = 6
Solve: x = 3

## Equations with Fractions

(x + 1)/3 = 4
Multiply both sides by 3: x + 1 = 12
Subtract 1: x = 11

x/2 + x/3 = 10
Common denominator 6: 3x/6 + 2x/6 = 10
5x/6 = 10
x = 12

## Word Problems — Setting Up Equations

"I think of a number, double it and add 7. The answer is 19. What is the number?"
Let the number be x.
2x + 7 = 19 → 2x = 12 → x = 6

"Three consecutive integers sum to 48. Find them."
Let the integers be n, n+1, n+2.
n + (n+1) + (n+2) = 48 → 3n + 3 = 48 → 3n = 45 → n = 15
Integers: 15, 16, 17

## Simultaneous Equations (Linear)

Solve: 2x + y = 7 and x + 3y = 11

Elimination method:
Multiply first equation by 3: 6x + 3y = 21
Subtract second: 5x = 10 → x = 2
Substitute: 4 + y = 7 → y = 3

Substitution method:
From first equation: y = 7 - 2x
Substitute: x + 3(7 - 2x) = 11 → x + 21 - 6x = 11 → -5x = -10 → x = 2
