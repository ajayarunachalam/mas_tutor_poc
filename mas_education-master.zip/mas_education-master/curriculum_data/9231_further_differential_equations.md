# Further Differential Equations — Cambridge International AS & A Level Further Mathematics (9231)

## Second-Order Linear Differential Equations with Constant Coefficients

The general form is:
a d²y/dx² + b dy/dx + cy = f(x)

where a, b, c are constants.

**Solution structure:** General solution = Complementary function (CF) + Particular integral (PI)
y = y_CF + y_PI

## Complementary Function (Homogeneous Case)

Set f(x) = 0 and solve the **auxiliary equation**: am² + bm + c = 0.

**Three cases depending on the discriminant Δ = b² − 4ac:**

**Case 1: Two distinct real roots (Δ > 0), m₁ ≠ m₂**
CF: y = Ae^(m₁x) + Be^(m₂x)

**Case 2: Repeated real root (Δ = 0), m₁ = m₂ = m**
CF: y = (A + Bx)e^(mx)

**Case 3: Complex conjugate roots (Δ < 0), m = α ± βi**
CF: y = e^(αx)(A cos βx + B sin βx)

Example: Solve d²y/dx² − 5dy/dx + 6y = 0.
Auxiliary equation: m² − 5m + 6 = (m−2)(m−3) = 0.
Roots: m = 2, 3 (distinct real).
CF: y = Ae^(2x) + Be^(3x).

Example: Solve d²y/dx² + 4dy/dx + 4y = 0.
Auxiliary equation: m² + 4m + 4 = (m+2)² = 0.
Repeated root: m = −2.
CF: y = (A + Bx)e^(−2x).

Example: Solve d²y/dx² − 2dy/dx + 5y = 0.
Auxiliary equation: m² − 2m + 5 = 0 → m = (2 ± √(4−20))/2 = 1 ± 2i.
CF: y = e^x(A cos 2x + B sin 2x).

## Particular Integral

The PI is a specific solution to the full equation a y'' + b y' + cy = f(x).

**Trial PI by form of f(x):**

| f(x) | Trial PI |
|---|---|
| Constant k | y_P = k/c (if c ≠ 0) |
| Polynomial pₙ(x) | y_P = polynomial of same degree |
| e^(kx) | y_P = pe^(kx) (if k not a root of aux. eq.) |
| e^(kx) | y_P = pxe^(kx) (if k is a simple root) |
| e^(kx) | y_P = px²e^(kx) (if k is a repeated root) |
| sin(kx) or cos(kx) | y_P = p sin(kx) + q cos(kx) |

Substitute the trial form into the DE and equate coefficients to find the constants.

Example: Solve d²y/dx² − 3dy/dx + 2y = 4e^(3x).
Auxiliary equation: m² − 3m + 2 = (m−1)(m−2) = 0. Roots m = 1, 2.
CF: y_CF = Ae^x + Be^(2x).
Trial PI: y_P = pe^(3x) (k=3 is not a root).
y_P' = 3pe^(3x), y_P'' = 9pe^(3x).
Substitute: 9pe^(3x) − 9pe^(3x) + 2pe^(3x) = 4e^(3x) → 2p = 4 → p = 2.
PI: y_P = 2e^(3x).
General solution: y = Ae^x + Be^(2x) + 2e^(3x).

## Applying Initial or Boundary Conditions

The general solution contains two arbitrary constants A and B. Initial conditions (values of y and dy/dx at a given x) determine them uniquely.

Example (continued from above): Given y(0) = 1 and y'(0) = 3.
y = Ae^x + Be^(2x) + 2e^(3x).
y(0): A + B + 2 = 1 → A + B = −1.
y' = Ae^x + 2Be^(2x) + 6e^(3x).
y'(0): A + 2B + 6 = 3 → A + 2B = −3.
Subtracting: B = −2, A = 1.
Particular solution: y = e^x − 2e^(2x) + 2e^(3x).

## Simple Harmonic Motion (SHM)

SHM is modelled by:
d²x/dt² = −ω²x (or d²x/dt² + ω²x = 0)

Auxiliary equation: m² + ω² = 0 → m = ±ωi.
General solution: x = A cos(ωt) + B sin(ωt) = R cos(ωt − φ)

where R = amplitude, ω = angular frequency, T = 2π/ω = period.

## Damped Oscillations

Adding a damping term: d²x/dt² + 2k dx/dt + ω²x = 0.
Auxiliary equation: m² + 2km + ω² = 0, roots m = −k ± √(k²−ω²).

**Three types:**
- **Underdamped** (k < ω): complex roots → oscillatory decay: x = e^(−kt)(A cos βt + B sin βt)
- **Critically damped** (k = ω): repeated root → fastest return without oscillation
- **Overdamped** (k > ω): two negative real roots → exponential decay

Example: d²x/dt² + 4dx/dt + 13x = 0, x(0) = 0, x'(0) = 3.
Auxiliary: m² + 4m + 13 = 0 → m = (−4 ± √(16−52))/2 = −2 ± 3i.
CF: x = e^(−2t)(A cos 3t + B sin 3t).
x(0) = 0 → A = 0.
x' = e^(−2t)(−2B sin 3t + 3B cos 3t) + (−2)e^(−2t)(B sin 3t).
x'(0) = 3B = 3 → B = 1.
Solution: x = e^(−2t) sin 3t (underdamped oscillation decaying to zero).
