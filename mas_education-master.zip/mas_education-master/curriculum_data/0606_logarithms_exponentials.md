# Logarithms and Exponential Functions — Cambridge IGCSE Additional Mathematics (0606)

## What is a Logarithm?

A logarithm is the inverse of an exponential function.

If aˣ = b, then log_a(b) = x (read: "log base a of b equals x")

The most common bases are:
- Base 10: log₁₀(x), written as lg(x) or log(x)
- Base e: log_e(x), written as ln(x) (the natural logarithm)

Key values: log_a(1) = 0 (since a⁰ = 1), log_a(a) = 1 (since a¹ = a)

Example: log₂(8) = 3 because 2³ = 8.
Example: log₃(1/9) = −2 because 3⁻² = 1/9.

## Laws of Logarithms

| Law | Statement | Example |
|---|---|---|
| Product | log(ab) = log(a) + log(b) | log(6) = log(2) + log(3) |
| Quotient | log(a/b) = log(a) − log(b) | log(5) = log(10) − log(2) |
| Power | log(aⁿ) = n log(a) | log(8) = 3 log(2) |
| Change of base | log_a(b) = ln(b)/ln(a) | log₂(5) = ln(5)/ln(2) |

**Remember:** log(a + b) ≠ log(a) + log(b). The product law applies to multiplication inside the log, not addition.

## Solving Exponential Equations

To solve aˣ = b: take logarithms of both sides.

Example: Solve 3ˣ = 20.
Taking ln: x ln(3) = ln(20)
x = ln(20)/ln(3) = 2.727 (3 d.p.)

Example: Solve 2^(2x−1) = 5.
(2x − 1) ln 2 = ln 5
2x − 1 = ln(5)/ln(2) = 2.322
2x = 3.322, so x = 1.661

To solve log equations, use the inverse: if log_a(x) = k then x = aᵏ.
Example: log₃(2x − 1) = 4 → 2x − 1 = 3⁴ = 81 → x = 41.

## The Exponential Function y = eˣ

The number e ≈ 2.718 is the base of the natural logarithm. The function y = eˣ is its own derivative.

Key properties:
- y = eˣ always positive; passes through (0, 1)
- As x → −∞, y → 0 (asymptote at y = 0)
- y = e^(kx) grows faster for larger k

Inverse: if y = eˣ then x = ln(y). So ln(eˣ) = x and e^(ln x) = x.

**Sketching transformations:**
- y = eˣ + 2: shift up 2, asymptote becomes y = 2
- y = e^(x−3): shift right 3, same asymptote y = 0
- y = 2eˣ: vertical stretch by factor 2

## Exponential Growth and Decay

Many real situations follow the model N = N₀ eᵏᵗ, where:
- N₀ is the initial value
- k > 0 gives growth, k < 0 gives decay
- t is time

Example: A population P = 500e^(0.04t) (t in years).
At t = 10: P = 500e^(0.4) ≈ 500 × 1.492 = 746.

**Linearising exponential data:** If y = Abˣ, taking logs gives:
lg y = lg A + x lg b
This is linear in x. Plotting lg y against x gives a straight line with gradient lg b and y-intercept lg A.

Similarly, if y = Axⁿ: lg y = lg A + n lg x — plot lg y against lg x.

## Worked Example

The number of bacteria N in a culture at time t hours is given by N = 200e^(0.15t).

(a) Find the initial number. t = 0: N = 200e⁰ = 200.

(b) Find N when t = 4. N = 200e^(0.6) = 200 × 1.822 = 364.

(c) Find t when N = 1000.
1000 = 200e^(0.15t)
5 = e^(0.15t)
ln 5 = 0.15t
t = ln(5)/0.15 = 1.609/0.15 = 10.7 hours.
