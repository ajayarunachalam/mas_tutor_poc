# Complex Numbers — Cambridge International AS & A Level Further Mathematics (9231)

## Introduction to Complex Numbers

A complex number has the form z = a + bi, where:
- a is the **real part**: Re(z) = a
- b is the **imaginary part**: Im(z) = b
- i is the imaginary unit: i² = −1

## Arithmetic of Complex Numbers

**Addition/subtraction:** Add real and imaginary parts separately.
(3 + 2i) + (1 − 5i) = 4 − 3i

**Multiplication:** Expand like brackets, use i² = −1.
(2 + 3i)(1 − 4i) = 2 − 8i + 3i − 12i² = 2 − 5i + 12 = 14 − 5i

**Division:** Multiply numerator and denominator by the complex conjugate of the denominator.
(3 + 2i)/(1 − i) = (3 + 2i)(1 + i)/[(1 − i)(1 + i)] = (3 + 3i + 2i − 2)/(1 + 1) = (1 + 5i)/2 = 1/2 + 5i/2

## Modulus, Argument and Complex Conjugate

**Conjugate:** z* = a − bi (flip sign of imaginary part). Note: z × z* = a² + b² = |z|².

**Modulus:** |z| = √(a² + b²) — the distance of z from the origin in the Argand diagram.

**Argument:** arg(z) = θ = arctan(b/a), adjusted for the quadrant of (a, b).
Convention: arg(z) ∈ (−π, π] (principal argument).

Example: Find the modulus and argument of z = −1 + i√3.
|z| = √(1 + 3) = 2.
The point (−1, √3) is in the second quadrant.
arg(z) = π − arctan(√3/1) = π − π/3 = 2π/3.

## Complex Roots of Polynomials

**Key theorem:** If a polynomial has real coefficients and z = a + bi (b ≠ 0) is a root, then its complex conjugate z* = a − bi is also a root.

Roots always come in conjugate pairs for real-coefficient polynomials.

Example: Given that 2 + i is a root of p(x) = x³ − 5x² + 9x − 5, find all roots.
Since coefficients are real, 2 − i is also a root.
Sum of complex roots = (2+i) + (2−i) = 4.
Product of complex roots = (2+i)(2−i) = 5.
So (x² − 4x + 5) is a factor.
Divide: x³ − 5x² + 9x − 5 = (x² − 4x + 5)(x − 1).
Third root: x = 1.

Example: Form the cubic equation with roots 3, 1 + 2i, 1 − 2i.
Factors: (x − 3), (x − (1+2i)), (x − (1−2i)).
Last two multiply to: (x − 1)² + 4 = x² − 2x + 5.
Cubic: (x − 3)(x² − 2x + 5) = x³ − 5x² + 11x − 15.

## Polar (Modulus-Argument) Form

Every complex number can be written in polar form:
z = r(cos θ + i sin θ) = r cis θ

where r = |z| and θ = arg(z).

**Multiplication in polar form:** multiply moduli, add arguments.
z₁z₂ = r₁r₂(cos(θ₁+θ₂) + i sin(θ₁+θ₂))

**Division in polar form:** divide moduli, subtract arguments.
z₁/z₂ = (r₁/r₂)(cos(θ₁−θ₂) + i sin(θ₁−θ₂))

Example: z₁ = 2(cos(π/3) + i sin(π/3)), z₂ = 3(cos(π/6) + i sin(π/6)).
z₁z₂ = 6(cos(π/2) + i sin(π/2)) = 6i.

## De Moivre's Theorem

For any integer (or rational) n:
[r(cos θ + i sin θ)]ⁿ = rⁿ(cos nθ + i sin nθ)

**Powers of complex numbers:**
Example: Find (1 + i)⁸.
|1+i| = √2, arg(1+i) = π/4.
(1+i)⁸ = (√2)⁸(cos(8×π/4) + i sin(8×π/4)) = 16(cos 2π + i sin 2π) = 16.

**nth roots of a complex number:** z^(1/n) has n distinct roots.
The roots of rⁿ = R at argument α are:
zₖ = R^(1/n) (cos((α + 2kπ)/n) + i sin((α + 2kπ)/n)), k = 0, 1, ..., n−1.

Example: Find the cube roots of 8.
8 = 8(cos 0 + i sin 0).
Roots: 2(cos(2kπ/3) + i sin(2kπ/3)) for k = 0, 1, 2.
z₀ = 2, z₁ = 2(cos(2π/3) + i sin(2π/3)) = −1 + i√3, z₂ = −1 − i√3.

## Trigonometric Identities via De Moivre

Example: Derive cos 3θ in terms of cos θ.
(cos θ + i sin θ)³ = cos 3θ + i sin 3θ.
Expanding: cos³θ + 3cos²θ(i sin θ) + 3cosθ(−sin²θ) + (−i sin³θ).
Real part: cos 3θ = cos³θ − 3cosθ sin²θ = cos³θ − 3cosθ(1−cos²θ) = 4cos³θ − 3cosθ.
