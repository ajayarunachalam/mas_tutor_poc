"""
MAS Education POC — BeeAI AgentStack Entry Point
Single BeeAI server wrapping the full LangGraph orchestrator.
Open http://localhost:8000/ui for the demo interface.

NOTE: BeeAI SDK allows ONLY ONE @server.agent() per Server instance.
The full orchestrator (tutor + assess + plan + dialogue + monitor logic)
runs internally via LangGraph. 'summary' keyword triggers session report.
"""
import os
import uuid
from dotenv import load_dotenv
load_dotenv()

from anthropic import AsyncAnthropic
from agentstack_sdk.server import Server
from agentstack_sdk.server.context import RunContext
from a2a.types import Message

from agents.dialogue_agent import DialogueTracker
from orchestrator.poc_orchestrator import create_orchestrator, SessionState
from agents.monitor_agent import print_session_report
from db.init_db import init_database

# Initialise database on startup
init_database()

anthropic_client = AsyncAnthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))
server = Server()

# Session store (in-memory — sufficient for POC single-user demo)
active_sessions: dict[str, dict] = {}


def get_or_create_session(learner_id: str) -> dict:
    if learner_id not in active_sessions:
        session_id = str(uuid.uuid4())[:8]
        tracker = DialogueTracker(learner_id, session_id)
        orchestrator = create_orchestrator(anthropic_client, tracker)
        active_sessions[learner_id] = {
            "session_id": session_id,
            "tracker": tracker,
            "orchestrator": orchestrator,
            "history": [],
            "current_topic": None,
            "turn_count": 0
        }
    return active_sessions[learner_id]


def _extract_text(message: Message) -> str:
    """Extract plain text from A2A Message parts."""
    return "".join(
        part.root.text for part in message.parts
        if hasattr(part.root, "text")
    ).strip()


@server.agent(name="MAS Tutor", description="GCSE Maths Socratic Tutor — multi-agent system")
async def tutor_agent(message: Message, context: RunContext):
    """
    Main entry point — Socratic GCSE Maths Tutor.
    RAG-grounded responses. Multi-agent MAS collaboration behind the scenes.
    Say 'summary' to get a session report.
    """
    learner_id = "demo-student-001"  # Single demo learner for POC
    student_input = _extract_text(message)

    # Special keyword: session summary
    if student_input.lower().strip() == "summary":
        if learner_id in active_sessions:
            session_id = active_sessions[learner_id]["session_id"]
            print_session_report(session_id)
            yield f"Session {session_id} summary printed to terminal."
        else:
            yield "No active session found."
        return

    session = get_or_create_session(learner_id)

    initial_state = SessionState(
        session_id=session["session_id"],
        learner_id=learner_id,
        student_input=student_input,
        conversation_history=session["history"],
        current_topic=session.get("current_topic") or "quadratic-equations",
        current_topic_name="Quadratic Equations",
        intent="unknown",
        agent_response="",
        rag_chunks=[],
        citations=[],
        mastery=0.0,
        engagement_state=session["tracker"].state,
        intervention_prompt="",
        should_assess=False,
        advancement_check={},
        turn_count=session["turn_count"]
    )

    # Run through LangGraph orchestrator (async nodes as of Phase 1 migration, 2026-07-09)
    result = await session["orchestrator"].ainvoke(initial_state)

    # Update session state
    session["history"] = result["conversation_history"]
    session["current_topic"] = result["current_topic"]
    session["turn_count"] = result["turn_count"]

    # Format response with citations
    response = result["agent_response"]
    if result.get("citations"):
        response += f"\n\n*Sources: {', '.join(result['citations'][:2])}*"

    # Print engagement state to console
    print(f"[Dialogue: {result['engagement_state']}] [Topic: {result['current_topic']}] [Mastery: {result.get('mastery', 0):.2f}]")

    yield response


def main():
    print("="*60)
    print("MAS Education POC — Starting BeeAI Server...")
    print(f"Agent: MAS Tutor (tutor + assess + plan + dialogue + monitor)")
    print(f"Web UI: http://localhost:8000/ui")
    print(f"ChromaDB: {os.getenv('CHROMA_PATH')}")
    print(f"SQLite: {os.getenv('SQLITE_DB', 'poc_learner.db')}")
    print("="*60)
    server.run(host="0.0.0.0", port=8000, self_registration=False)


if __name__ == "__main__":
    main()
