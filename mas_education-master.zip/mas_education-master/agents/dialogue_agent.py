"""
Dialogue Agent — MAS Education POC
Manages engagement state machine and dialogic quality monitoring.
States: EXPLORING → STUCK → BREAKTHROUGH → CONSOLIDATING → MASTERED
"""
import os
import re
import json
from datetime import datetime
from db.db import log_audit

# Engagement states (from v2.1 architecture)
EXPLORING = "EXPLORING"
STUCK = "STUCK"
BREAKTHROUGH = "BREAKTHROUGH"
CONSOLIDATING = "CONSOLIDATING"
MASTERED = "MASTERED"

STUCK_THRESHOLD = 3        # Consecutive short responses before STUCK
SHORT_RESPONSE_WORDS = 5   # Responses below this count as "short"

IDK_PATTERNS = [
    r"\bidk\b", r"\bi don'?t know\b", r"\bno idea\b",
    r"\bnot sure\b", r"\bi'?m lost\b", r"\bdon'?t understand\b"
]


class DialogueTracker:
    """
    Tracks engagement state for a single learner session.
    One instance per session — managed by orchestrator.
    """

    def __init__(self, learner_id: str, session_id: str):
        self.learner_id = learner_id
        self.session_id = session_id
        self.state = EXPLORING
        self.consecutive_short_responses = 0
        self.turn_count = 0
        self.open_question_count = 0
        self.total_question_count = 0
        self.student_elaboration_count = 0  # responses > 20 words
        self.breakthroughs = 0

    def update(self, student_input: str, agent_response: str, mastery: float) -> dict:
        """
        Update engagement state based on latest exchange.
        Returns: {state, intervention_needed, intervention_type, quality_metrics}
        """
        self.turn_count += 1

        # Analyse student input
        word_count = len(student_input.split())
        is_short = word_count < SHORT_RESPONSE_WORDS
        is_idk = any(re.search(p, student_input.lower()) for p in IDK_PATTERNS)

        if word_count > 20:
            self.student_elaboration_count += 1

        # Analyse agent response for question types
        if "?" in agent_response:
            self.total_question_count += 1
            # Simple heuristic: open questions start with What/How/Why/Tell me
            if re.search(r'\b(what|how|why|tell me|can you|could you)\b', agent_response.lower()):
                self.open_question_count += 1

        # State machine transitions
        old_state = self.state
        intervention_needed = False
        intervention_type = None

        if mastery >= 0.85:
            self.state = MASTERED
        elif self.state == CONSOLIDATING and mastery >= 0.6:
            pass  # Stay in CONSOLIDATING until mastery threshold
        elif self.state in (EXPLORING, STUCK):
            if is_short or is_idk:
                self.consecutive_short_responses += 1
            else:
                self.consecutive_short_responses = 0

            if self.consecutive_short_responses >= STUCK_THRESHOLD:
                if self.state != STUCK:
                    self.state = STUCK
                intervention_needed = True
                intervention_type = "stuck_intervention"
            elif is_idk and not is_short:
                # IDK but expressed in words — productive struggle
                intervention_type = "productive_struggle"

        elif self.state == STUCK:
            if not is_short and not is_idk:
                # Recovery from STUCK
                self.state = EXPLORING
                self.consecutive_short_responses = 0

        # Check for breakthrough (significant elaboration after stuck)
        if (old_state in (STUCK, EXPLORING) and
                word_count > 30 and not is_idk):
            self.state = BREAKTHROUGH
            self.breakthroughs += 1
            if mastery >= 0.4:
                self.state = CONSOLIDATING

        # Quality metrics
        open_ratio = self.open_question_count / max(self.total_question_count, 1)
        elaboration_rate = self.student_elaboration_count / max(self.turn_count, 1)

        result = {
            "state": self.state,
            "previous_state": old_state,
            "state_changed": self.state != old_state,
            "intervention_needed": intervention_needed,
            "intervention_type": intervention_type,
            "quality_metrics": {
                "open_question_ratio": round(open_ratio, 2),
                "student_elaboration_rate": round(elaboration_rate, 2),
                "breakthroughs": self.breakthroughs,
                "consecutive_short": self.consecutive_short_responses
            }
        }

        if self.state != old_state:
            log_audit(
                self.session_id, self.learner_id, "dialogue-agent",
                f"state_transition_{old_state}_to_{self.state}",
                f"Engagement state: {old_state} → {self.state}",
                result
            )

        return result

    def get_intervention_prompt(self) -> str:
        """Returns a prompt addition for the Tutor Agent when intervention is needed."""
        if self.state == STUCK:
            return (
                "\n[DIALOGUE AGENT: Student is STUCK. Switch from closed to open-ended questions. "
                "Ask 'What do you already know about this topic?' "
                "Do NOT provide the answer or a worked example.]"
            )
        elif self.state == BREAKTHROUGH:
            return (
                "\n[DIALOGUE AGENT: BREAKTHROUGH detected. Acknowledge the student's insight. "
                "Reinforce the reasoning process. Build confidence.]"
            )
        return ""

    def get_summary(self) -> dict:
        return {
            "final_state": self.state,
            "turns": self.turn_count,
            "breakthroughs": self.breakthroughs,
            "quality_metrics": {
                "open_question_ratio": round(self.open_question_count / max(self.total_question_count, 1), 2),
                "student_elaboration_rate": round(self.student_elaboration_count / max(self.turn_count, 1), 2)
            }
        }
