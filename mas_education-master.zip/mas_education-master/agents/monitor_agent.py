"""
Monitor Agent — MAS Education POC
Aggregates audit logs, estimates session cost, generates session summaries.
Runs asynchronously — never blocks the response path.
"""
import os
import json
from datetime import datetime
from db.db import get_conn

# Approximate cost per token (USD) — for cost tracking
COST_PER_TOKEN = {
    "claude-sonnet-4-6": {"input": 0.000003, "output": 0.000015},
    "qwen3:8b": {"input": 0.0, "output": 0.0}  # Local, free
}


def log_session_event(session_id: str, learner_id: str, event_type: str,
                       agent: str, data: dict):
    """Log a session event to session_log table."""
    conn = get_conn()
    conn.execute("""
        INSERT INTO session_log (session_id, learner_id, timestamp, agent, event_type, metadata)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (
        session_id, learner_id,
        datetime.utcnow().isoformat(),
        agent, event_type,
        json.dumps(data)
    ))
    conn.commit()
    conn.close()


def get_session_summary(session_id: str) -> dict:
    """
    Generate end-of-session summary.
    Includes: turn count, mastery progress, cost estimate, engagement metrics.
    """
    conn = get_conn()

    # Count turns
    turns = conn.execute(
        "SELECT COUNT(*) FROM session_log WHERE session_id=?", (session_id,)
    ).fetchone()[0]

    # Get audit events for this session
    events = conn.execute(
        "SELECT agent, decision, technical FROM audit_events WHERE session_id=?",
        (session_id,)
    ).fetchall()

    # Aggregate cost
    total_tokens = 0
    total_cost_usd = 0.0
    mastery_updates = []

    for event in events:
        try:
            tech = json.loads(event["technical"])
            if "tokens_used" in tech:
                model = tech.get("model", "claude-sonnet-4-6")
                tokens = tech["tokens_used"]
                total_tokens += tokens
                cost = COST_PER_TOKEN.get(model, {}).get("output", 0) * tokens
                total_cost_usd += cost
            if "new_mastery" in tech:
                mastery_updates.append({
                    "topic": tech.get("topic_id"),
                    "mastery": tech["new_mastery"]
                })
        except Exception:
            pass

    conn.close()

    return {
        "session_id": session_id,
        "total_turns": turns,
        "api_calls": len([e for e in events if e["agent"] == "tutor-agent"]),
        "estimated_cost_usd": round(total_cost_usd, 4),
        "estimated_cost_gbp": round(total_cost_usd * 0.79, 4),
        "mastery_updates": mastery_updates,
        "timestamp": datetime.utcnow().isoformat()
    }


def print_session_report(session_id: str):
    """Print a formatted session report to console."""
    summary = get_session_summary(session_id)
    print("\n" + "="*50)
    print(f"SESSION REPORT: {session_id}")
    print("="*50)
    print(f"Turns: {summary['total_turns']}")
    print(f"API calls: {summary['api_calls']}")
    print(f"Estimated cost: £{summary['estimated_cost_gbp']:.4f}")
    if summary["mastery_updates"]:
        print("Mastery updates:")
        for mu in summary["mastery_updates"]:
            print(f"  {mu['topic']}: {mu['mastery']:.3f}")
    print("="*50)
