"""
Assessment Agent — MAS Education POC
Tracks mastery via BKT, scores responses, implements self-reflection loop.
Self-reflection triggers when predicted vs actual mastery diverges > 10% over 3 sessions.
"""
import os
import json
from datetime import datetime
from anthropic import Anthropic
from db.kg import bkt_update_kg
from db.db import log_audit, get_conn
from rag.math_verify import verify_response as math_verify_response

LLM_MODEL = os.getenv("LLM_PRIMARY", "claude-sonnet-4-6")
MASTERY_THRESHOLD = 0.85           # Advance to next topic
DIVERGENCE_THRESHOLD = 0.10        # 10 percentile points — triggers self-reflection
REFLECTION_WINDOW = 3              # Sessions to check divergence over

SCORING_SYSTEM_PROMPT = """You are assessing a GCSE Mathematics student's response.

Score the student's response as:
- CORRECT: The reasoning and answer are mathematically correct
- PARTIAL: Some correct reasoning but incomplete or minor errors
- INCORRECT: Fundamentally wrong approach or answer

Also identify:
- MISCONCEPTION: If the student holds a specific wrong mathematical belief, describe it briefly (e.g. "confuses sine and cosine ratios", "adds exponents instead of multiplying when squaring a product"). MISCONCEPTION must describe a mathematical error the student made — NEVER use it to note topic mismatch, describe what the student is discussing, or say the student is "confused about the topic". If no clear mathematical misconception is present, respond with "none".
- CONFIDENCE: HIGH / MEDIUM / LOW (based on how confidently they expressed themselves)

Respond in this exact format:
SCORE: [CORRECT|PARTIAL|INCORRECT]
MISCONCEPTION: [description or "none"]
CONFIDENCE: [HIGH|MEDIUM|LOW]
FEEDBACK: [one sentence of constructive feedback, no more]"""


async def score_response(
    student_response: str,
    topic_id: str,
    expected_concept: str,
    session_id: str,
    learner_id: str,
    anthropic_client: Anthropic = None,
    question_context: str = None
) -> dict:
    """
    Score a student response and update BKT mastery.

    Args:
        question_context: The tutor's question (last assistant message). When provided,
                          enables sympy verification of mathematical claims.

    Returns scoring result and updated mastery estimate.
    """
    if anthropic_client is None:
        anthropic_client = Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))

    # Use LLM to score the response
    scoring_response = await anthropic_client.messages.create(
        model=LLM_MODEL,
        max_tokens=150,
        system=SCORING_SYSTEM_PROMPT,
        messages=[{
            "role": "user",
            "content": f"Topic: {topic_id}\nExpected concept: {expected_concept}\n\nStudent response: {student_response}"
        }]
    )

    scoring_text = scoring_response.content[0].text

    # Parse scoring
    score = "INCORRECT"
    misconception = "none"
    confidence = "LOW"
    feedback = ""

    for line in scoring_text.strip().split("\n"):
        if line.startswith("SCORE:"):
            score = line[6:].strip()
        elif line.startswith("MISCONCEPTION:"):
            misconception = line[14:].strip()
        elif line.startswith("CONFIDENCE:"):
            confidence = line[11:].strip()
        elif line.startswith("FEEDBACK:"):
            feedback = line[9:].strip()

    # Sympy computation verification — check student's mathematical claim symbolically
    math_check = math_verify_response(student_response, question_context)
    computation_verified = math_check.verified  # True / False / None

    # Conjunction logic: adjust LLM score when sympy contradicts it
    # Conservative: only demote to PARTIAL (never full reversal) to preserve LLM judgment
    if computation_verified is not None:
        if score == "CORRECT" and computation_verified is False:
            score = "PARTIAL"  # LLM said correct but sympy says the claimed value is wrong
        elif score == "INCORRECT" and computation_verified is True:
            score = "PARTIAL"  # LLM said wrong but sympy confirms the claimed value satisfies equation

    # BKT update — writes to Neo4j HAS_MASTERY
    is_correct  = score == "CORRECT"
    new_mastery = bkt_update_kg(learner_id, topic_id, is_correct)
    mastered    = new_mastery >= MASTERY_THRESHOLD

    # Log to session
    conn = get_conn()
    conn.execute("""
        INSERT INTO session_log (session_id, learner_id, timestamp, agent, event_type, input_text, output_text, metadata)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        session_id, learner_id, datetime.utcnow().isoformat(),
        "assessment-agent", "mastery_update",
        student_response, feedback,
        json.dumps({"score": score, "new_mastery": new_mastery, "topic_id": topic_id,
                    "misconception": misconception, "mastered": mastered})
    ))
    conn.commit()
    conn.close()

    # Check for self-reflection trigger
    should_reflect = _check_reflection_trigger(learner_id, topic_id)

    # Audit log
    log_audit(
        session_id=session_id,
        learner_id=learner_id,
        agent="assessment-agent",
        decision="mastery_update",
        reasoning=f"Response scored {score}. Mastery: {new_mastery:.2f}. Mastered: {mastered}",
        technical={
            "score": score, "new_mastery": new_mastery, "topic_id": topic_id,
            "misconception": misconception, "should_reflect": should_reflect,
            "computation_verified": computation_verified,
            "computation_method": math_check.method
        }
    )

    return {
        "score": score,
        "misconception": misconception,
        "confidence": confidence,
        "feedback": feedback,
        "new_mastery": new_mastery,
        "mastered": mastered,
        "should_reflect": should_reflect
    }


def _check_reflection_trigger(learner_id: str, topic_id: str) -> bool:
    """
    Self-reflection loop check.
    Triggers if: recent mastery trajectory diverges > 10% from prediction over 3 sessions.
    Simplified for POC: checks if mastery has stalled (< 5% improvement in last 3 assessments).
    Production: compare predicted trajectory vs actual via stored predictions.
    """
    conn = get_conn()
    recent = conn.execute("""
        SELECT metadata FROM session_log
        WHERE learner_id=? AND agent='assessment-agent'
        AND json_extract(metadata, '$.topic_id') = ?
        ORDER BY timestamp DESC LIMIT ?
    """, (learner_id, topic_id, REFLECTION_WINDOW)).fetchall()
    conn.close()

    if len(recent) < REFLECTION_WINDOW:
        return False

    # Extract mastery values from recent sessions
    mastery_values = []
    for row in recent:
        try:
            meta = json.loads(row["metadata"])
            mastery_values.append(meta.get("new_mastery", 0))
        except Exception:
            pass

    if len(mastery_values) < REFLECTION_WINDOW:
        return False

    # Check for stall: if mastery hasn't improved by > DIVERGENCE_THRESHOLD
    oldest = mastery_values[-1]
    newest = mastery_values[0]
    improvement = newest - oldest

    return improvement < DIVERGENCE_THRESHOLD  # Stalled — trigger reflection


def get_policy_adjustment(learner_id: str, topic_id: str) -> dict:
    """
    When self-reflection triggers: suggest policy adjustments.
    Returns recommended changes to hint threshold, difficulty, approach.
    """
    return {
        "recommendation": "mastery_stall_detected",
        "suggested_actions": [
            "Reduce difficulty: serve easier sub-topic first",
            "Increase scaffolding: offer more structured hints",
            "Check for misconception: re-assess foundational concept"
        ],
        "hint_threshold_adjustment": -1,  # Offer hints sooner
        "notify_teacher": True
    }
