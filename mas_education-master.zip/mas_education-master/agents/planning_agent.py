"""
Planning Agent — MAS Education POC (Phase 4: Neo4j)
Manages learning pathway via the Neo4j knowledge graph.
Advances learner to next LO when mastery >= 0.85 AND evidence >= 5.
"""
from db.kg import (
    get_next_lo,
    get_learner_mastery,
    check_advancement_kg,
    kg_session,
)
from db.db import log_audit

MASTERY_THRESHOLD  = 0.85
EVIDENCE_THRESHOLD = 5


def get_learner_plan(learner_id: str, session_id: str) -> dict:
    """
    Returns current position, mastered/in-progress LO counts, and next LO.
    Called at session start and after each mastery update.
    """
    # Fetch all HAS_MASTERY edges for this learner
    cypher = """
        MATCH (l:Learner {id: $learner_id})-[m:HAS_MASTERY]->(lo:LearningObjective)
        RETURN lo.id AS lo_id, lo.text AS lo_text,
               m.p_mastery AS p_mastery, m.mastered AS mastered
    """
    mastered_ids    = []
    in_progress_ids = []

    with kg_session() as session:
        result = session.run(cypher, learner_id=learner_id)
        for record in result:
            if record["mastered"]:
                mastered_ids.append(record["lo_id"])
            elif record["p_mastery"] is not None and record["p_mastery"] >= 0.2:
                in_progress_ids.append(record["lo_id"])

    # Get total LO count for completion percentage
    with kg_session() as session:
        total_result = session.run("MATCH (lo:LearningObjective) RETURN count(lo) AS n")
        total_los = total_result.single()["n"]

    current_lo = get_next_lo(learner_id)

    plan = {
        "learner_id":        learner_id,
        "mastered_los":      mastered_ids,
        "in_progress_los":   in_progress_ids,
        "current_lo":        current_lo,
        "total_los":         total_los,
        "completion_pct":    round(len(mastered_ids) / total_los * 100, 1) if total_los else 0.0,
    }

    next_lo_id = current_lo["id"] if current_lo else "all complete"
    log_audit(
        session_id=session_id,
        learner_id=learner_id,
        agent="planning-agent",
        decision="pathway_update",
        reasoning=(
            f"Learner has mastered {len(mastered_ids)}/{total_los} LOs. "
            f"Next: {next_lo_id}"
        ),
        technical=plan,
    )

    return plan


def get_agnostic_position(learner_id: str) -> dict:
    """
    Returns the learner's position in the product-agnostic concept hierarchy.

    Traverses Learner→HAS_MASTERY→LO→TEACHES→ConceptInstance→INSTANCE_OF→Concept
    then up through Area→Branch→Domain.

    Returns:
        Nested dict {domains: [{name, branches: [{name, areas: [{name, avg_mastery,
        concepts: [{id, name, avg_mastery, lo_count}]}]}]}]}
        Returns empty domains list if learner has no ConceptInstance mastery data.
    """
    cypher = """
        MATCH (l:Learner {id: $learner_id})-[m:HAS_MASTERY]->(lo:LearningObjective)
              -[:TEACHES]->(ci:ConceptInstance)-[:INSTANCE_OF]->(c:Concept)
              <-[:HAS_CONCEPT]-(a:Area)<-[:HAS_AREA]-(b:Branch)<-[:HAS_BRANCH]-(d:Domain)
        RETURN d.name AS domain, b.name AS branch, a.name AS area,
               c.id AS concept_id, c.name AS concept_name,
               avg(m.p_mastery) AS avg_mastery, count(lo) AS lo_count
        ORDER BY domain, branch, area, concept_name
    """
    rows: list[dict] = []
    with kg_session() as session:
        result = session.run(cypher, learner_id=learner_id)
        rows = [dict(r) for r in result]

    if not rows:
        return {"domains": []}

    # Build nested structure
    domain_map: dict = {}
    for r in rows:
        d = r["domain"]
        b = r["branch"]
        a = r["area"]
        if d not in domain_map:
            domain_map[d] = {}
        if b not in domain_map[d]:
            domain_map[d][b] = {}
        if a not in domain_map[d][b]:
            domain_map[d][b][a] = []
        domain_map[d][b][a].append({
            "id":          r["concept_id"],
            "name":        r["concept_name"],
            "avg_mastery": round(r["avg_mastery"], 4) if r["avg_mastery"] is not None else None,
            "lo_count":    r["lo_count"],
        })

    domains = []
    for d_name, branches in domain_map.items():
        branch_list = []
        for b_name, areas in branches.items():
            area_list = []
            for a_name, concepts in areas.items():
                area_mastery = (
                    sum(c["avg_mastery"] for c in concepts if c["avg_mastery"] is not None)
                    / max(1, sum(1 for c in concepts if c["avg_mastery"] is not None))
                ) if any(c["avg_mastery"] is not None for c in concepts) else None
                area_list.append({
                    "name":        a_name,
                    "avg_mastery": round(area_mastery, 4) if area_mastery is not None else None,
                    "concepts":    concepts,
                })
            branch_list.append({"name": b_name, "areas": area_list})
        domains.append({"name": d_name, "branches": branch_list})

    return {"domains": domains}


def check_advancement(learner_id: str, lo_id: str, session_id: str) -> dict:
    """
    Called by orchestrator after Assessment Agent update.
    Returns whether to advance to next LO.
    """
    result = check_advancement_kg(
        learner_id=learner_id,
        lo_id=lo_id,
        mastery_threshold=MASTERY_THRESHOLD,
        evidence_threshold=EVIDENCE_THRESHOLD,
    )

    if result.get("advance"):
        next_lo = result.get("next_topic")
        log_audit(
            session_id=session_id,
            learner_id=learner_id,
            agent="planning-agent",
            decision="advance_lo",
            reasoning=(
                f"Mastery {result['mastery_achieved']:.2f} >= {MASTERY_THRESHOLD} "
                f"with sufficient evidence"
            ),
            technical={
                "from_lo": lo_id,
                "to_lo":   next_lo["id"] if next_lo else None,
            },
        )

    return result
