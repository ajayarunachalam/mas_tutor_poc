#!/usr/bin/env bash
# stop.sh — Stop the MAS Education chat UI (port 8080)

PORT=8080
PID=$(lsof -ti tcp:$PORT 2>/dev/null)

if [ -z "$PID" ]; then
    echo "MAS chat UI is not running on port $PORT."
else
    echo "Stopping MAS chat UI (PID $PID) on port $PORT..."
    kill "$PID"
    sleep 1
    if kill -0 "$PID" 2>/dev/null; then
        kill -9 "$PID"
        echo "Force-killed PID $PID."
    else
        echo "Stopped."
    fi
fi
