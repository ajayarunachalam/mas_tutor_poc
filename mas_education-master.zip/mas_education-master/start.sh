#!/usr/bin/env bash
# start.sh — Start the MAS Education chat UI in the background

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG="$SCRIPT_DIR/chat_ui.log"
PORT=8080

# Check if already running
EXISTING=$(lsof -ti tcp:$PORT 2>/dev/null)
if [ -n "$EXISTING" ]; then
    echo "MAS chat UI already running on port $PORT (PID $EXISTING)."
    echo "Run ./stop.sh first if you want to restart."
    exit 1
fi

echo "Starting MAS chat UI..."
cd "$SCRIPT_DIR" || exit 1
nohup uv run python chat_ui.py > "$LOG" 2>&1 &
PID=$!

sleep 1
if kill -0 "$PID" 2>/dev/null; then
    echo "Started (PID $PID). Listening on http://localhost:$PORT"
    echo "Log: $LOG"
else
    echo "Failed to start — check $LOG for errors."
    tail -10 "$LOG"
    exit 1
fi
