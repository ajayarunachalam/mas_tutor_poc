"""
Integration tests for the MAS Tutor API — ISC-37 to ISC-40, ISC-15, ISC-19.

TDD RED phase: most tests fail immediately (routes missing, validation absent).
TDD GREEN phase: implement Issues 1-4 → all tests pass.

Uses the `test_client` fixture from conftest.py which:
- Injects a mock LLM (no real OpenRouter calls)
- Uses FastAPI TestClient (synchronous, in-process)
- Clears active_sessions before each test (autouse fixture)

Each test maps to one or more ISCs — see comments.
"""
import pytest
import json


# ── Health endpoint ────────────────────────────────────────────────────────

@pytest.mark.integration
def test_health(test_client):
    """
    ISC-15: GET /health returns {"status": "ok", "service": "mas-tutor"}.

    RED: fails until GET /health route is added to chat_ui.py.
    """
    resp = test_client.get("/health")
    assert resp.status_code == 200
    body = resp.json()
    assert body.get("status") == "ok"
    assert "service" in body


# ── /chat — valid request ──────────────────────────────────────────────────

@pytest.mark.integration
def test_chat_valid_returns_200(test_client):
    """
    ISC-37: POST /chat with valid payload and mocked LLM returns HTTP 200
    JSON with "response" key.
    """
    payload = {"learner_id": "test-student", "message": "What is a quadratic equation?"}
    resp = test_client.post("/chat", json=payload)
    assert resp.status_code == 200, f"Expected 200, got {resp.status_code}: {resp.text}"
    body = resp.json()
    assert "response" in body, f"'response' key missing from: {body}"
    assert isinstance(body["response"], str)
    assert len(body["response"]) > 0


# ── /chat — FAQ intercept ──────────────────────────────────────────────────

@pytest.mark.integration
def test_chat_faq_returns_without_llm(test_client):
    """
    ISC-38: POST /chat with FAQ trigger phrase returns FAQ string in
    "response". The mock LLM must NOT be called.

    Verified by checking the response contains known FAQ text.
    """
    from unittest.mock import patch, MagicMock

    llm_call_tracker = MagicMock()

    payload = {"learner_id": "test-student", "message": "what topics do you cover"}
    with patch("chat_ui.anthropic_client.messages.create", llm_call_tracker):
        resp = test_client.post("/chat", json=payload)

    assert resp.status_code == 200
    body = resp.json()
    # FAQ response should contain topic list content
    assert "Number" in body.get("response", ""), (
        f"Expected FAQ topic list in response, got: {body.get('response', '')[:200]}"
    )
    # LLM should NOT have been called for FAQ
    llm_call_tracker.assert_not_called()


# ── /chat — oversized message ──────────────────────────────────────────────

@pytest.mark.integration
def test_chat_oversized_message_returns_400(test_client):
    """
    ISC-40: POST /chat with message longer than 2000 chars returns HTTP 400.

    RED: fails until max_length=2000 validation is added to ChatRequest.message.
    """
    payload = {"learner_id": "test-student", "message": "x" * 2001}
    resp = test_client.post("/chat", json=payload)
    assert resp.status_code in (400, 422), (
        f"Expected 400 or 422 for oversized message, got {resp.status_code}"
    )


# ── /chat — malformed body ─────────────────────────────────────────────────

@pytest.mark.integration
def test_chat_missing_message_field_returns_422(test_client):
    """
    ISC-19: POST /chat with missing 'message' field returns HTTP 422
    with Pydantic validation error detail.
    """
    resp = test_client.post("/chat", json={"learner_id": "student-1"})
    assert resp.status_code == 422
    body = resp.json()
    assert "detail" in body


# ── /chat — invalid learner_id ─────────────────────────────────────────────

@pytest.mark.integration
def test_chat_invalid_learner_id_returns_422(test_client):
    """
    ISC-8: POST /chat with path-traversal learner_id returns 422.

    RED: fails until Field(pattern=...) is added to ChatRequest.learner_id.
    """
    payload = {"learner_id": "../../etc/passwd", "message": "hello"}
    resp = test_client.post("/chat", json=payload)
    assert resp.status_code == 422, (
        f"Expected 422 for invalid learner_id, got {resp.status_code}: {resp.text}"
    )


# ── /admin/metrics ─────────────────────────────────────────────────────────

@pytest.mark.integration
def test_metrics_endpoint(test_client):
    """
    ISC-24: GET /admin/metrics returns JSON with total_sessions, total_turns,
    avg_latency_ms keys.

    RED: fails until /admin/metrics route is added.
    """
    resp = test_client.get("/admin/metrics")
    assert resp.status_code == 200, f"Expected 200, got {resp.status_code}: {resp.text}"
    body = resp.json()
    for key in ("total_sessions", "total_turns", "avg_latency_ms"):
        assert key in body, f"Expected '{key}' in metrics response: {body}"
