"""
Shared fixtures for the MAS Tutor test suite.

TDD CYCLE GUIDANCE
==================
These fixtures mock the LLM client so tests never call real OpenRouter.
The mock returns a canned response — enough to verify routing logic,
session state, and HTTP contracts without touching the network.

Red phase: run `uv run pytest` now → most tests fail (logic not implemented)
Green phase: implement each Issue (1-4) → its ISC group goes green
Refactor: clean up after each green phase; tests stay green

Fixture overview
----------------
mock_llm_response  — a minimal _MessagesResponse-like object
mock_llm_client    — drop-in for the OpenRouterClient / Anthropic client
test_app           — FastAPI app with mock LLM injected before routes fire
test_client        — httpx TestClient wrapping test_app
"""
import pytest
from unittest.mock import MagicMock, patch
from fastapi.testclient import TestClient


# ── Minimal LLM response stubs ─────────────────────────────────────────────

class _FakeTextBlock:
    def __init__(self, text: str):
        self.text = text


class _FakeUsage:
    def __init__(self):
        self.input_tokens = 10
        self.output_tokens = 20


class _FakeMessagesResponse:
    def __init__(self, text: str = "This is a Socratic question for you to consider."):
        self.content = [_FakeTextBlock(text)]
        self.usage = _FakeUsage()


class _FakeMessages:
    """Mimics client.messages interface (async OpenRouterClient / AsyncOpenAI shape).

    create() is an async coroutine because the production client contract is now async
    (Phase 1 async migration): every caller does `await client.messages.create(...)`.
    A synchronous create() would return a non-awaitable and break `await` at runtime.
    """
    async def create(self, model, max_tokens, messages, system=""):
        return _FakeMessagesResponse()


class MockLLMClient:
    """Drop-in for both Anthropic and OpenRouterClient."""
    def __init__(self):
        self.messages = _FakeMessages()


@pytest.fixture
def mock_llm_response():
    return _FakeMessagesResponse()


@pytest.fixture
def mock_llm_client():
    return MockLLMClient()


# ── App fixture with mocked LLM ────────────────────────────────────────────

@pytest.fixture
def test_app(mock_llm_client):
    """
    Returns the FastAPI app with the global anthropic_client replaced by
    mock_llm_client. Import is deferred so the patch is applied BEFORE
    any route handler captures a reference to the real client.
    """
    with patch("chat_ui.anthropic_client", mock_llm_client):
        import chat_ui
        chat_ui.anthropic_client = mock_llm_client
        # Also patch inside orchestrator if it holds its own reference
        yield chat_ui.app


@pytest.fixture
def test_client(test_app):
    """httpx TestClient — no real HTTP, no network calls."""
    with TestClient(test_app, raise_server_exceptions=False) as client:
        yield client


# ── Session state helpers ──────────────────────────────────────────────────

@pytest.fixture(autouse=True)
def clear_sessions():
    """Wipe active_sessions before each test to prevent state bleed."""
    import chat_ui
    chat_ui.active_sessions.clear()
    yield
    chat_ui.active_sessions.clear()
