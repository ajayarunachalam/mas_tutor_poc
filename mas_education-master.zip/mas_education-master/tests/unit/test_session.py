"""
Unit tests for session management — ISC-33, ISC-34, ISC-9 to ISC-13.

TDD RED phase: these tests fail until session cap, cleanup, and history trim are added.
TDD GREEN phase: implement Issue 2 → all tests pass.

Tests cover:
- get_or_create_session() creates new session and returns same object on repeat call
- Cleanup removes stale sessions (last_active > SESSION_TTL_MINUTES)
- Cleanup keeps recent sessions untouched
- Session cap raises 503 when MAX_SESSIONS exceeded
- Conversation history is trimmed before orchestrator call
"""
import pytest
from datetime import datetime, timedelta
from unittest.mock import patch


@pytest.mark.unit
def test_get_or_create_same_object():
    """Calling get_or_create_session twice with same ID returns identical dict."""
    import chat_ui
    s1 = chat_ui.get_or_create_session("test-user-001")
    s2 = chat_ui.get_or_create_session("test-user-001")
    assert s1 is s2, "Expected same session dict object on repeated call"


@pytest.mark.unit
def test_new_session_has_required_keys():
    """A freshly created session has all expected keys."""
    import chat_ui
    session = chat_ui.get_or_create_session("new-user-xyz")
    required_keys = {"session_id", "orchestrator", "history", "tracker", "turn_count"}
    missing = required_keys - set(session.keys())
    assert not missing, f"Session missing keys: {missing}"


@pytest.mark.unit
def test_cleanup_removes_stale_sessions():
    """
    Sessions with last_active older than SESSION_TTL_MINUTES are removed.

    RED: fails until cleanup_stale_sessions() and last_active tracking are implemented.
    GREEN: implement cleanup logic in chat_ui.py.
    """
    import chat_ui

    # Create a session and backdate its last_active
    chat_ui.get_or_create_session("stale-user")
    stale_time = datetime.utcnow() - timedelta(minutes=31)
    chat_ui.active_sessions["stale-user"]["last_active"] = stale_time

    # Also create a fresh session
    chat_ui.get_or_create_session("fresh-user")

    # Run synchronous version of cleanup (or call the function directly)
    # Adjust the import path once cleanup function is named
    chat_ui.cleanup_stale_sessions_sync()  # implement this helper

    assert "stale-user" not in chat_ui.active_sessions, "Stale session should be removed"
    assert "fresh-user" in chat_ui.active_sessions, "Fresh session should be kept"


@pytest.mark.unit
def test_cleanup_keeps_recent_sessions():
    """Sessions active within the TTL window are not removed."""
    import chat_ui

    chat_ui.get_or_create_session("recent-user")
    # last_active defaults to now — should survive cleanup
    chat_ui.cleanup_stale_sessions_sync()

    assert "recent-user" in chat_ui.active_sessions


@pytest.mark.unit
def test_session_cap_raises_503():
    """
    Creating more than MAX_SESSIONS sessions raises HTTPException 503.

    RED: fails until cap check is added to get_or_create_session().
    GREEN: add `if len(active_sessions) >= MAX_SESSIONS: raise HTTPException(503)`.
    """
    import chat_ui
    from fastapi import HTTPException

    cap = getattr(chat_ui, "MAX_SESSIONS", 200)

    # Fill to cap
    for i in range(cap):
        chat_ui.active_sessions[f"cap-user-{i}"] = {
            "session_id": f"s{i}",
            "orchestrator": None,
            "history": [],
            "tracker": None,
            "turn_count": 0,
            "last_active": datetime.utcnow(),
            "current_topic": None,
            "current_topic_name": "Mathematics",
        }

    with pytest.raises(HTTPException) as exc_info:
        chat_ui.get_or_create_session("overflow-user")

    assert exc_info.value.status_code == 503


@pytest.mark.unit
def test_history_trimmed_to_limit():
    """
    Conversation history is capped at HISTORY_TRIM entries (default 40).

    RED: fails until trim logic is added before orchestrator call.
    GREEN: add `session["history"] = session["history"][-HISTORY_TRIM:]`.
    """
    import chat_ui

    session = chat_ui.get_or_create_session("trim-user")
    trim_limit = getattr(chat_ui, "HISTORY_TRIM", 40)

    # Inject 60 fake messages
    session["history"] = [{"role": "user", "content": f"msg {i}"} for i in range(60)]

    chat_ui.trim_session_history(session)  # implement this helper

    assert len(session["history"]) <= trim_limit, (
        f"History should be trimmed to ≤{trim_limit}, got {len(session['history'])}"
    )
