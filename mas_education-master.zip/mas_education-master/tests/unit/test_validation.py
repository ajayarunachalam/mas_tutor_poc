"""
Unit tests for input validation — ISC-35, ISC-36, ISC-7, ISC-8.

TDD RED phase: these tests fail until validators are added to ChatRequest.
TDD GREEN phase: implement Issue 1 validation → all tests pass.

Tests cover:
- learner_id regex rejects path traversal and injection patterns
- learner_id regex accepts valid alphanumeric+hyphen+underscore IDs
- message length guard raises on 2001-char string, passes on 2000-char string
"""
import pytest
from pydantic import ValidationError


@pytest.mark.unit
@pytest.mark.parametrize("learner_id,should_pass", [
    # Valid IDs
    ("student-123", True),
    ("abc", True),
    ("ABC-XYZ_001", True),
    ("a" * 64, True),          # exactly at limit
    # Invalid IDs
    ("../../etc/passwd", False),
    ("'; DROP TABLE sessions; --", False),
    ("user with spaces", False),
    ("a" * 65, False),          # one over limit
    ("", False),               # empty
    ("user@domain.com", False), # @ not allowed
])
def test_learner_id_validation(learner_id: str, should_pass: bool):
    """
    ChatRequest.learner_id must match ^[a-zA-Z0-9_-]{1,64}$.

    RED: fails until Pydantic Field(pattern=...) is added to ChatRequest.
    """
    from chat_ui import ChatRequest

    if should_pass:
        req = ChatRequest(learner_id=learner_id, message="hello")
        assert req.learner_id == learner_id
    else:
        with pytest.raises(ValidationError):
            ChatRequest(learner_id=learner_id, message="hello")


@pytest.mark.unit
def test_message_length_accepts_2000_chars():
    """Message exactly at the 2000-char limit is accepted."""
    from chat_ui import ChatRequest
    req = ChatRequest(learner_id="student-1", message="x" * 2000)
    assert len(req.message) == 2000


@pytest.mark.unit
def test_message_length_rejects_2001_chars():
    """
    Message one character over the limit raises ValidationError.

    RED: fails until max_length=2000 is added to ChatRequest.message field.
    """
    from chat_ui import ChatRequest
    with pytest.raises(ValidationError):
        ChatRequest(learner_id="student-1", message="x" * 2001)


@pytest.mark.unit
def test_message_empty_string_rejected():
    """Empty message should be rejected (min_length=1)."""
    from chat_ui import ChatRequest
    with pytest.raises(ValidationError):
        ChatRequest(learner_id="student-1", message="")
