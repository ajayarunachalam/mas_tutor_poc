"""
Unit tests for FAQ intercept logic — ISC-32.

TDD RED phase: these tests fail until _check_faq() exists and handles all patterns.
TDD GREEN phase: implement _check_faq() in chat_ui.py → all 8 cases pass.

These tests verify:
- All 4 FAQ trigger categories return the correct canned response string
- None of the FAQ responses are empty
- The LLM is never called for FAQ inputs (no network, no mock needed)
- Non-FAQ input returns None (falls through to LLM path)
"""
import pytest
from chat_ui import _check_faq, _FAQ_TOPICS, _FAQ_HOW_IT_WORKS, _FAQ_HOW_TO_USE, _FAQ_HELP


@pytest.mark.unit
@pytest.mark.parametrize("message,expected_contains", [
    # Topics FAQ
    ("what topics do you cover?", "Number"),
    ("list topics", "Algebra"),
    ("what can you teach me?", "Geometry"),
    # How it works FAQ
    ("how does this work", "Socratic"),
    ("how do you work", "Agent"),
    # How to use FAQ
    ("how do i use the tutor", "Start naturally"),
    # Help
    ("help", "MAS Tutor"),
    # Non-FAQ — must return None
    ("what is a quadratic equation", None),
])
def test_faq_patterns(message: str, expected_contains: str | None):
    result = _check_faq(message)
    if expected_contains is None:
        assert result is None, f"Expected None for non-FAQ message '{message}', got: {result!r}"
    else:
        assert result is not None, f"Expected FAQ response for '{message}', got None"
        assert expected_contains in result, (
            f"Expected '{expected_contains}' in FAQ response for '{message}'. "
            f"Got: {result[:100]!r}"
        )


@pytest.mark.unit
def test_faq_returns_nonempty_strings():
    """All FAQ trigger phrases return non-empty string responses."""
    triggers = [
        "what topics",
        "how does this work",
        "how do i use the tutor",
        "help",
    ]
    for trigger in triggers:
        result = _check_faq(trigger)
        assert result, f"_check_faq('{trigger}') returned empty or None"
        assert len(result) > 50, f"FAQ response for '{trigger}' seems too short: {result!r}"


@pytest.mark.unit
def test_faq_case_insensitive():
    """FAQ patterns should match regardless of case."""
    assert _check_faq("WHAT TOPICS") is not None
    assert _check_faq("How Does This Work") is not None
