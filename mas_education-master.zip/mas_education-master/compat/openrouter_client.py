"""
Thin Anthropic-compatible wrapper over OpenRouter.

Drop-in replacement for anthropic.Anthropic() — accepts the same
messages.create(model, max_tokens, system, messages) call signature
and returns an object with .content[0].text, so no agent code changes.

Uses the openai library (already in venv) pointed at OpenRouter's
OpenAI-compatible endpoint.
"""
import os
from openai import AsyncOpenAI


class _TextBlock:
    def __init__(self, text: str):
        self.text = text


class _Usage:
    def __init__(self, input_tokens: int, output_tokens: int):
        self.input_tokens = input_tokens
        self.output_tokens = output_tokens


class _MessagesResponse:
    def __init__(self, text: str, usage: _Usage | None = None):
        self.content = [_TextBlock(text)]
        self.usage = usage or _Usage(0, 0)


class _Messages:
    def __init__(self, client: AsyncOpenAI):
        self._client = client

    async def create(self, model: str, max_tokens: int, messages: list, system: str = "") -> _MessagesResponse:
        # OpenRouter requires the Anthropic provider prefix on model names
        or_model = f"anthropic/{model}" if not model.startswith("anthropic/") else model

        oai_messages = ([{"role": "system", "content": system}] if system else []) + list(messages)

        resp = await self._client.chat.completions.create(
            model=or_model,
            max_tokens=max_tokens,
            messages=oai_messages,
        )

        text = resp.choices[0].message.content or ""
        usage = _Usage(
            input_tokens=getattr(resp.usage, "prompt_tokens", 0),
            output_tokens=getattr(resp.usage, "completion_tokens", 0),
        )
        return _MessagesResponse(text, usage)


class OpenRouterClient:
    """Drop-in replacement for anthropic.Anthropic() — routes via OpenRouter."""

    def __init__(self, api_key: str | None = None):
        self.messages = _Messages(
            AsyncOpenAI(
                api_key=api_key or os.getenv("OPENROUTER_API_KEY"),
                base_url="https://openrouter.ai/api/v1",
            )
        )
