"""
Smoke tests for the syllabus pipeline stages.
Tests validate schema loading and basic module imports only.
Integration tests (PDF→LLM→graph) require ANTHROPIC_API_KEY and Neo4j.
"""
from __future__ import annotations

import yaml
from pathlib import Path

SCHEMA_PATH = Path(__file__).parent.parent / "schemas" / "product_specific.schema.yaml"


def test_schema_loads():
    """Schema YAML is valid and parseable."""
    schema = yaml.safe_load(SCHEMA_PATH.read_text())
    assert schema["type"] == "object"
    assert "qualification" in schema["properties"]


def test_pipeline_modules_importable():
    """All pipeline stage modules can be imported."""
    from pipeline import pdf_normalise
    from pipeline import yaml_validate
    assert hasattr(pdf_normalise, "normalise")
    assert hasattr(yaml_validate, "validate")


def test_validate_minimal_valid():
    """validate() accepts a minimal well-formed qualification dict."""
    from pipeline.yaml_validate import validate
    data = {
        "qualification": {
            "code": "0580",
            "name": "IGCSE Mathematics",
            "level": "IGCSE",
            "awarding_body": "Cambridge International",
            "syllabus_year": 2025,
            "topics": [
                {
                    "id": "0580-t1",
                    "name": "Number",
                    "order": 1,
                    "subtopics": [
                        {
                            "id": "0580-t1-s1",
                            "name": "Integers",
                            "learning_objectives": [
                                {
                                    "id": "0580-t1-s1-lo1",
                                    "text": "Understand integers.",
                                    "bloom_level": "understand",
                                    "difficulty": 2,
                                }
                            ],
                        }
                    ],
                }
            ],
        }
    }
    result = validate(data)
    assert result.valid, result.errors


def test_validate_rejects_bad_bloom():
    """validate() rejects an unknown bloom_level."""
    from pipeline.yaml_validate import validate
    data = {
        "qualification": {
            "code": "0580",
            "name": "Test",
            "level": "IGCSE",
            "syllabus_year": 2025,
            "topics": [
                {
                    "id": "t1",
                    "name": "Topic",
                    "subtopics": [
                        {
                            "id": "t1-s1",
                            "name": "Sub",
                            "learning_objectives": [
                                {
                                    "id": "t1-s1-lo1",
                                    "text": "Do something.",
                                    "bloom_level": "INVALID_LEVEL",
                                    "difficulty": 2,
                                }
                            ],
                        }
                    ],
                }
            ],
        }
    }
    result = validate(data)
    assert not result.valid
