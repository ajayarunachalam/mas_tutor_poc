"""
Syllabus Pipeline — Configuration.

Reads from environment / .env file.
"""
from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

# LLM
LLM_EXTRACT_MODEL   = os.getenv("LLM_EXTRACT_MODEL",  "claude-haiku-4-5-20251001")
LLM_AGNOSTIC_MODEL  = os.getenv("LLM_AGNOSTIC_MODEL", "claude-sonnet-4-6")
ANTHROPIC_API_KEY   = os.getenv("ANTHROPIC_API_KEY",  "")

# Neo4j (via cambridge_kg)
NEO4J_URI      = os.getenv("NEO4J_URI",      "bolt://localhost:7687")
NEO4J_USER     = os.getenv("NEO4J_USER",     "neo4j")
NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD", "")

# Paths
OUTPUT_DIR            = Path(os.getenv("OUTPUT_DIR", str(Path(__file__).parent / "output")))
PRODUCT_SPECIFIC_DIR  = OUTPUT_DIR / "product_specific"
PRODUCT_AGNOSTIC_DIR  = OUTPUT_DIR / "product_agnostic"
FLAGGED_DIR           = OUTPUT_DIR / "flagged"
