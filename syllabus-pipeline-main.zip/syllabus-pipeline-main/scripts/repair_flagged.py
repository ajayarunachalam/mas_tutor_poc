#!/usr/bin/env python3
"""
Repair flagged YAMLs with common LLM extraction errors, re-validate, and ingest.

Fixes applied:
  - 'AS and A-Level' / 'AS & A Level' / 'A and AS Level' → 'A-Level'
  - topic order 0 → renumber starting at 1
  - subtopics with empty learning_objectives → removed
  - LOs missing required fields (text, bloom_level, difficulty) → removed
  - bloom_level variants (e.g. 'explain') → mapped to nearest valid value

Usage:
    uv run python scripts/repair_flagged.py
    uv run python scripts/repair_flagged.py --dry-run
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

import yaml

sys.path.insert(0, str(Path(__file__).parent.parent))

from pipeline.yaml_validate import validate
from pipeline.ingest_product import ingest

OUTPUT_DIR = Path(__file__).parent.parent / "output"
FLAGGED_DIR = OUTPUT_DIR / "flagged"
PRODUCT_SPECIFIC_DIR = OUTPUT_DIR / "product_specific"

LEVEL_MAP = {
    "as and a-level": "A-Level",
    "as & a-level": "A-Level",
    "as & a level": "A-Level",
    "a and as level": "A-Level",
    "a level": "A-Level",
    "a-level": "A-Level",
    "as level": "AS",
    "as-level": "AS",
    "igcse": "IGCSE",
    "further": "Further",
}

BLOOM_MAP = {
    "remember": "remember",
    "recall": "remember",
    "identify": "remember",
    "name": "remember",
    "list": "remember",
    "state": "remember",
    "understand": "understand",
    "explain": "understand",
    "describe": "understand",
    "summarise": "understand",
    "summarize": "understand",
    "interpret": "understand",
    "classify": "understand",
    "apply": "apply",
    "use": "apply",
    "calculate": "apply",
    "solve": "apply",
    "demonstrate": "apply",
    "analyse": "analyse",
    "analyze": "analyse",
    "compare": "analyse",
    "distinguish": "analyse",
    "differentiate": "analyse",
    "evaluate": "evaluate",
    "assess": "evaluate",
    "judge": "evaluate",
    "justify": "evaluate",
    "create": "create",
    "design": "create",
    "construct": "create",
    "plan": "create",
}

VALID_BLOOM = {"remember", "understand", "apply", "analyse", "evaluate", "create"}

LO_TYPE_MAP = {
    "conceptual": "conceptual",
    "concept": "conceptual",
    "declarative": "conceptual",
    "factual": "conceptual",
    "procedural": "procedural",
    "procedure": "procedural",
    "skill": "procedural",
    "practical": "procedural",
    "process": "procedural",
    "metacognitive": "metacognitive",
    "meta": "metacognitive",
    "reflective": "metacognitive",
    "evaluative": "metacognitive",
    "analytical": "conceptual",  # closest match
    "analytical thinking": "metacognitive",
    "critical": "metacognitive",
}


def fix_level(level: str) -> str:
    """Normalise level string to a valid enum value."""
    normalized = level.lower().strip()
    return LEVEL_MAP.get(normalized, level)


def fix_bloom(bloom: str) -> str:
    """Map bloom_level to a valid value."""
    if bloom in VALID_BLOOM:
        return bloom
    lower = bloom.lower().strip()
    return BLOOM_MAP.get(lower, "understand")  # Default fallback


def repair(data: dict) -> dict:
    """Apply repairs to extracted YAML data. Returns modified dict."""
    qual = data.get("qualification", {})

    # Fix level
    level = qual.get("level", "")
    fixed_level = fix_level(level)
    if fixed_level != level:
        print(f"  Fix level: '{level}' → '{fixed_level}'")
        qual["level"] = fixed_level

    # Fix topics
    topics = qual.get("topics", [])
    repaired_topics = []
    for i, topic in enumerate(topics):
        # Fix order (1-based)
        if topic.get("order", 1) < 1:
            print(f"  Fix topic order: topic '{topic.get('name', '?')}' order {topic.get('order')} → {i+1}")
            topic["order"] = i + 1

        # Fix subtopics
        subtopics = topic.get("subtopics", [])
        repaired_subtopics = []
        for st in subtopics:
            # Remove subtopics with no name
            if not st.get("name"):
                print(f"  Remove unnamed subtopic in '{topic.get('name', '?')}'")
                continue

            # Fix learning objectives
            los = st.get("learning_objectives", [])
            repaired_los = []
            for lo in los:
                # Remove LOs missing required fields
                if not lo.get("text"):
                    print(f"  Remove LO missing 'text' in '{st.get('name', '?')}'")
                    continue
                if not lo.get("bloom_level"):
                    lo["bloom_level"] = "understand"
                    print(f"  Default bloom_level='understand' for LO in '{st.get('name', '?')}'")
                else:
                    fixed_bloom = fix_bloom(lo["bloom_level"])
                    if fixed_bloom != lo["bloom_level"]:
                        print(f"  Fix bloom_level: '{lo['bloom_level']}' → '{fixed_bloom}'")
                        lo["bloom_level"] = fixed_bloom
                if not lo.get("difficulty"):
                    lo["difficulty"] = 3
                    print(f"  Default difficulty=3 for LO in '{st.get('name', '?')}'")
                # Fix lo_type
                lo_type = lo.get("lo_type", "")
                if lo_type and lo_type not in {"conceptual", "procedural", "metacognitive"}:
                    fixed_type = LO_TYPE_MAP.get(lo_type.lower(), "conceptual")
                    print(f"  Fix lo_type: '{lo_type}' → '{fixed_type}'")
                    lo["lo_type"] = fixed_type
                repaired_los.append(lo)

            # Only keep subtopics that have at least one valid LO
            if not repaired_los:
                print(f"  Remove subtopic '{st.get('name', '?')}' — no valid LOs")
                continue

            st["learning_objectives"] = repaired_los
            repaired_subtopics.append(st)

        if not repaired_subtopics:
            print(f"  WARNING: topic '{topic.get('name', '?')}' has no valid subtopics after repair")
            # Keep it anyway with empty subtopics — might fail validation still
        topic["subtopics"] = repaired_subtopics
        repaired_topics.append(topic)

    qual["topics"] = repaired_topics
    data["qualification"] = qual
    return data


def main() -> int:
    parser = argparse.ArgumentParser(description="Repair flagged YAMLs and re-ingest")
    parser.add_argument("--dry-run", action="store_true", help="Validate only, skip ingest")
    parser.add_argument("--file", help="Process specific file only")
    args = parser.parse_args()

    if args.file:
        flagged = [FLAGGED_DIR / args.file]
    else:
        flagged = sorted(FLAGGED_DIR.glob("*.yaml"))

    if not flagged:
        print("No flagged YAMLs found")
        return 0

    ok = 0
    still_broken = 0

    for path in flagged:
        print(f"\n{'='*60}")
        print(f"Repairing: {path.name}")

        with open(path) as f:
            data = yaml.safe_load(f)

        if not data:
            print("  SKIP: empty file")
            continue

        repaired = repair(data)

        result = validate(repaired)
        if not result.valid:
            print(f"  STILL INVALID after repair:")
            for e in result.errors:
                print(f"    {e}")
            still_broken += 1
            # Save repaired version back to flagged
            path.write_text(yaml.dump(repaired, allow_unicode=True, default_flow_style=False))
            continue

        print(f"  Validation PASSED: {result.topic_count} topics, {result.lo_count} LOs")

        # Save to product_specific
        code = repaired["qualification"]["code"]
        year = repaired["qualification"]["syllabus_year"]
        revision = repaired["qualification"].get("revision", 0)
        out_path = PRODUCT_SPECIFIC_DIR / f"{code}_{year}_r{revision}.yaml"
        out_path.write_text(yaml.dump(repaired, allow_unicode=True, default_flow_style=False))
        print(f"  Saved: {out_path.name}")

        if not args.dry_run:
            stats = ingest(repaired)
            print(f"  Ingested: {stats['topics']} topics, {stats['learning_objectives']} LOs")
            ok += 1
        else:
            print(f"  [DRY RUN] Would ingest")
            ok += 1

    print(f"\n{'='*60}")
    print(f"Repaired+ingested: {ok}")
    print(f"Still broken: {still_broken}")
    return 0 if still_broken == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
