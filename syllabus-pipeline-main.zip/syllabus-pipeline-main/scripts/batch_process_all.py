#!/usr/bin/env python3
"""
Batch process all Cambridge syllabus PDFs through the full pipeline:
  1. extract-product + ingest (product-specific layer)
  2. extract-agnostic (concept mapping)
  3. ingest-agnostic (ConceptInstances into Neo4j)

Skips PDFs whose product-specific YAML already exists.
Never removes existing product-agnostic nodes.

Usage:
    uv run python scripts/batch_process_all.py
    uv run python scripts/batch_process_all.py --skip-agnostic
    uv run python scripts/batch_process_all.py --only-agnostic
"""
from __future__ import annotations

import argparse
import re
import subprocess
import sys
import time
from pathlib import Path

SYLLABUSES_DIR = Path.home() / "projects/mas_education_poc/syllabuses"
OUTPUT_DIR     = Path(__file__).parent.parent / "output"
PRODUCT_SPECIFIC_DIR = OUTPUT_DIR / "product_specific"
PRODUCT_AGNOSTIC_DIR = OUTPUT_DIR / "product_agnostic"
CLI = Path(__file__).parent.parent / "cli.py"


def get_code_from_filename(pdf: Path) -> str | None:
    """Extract qual code from filename like 0610_2026_syllabus.pdf"""
    m = re.match(r"^(\d{4})_\d{4}_", pdf.name)
    if m:
        return m.group(1)
    # Legacy names like igcse_0580_mathematics_2025-2027.pdf
    m = re.search(r"_(\d{4})_", pdf.name)
    if m:
        return m.group(1)
    return None


def get_product_specific_yaml(code: str) -> Path | None:
    """Find existing product-specific YAML for a code."""
    matches = list(PRODUCT_SPECIFIC_DIR.glob(f"{code}_*.yaml"))
    return matches[0] if matches else None


def get_agnostic_mapping_yaml(code: str) -> Path | None:
    """Find existing agnostic mapping YAML for a code."""
    matches = list(PRODUCT_AGNOSTIC_DIR.glob(f"{code}_*mapping*.yaml"))
    return matches[0] if matches else None


def run_cmd(cmd: list[str], timeout: int = 600) -> tuple[int, str]:
    """Run a command and return (exit_code, output)."""
    result = subprocess.run(
        cmd, capture_output=True, text=True, timeout=timeout
    )
    output = result.stdout + result.stderr
    return result.returncode, output


def main() -> int:
    parser = argparse.ArgumentParser(description="Batch process all Cambridge syllabuses")
    parser.add_argument("--skip-agnostic", action="store_true",
                        help="Only do extract-product + ingest, skip agnostic steps")
    parser.add_argument("--only-agnostic", action="store_true",
                        help="Only run extract-agnostic + ingest-agnostic (skip product steps)")
    parser.add_argument("--code", help="Process only this qualification code")
    args = parser.parse_args()

    pdfs = sorted(SYLLABUSES_DIR.glob("*.pdf"))
    if not pdfs:
        print(f"ERROR: No PDFs found in {SYLLABUSES_DIR}")
        return 1

    print(f"=== Batch Processor ===")
    print(f"Found {len(pdfs)} PDFs in {SYLLABUSES_DIR}\n")

    stats = {"product_ok": 0, "product_skip": 0, "product_fail": 0,
             "agnostic_ok": 0, "agnostic_skip": 0, "agnostic_fail": 0}
    failures = []

    for pdf in pdfs:
        code = get_code_from_filename(pdf)
        if not code:
            print(f"SKIP {pdf.name}: cannot extract qual code")
            continue

        if args.code and code != args.code:
            continue

        print(f"\n{'='*60}")
        print(f"Processing {pdf.name} (code={code})")

        # ── Stage 1: extract-product + ingest ────────────────────────
        if not args.only_agnostic:
            existing = get_product_specific_yaml(code)
            if existing:
                print(f"  [SKIP product] Already exists: {existing.name}")
                stats["product_skip"] += 1
                ps_yaml = existing
            else:
                print(f"  [RUNNING] cli.py run --pdf {pdf.name} --code {code}")
                rc, out = run_cmd([
                    sys.executable, str(CLI), "run",
                    "--pdf", str(pdf), "--code", code
                ], timeout=900)
                print(out[-3000:] if len(out) > 3000 else out)
                if rc != 0:
                    print(f"  [FAILED] extract-product/ingest for {code}")
                    stats["product_fail"] += 1
                    failures.append(f"{code} (product)")
                    continue
                stats["product_ok"] += 1
                ps_yaml = get_product_specific_yaml(code)
                if not ps_yaml:
                    print(f"  [WARN] Product YAML not found after run for {code}")
                    continue
        else:
            ps_yaml = get_product_specific_yaml(code)
            if not ps_yaml:
                print(f"  [SKIP agnostic] No product YAML for {code}")
                continue

        if args.skip_agnostic:
            continue

        # ── Stage 2: extract-agnostic ─────────────────────────────────
        existing_mapping = get_agnostic_mapping_yaml(code)
        if existing_mapping:
            print(f"  [SKIP agnostic] Already exists: {existing_mapping.name}")
            stats["agnostic_skip"] += 1
            mapping_yaml = existing_mapping
        else:
            print(f"  [RUNNING] cli.py extract-agnostic {ps_yaml.name}")
            rc, out = run_cmd([
                sys.executable, str(CLI), "extract-agnostic",
                "--yaml", str(ps_yaml)
            ], timeout=600)
            print(out[-2000:] if len(out) > 2000 else out)
            if rc != 0:
                print(f"  [FAILED] extract-agnostic for {code}")
                stats["agnostic_fail"] += 1
                failures.append(f"{code} (agnostic extract)")
                continue
            mapping_yaml = get_agnostic_mapping_yaml(code)
            if not mapping_yaml:
                print(f"  [WARN] Agnostic mapping not found after extract for {code}")
                continue

        # ── Stage 3: ingest-agnostic ──────────────────────────────────
        print(f"  [RUNNING] cli.py ingest-agnostic {mapping_yaml.name}")
        rc, out = run_cmd([
            sys.executable, str(CLI), "ingest-agnostic",
            "--yaml", str(mapping_yaml)
        ], timeout=300)
        print(out[-2000:] if len(out) > 2000 else out)
        if rc != 0:
            print(f"  [FAILED] ingest-agnostic for {code}")
            stats["agnostic_fail"] += 1
            failures.append(f"{code} (agnostic ingest)")
        else:
            stats["agnostic_ok"] += 1

        time.sleep(0.5)  # Brief pause between qualifications

    print(f"\n{'='*60}")
    print("=== BATCH COMPLETE ===")
    print(f"Product extract+ingest:   OK={stats['product_ok']}  SKIP={stats['product_skip']}  FAIL={stats['product_fail']}")
    print(f"Agnostic extract+ingest:  OK={stats['agnostic_ok']}  SKIP={stats['agnostic_skip']}  FAIL={stats['agnostic_fail']}")
    if failures:
        print(f"\nFailed items:")
        for f in failures:
            print(f"  - {f}")
    return 0 if not failures else 1


if __name__ == "__main__":
    sys.exit(main())
