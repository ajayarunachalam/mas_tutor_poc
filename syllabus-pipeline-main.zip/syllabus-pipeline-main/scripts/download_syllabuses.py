#!/usr/bin/env python3
"""
Download Cambridge International syllabus PDFs.

Fetches both IGCSE and A-Level subject listing pages, visits each subject page,
extracts the most recent syllabus PDF link, and downloads to the output directory.

Usage:
    uv run python scripts/download_syllabuses.py --out ~/projects/mas_education_poc/syllabuses/
    uv run python scripts/download_syllabuses.py --dry-run
"""
from __future__ import annotations

import argparse
import re
import sys
import time
import urllib.request
import urllib.error
from html.parser import HTMLParser
from pathlib import Path

BASE_URL = "https://www.cambridgeinternational.org"

IGCSE_SUBJECTS_URL = (
    "https://www.cambridgeinternational.org/programmes-and-qualifications/"
    "cambridge-upper-secondary/cambridge-igcse/subjects/"
)
ALEVEL_SUBJECTS_URL = (
    "https://www.cambridgeinternational.org/programmes-and-qualifications/"
    "cambridge-advanced/cambridge-international-as-and-a-levels/subjects/"
)

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-GB,en;q=0.9",
}

# These are 9-1 variants / duplicates / regional variants to skip in favour of standard codes
SKIP_CODES = {
    "0970", "0971", "0972", "0973", "0974", "0975", "0976", "0977", "0978", "0979",
    "0980", "0981", "0982", "0983", "0984", "0985", "0986", "0987", "0988", "0989",
    "0990", "0991", "0992", "0993", "0994", "0995", "0996",
    "7156", "7157", "7158", "7159", "7160", "7162", "7167", "7168", "7184",  # 9-1 lang
    "0465", "0524",  # Regional English variants
}


class LinkParser(HTMLParser):
    """Extract href values from <a> tags."""

    def __init__(self) -> None:
        super().__init__()
        self.links: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag == "a":
            for name, val in attrs:
                if name == "href" and val:
                    self.links.append(val)


def fetch(url: str, retries: int = 3) -> str:
    """Fetch a URL and return the HTML content."""
    req = urllib.request.Request(url, headers=HEADERS)
    for attempt in range(retries):
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                return resp.read().decode("utf-8", errors="replace")
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return ""
            if attempt < retries - 1:
                time.sleep(2 ** attempt)
                continue
            raise
        except Exception:
            if attempt < retries - 1:
                time.sleep(2 ** attempt)
                continue
            raise
    return ""


def get_subject_urls(listing_url: str) -> list[tuple[str, str]]:
    """
    Parse a subject listing page and return (code, subject_url) pairs.
    Looks for links matching /programmes-and-qualifications/cambridge-igcse-*-NNNN/
    or /programmes-and-qualifications/cambridge-international-*-NNNN/
    """
    html = fetch(listing_url)
    parser = LinkParser()
    parser.feed(html)

    subjects = []
    seen_codes = set()

    for href in parser.links:
        # Match subject detail page URLs containing a numeric code at the end
        # Patterns:
        #   /programmes-and-qualifications/cambridge-igcse-biology-0610/
        #   /programmes-and-qualifications/cambridge-international-as-a-level-physics-9702/
        #   /programmes-and-qualifications/cambridge-igcse-mathematics-0580/
        m = re.search(r"/programmes-and-qualifications/[a-z0-9-]+-(\d{4})/", href)
        if not m:
            continue
        code = m.group(1)
        if code in seen_codes or code in SKIP_CODES:
            continue
        seen_codes.add(code)
        full_url = BASE_URL + href if href.startswith("/") else href
        subjects.append((code, full_url))

    return subjects


def get_syllabus_pdf_url(subject_url: str) -> str | None:
    """
    Visit a subject page and find the most recent syllabus PDF URL.
    Prefers links with 'syllabus' in the URL (not specimen papers, grade descriptors, etc).
    Among multiple syllabuses, picks the most recent by year.
    """
    html = fetch(subject_url)
    if not html:
        return None

    parser = LinkParser()
    parser.feed(html)

    pdf_links = []
    for href in parser.links:
        if not href.endswith(".pdf"):
            continue
        lower = href.lower()
        # Must contain 'syllabus' in URL; skip specimen papers, mark schemes, etc.
        if "syllabus" not in lower:
            continue
        if any(skip in lower for skip in ["specimen", "mark-scheme", "grade-description",
                                           "past-paper", "specimen-paper", "examiner"]):
            continue
        full_url = BASE_URL + href if href.startswith("/") else href
        # Extract year for sorting (prefer highest year)
        years = re.findall(r"20\d\d", href)
        year = max(int(y) for y in years) if years else 0
        pdf_links.append((year, full_url))

    if not pdf_links:
        return None

    # Return URL with highest year
    pdf_links.sort(key=lambda x: x[0], reverse=True)
    return pdf_links[0][1]


def download_pdf(url: str, dest: Path) -> bool:
    """Download a PDF to dest. Returns True if successful."""
    req = urllib.request.Request(url, headers=HEADERS)
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            content = resp.read()
            if len(content) < 10_000:
                print(f"  WARNING: Very small file ({len(content)} bytes) — may not be valid PDF")
            dest.write_bytes(content)
            return True
    except Exception as e:
        print(f"  ERROR downloading {url}: {e}")
        return False


def pdf_filename(code: str, url: str) -> str:
    """Generate a filename from the code and URL."""
    # Extract year range from URL like 2026-2028-syllabus.pdf → 2026
    years = re.findall(r"20\d\d", url)
    year = years[0] if years else "unknown"
    return f"{code}_{year}_syllabus.pdf"


def main() -> int:
    parser = argparse.ArgumentParser(description="Download Cambridge syllabus PDFs")
    parser.add_argument("--out", default="~/projects/mas_education_poc/syllabuses/",
                        help="Output directory for PDFs")
    parser.add_argument("--dry-run", action="store_true",
                        help="Discover URLs but do not download")
    parser.add_argument("--delay", type=float, default=1.0,
                        help="Delay between requests in seconds (default: 1.0)")
    args = parser.parse_args()

    out_dir = Path(args.out).expanduser()
    out_dir.mkdir(parents=True, exist_ok=True)

    print("=== Cambridge Syllabus Downloader ===")
    print(f"Output: {out_dir}")
    print(f"Dry run: {args.dry_run}\n")

    all_subjects: list[tuple[str, str, str]] = []  # (code, level, url)

    print("Fetching IGCSE subject list...")
    igcse = get_subject_urls(IGCSE_SUBJECTS_URL)
    for code, url in igcse:
        all_subjects.append((code, "IGCSE", url))
    print(f"  Found {len(igcse)} IGCSE subjects")

    time.sleep(args.delay)

    print("Fetching A-Level subject list...")
    alevel = get_subject_urls(ALEVEL_SUBJECTS_URL)
    for code, url in alevel:
        all_subjects.append((code, "A-Level", url))
    print(f"  Found {len(alevel)} A-Level subjects")

    print(f"\nTotal subjects to check: {len(all_subjects)}\n")

    downloaded = 0
    skipped = 0
    failed = 0
    no_pdf = 0

    results: list[dict] = []

    for i, (code, level, subject_url) in enumerate(all_subjects, 1):
        print(f"[{i}/{len(all_subjects)}] {code} ({level})")
        time.sleep(args.delay)

        pdf_url = get_syllabus_pdf_url(subject_url)
        if not pdf_url:
            print(f"  No syllabus PDF found at {subject_url}")
            no_pdf += 1
            results.append({"code": code, "level": level, "status": "no_pdf", "url": None})
            continue

        fname = pdf_filename(code, pdf_url)
        dest = out_dir / fname

        if dest.exists():
            print(f"  Already exists: {fname}")
            skipped += 1
            results.append({"code": code, "level": level, "status": "skipped", "url": pdf_url, "file": str(dest)})
            continue

        print(f"  PDF: {pdf_url}")
        if args.dry_run:
            print(f"  [DRY RUN] Would download to: {fname}")
            results.append({"code": code, "level": level, "status": "dry_run", "url": pdf_url, "file": fname})
            downloaded += 1
            continue

        time.sleep(args.delay)
        ok = download_pdf(pdf_url, dest)
        if ok:
            size_kb = dest.stat().st_size // 1024
            print(f"  Downloaded: {fname} ({size_kb} KB)")
            downloaded += 1
            results.append({"code": code, "level": level, "status": "ok", "url": pdf_url, "file": str(dest)})
        else:
            failed += 1
            results.append({"code": code, "level": level, "status": "failed", "url": pdf_url})

    print(f"\n=== Summary ===")
    print(f"  Downloaded: {downloaded}")
    print(f"  Skipped (exists): {skipped}")
    print(f"  No PDF found: {no_pdf}")
    print(f"  Failed: {failed}")

    # Write manifest
    import json
    manifest = out_dir / "download_manifest.json"
    manifest.write_text(json.dumps(results, indent=2))
    print(f"\nManifest written: {manifest}")

    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
