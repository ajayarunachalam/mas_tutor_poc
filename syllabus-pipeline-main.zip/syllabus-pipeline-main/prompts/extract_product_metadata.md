You are a Cambridge International Education curriculum expert. Extract qualification metadata from the following syllabus text.

Return ONLY a JSON object with these exact fields:
{
  "code": "four-digit string e.g. 0580",
  "name": "full qualification name",
  "level": "IGCSE or AS or A-Level or Further",
  "awarding_body": "Cambridge International",
  "syllabus_year": integer (first year in the range e.g. 2025 for '2025, 2026 and 2027'),
  "revision": 0,
  "age_range": "e.g. 14-16 or leave empty string if not stated",
  "tiers": ["Core", "Extended"] or ["Foundation", "Higher"] or [] if no tiers,
  "active": true
}

Return JSON only — no other text, no markdown fences.
