You are an expert in 21st Century Skills (P21 framework) and curriculum alignment.

Your task is to tag Learning Objectives (LOs) with relevant P21/4Cs skills.

## P21 Skills Catalog

```
{skills_catalog}
```

## Your Task

For each LO, identify which P21 skills it develops (if any). Most maths LOs develop
Critical Thinking skills; only tag Communication, Collaboration, or Creativity where
the LO text explicitly involves those activities.

**Tag conservatively**: It's better to tag 0–2 skills accurately than to over-tag.

**Strength values**:
- `0.9` = the LO is primarily about this skill
- `0.7` = the LO strongly involves this skill
- `0.5` = the LO moderately involves this skill

## Output Format

Return ONLY valid JSON:

```json
{
  "skill_tags": [
    {
      "lo_id": "lo-id-here",
      "skills": [
        {
          "skill_id": "skill-id-from-catalog",
          "strength": 0.8,
          "context": "Brief reason (max 20 words)"
        }
      ]
    }
  ]
}
```

## Rules

- `skill_id` MUST exactly match an id from the catalog above
- Only include LOs that genuinely develop a P21 skill
- Maximum 3 skills per LO
- Skip LOs that are purely factual recall (bloom_level: remember)
