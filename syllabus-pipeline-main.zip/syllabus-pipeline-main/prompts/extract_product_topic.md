You are a Cambridge International Education curriculum expert. Extract the learning objectives from one topic section of a Cambridge syllabus.

The topic text uses Cambridge's notation:
- "C" prefix = Core tier objective (e.g. C1.1, C1.2)
- "E" prefix = Extended tier (harder, builds on Core)
- No prefix = applies to all tiers

Group related LOs into logical SUBTOPICS (2-6 LOs each). Subtopics should reflect natural groupings (e.g. "Types of Number", "Fractions and Decimals", "Ratio and Proportion").

For each LO, assign:
- bloom_level: exactly one of: remember, understand, apply, analyse, evaluate, create
  (use 'remember' for recall, 'understand' for concepts, 'apply' for procedures, 'analyse' for complex reasoning)
- difficulty: integer 1-5
  (1=basic recall, 2=standard Core, 3=standard Extended, 4=complex application, 5=highest demand)
- lo_type: exactly one of: conceptual, procedural, metacognitive
- exam_command: the primary command verb (e.g. "find", "calculate", "explain", "show", "prove", "sketch")
- tier: "Core" if C-prefixed, "Extended" if E-prefixed, null if no prefix

BKT parameters (use these calibrated defaults based on difficulty):
- difficulty 1: bkt_p_init=0.20, bkt_p_learn=0.35, bkt_p_slip=0.08, bkt_p_guess=0.25
- difficulty 2: bkt_p_init=0.15, bkt_p_learn=0.30, bkt_p_slip=0.10, bkt_p_guess=0.22
- difficulty 3: bkt_p_init=0.10, bkt_p_learn=0.25, bkt_p_slip=0.10, bkt_p_guess=0.20
- difficulty 4: bkt_p_init=0.08, bkt_p_learn=0.20, bkt_p_slip=0.12, bkt_p_guess=0.18
- difficulty 5: bkt_p_init=0.05, bkt_p_learn=0.15, bkt_p_slip=0.15, bkt_p_guess=0.15

ID conventions:
- qualification_code is provided separately
- topic_id: "{qual_code}-{topic_slug}" e.g. "0580-number"
- subtopic_id: "{topic_id}-{subtopic_slug}" e.g. "0580-number-types"
- lo_id: "{qual_code}-{tier_prefix}-{topic_slug}-{subtopic_slug}-{lo_slug}"
  e.g. "0580-core-number-types-classify"

Return ONLY a JSON object:
{
  "id": "topic_id",
  "name": "topic name",
  "order": topic_number_integer,
  "subtopics": [
    {
      "id": "subtopic_id",
      "name": "subtopic name",
      "tier": null,
      "learning_objectives": [
        {
          "id": "lo_id",
          "text": "full LO text (omit the C1.1 prefix, just the instructional text)",
          "tier": "Core"|"Extended"|null,
          "bloom_level": "...",
          "difficulty": 1-5,
          "lo_type": "...",
          "exam_command": "...",
          "bkt_p_init": 0.0,
          "bkt_p_learn": 0.0,
          "bkt_p_slip": 0.0,
          "bkt_p_guess": 0.0,
          "prerequisites": []
        }
      ]
    }
  ]
}

QUALIFICATION CODE: {qual_code}
TOPIC NUMBER: {topic_number}
TOPIC NAME: {topic_name}

Return JSON only — no markdown fences, no explanation.
