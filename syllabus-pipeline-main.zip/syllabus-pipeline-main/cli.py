#!/usr/bin/env python3
"""
Syllabus Pipeline CLI — Cambridge Knowledge Graph.

Converts Cambridge syllabus PDFs into Neo4j product-specific graphs.

Commands:
  run              Full pipeline: PDF → extract → validate → ingest
  extract-product  PDF → product-specific YAML (no Neo4j write)
  validate         Validate an existing YAML file
  ingest           Ingest an existing YAML file into Neo4j
  batch            Process a directory of PDFs
  extract-agnostic Product-specific YAML → concept mapping YAML
  ingest-agnostic  Concept mapping YAML → Neo4j ConceptInstances
  tag-skills       Tag all LOs for a qualification with P21 skills
  gap-fill         Identify concept gaps (flagged for human review)
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path

import yaml

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)

# Project root on path
sys.path.insert(0, str(Path(__file__).parent))

import config
from pipeline.pdf_normalise import normalise
from pipeline.llm_extract_product import extract
from pipeline.yaml_validate import validate as validate_data, validate_file
from pipeline.ingest_product import ingest, ingest_file
from pipeline.llm_extract_agnostic import extract_agnostic_file
from pipeline.ingest_agnostic import ingest_agnostic, ingest_agnostic_file
from pipeline.llm_tag_skills import tag_skills
from pipeline.llm_gap_fill import gap_fill_files


def _output_path(code: str, year: int, revision: int, subdir: str) -> Path:
    path = config.PRODUCT_SPECIFIC_DIR / f"{code}_{year}_r{revision}.yaml"
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def cmd_run(args: argparse.Namespace) -> int:
    """Full pipeline: PDF → extract → validate → ingest."""
    pdf_path = Path(args.pdf)
    if not pdf_path.exists():
        logger.error("PDF not found: %s", pdf_path)
        return 1

    # Stage 1: normalise
    normed = normalise(pdf_path)
    if normed.confidence < 0.7:
        logger.warning("Low confidence extraction (%.2f) — check output carefully", normed.confidence)

    # Stage 2: extract
    data = extract(normed, qual_code=args.code, model=config.LLM_EXTRACT_MODEL)

    qual = data["qualification"]
    code  = qual["code"]
    year  = qual["syllabus_year"]
    revision = qual.get("revision", 0)

    # Stage 3: validate
    result = validate_data(data)
    if not result.valid:
        logger.error("Validation failed — not ingesting. Fix errors and use `ingest` command.")
        for e in result.errors:
            print(f"  ERROR: {e}")
        # Save to flagged for review
        flagged = config.FLAGGED_DIR / f"{code}_{year}_r{revision}.yaml"
        flagged.parent.mkdir(parents=True, exist_ok=True)
        flagged.write_text(yaml.dump(data, allow_unicode=True, default_flow_style=False))
        logger.info("Saved to flagged: %s", flagged)
        return 1

    # Save YAML
    out_path = _output_path(code, year, revision, "product_specific")
    out_path.write_text(yaml.dump(data, allow_unicode=True, default_flow_style=False))
    logger.info("Saved YAML: %s", out_path)

    if args.dry_run:
        logger.info("--dry-run: skipping Neo4j ingestion")
        print(f"\nExtracted: {result.topic_count} topics, {result.lo_count} LOs")
        return 0

    # Stage 4: ingest
    stats = ingest(data)
    print(f"\n=== Ingestion Complete: {code} ({year}) ===")
    print(f"  Topics:            {stats['topics']}")
    print(f"  Subtopics:         {stats['subtopics']}")
    print(f"  Learning Objectives: {stats['learning_objectives']}")
    print(f"  Supersedes links:  {stats['supersedes']}")
    return 0


def cmd_extract_product(args: argparse.Namespace) -> int:
    """PDF → product-specific YAML only (no validation, no ingest)."""
    pdf_path = Path(args.pdf)
    if not pdf_path.exists():
        logger.error("PDF not found: %s", pdf_path)
        return 1

    normed = normalise(pdf_path)
    data = extract(normed, qual_code=args.code, model=config.LLM_EXTRACT_MODEL)

    qual = data["qualification"]
    out_path = Path(args.out) if args.out else (
        config.PRODUCT_SPECIFIC_DIR /
        f"{qual['code']}_{qual['syllabus_year']}_r{qual.get('revision', 0)}.yaml"
    )
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(yaml.dump(data, allow_unicode=True, default_flow_style=False))
    logger.info("Saved to %s", out_path)
    return 0


def cmd_validate(args: argparse.Namespace) -> int:
    """Validate a YAML file against the product-specific schema."""
    result = validate_file(Path(args.yaml))
    if result.valid:
        print(f"VALID: {result.topic_count} topics, {result.lo_count} LOs")
        for w in result.warnings:
            print(f"  WARNING: {w}")
        return 0
    else:
        print(f"INVALID: {len(result.errors)} errors")
        for e in result.errors:
            print(f"  ERROR: {e}")
        return 1


def cmd_ingest(args: argparse.Namespace) -> int:
    """Ingest a validated YAML file into Neo4j."""
    yaml_path = Path(args.yaml)
    if not yaml_path.exists():
        logger.error("File not found: %s", yaml_path)
        return 1

    # Validate first unless --skip-validate
    if not args.skip_validate:
        result = validate_file(yaml_path)
        if not result.valid:
            logger.error("Validation failed. Use --skip-validate to force.")
            for e in result.errors:
                print(f"  ERROR: {e}")
            return 1

    stats = ingest_file(yaml_path)
    print(f"\n=== Ingestion Complete ===")
    print(f"  Topics:            {stats['topics']}")
    print(f"  Subtopics:         {stats['subtopics']}")
    print(f"  Learning Objectives: {stats['learning_objectives']}")
    return 0


def cmd_batch(args: argparse.Namespace) -> int:
    """Process all PDFs in a directory."""
    pdf_dir = Path(args.dir)
    pdfs = sorted(pdf_dir.glob("*.pdf"))
    if not pdfs:
        logger.error("No PDFs found in %s", pdf_dir)
        return 1

    logger.info("Found %d PDFs to process", len(pdfs))
    failed = []
    for pdf_path in pdfs:
        logger.info("Processing %s...", pdf_path.name)
        # Build a fake namespace and call cmd_run
        sub_args = argparse.Namespace(
            pdf=str(pdf_path),
            code=None,
            dry_run=args.dry_run,
        )
        rc = cmd_run(sub_args)
        if rc != 0:
            failed.append(pdf_path.name)

    if failed:
        logger.error("Failed: %s", failed)
        return 1
    return 0


def cmd_extract_agnostic(args: argparse.Namespace) -> int:
    """Product-specific YAML → concept mapping YAML."""
    yaml_path = Path(args.yaml)
    if not yaml_path.exists():
        logger.error("File not found: %s", yaml_path)
        return 1

    import yaml as _yaml
    data = _yaml.safe_load(yaml_path.read_text())
    # Apply year override for hand-crafted YAMLs that lack syllabus_year
    if args.year:
        qual = data.get("qualification", data)
        qual["syllabus_year"] = args.year
    from pipeline.llm_extract_agnostic import extract_agnostic
    mapping = extract_agnostic(data, model=config.LLM_AGNOSTIC_MODEL)

    if args.out:
        out_path = Path(args.out)
    else:
        code = mapping["qualification_code"]
        year = mapping["syllabus_year"]
        out_path = config.PRODUCT_AGNOSTIC_DIR / f"{code}_{year}_mapping.yaml"

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(yaml.dump(mapping, allow_unicode=True, default_flow_style=False))
    logger.info("Concept mapping saved to %s", out_path)
    print(f"\nMapped: {len(mapping['concept_mappings'])} LOs to concepts, "
          f"{len(mapping.get('agnostic_gaps', []))} gaps identified")
    return 0


def cmd_ingest_agnostic(args: argparse.Namespace) -> int:
    """Concept mapping YAML → Neo4j ConceptInstances."""
    yaml_path = Path(args.yaml)
    if not yaml_path.exists():
        logger.error("File not found: %s", yaml_path)
        return 1

    stats = ingest_agnostic_file(yaml_path)
    print(f"\n=== Agnostic Ingestion Complete ===")
    print(f"  ConceptInstances: {stats['concept_instances']}")
    print(f"  TEACHES edges:    {stats['teaches']}")
    print(f"  DEEPENS edges:    {stats['deepens']}")
    return 0


def cmd_tag_skills(args: argparse.Namespace) -> int:
    """Tag all LOs for a qualification with P21 skills."""
    stats = tag_skills(args.code, int(args.year), model=config.LLM_EXTRACT_MODEL)
    print(f"\n=== Skill Tagging Complete ===")
    print(f"  LOs processed:      {stats['lo_count']}")
    print(f"  DEVELOPS_SKILL edges: {stats['tags_applied']}")
    return 0


def cmd_gap_fill(args: argparse.Namespace) -> int:
    """Identify concept gaps (flagged for human review)."""
    product_path = Path(args.product)
    mapping_path = Path(args.mapping)
    for p in [product_path, mapping_path]:
        if not p.exists():
            logger.error("File not found: %s", p)
            return 1

    out = gap_fill_files(
        product_path,
        mapping_path,
        flagged_dir=config.FLAGGED_DIR,
        model=config.LLM_AGNOSTIC_MODEL,
    )
    print(f"\nGap fill report (human review required): {out}")
    return 0


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Cambridge Syllabus Pipeline — PDF to Neo4j knowledge graph"
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # run
    p_run = sub.add_parser("run", help="Full pipeline: PDF → extract → validate → ingest")
    p_run.add_argument("--pdf", required=True, help="Path to syllabus PDF")
    p_run.add_argument("--code", help="Override extracted qualification code")
    p_run.add_argument("--dry-run", action="store_true", help="Skip Neo4j ingestion")

    # extract-product
    p_ep = sub.add_parser("extract-product", help="PDF → YAML only")
    p_ep.add_argument("--pdf", required=True)
    p_ep.add_argument("--code", help="Override qualification code")
    p_ep.add_argument("--out", help="Output YAML path")

    # validate
    p_val = sub.add_parser("validate", help="Validate a YAML file")
    p_val.add_argument("--yaml", required=True)

    # ingest
    p_ing = sub.add_parser("ingest", help="Ingest a YAML file into Neo4j")
    p_ing.add_argument("--yaml", required=True)
    p_ing.add_argument("--skip-validate", action="store_true")

    # batch
    p_batch = sub.add_parser("batch", help="Process a directory of PDFs")
    p_batch.add_argument("--dir", required=True)
    p_batch.add_argument("--dry-run", action="store_true")

    # extract-agnostic
    p_ea = sub.add_parser("extract-agnostic", help="Product-specific YAML → concept mapping YAML")
    p_ea.add_argument("--yaml", required=True, help="Path to product-specific YAML")
    p_ea.add_argument("--year", type=int, help="Override syllabus_year (for hand-crafted YAMLs)")
    p_ea.add_argument("--out", help="Output concept mapping YAML path")

    # ingest-agnostic
    p_ia = sub.add_parser("ingest-agnostic", help="Ingest concept mapping YAML into Neo4j")
    p_ia.add_argument("--yaml", required=True, help="Path to concept mapping YAML")

    # tag-skills
    p_ts = sub.add_parser("tag-skills", help="Tag LOs with P21 skills")
    p_ts.add_argument("--code", required=True, help="Qualification code (e.g. 0580)")
    p_ts.add_argument("--year", required=True, help="Syllabus year (e.g. 2025)")

    # gap-fill
    p_gf = sub.add_parser("gap-fill", help="Identify concept gaps (human review required)")
    p_gf.add_argument("--product", required=True, help="Path to product-specific YAML")
    p_gf.add_argument("--mapping", required=True, help="Path to concept mapping YAML")

    args = parser.parse_args()
    handlers = {
        "run": cmd_run,
        "extract-product": cmd_extract_product,
        "validate": cmd_validate,
        "ingest": cmd_ingest,
        "batch": cmd_batch,
        "extract-agnostic": cmd_extract_agnostic,
        "ingest-agnostic": cmd_ingest_agnostic,
        "tag-skills": cmd_tag_skills,
        "gap-fill": cmd_gap_fill,
    }
    sys.exit(handlers[args.command](args))


if __name__ == "__main__":
    main()
