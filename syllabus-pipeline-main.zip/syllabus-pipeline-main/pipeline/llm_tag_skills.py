"""
Stage 5a — P21 Skill Tagging.

Tags LOs with P21/4Cs skills by reading existing LOs from Neo4j for a qualification,
running an LLM batch call, then writing DEVELOPS_SKILL edges back to Neo4j.

Idempotent: MERGE on (lo_id, skill_id) pair.
"""
from __future__ import annotations

import json
import logging
import re
from pathlib import Path

import anthropic
from json_repair import repair_json

from cambridge_kg.driver import kg_session
from pipeline.llm_extract_agnostic import fetch_skills_catalog, _build_skills_catalog_text, _llm_call

logger = logging.getLogger(__name__)

_PROMPTS_DIR = Path(__file__).parent.parent / "prompts"


def _parse_json(raw: str) -> dict:
    raw = re.sub(r"^```(?:json)?\s*", "", raw.strip())
    raw = re.sub(r"\s*```$", "", raw)
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        logger.warning("JSON malformed in skill tagging — attempting repair")
        return repair_json(raw, return_objects=True)


def _fetch_los_for_qual(code: str, year: int) -> list[dict]:
    """Fetch all LOs for a qualification from Neo4j."""
    with kg_session() as session:
        result = session.run("""
            MATCH (q:Qualification {code: $code, syllabus_year: $year})
                  -[:HAS_TOPIC]->(:Topic)
                  -[:HAS_SUBTOPIC]->(:Subtopic)
                  -[:HAS_LO]->(lo:LearningObjective)
            RETURN DISTINCT lo.id AS id, lo.text AS text,
                   lo.bloom_level AS bloom_level, lo.difficulty AS difficulty
            ORDER BY lo.id
        """, code=code, year=year)
        return [dict(r) for r in result]


def tag_skills(code: str, year: int, model: str = "claude-haiku-4-5-20251001") -> dict:
    """
    Tag all LOs for a qualification with P21/4Cs skills.

    Args:
        code: Qualification code (e.g. '0580')
        year: Syllabus year (e.g. 2025)
        model: LLM model (haiku is sufficient for tagging)

    Returns:
        Stats dict: {lo_count, tags_applied, skills_applied}
    """
    client = anthropic.Anthropic()

    # Fetch P21 skills catalog
    skills_catalog = fetch_skills_catalog()
    skill_ids = {s["skill_id"] for s in skills_catalog}
    catalog_text = _build_skills_catalog_text(skills_catalog)

    # Fetch LOs from Neo4j
    los = _fetch_los_for_qual(code, year)
    if not los:
        logger.warning("No LOs found for %s year=%s — skipping skill tagging", code, year)
        return {"lo_count": 0, "tags_applied": 0, "skills_applied": 0}

    logger.info("Tagging %d LOs with P21 skills (code=%s year=%s)", len(los), code, year)

    # Build prompt
    system_tpl = (_PROMPTS_DIR / "tag_skills.md").read_text()
    system = system_tpl.replace("{skills_catalog}", catalog_text)

    _BATCH_SIZE = 100
    all_tags: list[dict] = []

    for i in range(0, len(los), _BATCH_SIZE):
        batch = los[i: i + _BATCH_SIZE]
        user = f"LEARNING OBJECTIVES:\n\n{json.dumps(batch, indent=2)}"
        raw = _llm_call(client, system, user, model=model)
        result = _parse_json(raw)
        all_tags.extend(result.get("skill_tags", []))

    # Write DEVELOPS_SKILL edges to Neo4j
    stats = {"lo_count": len(los), "tags_applied": 0, "skills_applied": 0}
    with kg_session() as session:
        for tag in all_tags:
            lo_id = tag.get("lo_id")
            for skill_entry in tag.get("skills", []):
                skill_id = skill_entry.get("skill_id")
                if not skill_id or skill_id not in skill_ids:
                    continue
                strength = float(skill_entry.get("strength", 0.7))
                context = skill_entry.get("context", "")

                session.run("""
                    MATCH (lo:LearningObjective {id: $lo_id})
                    MATCH (s:Skill {id: $skill_id})
                    MERGE (lo)-[r:DEVELOPS_SKILL {skill_id: $skill_id}]->(s)
                    SET r.strength = $strength,
                        r.context  = $context
                """, lo_id=lo_id, skill_id=skill_id, strength=strength, context=context)
                stats["tags_applied"] += 1
                stats["skills_applied"] += 1

    logger.info("Skill tagging complete: %d DEVELOPS_SKILL edges created", stats["tags_applied"])
    return stats
