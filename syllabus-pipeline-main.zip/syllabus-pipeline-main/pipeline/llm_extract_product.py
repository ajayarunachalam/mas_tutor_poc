"""
Stage 2 — LLM Extraction: PDF text → product-specific YAML dict.

Two-pass approach:
  Pass 1: Extract qualification metadata from metadata_text.
  Pass 2: For each topic section, extract subtopics + LOs.
  Returns a combined dict ready for yaml_validate.py.
"""
from __future__ import annotations

import json
import logging
import re
import time
from pathlib import Path

import anthropic

from pipeline.pdf_normalise import NormalisedPDF

logger = logging.getLogger(__name__)

_PROMPTS_DIR = Path(__file__).parent.parent / "prompts"

# Default BKT params by difficulty level
_BKT_DEFAULTS = {
    1: dict(bkt_p_init=0.20, bkt_p_learn=0.35, bkt_p_slip=0.08, bkt_p_guess=0.25),
    2: dict(bkt_p_init=0.15, bkt_p_learn=0.30, bkt_p_slip=0.10, bkt_p_guess=0.22),
    3: dict(bkt_p_init=0.10, bkt_p_learn=0.25, bkt_p_slip=0.10, bkt_p_guess=0.20),
    4: dict(bkt_p_init=0.08, bkt_p_learn=0.20, bkt_p_slip=0.12, bkt_p_guess=0.18),
    5: dict(bkt_p_init=0.05, bkt_p_learn=0.15, bkt_p_slip=0.15, bkt_p_guess=0.15),
}


def _llm_call(
    client: anthropic.Anthropic,
    system: str,
    user: str,
    model: str = "claude-haiku-4-5-20251001",
    max_tokens: int = 8000,
) -> str:
    """Single LLM call with exponential backoff on overload."""
    for attempt in range(1, 7):
        try:
            response = client.messages.create(
                model=model,
                max_tokens=max_tokens,
                system=system,
                messages=[{"role": "user", "content": user}],
            )
            return response.content[0].text.strip()
        except Exception as exc:
            if "overloaded" in str(exc).lower() and attempt < 6:
                wait = 20 * (2 ** (attempt - 1))
                logger.warning("API overloaded (attempt %d/6) — waiting %ds", attempt, wait)
                time.sleep(wait)
            else:
                raise


def _parse_json(raw: str) -> dict | list:
    """Strip markdown fences and parse JSON, with repair fallback."""
    from json_repair import repair_json
    raw = re.sub(r"^```(?:json)?\s*", "", raw.strip())
    raw = re.sub(r"\s*```$", "", raw)
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        logger.warning("JSON malformed — attempting repair")
        repaired = repair_json(raw, return_objects=True)
        return repaired


def _normalise_prerequisites(lo: dict) -> None:
    """Coerce prerequisite entries from strings to {id, strength} objects."""
    raw = lo.get("prerequisites", [])
    normalised = []
    for p in raw:
        if isinstance(p, str):
            normalised.append({"id": p, "strength": "soft"})
        elif isinstance(p, dict) and "id" in p:
            p.setdefault("strength", "soft")
            normalised.append(p)
    lo["prerequisites"] = normalised


def _ensure_bkt(lo: dict) -> dict:
    """Fill missing BKT params from calibrated defaults."""
    difficulty = max(1, min(5, lo.get("difficulty", 2)))
    defaults = _BKT_DEFAULTS[difficulty]
    for k, v in defaults.items():
        lo.setdefault(k, v)
    lo.setdefault("prerequisites", [])
    _normalise_prerequisites(lo)
    return lo


def extract_metadata(client: anthropic.Anthropic, metadata_text: str) -> dict:
    """Pass 1: extract qualification metadata."""
    system = (_PROMPTS_DIR / "extract_product_metadata.md").read_text()
    user = f"SYLLABUS TEXT:\n\n{metadata_text[:6000]}"

    logger.info("Extracting qualification metadata...")
    raw = _llm_call(client, system, user, max_tokens=512)
    metadata = _parse_json(raw)
    metadata.setdefault("revision", 0)
    metadata.setdefault("active", True)
    metadata.setdefault("awarding_body", "Cambridge International")
    metadata.setdefault("tiers", [])
    logger.info("Metadata: code=%s name=%s year=%s tiers=%s",
                metadata.get("code"), metadata.get("name"),
                metadata.get("syllabus_year"), metadata.get("tiers"))
    return metadata


def extract_topic(
    client: anthropic.Anthropic,
    section: dict,
    qual_code: str,
    topic_system: str,
) -> dict | None:
    """Pass 2: extract one topic section into structured dict."""
    heading = section["heading"]
    topic_number = section["number"]
    topic_name = " ".join(heading.split()[1:])  # strip leading number

    system = topic_system.replace("{qual_code}", qual_code)\
                         .replace("{topic_number}", str(topic_number))\
                         .replace("{topic_name}", topic_name)

    # Truncate very long sections to avoid token limits
    topic_text = section["text"]
    if len(topic_text) > 8000:
        logger.warning("Topic '%s' text truncated from %d to 8000 chars", heading, len(topic_text))
        topic_text = topic_text[:8000]

    user = f"TOPIC TEXT:\n\n{topic_text}"
    logger.info("Extracting topic: %s", heading)

    try:
        raw = _llm_call(client, system, user, max_tokens=8000)
        topic_dict = _parse_json(raw)
    except Exception as exc:
        logger.error("Failed to extract topic '%s': %s", heading, exc)
        return None

    # Filter incomplete LOs and ensure BKT params on valid ones
    for subtopic in topic_dict.get("subtopics", []):
        valid_los = []
        for lo in subtopic.get("learning_objectives", []):
            if lo.get("text") and lo.get("bloom_level") and lo.get("difficulty"):
                _ensure_bkt(lo)
                valid_los.append(lo)
            else:
                logger.debug("Dropping incomplete LO (missing required fields): %s", lo.get("id", "?"))
        subtopic["learning_objectives"] = valid_los

    return topic_dict


def extract(
    normed: NormalisedPDF,
    qual_code: str | None = None,
    model: str = "claude-haiku-4-5-20251001",
) -> dict:
    """
    Full extraction: metadata + all topics. Returns product-specific YAML dict.
    qual_code overrides extracted code if provided.
    """
    client = anthropic.Anthropic()
    topic_system = (_PROMPTS_DIR / "extract_product_topic.md").read_text()

    # Pass 1: metadata
    metadata = extract_metadata(client, normed.metadata_text)
    if qual_code:
        metadata["code"] = qual_code
    code = metadata["code"]

    # Pass 2: topics
    topics = []
    for section in normed.topic_sections:
        topic = extract_topic(client, section, code, topic_system)
        if topic:
            topics.append(topic)

    lo_count = sum(
        len(st.get("learning_objectives", []))
        for t in topics
        for st in t.get("subtopics", [])
    )
    logger.info("Extraction complete: %d topics, %d LOs", len(topics), lo_count)

    return {"qualification": {**metadata, "topics": topics}}
