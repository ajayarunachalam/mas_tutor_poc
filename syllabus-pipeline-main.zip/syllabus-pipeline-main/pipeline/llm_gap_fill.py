"""
Stage 5b — Gap Fill (optional, human review required).

Reviews the concept mappings for a qualification and identifies LOs that could not be
mapped to any existing Concept. Uses an LLM to suggest new Concept nodes that should
be added to the product-agnostic layer.

All output is FLAGGED — no automatic writes to Neo4j. Human review required.
"""
from __future__ import annotations

import json
import logging
import re
from pathlib import Path

import anthropic
import yaml
from json_repair import repair_json

from pipeline.llm_extract_agnostic import (
    fetch_concept_catalog,
    _build_concept_catalog_text,
    _collect_los,
    _llm_call,
)

logger = logging.getLogger(__name__)

_PROMPTS_DIR = Path(__file__).parent.parent / "prompts"


def _parse_json(raw: str) -> dict:
    raw = re.sub(r"^```(?:json)?\s*", "", raw.strip())
    raw = re.sub(r"\s*```$", "", raw)
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return repair_json(raw, return_objects=True)


def gap_fill(
    product_yaml: dict,
    mapping_yaml: dict,
    model: str = "claude-sonnet-4-6",
) -> list[dict]:
    """
    Identify concepts in the qualification not covered by existing concept catalog.

    Args:
        product_yaml: Product-specific YAML dict.
        mapping_yaml: Concept mapping YAML dict (output of llm_extract_agnostic).
        model: LLM model.

    Returns:
        List of gap dicts {name, description, suggested_area, source, supporting_lo_ids}.
    """
    client = anthropic.Anthropic()

    qual = product_yaml.get("qualification", product_yaml)
    code = qual.get("code", "UNKNOWN")

    # Find unmapped LOs
    all_los = _collect_los(product_yaml)
    mapped_lo_ids = {m["lo_id"] for m in mapping_yaml.get("concept_mappings", [])}
    unmapped_los = [lo for lo in all_los if lo["id"] not in mapped_lo_ids]

    if not unmapped_los:
        logger.info("All LOs are mapped — no gap fill needed for %s", code)
        return []

    logger.info("Gap fill: %d unmapped LOs for %s", len(unmapped_los), code)

    # Fetch concept catalog
    catalog = fetch_concept_catalog()
    catalog_text = _build_concept_catalog_text(catalog)

    # Mapped concepts summary
    mapped_concepts = set()
    for m in mapping_yaml.get("concept_mappings", []):
        for c in m.get("concepts", []):
            mapped_concepts.add(c["concept_id"])
    mapped_text = "\n".join(sorted(mapped_concepts)) if mapped_concepts else "(none yet)"

    # Build prompt
    system_tpl = (_PROMPTS_DIR / "gap_fill.md").read_text()
    system = (
        system_tpl
        .replace("{concept_catalog}", catalog_text)
        .replace("{qual_code}", code)
        .replace("{qual_name}", qual.get("name", code))
        .replace("{level}", qual.get("level", ""))
        .replace("{mapped_concepts}", mapped_text)
        .replace("{unmapped_los}", json.dumps(unmapped_los[:50], indent=2))  # Cap at 50
    )

    user = f"Please identify conceptual gaps for {code}."
    raw = _llm_call(client, system, user, model=model, max_tokens=4000)
    result = _parse_json(raw)

    gaps = result.get("gaps", [])
    logger.info("Gap fill identified %d potential new concepts for %s", len(gaps), code)

    # Merge with any gaps already in the mapping YAML
    existing_gaps = mapping_yaml.get("agnostic_gaps", [])
    all_gaps = existing_gaps + [g for g in gaps if g not in existing_gaps]

    return all_gaps


def gap_fill_files(
    product_yaml_path: Path,
    mapping_yaml_path: Path,
    flagged_dir: Path,
    model: str = "claude-sonnet-4-6",
) -> Path:
    """
    Load YAML files, run gap fill, save flagged output, return path.
    """
    product_yaml = yaml.safe_load(Path(product_yaml_path).read_text())
    mapping_yaml = yaml.safe_load(Path(mapping_yaml_path).read_text())

    gaps = gap_fill(product_yaml, mapping_yaml, model=model)

    # Update mapping YAML with gaps and save to flagged
    mapping_yaml["agnostic_gaps"] = gaps
    code = mapping_yaml.get("qualification_code", "unknown")
    year = mapping_yaml.get("syllabus_year", 0)

    flagged_dir = Path(flagged_dir)
    flagged_dir.mkdir(parents=True, exist_ok=True)
    out_path = flagged_dir / f"{code}_{year}_gaps.yaml"
    out_path.write_text(yaml.dump(mapping_yaml, allow_unicode=True, default_flow_style=False))
    logger.info("Gap fill report saved to %s (human review required)", out_path)
    return out_path
