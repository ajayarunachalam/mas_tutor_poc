"""
Stage 2b — Product-Agnostic Concept Extraction.

Takes a product-specific YAML dict (or file) and maps LOs to existing Concept nodes
in the product-agnostic knowledge graph layer.

Uses claude-sonnet-4-6 (higher reasoning) for this step.
Fetches the live concept catalog from Neo4j to ensure accuracy.

Returns a concept mapping dict ready for yaml_validate → ingest_agnostic.
"""
from __future__ import annotations

import json
import logging
import re
from pathlib import Path

import anthropic
import yaml
from json_repair import repair_json

from cambridge_kg.driver import kg_session

logger = logging.getLogger(__name__)

_PROMPTS_DIR = Path(__file__).parent.parent / "prompts"


def _llm_call(client: anthropic.Anthropic, system: str, user: str, model: str, max_tokens: int = 8000) -> str:
    """Single LLM call with JSON repair on failure.

    Uses OpenRouter (OpenAI-compatible) when OPENROUTER_API_KEY env var is set,
    falling back to the Anthropic client otherwise.
    """
    import os
    import time
    openrouter_key = os.getenv("OPENROUTER_API_KEY")

    for attempt in range(1, 5):
        try:
            if openrouter_key:
                from openai import OpenAI as _OpenAI
                or_client = _OpenAI(
                    base_url="https://openrouter.ai/api/v1",
                    api_key=openrouter_key,
                )
                or_response = or_client.chat.completions.create(
                    model=f"anthropic/{model}",
                    max_tokens=max_tokens,
                    messages=[
                        {"role": "system", "content": system},
                        {"role": "user", "content": user},
                    ],
                )
                return or_response.choices[0].message.content.strip()
            else:
                response = client.messages.create(
                    model=model,
                    max_tokens=max_tokens,
                    system=system,
                    messages=[{"role": "user", "content": user}],
                )
                return response.content[0].text.strip()
        except Exception as exc:
            if "overloaded" in str(exc).lower() and attempt < 4:
                wait = 30 * attempt
                logger.warning("API overloaded (attempt %d/4) — waiting %ds", attempt, wait)
                time.sleep(wait)
            else:
                raise


def _parse_json(raw: str) -> dict:
    """Strip markdown fences and parse JSON with repair fallback."""
    raw = re.sub(r"^```(?:json)?\s*", "", raw.strip())
    raw = re.sub(r"\s*```$", "", raw)
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        logger.warning("JSON malformed — attempting repair")
        return repair_json(raw, return_objects=True)


def fetch_concept_catalog() -> list[dict]:
    """
    Fetch all Concept nodes from Neo4j, with their Area context.
    Returns list of {concept_id, concept_name, area_id, area_name} dicts.
    """
    with kg_session() as session:
        result = session.run("""
            MATCH (a:Area)-[:HAS_CONCEPT]->(c:Concept)
            RETURN a.id AS area_id, a.name AS area_name,
                   c.id AS concept_id, c.name AS concept_name
            ORDER BY a.id, c.name
        """)
        return [dict(r) for r in result]


def fetch_skills_catalog() -> list[dict]:
    """
    Fetch all Skill nodes from Neo4j with their CapabilityDomain context.
    Returns list of {skill_id, skill_name, domain_name} dicts.
    """
    with kg_session() as session:
        result = session.run("""
            MATCH (cd:CapabilityDomain)-[:HAS_SKILL]->(s:Skill)
            RETURN s.id AS skill_id, s.name AS skill_name, cd.name AS domain_name
            ORDER BY cd.name, s.name
        """)
        return [dict(r) for r in result]


def _build_concept_catalog_text(catalog: list[dict]) -> str:
    """Format concept catalog for prompt injection."""
    lines = []
    for entry in catalog:
        lines.append(f"{entry['concept_id']} | {entry['area_id']} | {entry['concept_name']}")
    return "\n".join(lines)


def _build_skills_catalog_text(catalog: list[dict]) -> str:
    """Format P21 skills catalog for prompt injection."""
    lines = []
    for entry in catalog:
        lines.append(f"{entry['skill_id']} | {entry['domain_name']} | {entry['skill_name']}")
    return "\n".join(lines)


def _collect_los(data: dict) -> list[dict]:
    """Extract all LOs from a product-specific YAML dict."""
    los = []
    qual = data.get("qualification", data)
    for topic in qual.get("topics", []):
        for subtopic in topic.get("subtopics", []):
            for lo in subtopic.get("learning_objectives", []):
                if lo.get("id") and lo.get("text"):
                    los.append({
                        "id": lo["id"],
                        "text": lo["text"],
                        "bloom_level": lo.get("bloom_level", "understand"),
                        "difficulty": lo.get("difficulty", 2),
                        "tier": lo.get("tier"),
                    })
    return los


def extract_agnostic(
    data: dict,
    model: str = "claude-sonnet-4-6",
) -> dict:
    """
    Extract product-agnostic concept mappings from a product-specific YAML dict.

    Args:
        data: Product-specific YAML dict (qualification + topics + LOs).
        model: LLM model to use (default: sonnet for reasoning quality).

    Returns:
        Concept mapping dict {qualification_code, syllabus_year, concept_mappings, agnostic_gaps}.
    """
    client = anthropic.Anthropic()

    qual = data.get("qualification", data)
    code = qual.get("code", "UNKNOWN")
    year = qual.get("syllabus_year", 0)

    # Fetch live concept catalog from Neo4j
    logger.info("Fetching concept catalog from Neo4j (%s concepts expected)...", "~105")
    catalog = fetch_concept_catalog()
    concept_ids = {c["concept_id"] for c in catalog}
    logger.info("Catalog: %d concepts across %d areas", len(catalog),
                len({c["area_id"] for c in catalog}))

    # Collect all LOs
    los = _collect_los(data)
    logger.info("Extracting agnostic mappings for %d LOs (code=%s year=%s)", len(los), code, year)

    # Build prompt
    system_tpl = (_PROMPTS_DIR / "extract_agnostic.md").read_text()
    catalog_text = _build_concept_catalog_text(catalog)
    system = system_tpl.replace("{concept_catalog}", catalog_text)

    # Batch LOs (process all at once for up to ~250 LOs, split if more)
    _BATCH_SIZE = 100
    all_mappings: list[dict] = []
    all_gaps: list[dict] = []

    for i in range(0, len(los), _BATCH_SIZE):
        batch = los[i: i + _BATCH_SIZE]
        user = f"LEARNING OBJECTIVES (batch {i // _BATCH_SIZE + 1}):\n\n{json.dumps(batch, indent=2)}"

        logger.info("LLM call: mapping %d LOs (batch %d/%d)", len(batch),
                    i // _BATCH_SIZE + 1, (len(los) - 1) // _BATCH_SIZE + 1)

        raw = _llm_call(client, system, user, model=model)
        result = _parse_json(raw)

        # Validate concept_ids — filter mappings with unknown concepts
        for mapping in result.get("concept_mappings", []):
            valid_concepts = [
                c for c in mapping.get("concepts", [])
                if c.get("concept_id") in concept_ids
            ]
            if valid_concepts:
                mapping["concepts"] = valid_concepts
                all_mappings.append(mapping)

        all_gaps.extend(result.get("agnostic_gaps", []))

    logger.info(
        "Extraction complete: %d LOs mapped to concepts, %d gaps identified",
        len(all_mappings), len(all_gaps),
    )

    return {
        "qualification_code": code,
        "syllabus_year": year,
        "concept_mappings": all_mappings,
        "agnostic_gaps": all_gaps,
    }


def extract_agnostic_file(yaml_path: Path, model: str = "claude-sonnet-4-6") -> dict:
    """Load a product-specific YAML file and run agnostic extraction."""
    data = yaml.safe_load(Path(yaml_path).read_text())
    return extract_agnostic(data, model=model)
