"""
Stage 4 — Product-Specific Ingestion.

Reads a validated product-specific YAML dict (or file) and writes
the Qualification → Topic → Subtopic → LearningObjective graph to Neo4j.

All writes use MERGE — fully idempotent. Re-running on the same
(code, syllabus_year, revision) is safe.

Also creates SUPERSEDES relationship if a prior version exists.
"""
from __future__ import annotations

import logging
from pathlib import Path

import yaml

from cambridge_kg.driver import kg_session

logger = logging.getLogger(__name__)


def _slug(text: str) -> str:
    """Convert text to a lowercase hyphenated slug."""
    import re
    text = text.lower().strip()
    text = re.sub(r"[^a-z0-9]+", "-", text)
    return text.strip("-")


def ingest(data: dict) -> dict:
    """
    Ingest a qualification dict into Neo4j.
    Returns stats dict.
    """
    qual = data["qualification"]
    code = qual["code"]
    year = qual["syllabus_year"]
    revision = qual.get("revision", 0)

    stats = {
        "qualifications": 0,
        "topics": 0,
        "subtopics": 0,
        "learning_objectives": 0,
        "has_topic": 0,
        "has_subtopic": 0,
        "has_lo": 0,
        "prerequisite_of": 0,
        "supersedes": 0,
    }

    with kg_session() as session:
        # --- Qualification node (composite key: code + year + revision) ---
        session.run("""
            MERGE (q:Qualification {code: $code, syllabus_year: $year, revision: $revision})
            SET q.name          = $name,
                q.level         = $level,
                q.awarding_body = $awarding_body,
                q.age_range     = $age_range,
                q.tiers         = $tiers,
                q.active        = $active
        """, code=code, year=year, revision=revision,
             name=qual.get("name", ""),
             level=qual.get("level", ""),
             awarding_body=qual.get("awarding_body", "Cambridge International"),
             age_range=qual.get("age_range", ""),
             tiers=qual.get("tiers", []),
             active=qual.get("active", True))
        stats["qualifications"] += 1

        # --- SUPERSEDES: link to any prior version ---
        result = session.run("""
            MATCH (q:Qualification {code: $code, syllabus_year: $year, revision: $revision})
            MATCH (prior:Qualification {code: $code})
            WHERE prior.syllabus_year < $year
               OR (prior.syllabus_year = $year AND prior.revision < $revision)
            MERGE (q)-[:SUPERSEDES]->(prior)
            RETURN count(*) AS n
        """, code=code, year=year, revision=revision)
        stats["supersedes"] = result.single()["n"]

        # --- Topics ---
        for topic in qual.get("topics", []):
            topic_id = topic.get("id") or f"{code}-{_slug(topic['name'])}"
            session.run("""
                MERGE (t:Topic {id: $id})
                SET t.name              = $name,
                    t.order             = $order,
                    t.qualification_code = $code
            """, id=topic_id, name=topic["name"],
                 order=topic.get("order", 0), code=code)
            stats["topics"] += 1

            session.run("""
                MATCH (q:Qualification {code: $code, syllabus_year: $year, revision: $revision})
                MATCH (t:Topic {id: $topic_id})
                MERGE (q)-[:HAS_TOPIC]->(t)
            """, code=code, year=year, revision=revision, topic_id=topic_id)
            stats["has_topic"] += 1

            # --- Subtopics ---
            for subtopic in topic.get("subtopics", []):
                st_id = subtopic.get("id") or f"{topic_id}-{_slug(subtopic['name'])}"
                session.run("""
                    MERGE (st:Subtopic {id: $id})
                    SET st.name    = $name,
                        st.tier    = $tier,
                        st.topic_id = $topic_id
                """, id=st_id, name=subtopic["name"],
                     tier=subtopic.get("tier"), topic_id=topic_id)
                stats["subtopics"] += 1

                session.run("""
                    MATCH (t:Topic {id: $topic_id})
                    MATCH (st:Subtopic {id: $st_id})
                    MERGE (t)-[:HAS_SUBTOPIC]->(st)
                """, topic_id=topic_id, st_id=st_id)
                stats["has_subtopic"] += 1

                # --- Learning Objectives ---
                for lo in subtopic.get("learning_objectives", []):
                    lo_id = lo.get("id") or f"{st_id}-lo"
                    session.run("""
                        MERGE (lo:LearningObjective {id: $id})
                        SET lo.text                  = $text,
                            lo.tier                  = $tier,
                            lo.bloom_level           = $bloom_level,
                            lo.difficulty            = $difficulty,
                            lo.lo_type               = $lo_type,
                            lo.exam_command          = $exam_command,
                            lo.bkt_p_init            = $bkt_p_init,
                            lo.bkt_p_learn           = $bkt_p_learn,
                            lo.bkt_p_slip            = $bkt_p_slip,
                            lo.bkt_p_guess           = $bkt_p_guess,
                            lo.qualification_code    = $qual_code,
                            lo.syllabus_year         = $year
                    """, id=lo_id, text=lo.get("text", ""),
                         tier=lo.get("tier"),
                         bloom_level=lo.get("bloom_level", "understand"),
                         difficulty=lo.get("difficulty", 2),
                         lo_type=lo.get("lo_type", "procedural"),
                         exam_command=lo.get("exam_command", ""),
                         bkt_p_init=lo.get("bkt_p_init", 0.10),
                         bkt_p_learn=lo.get("bkt_p_learn", 0.25),
                         bkt_p_slip=lo.get("bkt_p_slip", 0.10),
                         bkt_p_guess=lo.get("bkt_p_guess", 0.20),
                         qual_code=code,
                         year=year)
                    stats["learning_objectives"] += 1

                    session.run("""
                        MATCH (st:Subtopic {id: $st_id})
                        MATCH (lo:LearningObjective {id: $lo_id})
                        MERGE (st)-[:HAS_LO]->(lo)
                    """, st_id=st_id, lo_id=lo_id)
                    stats["has_lo"] += 1

                    # --- Prerequisites ---
                    for prereq in lo.get("prerequisites", []):
                        session.run("""
                            MATCH (from_lo:LearningObjective {id: $from_id})
                            MATCH (to_lo:LearningObjective {id: $to_id})
                            MERGE (from_lo)-[:PREREQUISITE_OF {strength: $strength}]->(to_lo)
                        """, from_id=prereq["id"], to_id=lo_id,
                             strength=prereq.get("strength", "soft"))
                        stats["prerequisite_of"] += 1

    logger.info(
        "Ingested %s (year=%s): %d topics, %d subtopics, %d LOs",
        code, year, stats["topics"], stats["subtopics"], stats["learning_objectives"],
    )
    return stats


def ingest_file(yaml_path: Path) -> dict:
    """Load a YAML file and ingest it."""
    data = yaml.safe_load(Path(yaml_path).read_text())
    return ingest(data)
