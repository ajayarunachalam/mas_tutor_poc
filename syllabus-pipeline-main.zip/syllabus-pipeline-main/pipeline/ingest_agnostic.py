"""
Stage 4b — Product-Agnostic Ingestion.

Reads a concept mapping YAML dict (or file) and creates:
  - ConceptInstance nodes (MERGE on id)
  - TEACHES:  LearningObjective → ConceptInstance
  - INSTANCE_OF: ConceptInstance → Concept
  - AT_LEVEL:    ConceptInstance → Qualification
  - DEEPENS:     ConceptInstance (d1) → ConceptInstance (d2) for same Concept within a qual

All writes use MERGE — fully idempotent.
"""
from __future__ import annotations

import logging
from collections import defaultdict
from pathlib import Path

import yaml

from cambridge_kg.driver import kg_session

logger = logging.getLogger(__name__)


def _ci_id(concept_id: str, qual_code: str, depth: int) -> str:
    """Construct a ConceptInstance node id."""
    return f"{concept_id}-{qual_code}-d{depth}"


def ingest_agnostic(mapping_data: dict) -> dict:
    """
    Ingest concept mapping dict into Neo4j.

    Creates ConceptInstance nodes and all bridge relationships.
    Returns stats dict.
    """
    code = mapping_data["qualification_code"]
    year = mapping_data["syllabus_year"]
    mappings = mapping_data.get("concept_mappings", [])

    stats = {
        "concept_instances": 0,
        "teaches": 0,
        "instance_of": 0,
        "at_level": 0,
        "deepens": 0,
    }

    # Group by concept_id: {concept_id: {depth: [ci_id, ...]}}
    # Used to derive DEEPENS relationships after all nodes created
    concept_depth_map: dict[str, dict[int, str]] = defaultdict(dict)

    with kg_session() as session:
        for mapping in mappings:
            lo_id = mapping["lo_id"]

            for c in mapping.get("concepts", []):
                concept_id = c["concept_id"]
                depth = c.get("depth", 1)  # default depth=1 for older mapping format
                ci_id = _ci_id(concept_id, code, depth)

                # ConceptInstance node
                session.run("""
                    MERGE (ci:ConceptInstance {id: $ci_id})
                    SET ci.depth              = $depth,
                        ci.qualification_code = $qual_code
                """, ci_id=ci_id, depth=depth, qual_code=code)
                stats["concept_instances"] += 1

                concept_depth_map[concept_id][depth] = ci_id

                # TEACHES: LO → ConceptInstance
                session.run("""
                    MATCH (lo:LearningObjective {id: $lo_id})
                    MATCH (ci:ConceptInstance {id: $ci_id})
                    MERGE (lo)-[:TEACHES]->(ci)
                """, lo_id=lo_id, ci_id=ci_id)
                stats["teaches"] += 1

                # INSTANCE_OF: ConceptInstance → Concept
                session.run("""
                    MATCH (ci:ConceptInstance {id: $ci_id})
                    MATCH (c:Concept {id: $concept_id})
                    MERGE (ci)-[:INSTANCE_OF]->(c)
                """, ci_id=ci_id, concept_id=concept_id)
                stats["instance_of"] += 1

                # AT_LEVEL: ConceptInstance → Qualification
                session.run("""
                    MATCH (ci:ConceptInstance {id: $ci_id})
                    MATCH (q:Qualification {code: $code, syllabus_year: $year})
                    MERGE (ci)-[:AT_LEVEL]->(q)
                """, ci_id=ci_id, code=code, year=year)
                stats["at_level"] += 1

        # DEEPENS: for each concept with multiple depths, link d1→d2→d3
        for concept_id, depth_map in concept_depth_map.items():
            sorted_depths = sorted(depth_map.keys())
            for i in range(len(sorted_depths) - 1):
                d_from = sorted_depths[i]
                d_to = sorted_depths[i + 1]
                ci_from = depth_map[d_from]
                ci_to = depth_map[d_to]
                session.run("""
                    MATCH (from_ci:ConceptInstance {id: $from_id})
                    MATCH (to_ci:ConceptInstance {id: $to_id})
                    MERGE (from_ci)-[:DEEPENS]->(to_ci)
                """, from_id=ci_from, to_id=ci_to)
                stats["deepens"] += 1

    logger.info(
        "Ingested agnostic mappings for %s (%s): %d CIs, %d TEACHES, %d DEEPENS",
        code, year, stats["concept_instances"], stats["teaches"], stats["deepens"],
    )
    return stats


def ingest_agnostic_file(yaml_path: Path) -> dict:
    """Load a concept mapping YAML file and ingest it."""
    data = yaml.safe_load(Path(yaml_path).read_text())
    return ingest_agnostic(data)
