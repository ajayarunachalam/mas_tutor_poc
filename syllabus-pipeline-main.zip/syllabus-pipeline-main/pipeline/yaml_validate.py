"""
Stage 3 — YAML Validation.

Validates a product-specific qualification dict against the JSON Schema.
Returns a ValidationResult with pass/fail and any errors.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path

import yaml
import jsonschema

logger = logging.getLogger(__name__)

_SCHEMA_PATH = Path(__file__).parent.parent / "schemas" / "product_specific.schema.yaml"


@dataclass
class ValidationResult:
    valid: bool
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    lo_count: int = 0
    topic_count: int = 0


def _load_schema() -> dict:
    return yaml.safe_load(_SCHEMA_PATH.read_text())


def _count_los(qual: dict) -> tuple[int, int]:
    """Return (topic_count, lo_count)."""
    topics = qual.get("topics", [])
    los = sum(
        len(st.get("learning_objectives", []))
        for t in topics
        for st in t.get("subtopics", [])
    )
    return len(topics), los


def validate(data: dict) -> ValidationResult:
    """
    Validate a qualification dict (as returned by llm_extract_product.extract).
    Returns ValidationResult.
    """
    schema = _load_schema()
    errors = []
    warnings = []

    # JSON Schema validation
    validator = jsonschema.Draft7Validator(schema)
    for error in validator.iter_errors(data):
        path = " > ".join(str(p) for p in error.absolute_path) or "root"
        errors.append(f"{path}: {error.message}")

    qual = data.get("qualification", {})
    topic_count, lo_count = _count_los(qual)

    # Business rule checks
    if lo_count == 0:
        errors.append("No learning objectives extracted")
    elif lo_count < 5:
        warnings.append(f"Very few LOs ({lo_count}) — extraction may be incomplete")

    if topic_count == 0:
        errors.append("No topics extracted")

    # Check for duplicate LO ids
    lo_ids = [
        lo["id"]
        for t in qual.get("topics", [])
        for st in t.get("subtopics", [])
        for lo in st.get("learning_objectives", [])
        if "id" in lo
    ]
    dupes = {id_ for id_ in lo_ids if lo_ids.count(id_) > 1}
    if dupes:
        warnings.append(f"Duplicate LO ids: {sorted(dupes)[:5]}")

    valid = len(errors) == 0
    result = ValidationResult(
        valid=valid,
        errors=errors,
        warnings=warnings,
        lo_count=lo_count,
        topic_count=topic_count,
    )

    if valid:
        logger.info("Validation PASSED: %d topics, %d LOs", topic_count, lo_count)
    else:
        logger.error("Validation FAILED: %d errors", len(errors))
        for e in errors:
            logger.error("  %s", e)
    for w in warnings:
        logger.warning("  WARNING: %s", w)

    return result


def validate_file(yaml_path: Path) -> ValidationResult:
    """Load a YAML file and validate it."""
    data = yaml.safe_load(Path(yaml_path).read_text())
    return validate(data)
