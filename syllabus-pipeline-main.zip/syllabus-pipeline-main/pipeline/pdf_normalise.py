"""
Stage 1 — PDF Normalisation.

Extracts clean, structured text from a Cambridge syllabus PDF.
Splits output into:
  - metadata_text: first N pages (cover, overview, assessment objectives)
  - topic_sections: list of {heading, text} dicts, one per subject content topic

Uses pdfplumber (primary) with a pymupdf fallback.
"""
from __future__ import annotations

import re
import logging
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)

# Lines containing these strings are navigation/header artifacts to strip
_STRIP_PATTERNS = [
    r"^Cambridge IGCSE.*syllabus for",
    r"^Cambridge (AS & A Level|A Level|IGCSE).*syllabus for",
    r"^Back to contents",
    r"^Back to cont",
    r"^\d+\s*$",                   # lone page numbers
    r"^Notes and examples\s*$",    # column header
]
_STRIP_RE = re.compile("|".join(_STRIP_PATTERNS), re.IGNORECASE)

# Topic heading: line that starts with a digit, space, then capitalised word(s)
# e.g. "1 Number", "4 Geometry and Trigonometry"
_TOPIC_HEADING_RE = re.compile(r"^(\d{1,2})\s+([A-Z][A-Za-z ,/&-]+)$")

# Content section sentinel
_CONTENT_SENTINEL_RE = re.compile(r"Subject content", re.IGNORECASE)


@dataclass
class NormalisedPDF:
    pdf_path: Path
    page_count: int
    metadata_text: str           # pre-content pages
    topic_sections: list[dict]   # [{"heading": "1 Number", "number": 1, "text": "..."}]
    confidence: float = 1.0      # 0-1; <0.7 triggers flagging


def _clean_line(line: str) -> str:
    return line.strip()


def _extract_text_pdfplumber(pdf_path: Path) -> list[str]:
    """Return list of page texts using pdfplumber."""
    import pdfplumber
    texts = []
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            texts.append(page.extract_text() or "")
    return texts


def _extract_text_pymupdf(pdf_path: Path) -> list[str]:
    """Fallback: return list of page texts using pymupdf."""
    import fitz  # pymupdf
    doc = fitz.open(str(pdf_path))
    return [page.get_text() for page in doc]


def _extract_pages(pdf_path: Path) -> tuple[list[str], str]:
    """Extract page texts. Returns (pages, method_used)."""
    try:
        pages = _extract_text_pdfplumber(pdf_path)
        return pages, "pdfplumber"
    except Exception as e:
        logger.warning("pdfplumber failed (%s), trying pymupdf", e)
    try:
        pages = _extract_text_pymupdf(pdf_path)
        return pages, "pymupdf"
    except Exception as e:
        raise RuntimeError(f"Both PDF extraction methods failed: {e}") from e


def _clean_page(raw: str) -> str:
    """Strip artifacts and return clean page text."""
    lines = []
    for line in raw.splitlines():
        line = _clean_line(line)
        if not line:
            continue
        if _STRIP_RE.search(line):
            continue
        lines.append(line)
    return "\n".join(lines)


def normalise(pdf_path: Path, metadata_pages: int = 12) -> NormalisedPDF:
    """
    Main entry point. Returns a NormalisedPDF with metadata_text and topic_sections.

    metadata_pages: how many pages to treat as metadata (cover, overview, AOs).
                    Subject content detection overrides this if found earlier.
    """
    pdf_path = Path(pdf_path)
    logger.info("Normalising %s", pdf_path.name)

    pages, method = _extract_pages(pdf_path)
    logger.info("Extracted %d pages via %s", len(pages), method)

    # Find where subject content starts
    content_start = metadata_pages
    for i, raw in enumerate(pages):
        if _CONTENT_SENTINEL_RE.search(raw) and i > 5:
            content_start = i
            break

    # Clean all pages
    cleaned = [_clean_page(p) for p in pages]

    metadata_text = "\n\n".join(cleaned[:content_start])
    content_pages = cleaned[content_start:]

    # Join all content and split into topic sections
    full_content = "\n".join(content_pages)
    topic_sections = _split_into_topics(full_content)

    if not topic_sections:
        logger.warning("No topic sections detected — returning full content as one section")
        topic_sections = [{"heading": "Content", "number": 0, "text": full_content}]
        confidence = 0.5
    else:
        logger.info("Detected %d topic sections", len(topic_sections))
        confidence = 1.0

    return NormalisedPDF(
        pdf_path=pdf_path,
        page_count=len(pages),
        metadata_text=metadata_text,
        topic_sections=topic_sections,
        confidence=confidence,
    )


_NON_SUBJECT_HEADINGS = re.compile(
    r"assessment|details|overview|introduction|aims|objectives|weighting|grading|subject content",
    re.IGNORECASE,
)


def _split_into_topics(text: str) -> list[dict]:
    """
    Split content text into topic sections by detecting numbered headings.

    Merges duplicate same-named sections (Cambridge Core + Extended tiers
    share the same topic numbers). Non-subject headings are excluded.

    Returns list of {heading, number, text} dicts, one per unique topic.
    """
    lines = text.splitlines()
    raw_sections: list[dict] = []
    current_heading = None
    current_number = 0
    current_lines: list[str] = []

    for line in lines:
        m = _TOPIC_HEADING_RE.match(line.strip())
        if (
            m
            and len(m.group(2).split()) <= 4
            and not _NON_SUBJECT_HEADINGS.search(m.group(2))
        ):
            # Save previous section
            if current_heading and current_lines:
                raw_sections.append({
                    "heading": current_heading,
                    "number": current_number,
                    "text": "\n".join(current_lines).strip(),
                })
            current_number = int(m.group(1))
            current_heading = f"{m.group(1)} {m.group(2).strip()}"
            current_lines = []
        else:
            if current_heading is not None:
                current_lines.append(line)

    # Final section
    if current_heading and current_lines:
        raw_sections.append({
            "heading": current_heading,
            "number": current_number,
            "text": "\n".join(current_lines).strip(),
        })

    # Merge duplicate same-heading sections (Core + Extended tiers)
    merged: dict[str, dict] = {}
    for s in raw_sections:
        key = s["heading"].lower()
        if key in merged:
            merged[key]["text"] = merged[key]["text"] + "\n\n" + s["text"]
        else:
            merged[key] = dict(s)

    return list(merged.values())
