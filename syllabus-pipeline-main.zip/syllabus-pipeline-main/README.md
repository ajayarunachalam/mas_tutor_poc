# syllabus-pipeline

Extracts structured learning content from Cambridge International Education PDF syllabuses and ingests it into the Neo4j knowledge graph.

Consumes the shared driver and schema from the [knowledge-graph](https://github.com/tgs21/knowledge-graph) repo.

---

## Pipeline Architecture

```
PDF Syllabus
     │
     ▼
┌─────────────────────────────────────────────────────────────────┐
│  Stage 1: extract-product                                        │
│  LLM (claude-haiku-4-5) reads PDF → structured YAML             │
│  Qualification → Topic → Subtopic → LearningObjective           │
└────────────────────────────┬────────────────────────────────────┘
                             │ output/product_specific/<code>_<year>_r<n>.yaml
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│  Stage 2: ingest (product-specific layer)                        │
│  YAML → Neo4j MERGE: Qualification/Topic/Subtopic/LO nodes       │
│  Idempotent — safe to re-run                                     │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│  Stage 3: extract-agnostic                                       │
│  LLM (claude-sonnet-4-6) maps LOs → Concept nodes in ontology   │
│  Output: concept_mappings YAML with depth + concept_id per LO   │
└────────────────────────────┬────────────────────────────────────┘
                             │ output/product_agnostic/<code>_<year>_mapping.yaml
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│  Stage 4: ingest-agnostic (bridge layer)                         │
│  ConceptInstance nodes + TEACHES / INSTANCE_OF / AT_LEVEL /     │
│  DEEPENS edges into Neo4j. Idempotent via MERGE.                 │
└─────────────────────────────────────────────────────────────────┘
```

### Graph Layers

```
Product-Agnostic (knowledge-graph repo owns)    Product-Specific (per qualification)
────────────────────────────────────────────    ─────────────────────────────────────
Domain → Branch → Area → Concept                Qualification → Topic → Subtopic → LO
                              ↑                                                   ↓
                      ConceptInstance ◄──── TEACHES ────────────────────────────┘
                      INSTANCE_OF ↓
                           Concept
```

---

## CLI Reference

```bash
# Full pipeline: extract product YAML from PDF, validate, ingest to Neo4j
uv run python cli.py run --pdf syllabuses/0610_2026_syllabus.pdf --code 0610

# Extract product YAML only (no ingest)
uv run python cli.py extract-product --pdf syllabuses/0610_2026_syllabus.pdf --code 0610

# Ingest an existing product YAML to Neo4j
uv run python cli.py ingest --yaml output/product_specific/0610_2026_r0.yaml

# Extract agnostic concept mapping from a product YAML
uv run python cli.py extract-agnostic --yaml output/product_specific/0610_2026_r0.yaml

# Ingest an agnostic concept mapping YAML to Neo4j
uv run python cli.py ingest-agnostic --yaml output/product_agnostic/0610_2026_mapping.yaml

# Validate a product YAML against schema
uv run python cli.py validate --yaml output/product_specific/0610_2026_r0.yaml
```

### Batch Scripts

```bash
# Download all Cambridge IGCSE + A-Level syllabus PDFs
uv run python scripts/download_syllabuses.py --out ~/projects/mas_education_poc/syllabuses/

# Process all PDFs through the full pipeline (idempotent — skips existing)
uv run python scripts/batch_process_all.py

# Only run product extraction + ingest (skip agnostic steps)
uv run python scripts/batch_process_all.py --skip-agnostic

# Only run agnostic steps for qualifications with existing product YAMLs
uv run python scripts/batch_process_all.py --only-agnostic

# Process a single qualification code only
uv run python scripts/batch_process_all.py --code 0610

# Repair common LLM extraction errors in output/flagged/ and re-ingest
uv run python scripts/repair_flagged.py

# Dry run (validate only, no ingest)
uv run python scripts/repair_flagged.py --dry-run
```

---

## Setup

### Prerequisites

- Neo4j 5.x running (POC: `cd ~/projects/mas_education_poc && docker compose -f docker-compose.neo4j.yml up -d`)
- Python 3.11+, uv
- Anthropic API key in `.env`

### Install

```bash
cd syllabus-pipeline
cp .env.example .env    # add ANTHROPIC_API_KEY, NEO4J_URI, NEO4J_PASSWORD
uv sync
```

### Environment Variables

```
ANTHROPIC_API_KEY=...
NEO4J_URI=bolt://localhost:7687
NEO4J_USER=neo4j
NEO4J_PASSWORD=...
LLM_EXTRACT_MODEL=claude-haiku-4-5-20251001   # product extraction (cost-efficient)
LLM_AGNOSTIC_MODEL=claude-sonnet-4-6           # agnostic mapping (higher accuracy)
```

---

## Output Directory

```
output/
├── product_specific/   # <code>_<year>_r<n>.yaml — validated product YAMLs
├── product_agnostic/   # <code>_<year>_mapping.yaml — concept mapping YAMLs
└── flagged/            # YAMLs that failed validation (awaiting repair)
```

> `output/` is gitignored — YAML artifacts live on disk only, not in version control.

---

## Current Processing Status (as of 2026-03-08)

| Metric | Count |
|--------|-------|
| PDFs downloaded | 138 |
| Qualifications fully processed (product + agnostic) | 91 |
| Qualifications product-only (agnostic pending) | 11 |
| Qualifications not processed (API credit exhaustion) | **36** |
| Neo4j Qualifications | 102 |
| Neo4j LearningObjectives | 8,222 |
| Neo4j ConceptInstances | 3,156 |
| Neo4j Concepts (product-agnostic, unchanged) | 483 |

### Missing Qualifications — API Credit Exhaustion

The following 36 qualifications could not be processed because Anthropic API credits
were exhausted during the batch run. PDFs are downloaded and ready in
`~/projects/mas_education_poc/syllabuses/`. Re-run `batch_process_all.py` once credits
are restored — it is fully idempotent and will skip the 102 already processed.

| Code | Level | Subject |
|------|-------|---------|
| 8102 | AS Level | US History since 1877 |
| 8238 | AS Level | Chinese Language |
| 8291 | AS Level | Environmental Management |
| 8386 | AS Level | Sport & Physical Education |
| 8679 | AS Level | Afrikaans Language |
| 8680 | AS & A Level | Arabic Language |
| 8684 | AS & A Level | Portuguese Language |
| 8686 | AS Level | Urdu Language |
| 8689 | AS & A Level | Tamil Language |
| 8695 | AS Level | Language and Literature in English |
| 9084 | AS & A Level | Law |
| 9231 | AS & A Level | Further Mathematics *(2028 version; 2024 version already in graph)* |
| 9274 | AS & A Level | Classical Studies |
| 9395 | AS & A Level | Travel & Tourism |
| 9481 | AS & A Level | Digital Media & Design |
| 9483 | AS & A Level | Music |
| 9484 | AS & A Level | Biblical Studies |
| 9487 | AS & A Level | Hinduism |
| 9488 | AS & A Level | Islamic Studies |
| 9489 | AS & A Level | History |
| 9607 | AS & A Level | Media Studies |
| 9626 | AS & A Level | Information Technology |
| 9680 | AS & A Level | Arabic Language *(A-Level companion to 8680)* |
| 9686 | A Level | Urdu |
| 9689 | A Level | Tamil |
| 9694 | AS & A Level | Thinking Skills |
| 9699 | AS & A Level | Sociology |
| 9709 | AS & A Level | Mathematics *(2028 version; 2024 version already in graph)* |
| 9718 | AS & A Level | Portuguese Language *(A-Level companion to 8684)* |
| 9844 | A Level | Spanish Language & Literature |
| 9866 | A Level | Urdu Language & Literature |
| 9868 | A Level | Chinese Language & Literature |
| 9897 | A Level | German Language & Literature |
| 9898 | A Level | French Language & Literature |
| 9981 | AS & A Level | European History *(US centres)* |
| 9982 | AS & A Level | International History *(US centres)* |

### Resuming After API Credit Top-up

```bash
cd ~/projects/syllabus-pipeline
uv run python scripts/batch_process_all.py
```

The script skips any qualification where `output/product_specific/<code>_*.yaml` already
exists. It will pick up all 36 missing codes automatically.

If some product YAMLs fail validation after extraction, they land in `output/flagged/`.
Run the repair script to fix and re-ingest:

```bash
uv run python scripts/repair_flagged.py
```

---

## Validation

Product YAMLs are validated against `schemas/product_specific.schema.yaml` before ingest.
Common validation errors and their fixes are handled automatically by `repair_flagged.py`:

| Error | Repair Applied |
|-------|----------------|
| `level` not in enum (e.g. `AS and A-Level`) | Normalised to `A-Level` / `AS` |
| Topic `order: 0` (minimum is 1) | Renumbered from 1 |
| Subtopic with no `learning_objectives` | Removed |
| `bloom_level: explain` not valid | Mapped to `understand` |
| `lo_type: analytical` not valid | Mapped to `conceptual` |
| `difficulty` missing | Defaulted to `3` |

---

## Repository Structure

```
syllabus-pipeline/
├── cli.py                          # Main CLI entry point
├── pipeline/
│   ├── llm_extract_product.py      # Stage 1: PDF → structured YAML via LLM
│   ├── yaml_validate.py            # Schema validation
│   ├── ingest_product.py           # Stage 2: product YAML → Neo4j
│   ├── llm_extract_agnostic.py     # Stage 3: LO → Concept mapping via LLM
│   └── ingest_agnostic.py          # Stage 4: concept mappings → Neo4j
├── prompts/                        # LLM prompt templates (Markdown)
├── schemas/                        # YAML validation schemas
├── scripts/
│   ├── download_syllabuses.py      # Download all Cambridge PDFs
│   ├── batch_process_all.py        # Batch pipeline runner (idempotent)
│   └── repair_flagged.py           # Auto-repair + re-ingest flagged YAMLs
└── output/                         # (gitignored) Generated YAML artifacts
    ├── product_specific/
    ├── product_agnostic/
    └── flagged/
```
