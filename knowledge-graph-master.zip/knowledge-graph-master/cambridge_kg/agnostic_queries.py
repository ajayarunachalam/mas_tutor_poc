"""
Cambridge Knowledge Graph — Product-Agnostic Query Helpers.

Provides Cypher-backed helpers for traversing the product-agnostic
layer: Domain → Branch → Area → Concept.
"""
from __future__ import annotations

from cambridge_kg.driver import kg_session


def get_all_domains() -> list[dict]:
    """Return all Domain nodes."""
    with kg_session() as session:
        result = session.run("MATCH (d:Domain) RETURN d ORDER BY d.name")
        return [dict(record["d"]) for record in result]


def get_domain(domain_id: str) -> dict | None:
    """Fetch a single Domain by id."""
    with kg_session() as session:
        result = session.run("MATCH (d:Domain {id: $id}) RETURN d", id=domain_id)
        record = result.single()
        return dict(record["d"]) if record else None


def get_branches(domain_id: str) -> list[dict]:
    """Return all Branches under a Domain, ordered by name."""
    cypher = """
        MATCH (d:Domain {id: $domain_id})-[:HAS_BRANCH]->(b:Branch)
        RETURN b ORDER BY b.name
    """
    with kg_session() as session:
        result = session.run(cypher, domain_id=domain_id)
        return [dict(record["b"]) for record in result]


def get_areas(branch_id: str) -> list[dict]:
    """Return all Areas under a Branch, ordered by name."""
    cypher = """
        MATCH (b:Branch {id: $branch_id})-[:HAS_AREA]->(a:Area)
        RETURN a ORDER BY a.name
    """
    with kg_session() as session:
        result = session.run(cypher, branch_id=branch_id)
        return [dict(record["a"]) for record in result]


def get_concepts_in_area(area_id: str) -> list[dict]:
    """Return all Concepts under an Area, ordered by name."""
    cypher = """
        MATCH (a:Area {id: $area_id})-[:HAS_CONCEPT]->(c:Concept)
        RETURN c ORDER BY c.name
    """
    with kg_session() as session:
        result = session.run(cypher, area_id=area_id)
        return [dict(record["c"]) for record in result]


def find_concept_by_name(name: str) -> dict | None:
    """Find a Concept by exact name (case-insensitive)."""
    cypher = """
        MATCH (c:Concept)
        WHERE toLower(c.name) = toLower($name)
        RETURN c LIMIT 1
    """
    with kg_session() as session:
        result = session.run(cypher, name=name)
        record = result.single()
        return dict(record["c"]) if record else None


def get_concept_qualifications(concept_id: str) -> list[dict]:
    """
    Return all Qualifications that teach this Concept (via ConceptInstance).
    Includes the depth at which it is taught.
    """
    cypher = """
        MATCH (c:Concept {id: $concept_id})
              <-[:INSTANCE_OF]-(ci:ConceptInstance)
              -[:AT_LEVEL]->(q:Qualification)
        RETURN q, ci.depth AS depth
        ORDER BY q.level, q.code
    """
    with kg_session() as session:
        result = session.run(cypher, concept_id=concept_id)
        return [
            {"qualification": dict(record["q"]), "depth": record["depth"]}
            for record in result
        ]


def get_domain_tree(domain_id: str) -> dict:
    """
    Return the full Domain→Branch→Area→Concept tree for a given domain.
    Used by the dashboard Knowledge Map view.
    """
    cypher = """
        MATCH (d:Domain {id: $domain_id})-[:HAS_BRANCH]->(b:Branch)
              -[:HAS_AREA]->(a:Area)
        OPTIONAL MATCH (a)-[:HAS_CONCEPT]->(c:Concept)
        RETURN d, b, a, collect(c) AS concepts
        ORDER BY b.name, a.name
    """
    with kg_session() as session:
        result = session.run(cypher, domain_id=domain_id)
        tree: dict = {}
        for record in result:
            d = dict(record["d"])
            b = dict(record["b"])
            a = dict(record["a"])
            concepts = [dict(c) for c in record["concepts"] if c is not None]

            if not tree:
                tree = {**d, "branches": {}}
            branch_id = b["id"]
            if branch_id not in tree["branches"]:
                tree["branches"][branch_id] = {**b, "areas": {}}
            area_id = a["id"]
            tree["branches"][branch_id]["areas"][area_id] = {**a, "concepts": concepts}

        # Convert dicts to lists for serialisation
        if tree:
            tree["branches"] = [
                {**bv, "areas": list(bv["areas"].values())}
                for bv in tree["branches"].values()
            ]
        return tree


def get_area_for_concept(concept_id: str) -> dict | None:
    """Return the Area that a Concept belongs to (via HAS_CONCEPT)."""
    cypher = """
        MATCH (a:Area)-[:HAS_CONCEPT]->(c:Concept {id: $concept_id})
        RETURN a LIMIT 1
    """
    with kg_session() as session:
        result = session.run(cypher, concept_id=concept_id)
        record = result.single()
        return dict(record["a"]) if record else None
