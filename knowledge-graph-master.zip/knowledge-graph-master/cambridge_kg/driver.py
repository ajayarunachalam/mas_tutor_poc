"""
Cambridge Knowledge Graph — Shared Neo4j Driver.

Extracted from MAS Education POC db/kg.py for use as a shared module
across all Cambridge KG repos (knowledge-graph, syllabus-pipeline, mas_education_poc).

Usage:
    from kg_driver import get_driver, close_driver, kg_session

    with kg_session() as session:
        result = session.run("MATCH (d:Domain) RETURN d.name")
        for record in result:
            print(record["d.name"])

Config (via .env or environment):
    NEO4J_URI      — default: bolt://localhost:7687
    NEO4J_USER     — default: neo4j
    NEO4J_PASSWORD — required
    NEO4J_DATABASE — default: neo4j
"""
from __future__ import annotations

import os
import logging
from contextlib import contextmanager
from pathlib import Path
from typing import Generator

from dotenv import load_dotenv
from neo4j import GraphDatabase, Driver, Session

load_dotenv()

logger = logging.getLogger(__name__)

_NEO4J_URI      = os.getenv("NEO4J_URI",      "bolt://localhost:7687")
_NEO4J_USER     = os.getenv("NEO4J_USER",     "neo4j")
_NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD", "")
_NEO4J_DATABASE = os.getenv("NEO4J_DATABASE", "neo4j")

_driver: Driver | None = None


def get_driver() -> Driver:
    """Return (or lazily create) the module-level Neo4j driver singleton."""
    global _driver
    if _driver is None:
        _driver = GraphDatabase.driver(
            _NEO4J_URI,
            auth=(_NEO4J_USER, _NEO4J_PASSWORD),
        )
        logger.info("Neo4j driver initialised → %s", _NEO4J_URI)
    return _driver


def close_driver() -> None:
    """Explicitly close the driver — call at process shutdown."""
    global _driver
    if _driver is not None:
        _driver.close()
        _driver = None
        logger.info("Neo4j driver closed.")


@contextmanager
def kg_session() -> Generator[Session, None, None]:
    """Context manager that yields an open Neo4j session."""
    driver = get_driver()
    with driver.session(database=_NEO4J_DATABASE) as session:
        yield session


def health_check() -> bool:
    """Return True if Neo4j is reachable and responding."""
    try:
        with kg_session() as session:
            result = session.run("RETURN 1 AS ok")
            record = result.single()
            return record is not None and record["ok"] == 1
    except Exception as exc:
        logger.error("Neo4j health check failed: %s", exc)
        return False
