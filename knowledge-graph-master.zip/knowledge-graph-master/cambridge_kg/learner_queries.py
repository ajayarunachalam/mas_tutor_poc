"""
Cambridge Knowledge Graph — Learner Mastery on Product-Agnostic Layer.

Derives learner concept/area/domain mastery from the product-specific
HAS_MASTERY edges (Learner → LearningObjective), traversing upward through
ConceptInstance → Concept → Area → Branch → Domain.

No mastery is stored at the concept level — it is always derived at query time.
"""
from __future__ import annotations

from cambridge_kg.driver import kg_session


def get_learner_concept_mastery(learner_id: str, concept_id: str) -> dict:
    """
    Derive a learner's mastery of a Concept by aggregating LO-level mastery.

    Returns:
        {
            concept_id: str,
            derived_mastery: float,        # average p_mastery across all contributing LOs
            contributing_lo_count: int,
            mastered_lo_count: int,
        }
    """
    cypher = """
        MATCH (learner:Learner {id: $learner_id})
              -[m:HAS_MASTERY]->(lo:LearningObjective)
              -[:TEACHES]->(ci:ConceptInstance)
              -[:INSTANCE_OF]->(c:Concept {id: $concept_id})
        RETURN avg(m.p_mastery)                                      AS derived_mastery,
               count(lo)                                             AS contributing_lo_count,
               sum(CASE WHEN m.mastered THEN 1 ELSE 0 END)          AS mastered_lo_count
    """
    with kg_session() as session:
        result = session.run(cypher, learner_id=learner_id, concept_id=concept_id)
        record = result.single()
        if record is None or record["contributing_lo_count"] == 0:
            return {
                "concept_id": concept_id,
                "derived_mastery": 0.0,
                "contributing_lo_count": 0,
                "mastered_lo_count": 0,
            }
        return {
            "concept_id": concept_id,
            "derived_mastery": record["derived_mastery"] or 0.0,
            "contributing_lo_count": record["contributing_lo_count"],
            "mastered_lo_count": record["mastered_lo_count"],
        }


def get_learner_area_mastery(learner_id: str, area_id: str) -> dict:
    """
    Derive learner mastery across all Concepts in an Area.

    Returns list of concept mastery dicts plus an area-level aggregate.
    """
    cypher = """
        MATCH (a:Area {id: $area_id})-[:HAS_CONCEPT]->(c:Concept)
        OPTIONAL MATCH (learner:Learner {id: $learner_id})
                       -[m:HAS_MASTERY]->(lo:LearningObjective)
                       -[:TEACHES]->(ci:ConceptInstance)
                       -[:INSTANCE_OF]->(c)
        RETURN c.id                                             AS concept_id,
               c.name                                          AS concept_name,
               avg(m.p_mastery)                                AS derived_mastery,
               count(DISTINCT lo)                              AS lo_count,
               sum(CASE WHEN m.mastered THEN 1 ELSE 0 END)    AS mastered_lo_count
        ORDER BY c.name
    """
    with kg_session() as session:
        result = session.run(cypher, learner_id=learner_id, area_id=area_id)
        concepts = []
        for record in result:
            concepts.append({
                "concept_id":       record["concept_id"],
                "concept_name":     record["concept_name"],
                "derived_mastery":  record["derived_mastery"] or 0.0,
                "lo_count":         record["lo_count"],
                "mastered_lo_count": record["mastered_lo_count"],
            })

    area_mastery = (
        sum(c["derived_mastery"] for c in concepts) / len(concepts)
        if concepts else 0.0
    )
    return {
        "area_id": area_id,
        "area_mastery": area_mastery,
        "concepts": concepts,
    }


def get_learner_domain_position(learner_id: str, domain_id: str) -> dict:
    """
    Full learner position on the product-agnostic graph for a domain.
    Returns the Domain→Branch→Area tree with derived mastery at each level.
    Used by the dashboard Knowledge Map tab.
    """
    cypher = """
        MATCH (d:Domain {id: $domain_id})-[:HAS_BRANCH]->(b:Branch)
              -[:HAS_AREA]->(a:Area)-[:HAS_CONCEPT]->(c:Concept)
        OPTIONAL MATCH (learner:Learner {id: $learner_id})
                       -[m:HAS_MASTERY]->(lo:LearningObjective)
                       -[:TEACHES]->(ci:ConceptInstance)
                       -[:INSTANCE_OF]->(c)
        RETURN b.id       AS branch_id,
               b.name     AS branch_name,
               a.id       AS area_id,
               a.name     AS area_name,
               c.id       AS concept_id,
               c.name     AS concept_name,
               avg(m.p_mastery)                              AS concept_mastery,
               count(DISTINCT lo)                            AS lo_count,
               sum(CASE WHEN m.mastered THEN 1 ELSE 0 END)  AS mastered_lo_count
        ORDER BY b.name, a.name, c.name
    """
    with kg_session() as session:
        result = session.run(cypher, learner_id=learner_id, domain_id=domain_id)

        branches: dict[str, dict] = {}
        for record in result:
            bid = record["branch_id"]
            aid = record["area_id"]
            if bid not in branches:
                branches[bid] = {"id": bid, "name": record["branch_name"], "areas": {}}
            if aid not in branches[bid]["areas"]:
                branches[bid]["areas"][aid] = {
                    "id": aid, "name": record["area_name"], "concepts": []
                }
            branches[bid]["areas"][aid]["concepts"].append({
                "id":             record["concept_id"],
                "name":           record["concept_name"],
                "mastery":        record["concept_mastery"] or 0.0,
                "lo_count":       record["lo_count"],
                "mastered_los":   record["mastered_lo_count"],
            })

    # Compute area and branch aggregates
    result_branches = []
    for b in branches.values():
        areas = []
        for a in b["areas"].values():
            concepts = a["concepts"]
            area_mastery = (
                sum(c["mastery"] for c in concepts) / len(concepts) if concepts else 0.0
            )
            areas.append({**a, "area_mastery": area_mastery})
        branch_mastery = (
            sum(a["area_mastery"] for a in areas) / len(areas) if areas else 0.0
        )
        result_branches.append({**b, "areas": areas, "branch_mastery": branch_mastery})

    domain_mastery = (
        sum(b["branch_mastery"] for b in result_branches) / len(result_branches)
        if result_branches else 0.0
    )

    return {
        "domain_id":      domain_id,
        "domain_mastery": domain_mastery,
        "branches":       result_branches,
    }
