"""
Phase 1 verification tests — schema and seed data.

Run after ingest/apply_schema.py and ingest/seed_agnostic.py + ingest/seed_skills.py.

Usage:
    uv run pytest tests/test_schema.py -v
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from cambridge_kg.driver import health_check, kg_session


@pytest.fixture(autouse=True)
def require_neo4j():
    if not health_check():
        pytest.skip("Neo4j not reachable")


class TestSchema:
    def test_domain_constraint_exists(self):
        with kg_session() as session:
            result = session.run("SHOW CONSTRAINTS")
            names = [r["name"] for r in result]
        assert "domain_id" in names, f"domain_id constraint missing. Found: {names}"

    def test_branch_constraint_exists(self):
        with kg_session() as session:
            result = session.run("SHOW CONSTRAINTS")
            names = [r["name"] for r in result]
        assert "branch_id" in names

    def test_area_constraint_exists(self):
        with kg_session() as session:
            result = session.run("SHOW CONSTRAINTS")
            names = [r["name"] for r in result]
        assert "area_id" in names

    def test_capability_domain_constraint_exists(self):
        with kg_session() as session:
            result = session.run("SHOW CONSTRAINTS")
            names = [r["name"] for r in result]
        assert "capability_domain_id" in names

    def test_skill_constraint_exists(self):
        with kg_session() as session:
            result = session.run("SHOW CONSTRAINTS")
            names = [r["name"] for r in result]
        assert "skill_id" in names


class TestMathematicsSeed:
    def test_mathematics_domain_exists(self):
        with kg_session() as session:
            result = session.run("MATCH (d:Domain {id: 'math'}) RETURN d.name AS name")
            record = result.single()
        assert record is not None, "Mathematics Domain node not found"
        assert record["name"] == "Mathematics"

    def test_three_branches_exist(self):
        with kg_session() as session:
            result = session.run(
                "MATCH (d:Domain {id: 'math'})-[:HAS_BRANCH]->(b) RETURN count(b) AS n"
            )
            n = result.single()["n"]
        assert n == 3, f"Expected 3 branches under Mathematics, found {n}"

    def test_pure_maths_branch_exists(self):
        with kg_session() as session:
            result = session.run(
                "MATCH (b:Branch {id: 'math-pure'}) RETURN b.name AS name"
            )
            record = result.single()
        assert record is not None
        assert record["name"] == "Pure Mathematics"

    def test_six_plus_areas_exist(self):
        with kg_session() as session:
            result = session.run(
                "MATCH (d:Domain {id: 'math'})-[:HAS_BRANCH]->()-[:HAS_AREA]->(a) "
                "RETURN count(a) AS n"
            )
            n = result.single()["n"]
        assert n >= 6, f"Expected at least 6 areas under Mathematics, found {n}"

    def test_poc_mathdomain_area_alignment(self):
        """Areas covering the 6 POC MathDomain names exist."""
        expected_poc_domains = {"Number", "Algebra", "Geometry", "Calculus", "Statistics", "Discrete"}
        with kg_session() as session:
            result = session.run(
                "MATCH (a:Area) WHERE a.poc_math_domain IS NOT NULL "
                "RETURN collect(a.poc_math_domain) AS domains"
            )
            domains = set(result.single()["domains"])
        # Discrete Mathematics maps to "Discrete"
        missing = expected_poc_domains - domains
        assert not missing, f"Missing POC MathDomain coverage in Areas: {missing}"

    def test_concept_seed_nodes_exist(self):
        with kg_session() as session:
            result = session.run(
                "MATCH (a:Area)-[:HAS_CONCEPT]->(c:Concept) RETURN count(c) AS n"
            )
            n = result.single()["n"]
        assert n >= 10, f"Expected at least 10 seed Concept nodes, found {n}"

    def test_differentiation_concept_exists(self):
        """Key spiral concept from POC must be present."""
        with kg_session() as session:
            result = session.run(
                "MATCH (c:Concept {id: 'concept-differentiation'}) RETURN c.name AS name"
            )
            record = result.single()
        assert record is not None, "concept-differentiation not found in graph"


class TestP21Skills:
    def test_four_capability_domains_exist(self):
        with kg_session() as session:
            result = session.run(
                "MATCH (cd:CapabilityDomain {framework: 'P21'}) RETURN count(cd) AS n"
            )
            n = result.single()["n"]
        assert n == 4, f"Expected 4 P21 CapabilityDomains, found {n}"

    def test_critical_thinking_domain_exists(self):
        with kg_session() as session:
            result = session.run(
                "MATCH (cd:CapabilityDomain {id: 'p21-critical-thinking'}) RETURN cd.name AS name"
            )
            record = result.single()
        assert record is not None
        assert "Critical Thinking" in record["name"]

    def test_skills_have_categories(self):
        with kg_session() as session:
            result = session.run(
                "MATCH (s:Skill) WHERE s.category IS NULL RETURN count(s) AS n"
            )
            n = result.single()["n"]
        assert n == 0, f"{n} Skill nodes have no category property"

    def test_all_capability_domains_have_skills(self):
        with kg_session() as session:
            result = session.run("""
                MATCH (cd:CapabilityDomain {framework: 'P21'})
                WHERE NOT (cd)-[:HAS_SKILL]->()
                RETURN count(cd) AS n
            """)
            n = result.single()["n"]
        assert n == 0, f"{n} CapabilityDomains have no HAS_SKILL edges"
