// Cambridge Knowledge Graph — Neo4j Schema
// Applies alongside existing MAS Education POC schema.
// Safe to re-run (IF NOT EXISTS guards throughout).
// Run via: python ingest/apply_schema.py

// ===== PRODUCT-AGNOSTIC LAYER =====

CREATE CONSTRAINT domain_id IF NOT EXISTS
  FOR (d:Domain) REQUIRE d.id IS UNIQUE;

CREATE CONSTRAINT branch_id IF NOT EXISTS
  FOR (b:Branch) REQUIRE b.id IS UNIQUE;

CREATE CONSTRAINT area_id IF NOT EXISTS
  FOR (a:Area) REQUIRE a.id IS UNIQUE;

// Note: Concept constraints already exist in POC schema (concept_id).
// The Concept node type is shared — no duplicate constraint needed.

// ===== P21 SKILLS GRAPH =====

CREATE CONSTRAINT capability_domain_id IF NOT EXISTS
  FOR (cd:CapabilityDomain) REQUIRE cd.id IS UNIQUE;

CREATE CONSTRAINT skill_id IF NOT EXISTS
  FOR (s:Skill) REQUIRE s.id IS UNIQUE;

// ===== INDEXES =====

CREATE INDEX domain_type IF NOT EXISTS
  FOR (d:Domain) ON (d.type);

CREATE INDEX domain_name IF NOT EXISTS
  FOR (d:Domain) ON (d.name);

CREATE INDEX branch_domain IF NOT EXISTS
  FOR (b:Branch) ON (b.domain_id);

CREATE INDEX area_branch IF NOT EXISTS
  FOR (a:Area) ON (a.branch_id);

CREATE INDEX concept_name IF NOT EXISTS
  FOR (c:Concept) ON (c.name);

CREATE INDEX skill_category IF NOT EXISTS
  FOR (s:Skill) ON (s.category);

CREATE INDEX resource_type IF NOT EXISTS
  FOR (r:Resource) ON (r.resource_type);

// ===== VERIFICATION =====
// After running: SHOW CONSTRAINTS; SHOW INDEXES;
