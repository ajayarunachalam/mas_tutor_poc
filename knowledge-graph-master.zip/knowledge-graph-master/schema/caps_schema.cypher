// CAPS Schema Extensions for Neo4j
// Adds CAPS-specific node types alongside existing Cambridge International graph
// Safe to re-run — all constraints use IF NOT EXISTS
// Run before caps_ingest.cypher

// ─── Constraints ────────────────────────────────────────────────────────────
CREATE CONSTRAINT caps_qual_id IF NOT EXISTS
  FOR (q:CAPSQualification) REQUIRE q.id IS UNIQUE;

CREATE CONSTRAINT caps_topic_id IF NOT EXISTS
  FOR (t:CAPSTopic) REQUIRE t.id IS UNIQUE;

CREATE CONSTRAINT caps_lo_id IF NOT EXISTS
  FOR (lo:CAPSLearningObjective) REQUIRE lo.id IS UNIQUE;

// ─── Indexes ─────────────────────────────────────────────────────────────────
CREATE INDEX caps_topic_paper IF NOT EXISTS FOR (t:CAPSTopic) ON (t.paper);
CREATE INDEX caps_topic_grade IF NOT EXISTS FOR (t:CAPSTopic) ON (t.grade);
CREATE INDEX caps_lo_topic IF NOT EXISTS FOR (lo:CAPSLearningObjective) ON (lo.topic_id);
