#!/usr/bin/env python3
"""
Ingest product-agnostic domain seed data into Neo4j.

Reads seed/domains/*.yaml and writes:
  :Domain nodes
  :Branch nodes + [:HAS_BRANCH] edges
  :Area nodes   + [:HAS_AREA] edges
  :Concept nodes + [:HAS_CONCEPT] edges (seed concepts only)

All operations use MERGE — safe to re-run (idempotent).

Usage:
    uv run python ingest/seed_agnostic.py [--domain mathematics] [--dry-run]
"""
from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

import yaml

PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from cambridge_kg.driver import kg_session, health_check

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)

SEED_DIR = PROJECT_ROOT / "seed" / "domains"


def load_domain_file(path: Path) -> dict:
    with open(path) as f:
        return yaml.safe_load(f)


def ingest_domain(data: dict, dry_run: bool = False) -> dict:
    """Ingest one domain file. Returns stats dict."""
    domain = data["domain"]
    stats = {"domains": 0, "branches": 0, "areas": 0, "concepts": 0,
             "has_branch": 0, "has_area": 0, "has_concept": 0}

    if dry_run:
        logger.info("[DRY RUN] Would ingest domain: %s", domain["name"])
        for branch in domain.get("branches", []):
            logger.info("  Branch: %s", branch["name"])
            for area in branch.get("areas", []):
                concepts = area.get("seed_concepts", [])
                logger.info("    Area: %s (%d seed concepts)", area["name"], len(concepts))
        return stats

    with kg_session() as session:
        # Domain node
        session.run("""
            MERGE (d:Domain {id: $id})
            SET d.name        = $name,
                d.type        = $type,
                d.description = $description
        """, id=domain["id"], name=domain["name"],
             type=domain.get("type", "subject"),
             description=domain.get("description", ""))
        stats["domains"] += 1

        for branch in domain.get("branches", []):
            # Branch node
            session.run("""
                MERGE (b:Branch {id: $id})
                SET b.name        = $name,
                    b.domain_id   = $domain_id,
                    b.description = $description
            """, id=branch["id"], name=branch["name"],
                 domain_id=domain["id"],
                 description=branch.get("description", ""))
            stats["branches"] += 1

            # HAS_BRANCH edge
            session.run("""
                MATCH (d:Domain {id: $domain_id})
                MATCH (b:Branch {id: $branch_id})
                MERGE (d)-[:HAS_BRANCH]->(b)
            """, domain_id=domain["id"], branch_id=branch["id"])
            stats["has_branch"] += 1

            for area in branch.get("areas", []):
                # Area node
                session.run("""
                    MERGE (a:Area {id: $id})
                    SET a.name            = $name,
                        a.branch_id       = $branch_id,
                        a.description     = $description,
                        a.poc_math_domain = $poc_math_domain
                """, id=area["id"], name=area["name"],
                     branch_id=branch["id"],
                     description=area.get("description", ""),
                     poc_math_domain=area.get("poc_math_domain"))
                stats["areas"] += 1

                # HAS_AREA edge
                session.run("""
                    MATCH (b:Branch {id: $branch_id})
                    MATCH (a:Area {id: $area_id})
                    MERGE (b)-[:HAS_AREA]->(a)
                """, branch_id=branch["id"], area_id=area["id"])
                stats["has_area"] += 1

                # Seed concepts
                for concept in area.get("seed_concepts", []):
                    session.run("""
                        MERGE (c:Concept {id: $id})
                        SET c.name        = $name,
                            c.description = $description
                    """, id=concept["id"], name=concept["name"],
                         description=concept.get("description", ""))
                    stats["concepts"] += 1

                    # HAS_CONCEPT edge
                    session.run("""
                        MATCH (a:Area {id: $area_id})
                        MATCH (c:Concept {id: $concept_id})
                        MERGE (a)-[:HAS_CONCEPT]->(c)
                    """, area_id=area["id"], concept_id=concept["id"])
                    stats["has_concept"] += 1

    return stats


def main() -> None:
    parser = argparse.ArgumentParser(description="Ingest product-agnostic domain seed data")
    parser.add_argument("--domain", help="Specific domain file name (without .yaml)")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    if not health_check():
        logger.error("Neo4j not reachable.")
        sys.exit(1)

    if args.domain:
        files = [SEED_DIR / f"{args.domain}.yaml"]
    else:
        files = sorted(SEED_DIR.glob("*.yaml"))

    if not files:
        logger.error("No domain YAML files found in %s", SEED_DIR)
        sys.exit(1)

    total = {"domains": 0, "branches": 0, "areas": 0, "concepts": 0,
             "has_branch": 0, "has_area": 0, "has_concept": 0}

    for path in files:
        logger.info("Processing %s...", path.name)
        data = load_domain_file(path)
        stats = ingest_domain(data, dry_run=args.dry_run)
        for k in total:
            total[k] += stats[k]

    if not args.dry_run:
        print("\n=== Agnostic Layer Ingestion Complete ===")
        print(f"  Domain nodes:      {total['domains']}")
        print(f"  Branch nodes:      {total['branches']}")
        print(f"  Area nodes:        {total['areas']}")
        print(f"  Concept nodes:     {total['concepts']}")
        print(f"  HAS_BRANCH edges:  {total['has_branch']}")
        print(f"  HAS_AREA edges:    {total['has_area']}")
        print(f"  HAS_CONCEPT edges: {total['has_concept']}")


if __name__ == "__main__":
    main()
