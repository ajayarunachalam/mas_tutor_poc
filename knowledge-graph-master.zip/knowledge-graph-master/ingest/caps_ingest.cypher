// CAPS Grade 12 Mathematics — Neo4j Ingest Script
// Idempotent — safe to re-run (uses MERGE throughout)
// Each statement is self-contained; no WITH-chaining across semicolons
// Run AFTER: schema/caps_schema.cypher

// ═══════════════════════════════════════════════════════════════════
// 1. CAPS Qualification node
// ═══════════════════════════════════════════════════════════════════
MERGE (q:CAPSQualification {id: 'CAPS-MTH-GR12'})
SET q.name = 'CAPS Grade 12 Mathematics',
    q.curriculum = 'CAPS',
    q.country = 'ZA',
    q.grade = 12,
    q.syllabus_year = 2026,
    q.awarding_body = 'Department of Basic Education (DBE)',
    q.papers = ['P1', 'P2'];

// ═══════════════════════════════════════════════════════════════════
// 2. CAPS Topic nodes — Paper 1
// ═══════════════════════════════════════════════════════════════════
MERGE (t:CAPSTopic {id: 'caps-mth-gr12-f-g'})
SET t.name = 'Functions and Graphs', t.paper = 'P1', t.nsc_marks = 35,
    t.terms = ['T1'], t.order = 1, t.curriculum = 'CAPS', t.grade = 12;

MERGE (t:CAPSTopic {id: 'caps-mth-gr12-n-p'})
SET t.name = 'Number Patterns (Sequences and Series)', t.paper = 'P1', t.nsc_marks = 25,
    t.terms = ['T1'], t.order = 2, t.curriculum = 'CAPS', t.grade = 12;

MERGE (t:CAPSTopic {id: 'caps-mth-gr12-fin'})
SET t.name = 'Finance, Growth and Decay', t.paper = 'P1', t.nsc_marks = 15,
    t.terms = ['T1', 'T2'], t.order = 3, t.curriculum = 'CAPS', t.grade = 12;

MERGE (t:CAPSTopic {id: 'caps-mth-gr12-alg'})
SET t.name = 'Algebra, Equations and Inequalities', t.paper = 'P1', t.nsc_marks = 25,
    t.terms = ['T1', 'T2'], t.order = 4, t.curriculum = 'CAPS', t.grade = 12;

MERGE (t:CAPSTopic {id: 'caps-mth-gr12-calc'})
SET t.name = 'Differential Calculus', t.paper = 'P1', t.nsc_marks = 35,
    t.terms = ['T2', 'T3'], t.order = 5, t.curriculum = 'CAPS', t.grade = 12;

MERGE (t:CAPSTopic {id: 'caps-mth-gr12-prob'})
SET t.name = 'Probability', t.paper = 'P1', t.nsc_marks = 15,
    t.terms = ['T3', 'T4'], t.order = 6, t.curriculum = 'CAPS', t.grade = 12;

// ═══════════════════════════════════════════════════════════════════
// 3. CAPS Topic nodes — Paper 2
// ═══════════════════════════════════════════════════════════════════
MERGE (t:CAPSTopic {id: 'caps-mth-gr12-stat'})
SET t.name = 'Statistics', t.paper = 'P2', t.nsc_marks = 20,
    t.terms = ['T1'], t.order = 7, t.curriculum = 'CAPS', t.grade = 12;

MERGE (t:CAPSTopic {id: 'caps-mth-gr12-ag'})
SET t.name = 'Analytical Geometry', t.paper = 'P2', t.nsc_marks = 40,
    t.terms = ['T1', 'T2'], t.order = 8, t.curriculum = 'CAPS', t.grade = 12;

MERGE (t:CAPSTopic {id: 'caps-mth-gr12-trig'})
SET t.name = 'Trigonometry', t.paper = 'P2', t.nsc_marks = 50,
    t.terms = ['T2', 'T3'], t.order = 9, t.curriculum = 'CAPS', t.grade = 12;

MERGE (t:CAPSTopic {id: 'caps-mth-gr12-eg'})
SET t.name = 'Euclidean Geometry and Measurement', t.paper = 'P2', t.nsc_marks = 40,
    t.terms = ['T3', 'T4'], t.order = 10, t.curriculum = 'CAPS', t.grade = 12;

// ═══════════════════════════════════════════════════════════════════
// 4. HAS_TOPIC relationships (batch — all in one statement)
// ═══════════════════════════════════════════════════════════════════
MATCH (q:CAPSQualification {id: 'CAPS-MTH-GR12'})
MATCH (t:CAPSTopic) WHERE t.curriculum = 'CAPS' AND t.grade = 12
MERGE (q)-[:HAS_TOPIC]->(t);

// ═══════════════════════════════════════════════════════════════════
// 5. CAPS Learning Objective nodes
// ═══════════════════════════════════════════════════════════════════
MERGE (lo:CAPSLearningObjective {id: 'caps-lo-fg-003'})
SET lo.text = 'Derive and sketch the inverse of a function and determine whether the inverse is itself a function',
    lo.bloom_level = 'analyse', lo.difficulty = 4, lo.topic_id = 'caps-mth-gr12-f-g';

MERGE (lo:CAPSLearningObjective {id: 'caps-lo-fg-004'})
SET lo.text = 'Sketch and interpret logarithmic functions as inverses of exponential functions',
    lo.bloom_level = 'apply', lo.difficulty = 3, lo.topic_id = 'caps-mth-gr12-f-g';

MERGE (lo:CAPSLearningObjective {id: 'caps-lo-calc-001'})
SET lo.text = 'Determine the derivative of f(x) from first principles using the limit definition',
    lo.bloom_level = 'understand', lo.difficulty = 4, lo.topic_id = 'caps-mth-gr12-calc';

MERGE (lo:CAPSLearningObjective {id: 'caps-lo-calc-007'})
SET lo.text = 'Solve practical optimisation problems by setting f-prime(x) = 0 and interpreting the result',
    lo.bloom_level = 'evaluate', lo.difficulty = 5, lo.topic_id = 'caps-mth-gr12-calc';

MERGE (lo:CAPSLearningObjective {id: 'caps-lo-trig-007'})
SET lo.text = 'Solve 2D and 3D trigonometry problems using sine rule, cosine rule and area formula',
    lo.bloom_level = 'evaluate', lo.difficulty = 5, lo.topic_id = 'caps-mth-gr12-trig';

// ═══════════════════════════════════════════════════════════════════
// 6. HAS_LO relationships
// ═══════════════════════════════════════════════════════════════════
MATCH (t:CAPSTopic) MATCH (lo:CAPSLearningObjective) WHERE lo.topic_id = t.id
MERGE (t)-[:HAS_LO]->(lo);

// ═══════════════════════════════════════════════════════════════════
// 7. RELATED_TO cross-links to Cambridge International KG
//    Uses OPTIONAL MATCH so no error if Cambridge concept missing
// ═══════════════════════════════════════════════════════════════════
OPTIONAL MATCH (camb:Concept {name: 'Functions'})
WITH camb WHERE camb IS NOT NULL
MATCH (caps:CAPSTopic {id: 'caps-mth-gr12-f-g'})
MERGE (caps)-[:RELATED_TO {note: 'CAPS P1 equivalent'}]->(camb);

OPTIONAL MATCH (camb:Concept {name: 'Differentiation'})
WITH camb WHERE camb IS NOT NULL
MATCH (caps:CAPSTopic {id: 'caps-mth-gr12-calc'})
MERGE (caps)-[:RELATED_TO {note: 'CAPS P1 equivalent'}]->(camb);

OPTIONAL MATCH (camb:Concept {name: 'Trigonometry'})
WITH camb WHERE camb IS NOT NULL
MATCH (caps:CAPSTopic {id: 'caps-mth-gr12-trig'})
MERGE (caps)-[:RELATED_TO {note: 'CAPS P2 equivalent'}]->(camb);

OPTIONAL MATCH (camb:Concept {name: 'Statistics'})
WITH camb WHERE camb IS NOT NULL
MATCH (caps:CAPSTopic {id: 'caps-mth-gr12-stat'})
MERGE (caps)-[:RELATED_TO {note: 'CAPS P2 equivalent'}]->(camb);

OPTIONAL MATCH (camb:Concept {name: 'Probability'})
WITH camb WHERE camb IS NOT NULL
MATCH (caps:CAPSTopic {id: 'caps-mth-gr12-prob'})
MERGE (caps)-[:RELATED_TO {note: 'CAPS P1 equivalent'}]->(camb);
