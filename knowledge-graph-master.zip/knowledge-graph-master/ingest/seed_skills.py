#!/usr/bin/env python3
"""
Ingest P21 / 4Cs skills framework into Neo4j.

Reads seed/skills/p21_4cs.yaml and writes:
  :CapabilityDomain nodes
  :Skill nodes + [:HAS_SKILL] edges

All operations use MERGE — idempotent.

Usage:
    uv run python ingest/seed_skills.py [--dry-run]
"""
from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

import yaml

PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from cambridge_kg.driver import kg_session, health_check

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)

SKILLS_PATH = PROJECT_ROOT / "seed" / "skills" / "p21_4cs.yaml"


def ingest_skills(dry_run: bool = False) -> dict:
    stats = {"capability_domains": 0, "skills": 0, "has_skill": 0}

    data = yaml.safe_load(SKILLS_PATH.read_text())

    if dry_run:
        for cd in data.get("capability_domains", []):
            skills = cd.get("skills", [])
            logger.info("[DRY RUN] CapabilityDomain: %s (%d skills)", cd["name"], len(skills))
        return stats

    with kg_session() as session:
        for cd in data.get("capability_domains", []):
            session.run("""
                MERGE (cd:CapabilityDomain {id: $id})
                SET cd.name        = $name,
                    cd.framework   = $framework,
                    cd.description = $description
            """, id=cd["id"], name=cd["name"],
                 framework=cd.get("framework", "P21"),
                 description=cd.get("description", ""))
            stats["capability_domains"] += 1

            for skill in cd.get("skills", []):
                session.run("""
                    MERGE (s:Skill {id: $id})
                    SET s.name        = $name,
                        s.description = $description,
                        s.category    = $category,
                        s.framework   = $framework
                """, id=skill["id"], name=skill["name"],
                     description=skill.get("description", ""),
                     category=skill.get("category", ""),
                     framework=cd.get("framework", "P21"))
                stats["skills"] += 1

                session.run("""
                    MATCH (cd:CapabilityDomain {id: $cd_id})
                    MATCH (s:Skill {id: $skill_id})
                    MERGE (cd)-[:HAS_SKILL]->(s)
                """, cd_id=cd["id"], skill_id=skill["id"])
                stats["has_skill"] += 1

    return stats


def main() -> None:
    parser = argparse.ArgumentParser(description="Ingest P21 4Cs skills data")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    if not health_check():
        logger.error("Neo4j not reachable.")
        sys.exit(1)

    logger.info("Ingesting P21 4Cs from %s", SKILLS_PATH)
    stats = ingest_skills(dry_run=args.dry_run)

    if not args.dry_run:
        print("\n=== P21 Skills Ingestion Complete ===")
        print(f"  CapabilityDomain nodes: {stats['capability_domains']}")
        print(f"  Skill nodes:            {stats['skills']}")
        print(f"  HAS_SKILL edges:        {stats['has_skill']}")


if __name__ == "__main__":
    main()
