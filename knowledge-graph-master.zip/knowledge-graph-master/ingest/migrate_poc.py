#!/usr/bin/env python3
"""
MAS Education POC → Knowledge Graph Migration.

One-time migration script to align the existing POC Neo4j data with the
knowledge-graph schema. Safe to re-run (idempotent — uses MERGE/SET where NULL).

Steps performed:
  1. Connect POC Concept nodes to Area nodes via HAS_CONCEPT (using MathDomain bridge)
  2. Add syllabus_year and revision properties to Qualification nodes (backfill)
  3. Drop old qualification_code unique constraint
  4. Add composite (code, syllabus_year, revision) unique constraint
  5. Add resource_type property to Resource nodes (backfill 'reference')
  6. Add context property to HAS_RESOURCE edges (backfill 'reference')
  7. Remove MathDomain nodes (superseded by Area nodes)

Usage:
    uv run python ingest/migrate_poc.py [--dry-run] [--skip-delete-mathdomains]
"""
from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from cambridge_kg.driver import kg_session, health_check

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)


def step1_connect_concepts_to_areas(dry_run: bool) -> int:
    """
    For each Concept with a BELONGS_TO MathDomain edge, find the corresponding
    Area node (matched via poc_math_domain property) and create HAS_CONCEPT edge.
    Returns count of edges created.
    """
    cypher_count = """
        MATCH (c:Concept)-[:BELONGS_TO]->(d:MathDomain)
        MATCH (a:Area {poc_math_domain: d.name})
        WHERE NOT (a)-[:HAS_CONCEPT]->(c)
        RETURN count(c) AS n
    """
    cypher_merge = """
        MATCH (c:Concept)-[:BELONGS_TO]->(d:MathDomain)
        MATCH (a:Area {poc_math_domain: d.name})
        MERGE (a)-[:HAS_CONCEPT]->(c)
        RETURN count(*) AS created
    """
    with kg_session() as session:
        n = session.run(cypher_count).single()["n"]
        logger.info("Step 1: %d Concepts need HAS_CONCEPT edges to Areas", n)
        if dry_run or n == 0:
            return n
        result = session.run(cypher_merge)
        created = result.single()["created"]
        logger.info("Step 1: created %d HAS_CONCEPT edges", created)
        return created


def step2_backfill_qualifications(dry_run: bool, syllabus_year: int = 2024) -> int:
    """Add syllabus_year and revision to Qualification nodes that lack them."""
    cypher_count = """
        MATCH (q:Qualification) WHERE q.syllabus_year IS NULL RETURN count(q) AS n
    """
    cypher_set = """
        MATCH (q:Qualification) WHERE q.syllabus_year IS NULL
        SET q.syllabus_year = $year, q.revision = 0
        RETURN count(q) AS updated
    """
    with kg_session() as session:
        n = session.run(cypher_count).single()["n"]
        logger.info("Step 2: %d Qualifications need syllabus_year backfill", n)
        if dry_run or n == 0:
            return n
        updated = session.run(cypher_set, year=syllabus_year).single()["updated"]
        logger.info("Step 2: set syllabus_year=%d, revision=0 on %d Qualifications", syllabus_year, updated)
        return updated


def step3_update_qualification_constraint(dry_run: bool) -> None:
    """
    Drop the old per-code unique constraint and add composite (code, year, revision).
    Skips gracefully if old constraint doesn't exist or new one already exists.
    """
    if dry_run:
        logger.info("Step 3: [DRY RUN] would update Qualification constraint")
        return

    with kg_session() as session:
        # Drop old constraint
        try:
            session.run("DROP CONSTRAINT qualification_code IF EXISTS")
            logger.info("Step 3: dropped qualification_code constraint")
        except Exception as exc:
            logger.warning("Step 3: could not drop qualification_code: %s", exc)

        # Add composite unique constraint
        try:
            session.run("""
                CREATE CONSTRAINT qualification_version IF NOT EXISTS
                  FOR (q:Qualification)
                  REQUIRE (q.code, q.syllabus_year, q.revision) IS UNIQUE
            """)
            logger.info("Step 3: created qualification_version composite constraint")
        except Exception as exc:
            logger.warning("Step 3: could not create qualification_version: %s", exc)


def step4_backfill_resources(dry_run: bool) -> dict:
    """Add resource_type to Resource nodes and context to HAS_RESOURCE edges."""
    counts = {"resources": 0, "edges": 0}

    cypher_resources = """
        MATCH (r:Resource) WHERE r.resource_type IS NULL
        SET r.resource_type = 'reference'
        RETURN count(r) AS n
    """
    cypher_edges = """
        MATCH ()-[rel:HAS_RESOURCE]->() WHERE rel.context IS NULL
        SET rel.context = 'reference'
        RETURN count(rel) AS n
    """
    if dry_run:
        with kg_session() as session:
            nr = session.run("MATCH (r:Resource) WHERE r.resource_type IS NULL RETURN count(r) AS n").single()["n"]
            ne = session.run("MATCH ()-[rel:HAS_RESOURCE]->() WHERE rel.context IS NULL RETURN count(rel) AS n").single()["n"]
        logger.info("Step 4: [DRY RUN] %d Resources + %d edges need backfill", nr, ne)
        return counts

    with kg_session() as session:
        counts["resources"] = session.run(cypher_resources).single()["n"]
        counts["edges"] = session.run(cypher_edges).single()["n"]
    logger.info("Step 4: backfilled %d Resource nodes + %d HAS_RESOURCE edges", counts["resources"], counts["edges"])
    return counts


def step5_remove_mathdomains(dry_run: bool) -> int:
    """Remove MathDomain nodes (superseded by Area nodes)."""
    cypher_count = "MATCH (d:MathDomain) RETURN count(d) AS n"
    cypher_delete = "MATCH (d:MathDomain) DETACH DELETE d RETURN count(d) AS n"

    with kg_session() as session:
        n = session.run(cypher_count).single()["n"]
        logger.info("Step 5: %d MathDomain nodes to remove", n)
        if dry_run or n == 0:
            return n
        session.run(cypher_delete)
        logger.info("Step 5: MathDomain nodes removed")
        return n


def verify_migration() -> dict:
    """Post-migration verification. Returns counts for reporting."""
    cypher = """
        MATCH (a:Area)-[:HAS_CONCEPT]->(c:Concept) RETURN count(DISTINCT c) AS concepts_with_area
        UNION ALL
        MATCH (c:Concept) RETURN count(c) AS concepts_with_area
        UNION ALL
        MATCH (q:Qualification) WHERE q.syllabus_year IS NOT NULL RETURN count(q) AS concepts_with_area
        UNION ALL
        MATCH (d:MathDomain) RETURN count(d) AS concepts_with_area
    """
    counts = {}
    with kg_session() as session:
        concepts_linked = session.run(
            "MATCH (a:Area)-[:HAS_CONCEPT]->(c:Concept) RETURN count(DISTINCT c) AS n"
        ).single()["n"]
        concepts_total = session.run("MATCH (c:Concept) RETURN count(c) AS n").single()["n"]
        quals_with_year = session.run(
            "MATCH (q:Qualification) WHERE q.syllabus_year IS NOT NULL RETURN count(q) AS n"
        ).single()["n"]
        mathdomain_remaining = session.run("MATCH (d:MathDomain) RETURN count(d) AS n").single()["n"]

        # Check constraint
        constraint_names = [r["name"] for r in session.run("SHOW CONSTRAINTS")]

    counts = {
        "concepts_linked_to_area": concepts_linked,
        "concepts_total": concepts_total,
        "qualifications_with_year": quals_with_year,
        "mathdomains_remaining": mathdomain_remaining,
        "qualification_version_constraint": "qualification_version" in constraint_names,
    }
    return counts


def main() -> None:
    parser = argparse.ArgumentParser(description="Migrate MAS Education POC to knowledge-graph schema")
    parser.add_argument("--dry-run", action="store_true", help="Report changes without applying them")
    parser.add_argument("--skip-delete-mathdomains", action="store_true",
                        help="Keep MathDomain nodes (useful for debugging)")
    parser.add_argument("--syllabus-year", type=int, default=2024,
                        help="Year to backfill on existing Qualifications (default: 2024)")
    args = parser.parse_args()

    if not health_check():
        logger.error("Neo4j not reachable. Is the container running?")
        sys.exit(1)

    logger.info("=== POC Migration %s===", "[DRY RUN] " if args.dry_run else "")

    step1_connect_concepts_to_areas(args.dry_run)
    step2_backfill_qualifications(args.dry_run, args.syllabus_year)
    step3_update_qualification_constraint(args.dry_run)
    step4_backfill_resources(args.dry_run)

    if not args.skip_delete_mathdomains:
        step5_remove_mathdomains(args.dry_run)
    else:
        logger.info("Step 5: skipped (--skip-delete-mathdomains)")

    if not args.dry_run:
        print("\n=== Migration Verification ===")
        counts = verify_migration()
        print(f"  Concepts linked to Area:       {counts['concepts_linked_to_area']} / {counts['concepts_total']}")
        print(f"  Qualifications with year:      {counts['qualifications_with_year']}")
        print(f"  MathDomain nodes remaining:    {counts['mathdomains_remaining']}")
        print(f"  qualification_version constraint: {'YES' if counts['qualification_version_constraint'] else 'NO'}")

        if counts["concepts_linked_to_area"] < counts["concepts_total"]:
            logger.warning(
                "%d Concepts have no Area link — check for missing poc_math_domain mappings",
                counts["concepts_total"] - counts["concepts_linked_to_area"]
            )
        else:
            logger.info("All Concepts are linked to an Area.")


if __name__ == "__main__":
    main()
