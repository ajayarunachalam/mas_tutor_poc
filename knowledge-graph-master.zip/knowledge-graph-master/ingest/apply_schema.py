#!/usr/bin/env python3
"""
Apply knowledge-graph schema to Neo4j.

Reads schema/schema.cypher and executes each statement.
Safe to re-run — all statements use IF NOT EXISTS guards.

Usage:
    uv run python ingest/apply_schema.py
"""
from __future__ import annotations

import logging
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from cambridge_kg.driver import kg_session, health_check

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)

SCHEMA_PATH = PROJECT_ROOT / "schema" / "schema.cypher"


def apply_schema() -> int:
    """Apply all schema statements. Returns count of statements executed."""
    if not SCHEMA_PATH.exists():
        raise FileNotFoundError(f"Schema file not found: {SCHEMA_PATH}")

    cypher_text = SCHEMA_PATH.read_text()
    # Strip comment lines before splitting on semicolons
    lines = [
        line for line in cypher_text.splitlines()
        if not line.strip().startswith("//")
    ]
    clean_text = "\n".join(lines)
    statements = [
        stmt.strip()
        for stmt in clean_text.split(";")
        if stmt.strip()
    ]

    executed = 0
    with kg_session() as session:
        for stmt in statements:
            if stmt:
                try:
                    session.run(stmt)
                    logger.info("OK: %.80s...", stmt.replace("\n", " "))
                    executed += 1
                except Exception as exc:
                    logger.warning("Skipped (%s): %.80s", exc, stmt.replace("\n", " "))

    return executed


def main() -> None:
    if not health_check():
        logger.error("Neo4j not reachable. Is the container running?")
        sys.exit(1)

    logger.info("Applying schema from %s", SCHEMA_PATH)
    count = apply_schema()
    logger.info("Schema applied: %d statements processed.", count)

    # Verify key constraints exist
    with kg_session() as session:
        result = session.run("SHOW CONSTRAINTS")
        constraints = [record["name"] for record in result]
    logger.info("Active constraints: %s", constraints)


if __name__ == "__main__":
    main()
