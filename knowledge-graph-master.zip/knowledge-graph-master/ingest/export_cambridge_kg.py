from neo4j import GraphDatabase

URI  = "bolt://localhost:7687"
AUTH = ("neo4j", "mas_education_poc_dev")

def cambridge_predicate(var):
    return (
        f"({var}:Domain OR {var}:Branch OR {var}:Area OR {var}:Concept "
        f"OR {var}:Subtopic OR {var}:Skill OR {var}:CapabilityDomain "
        f"OR ({var}:Qualification AND NOT {var}.code STARTS WITH 'CAPS') "
        f"OR ({var}:Topic AND NOT {var}.qualification_code STARTS WITH 'CAPS') "
        f"OR ({var}:ConceptInstance AND NOT {var}.qualification_code STARTS WITH 'CAPS') "
        f"OR ({var}:LearningObjective AND NOT {var}.qualification_code STARTS WITH 'CAPS'))"
    )

EXPORT_Q = f"""
CALL apoc.export.cypher.query(
  "MATCH (n) WHERE {cambridge_predicate('n')}
   OPTIONAL MATCH (n)-[r]->(m) WHERE {cambridge_predicate('m')}
   RETURN n, r, m",
  null,
  {{stream: true, format: "cypher-shell"}}
) YIELD cypherStatements RETURN cypherStatements
"""

driver = GraphDatabase.driver(URI, auth=AUTH)
out = []
with driver.session() as s:
    for rec in s.run(EXPORT_Q):
        chunk = rec["cypherStatements"]
        if chunk:
            out.append(chunk)
driver.close()

with open("/home/tonyts/cambridge_kg_export.cypher", "w") as f:
    f.write("".join(out))

lines = sum(1 for _ in open("/home/tonyts/cambridge_kg_export.cypher"))
size  = len(open("/home/tonyts/cambridge_kg_export.cypher").read())
print(f"Done. Lines: {lines} | Size: {size/1024/1024:.1f} MB")
