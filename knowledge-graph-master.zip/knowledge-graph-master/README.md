# Cambridge Knowledge Graph

Canonical Neo4j schema and product-agnostic knowledge ontology for Cambridge University Press & Assessment. This repo is the shared infrastructure consumed by all Cambridge KG repositories.

## Architecture

```
Product-Agnostic Layer (this repo owns)        Product-Specific Layer (per qualification)
─────────────────────────────────────────      ─────────────────────────────────────────
Domain → Branch → Area → Concept               Qualification → Topic → Subtopic → LO
                                 ↑                                              ↓
                         ConceptInstance ←──────────────────────────── TEACHES
                         INSTANCE_OF ↓
                              Concept
```

Additional: P21/4Cs skills graph (`CapabilityDomain → Skill`), linked to LOs via `DEVELOPS_SKILL`.

## Repository Structure

```
knowledge-graph/
├── schema/schema.cypher        # Neo4j constraints and indexes
├── seed/
│   ├── domains/                # Domain YAML files (one per subject domain)
│   └── skills/p21_4cs.yaml    # P21 4Cs framework
├── db/
│   ├── driver.py               # Shared Neo4j driver (importable by other repos)
│   ├── agnostic_queries.py     # Product-agnostic traversal helpers
│   └── learner_queries.py      # Derived learner mastery on agnostic layer
├── ingest/
│   ├── apply_schema.py         # Apply schema.cypher to Neo4j
│   ├── seed_agnostic.py        # Ingest domain/branch/area/concept seed data
│   └── seed_skills.py          # Ingest P21 4Cs
├── docker/docker-compose.yml   # Standalone Neo4j instance
└── tests/test_schema.py        # Phase 1 verification tests
```

## Setup

### Prerequisites
- Neo4j 5.x running (either standalone via docker/ or shared POC instance)
- Python 3.11+, uv

### Install
```bash
cd knowledge-graph
cp .env.example .env    # edit with Neo4j credentials
uv sync
```

### Phase 1: Apply schema and ingest seed data
```bash
uv run python ingest/apply_schema.py
uv run python ingest/seed_agnostic.py
uv run python ingest/seed_skills.py
uv run pytest tests/test_schema.py -v
```

### Start standalone Neo4j (if not using POC instance)
```bash
docker compose -f docker/docker-compose.yml up -d
```

## Using the shared driver in other repos

```bash
pip install -e /path/to/knowledge-graph
```

```python
from db.driver import kg_session, health_check
from db.agnostic_queries import get_domain_tree
from db.learner_queries import get_learner_domain_position

tree = get_domain_tree("math")
position = get_learner_domain_position("learner-123", "math")
```

## Current State (as of 2026-03-08)

| Layer | Status | Count |
|---|---|---|
| Schema | Applied | 5 constraints, 7 indexes |
| Product-agnostic ontology | Seeded (all 12 domains) | 12 Domains, 39 Branches, 123 Areas, 483 Concepts |
| P21 skills | Seeded | 4 CapabilityDomains, 17 Skills |
| Qualifications (product-specific) | Partially complete | 102 of 138 downloaded PDFs processed |
| ConceptInstances (bridge layer) | Active | 3,156 across 91 qualifications |
| LearningObjectives | Active | 8,222 across 102 qualifications |

### Syllabus Pipeline Coverage

Cambridge International syllabuses are ingested via the
[syllabus-pipeline](https://github.com/tgs21/syllabus-pipeline) repo.
138 PDFs were downloaded; 102 qualifications have been fully processed.

**36 qualifications are pending** (Anthropic API credits exhausted during batch run).
See the [syllabus-pipeline README](https://github.com/tgs21/syllabus-pipeline#missing-qualifications--api-credit-exhaustion)
for the full list and resume instructions.

### Product-Agnostic Constraint

The Domain/Branch/Area/Concept hierarchy is **additive only** — no nodes are ever deleted
during syllabus ingestion. The 483 Concepts cover all curriculum content mapped to date.

## Visualising the Graph (Neo4j Browser)

Open **http://localhost:7474** and log in with your Neo4j credentials.

The results panel defaults to a table view — click the **graph icon** on the left edge of
the results panel to switch to the force-directed graph view. Scroll to zoom, drag to
rearrange, click a node to inspect its properties, double-click to expand its relationships.

To colour nodes by label, click the **paintbrush icon** in the top-right of the graph panel
and assign colours/sizes per label.

### Starter Queries

**Product-agnostic ontology — all 12 domains**
```cypher
MATCH p=(d:Domain)-[:HAS_BRANCH]->(b)-[:HAS_AREA]->(a)-[:HAS_CONCEPT]->(c)
RETURN p LIMIT 200
```

**Explore interactively — start with domain nodes, then double-click to expand**
```cypher
MATCH (d:Domain) RETURN d
```

**One qualification's full topic structure**
```cypher
MATCH p=(q:Qualification {code: '0610'})-[:HAS_TOPIC|HAS_SUBTOPIC|HAS_LO*1..3]->(n)
RETURN p
```

**ConceptInstance bridge — how LOs link to Concepts**
```cypher
MATCH p=(lo:LearningObjective)-[:TEACHES]->(ci:ConceptInstance)-[:INSTANCE_OF]->(c:Concept)
RETURN p LIMIT 100
```

**DEEPENS spiral chains across qualifications**
```cypher
MATCH p=(ci1:ConceptInstance)-[:DEEPENS*1..5]->(ci2:ConceptInstance)
RETURN p LIMIT 50
```

**Cross-layer view — one concept and everything that teaches it**
```cypher
MATCH p=(q:Qualification)-[:HAS_TOPIC|HAS_SUBTOPIC|HAS_LO*1..3]->(lo:LearningObjective)
        -[:TEACHES]->(ci:ConceptInstance)-[:INSTANCE_OF]->(c:Concept {name: 'Differentiation'})
RETURN p
```

**Node counts at a glance**
```cypher
MATCH (n) RETURN labels(n)[0] AS label, count(n) AS count
ORDER BY count DESC
```

### Tips

- The **product-agnostic ontology** (Domain → Branch → Area → Concept) is the stable
  backbone — good starting point for any exploration.
- The **bridge layer** (ConceptInstance nodes with TEACHES/INSTANCE_OF/DEEPENS edges)
  connects the per-qualification structure to the ontology.
- Limit to `LIMIT 200` or fewer for readable graphs; the full graph has 10,000+ nodes.
- Save useful queries with the **star icon** next to the query bar.

## Phase Roadmap

| Phase | Description | Status |
|---|---|---|
| 1 | Schema + Mathematics domain seed + P21 4Cs | ✅ Done |
| 2 | Migrate mas_education_poc to import from this repo | ✅ Done |
| 3 | syllabus-pipeline: PDF → product-specific graph | ✅ Done |
| 4 | syllabus-pipeline: product-agnostic concept extraction | ✅ Done |
| 5 | Dashboard Knowledge Map tab | ✅ Done |
| 6 | All 12 domains seeded + 80+ syllabus batch run | ✅ Done (102/138 processed) |
| 7 | Remaining 36 qualifications (pending API credits) | ⏳ Pending |
